# Manuscript Table Provenance

This file maps each revised manuscript table to the code and compact reference
outputs that support it. It is a navigation aid, not an alternate statistical
specification. The runner and aggregator source code remains authoritative.

| Manuscript table | Content | Primary code | Reference outputs |
|---|---|---|---|
| Table I | Strict semantic OOD split counts | `code/data_adapter.py` | `configs/cache_manifests/ptbxl_labels.json` |
| Table II | Task-specific scores and decision rules | `code/revisionlib.py`, `code/run_ptbxl_revision.py`, `code/evaluate_modular_pipeline.py` | `reference_outputs/aggregates/modular_pipeline/summary.json` |
| Table III | Five-seed PTB-XL diagnosis and calibration | `code/run_ptbxl_revision.py`, `code/aggregate_results.py` | `reference_outputs/aggregates/ptbxl/seed_summary.csv`, `calibration_summary.csv`, `selective_summary.csv` |
| Table IV | Rare-class threshold sensitivity | `code/postprocess_promised_metrics.py` | `reference_outputs/aggregates/promised_postprocess/rare_seed_summary.csv`, `reference_outputs/manuscript_tables/Supplementary_Class_Distributions.csv` |
| Table V | Pool, Fuse, concatenation, TMC, and TMDF/ETMC controls | `code/run_ptbxl_revision.py`, `code/aggregate_results.py` | `reference_outputs/aggregates/ptbxl/seed_summary.csv`, `paired_seed_comparisons.csv` |
| Table VI | Strict and cross-dataset OOD detection | `code/run_ptbxl_revision.py`, `code/aggregate_results.py`, `code/postprocess_promised_metrics.py` | `reference_outputs/aggregates/ptbxl/ood_summary.csv`, `reference_outputs/aggregates/promised_postprocess/ood_paired_seed.csv` |
| Table VII | Raw and temperature-scaled calibration | `code/run_ptbxl_revision.py`, `code/aggregate_results.py` | `reference_outputs/aggregates/ptbxl/calibration_summary.csv`, `reference_outputs/manuscript_tables/Supplementary_PTB_Calibration_Summary.csv` |
| Table VIII | Noise-shift calibration | `code/infer_noise_shift_calibration.py`, `code/audit_noise_shift_calibration.py` | `reference_outputs/aggregates/noise_shift_calibration_audit/calibration_metrics.csv`, `reference_outputs/manuscript_tables/Supplementary_Noise_Calibration_Metrics.csv` |
| Table IX | Selective prediction | `code/aggregate_results.py`, `code/postprocess_promised_metrics.py` | `reference_outputs/aggregates/ptbxl/selective_summary.csv`, `reference_outputs/aggregates/promised_postprocess/selective_seed_summary.csv` |
| Table X | Synthetic corruption and SQI controls | `code/run_noise_sqi.py`, `code/aggregate_auxiliary.py` | `reference_outputs/aggregates/auxiliary/noise_summary.csv` |
| Table XI | Gate architecture controls | `code/run_noise_gate_extensions.py`, `code/audit_noise_gate_extensions.py` | `reference_outputs/aggregates/noise_gate_extensions/summary_aggregate.csv`, `source_corruption.csv` |
| Table XII | Source-count and pooling sensitivity | `code/run_ptbxl_revision.py`, `code/run_ptbxl_missing_extensions.py`, `code/audit_promised_extensions.py` | `reference_outputs/aggregates/promised_extensions/summary.csv`, `source_weight_diagnostics_summary.csv` |
| Table XIII | MHEALTH and WESAD LOSO results | `code/run_wearables_revision.py`, `code/aggregate_auxiliary.py` | `reference_outputs/aggregates/auxiliary/wearable_summary.csv`, `wearable_comparisons.csv` |
| Table XIV | Rare-class supports and classwise metrics | `code/aggregate_results.py`, `code/postprocess_promised_metrics.py` | `reference_outputs/manuscript_tables/Supplementary_Rare_Class_Metrics.csv`, `reference_outputs/aggregates/ptbxl/rare_class_summary.csv` |
| Table XV | Selected confidence intervals and paired effects | all relevant aggregators and audits | `reference_outputs/aggregates/ptbxl/paired_seed_comparisons.csv`, `reference_outputs/aggregates/promised_extensions/paired_effects.csv`, `reference_outputs/aggregates/auxiliary/wearable_comparisons.csv` |

The simple modular comparator is supported by
`reference_outputs/aggregates/modular_pipeline/summary.json`; its independent audit
is in `reference_outputs/aggregates/modular_pipeline_audit/audit.json`.

Patient-cluster and paired-patient bootstrap outputs require record-level arrays
that are intentionally excluded from this distributable package. The compact
reference aggregates retain the resulting summaries, while the full controlled
audit archive retains the identifier-bearing inputs.
