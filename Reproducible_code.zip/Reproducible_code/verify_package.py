#!/usr/bin/env python3
"""Verify package checksums, file inventory, language, and safety boundaries."""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CHECKSUM_FILE = ROOT / "SHA256SUMS"
TEXT_SUFFIXES = {
    "",
    ".complete",
    ".csv",
    ".env",
    ".json",
    ".md",
    ".py",
    ".sh",
    ".tex",
    ".txt",
    ".yaml",
    ".yml",
}
FORBIDDEN_BINARY_SUFFIXES = {".npy", ".npz", ".pickle", ".pkl", ".pt", ".pth"}
CJK_PATTERN = re.compile(
    "["
    "\u3400-\u4dbf"
    "\u4e00-\u9fff"
    "\uf900-\ufaff"
    "\u3040-\u30ff"
    "\uac00-\ud7af"
    "]"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_inventory() -> dict[str, str]:
    if not CHECKSUM_FILE.is_file():
        raise RuntimeError(f"missing checksum file: {CHECKSUM_FILE}")
    entries: dict[str, str] = {}
    for line_number, line in enumerate(CHECKSUM_FILE.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        digest, separator, relative = line.partition("  ")
        if not separator or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise RuntimeError(f"invalid SHA256SUMS line {line_number}")
        relative = relative.removeprefix("./")
        if relative in entries:
            raise RuntimeError(f"duplicate checksum entry: {relative}")
        entries[relative] = digest
    return entries


def write_inventory() -> None:
    files = sorted(
        (
            path
            for path in ROOT.rglob("*")
            if path.is_file() and path != CHECKSUM_FILE
        ),
        key=lambda path: path.relative_to(ROOT).as_posix(),
    )
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=".SHA256SUMS.", dir=ROOT
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            for path in files:
                relative = path.relative_to(ROOT).as_posix()
                handle.write(f"{sha256_file(path)}  ./{relative}\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, CHECKSUM_FILE)
    finally:
        if temporary.exists():
            temporary.unlink()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--write-checksums",
        action="store_true",
        help="atomically regenerate SHA256SUMS before verification",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.write_checksums:
        write_inventory()
    errors: list[str] = []
    inventory = parse_inventory()
    actual_files = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path != CHECKSUM_FILE
    }
    if set(inventory) != actual_files:
        for missing in sorted(actual_files - set(inventory)):
            errors.append(f"file is absent from SHA256SUMS: {missing}")
        for stale in sorted(set(inventory) - actual_files):
            errors.append(f"SHA256SUMS entry has no file: {stale}")

    for relative, expected in sorted(inventory.items()):
        path = ROOT / relative
        if path.is_symlink():
            errors.append(f"symbolic link is not allowed: {relative}")
            continue
        if not path.is_file():
            continue
        observed = sha256_file(path)
        if observed != expected:
            errors.append(f"checksum mismatch: {relative}")
        if path.suffix.lower() in FORBIDDEN_BINARY_SUFFIXES:
            errors.append(f"record-level or model binary is not allowed: {relative}")
        if path.suffix.lower() in TEXT_SUFFIXES:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                errors.append(f"text file is not valid UTF-8: {relative}")
                continue
            match = CJK_PATTERN.search(text)
            if match:
                line_number = text.count("\n", 0, match.start()) + 1
                errors.append(f"CJK character found in {relative}:{line_number}")

    if errors:
        print("Package verification failed:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print(
        f"Package verification passed: {len(actual_files)} inventoried files, "
        "no CJK text, no symlinks, and no record-level/model binaries."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
