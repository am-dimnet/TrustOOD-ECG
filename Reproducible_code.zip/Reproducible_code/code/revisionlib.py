"""Revision utilities for the Paper46 reviewer experiments.

This module is intentionally independent from ``code/trustlib.py`` so that the
published implementation remains unchanged.  It keeps the same basic encoders
and evidential parameterisation while making every reviewer-facing choice
explicit:

* evidence pooling: cumulative, source-count mean, or weight-normalised;
* decision branch: pooling only, feature-fusion only, or both;
* reliability gate: uncertainty + SQI, uncertainty only, SQI only, or none;
* inclusion/exclusion of the SQI feature source;
* source-local vacuity, quality and reliability weights in every prediction.

All OOD scores returned here follow one convention: **larger means more OOD**.
The post-hoc methods operate on a common penultimate feature space and never
modify the fitted classifier/backbone.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, Literal, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp
from sklearn.covariance import LedoitWolf, OAS
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve
from sklearn.neighbors import NearestNeighbors


PoolingMode = Literal["cumulative", "normalized", "mean"]
BranchMode = Literal["pooling_only", "fuse_only", "both"]
GateMode = Literal["both", "uncertainty_only", "sqi_only", "none"]
CovarianceMode = Literal["empirical", "ledoit_wolf", "oas"]


# Serializable provenance for experiment manifests and response-letter audits.
BASELINE_MANIFEST: Dict[str, Dict[str, str]] = {
    "TMC": {
        "paper": "Han et al., Trusted Multi-View Classification, ICLR 2021",
        "official_repo_class": "TMC",
        "fusion": "recursive Dempster-Shafer combination of real-view Dirichlets",
    },
    "TMDF": {
        "paper": (
            "Han et al., Trusted Multi-View Classification with Dynamic Evidential "
            "Fusion, IEEE TPAMI, DOI 10.1109/TPAMI.2022.3171983"
        ),
        "official_repo_class": "ETMC",
        "fusion": (
            "concat-feature pseudo-view evidence plus recursive Dempster-Shafer "
            "combination of real and pseudo views"
        ),
    },
}

# Every public scorer below has already been oriented to this convention.
OOD_SCORE_DIRECTION: Dict[str, str] = {
    name: "higher_is_ood"
    for name in ("MSP", "Energy", "ODIN", "Mahalanobis", "ViM", "KNN", "DICE", "GEN")
}


def _check_choice(name: str, value: str, choices: Iterable[str]) -> None:
    choices = tuple(choices)
    if value not in choices:
        raise ValueError(f"{name} must be one of {choices}, got {value!r}")


def _model_device(model: nn.Module) -> torch.device:
    try:
        return next(model.parameters()).device
    except StopIteration:
        return torch.device("cpu")


def _softmax_np(logits: np.ndarray) -> np.ndarray:
    logits = np.asarray(logits, dtype=np.float64)
    z = logits - logits.max(axis=1, keepdims=True)
    p = np.exp(z)
    return p / np.maximum(p.sum(axis=1, keepdims=True), 1e-300)


class ResBlock1D(nn.Module):
    """The residual block used by the original Paper46 waveform encoder."""

    def __init__(self, cin: int, cout: int, stride: int = 1, drop: float = 0.1):
        super().__init__()
        self.c1 = nn.Conv1d(cin, cout, 7, stride=stride, padding=3, bias=False)
        self.b1 = nn.BatchNorm1d(cout)
        self.c2 = nn.Conv1d(cout, cout, 7, padding=3, bias=False)
        self.b2 = nn.BatchNorm1d(cout)
        self.drop = nn.Dropout(drop)
        self.short = (
            nn.Identity()
            if stride == 1 and cin == cout
            else nn.Sequential(
                nn.Conv1d(cin, cout, 1, stride=stride, bias=False),
                nn.BatchNorm1d(cout),
            )
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.short(x)
        x = F.relu(self.b1(self.c1(x)))
        x = self.drop(x)
        x = self.b2(self.c2(x))
        return F.relu(x + residual)


class ResNet1D(nn.Module):
    """Waveform encoder with the same topology as ``trustlib.ResNet1D``."""

    def __init__(self, in_ch: int, out_dim: int = 128, base: int = 32, drop: float = 0.1):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv1d(in_ch, base, 15, stride=2, padding=7, bias=False),
            nn.BatchNorm1d(base),
            nn.ReLU(),
            nn.MaxPool1d(3, stride=2, padding=1),
        )
        channels = [base, base * 2, base * 4, out_dim]
        blocks = []
        cin = base
        for cout in channels:
            blocks.append(ResBlock1D(cin, cout, stride=2, drop=drop))
            cin = cout
        self.blocks = nn.Sequential(*blocks)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.out_dim = out_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.pool(self.blocks(self.stem(x))).squeeze(-1)


class MLPEncoder(nn.Module):
    """Vector-source encoder with the same topology as the original model."""

    def __init__(self, in_dim: int, out_dim: int = 128, hidden: int = 128, drop: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.ReLU(),
            nn.Dropout(drop),
            nn.Linear(hidden, out_dim),
            nn.ReLU(),
        )
        self.out_dim = out_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def nonnegative_evidence(logits: torch.Tensor) -> torch.Tensor:
    """Stable non-negative evidence mapping used throughout Paper46."""

    return F.softplus(logits)


class RevisionTrustModel(nn.Module):
    """Reviewer-facing evidential multi-source model.

    The gate is sequential rather than algebraically circular: each source first
    produces its own evidence and source-local vacuity ``u_s``; ``u_s`` and/or an
    externally computed quality value ``q_s`` then determine ``w_s``; only after
    that are sources pooled.  Gradients are intentionally retained through this
    sequence (there is no hidden ``detach``).

    Parameters
    ----------
    sources:
        Ordered mapping ``name -> {'type': 'wave'|'vec', 'in': dimension}``.
        An optional ``quality_key`` overrides the default ``f'{name}_q'``.
    pooling:
        ``cumulative`` is ``sum_s w_s e_s``; ``mean`` divides this sum by the
        number of sources; ``normalized`` divides by ``sum_s w_s``.
    branch:
        Selects pooled evidence, learned cross-source fusion evidence, or their
        additive combination.
    gate_mode:
        Inputs to each source gate. ``none`` fixes all weights to one.
    sqi_source:
        If false, ``sqi_source_name`` is removed as a feature source.  This is
        independent of using scalar SQI values in a gate.
    missing_quality:
        ``error`` catches an absent quality input; ``ones`` provides an explicit
        neutral-quality fallback and reports ``q_observed=False``.
    """

    def __init__(
        self,
        sources: Mapping[str, Mapping[str, Any]],
        n_classes: int,
        feat_dim: int = 128,
        proj_dim: int = 64,
        drop: float = 0.1,
        pooling: PoolingMode = "cumulative",
        branch: BranchMode = "both",
        gate_mode: GateMode = "both",
        sqi_source: bool = True,
        sqi_source_name: str = "sqi",
        missing_quality: Literal["error", "ones"] = "ones",
        fuse_hidden: int = 256,
        eps: float = 1e-8,
    ):
        super().__init__()
        _check_choice("pooling", pooling, ("cumulative", "normalized", "mean"))
        _check_choice("branch", branch, ("pooling_only", "fuse_only", "both"))
        _check_choice("gate_mode", gate_mode, ("both", "uncertainty_only", "sqi_only", "none"))
        _check_choice("missing_quality", missing_quality, ("error", "ones"))
        if n_classes < 2:
            raise ValueError("n_classes must be at least 2")

        selected = {
            name: dict(spec)
            for name, spec in sources.items()
            if sqi_source or name != sqi_source_name
        }
        if not selected:
            raise ValueError("at least one source must remain enabled")

        self.source_specs = selected
        self.src_names = list(selected)
        self.source_names = tuple(self.src_names)
        self.wave_sources = tuple(
            name for name, spec in selected.items() if spec.get("type") == "wave"
        )
        self.n_classes = int(n_classes)
        self.n_class = self.n_classes  # compatibility with trustlib callers
        self.feat_dim = int(feat_dim)
        self.pooling = pooling
        self.branch = branch
        self.gate_mode = gate_mode
        self.sqi_source = bool(sqi_source)
        self.sqi_source_name = sqi_source_name
        self.missing_quality = missing_quality
        self.eps = float(eps)

        self.enc = nn.ModuleDict()
        self.proj = nn.ModuleDict()
        self.head = nn.ModuleDict()
        self.gate = nn.ModuleDict()
        gate_dim = {"both": 2, "uncertainty_only": 1, "sqi_only": 1, "none": 0}[gate_mode]

        for name, spec in selected.items():
            source_type = spec.get("type")
            in_dim = int(spec["in"])
            if source_type == "wave":
                encoder = ResNet1D(in_dim, out_dim=feat_dim, drop=drop)
            elif source_type == "vec":
                encoder = MLPEncoder(in_dim, out_dim=feat_dim, drop=drop)
            else:
                raise ValueError(f"source {name!r} has unsupported type {source_type!r}")
            self.enc[name] = encoder
            self.proj[name] = nn.Sequential(nn.Linear(feat_dim, proj_dim), nn.ReLU())
            self.head[name] = nn.Linear(feat_dim, n_classes)
            if gate_dim:
                self.gate[name] = nn.Sequential(
                    nn.Linear(gate_dim, 16), nn.ReLU(), nn.Linear(16, 1)
                )

        if branch in ("fuse_only", "both"):
            self.fuse = nn.Sequential(
                nn.Linear(feat_dim * len(self.src_names), fuse_hidden),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(fuse_hidden, n_classes),
            )
        else:
            self.fuse = None

    def _quality(
        self, name: str, batch: Mapping[str, torch.Tensor], reference: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        key = str(self.source_specs[name].get("quality_key", f"{name}_q"))
        raw = batch.get(key)
        if raw is None:
            if self.gate_mode in ("both", "sqi_only") and self.missing_quality == "error":
                raise KeyError(f"quality key {key!r} is required for source {name!r}")
            q = torch.ones_like(reference)
            observed = torch.zeros_like(reference, dtype=torch.bool)
        else:
            q = raw.to(device=reference.device, dtype=reference.dtype).reshape(-1, 1)
            if q.shape[0] != reference.shape[0]:
                raise ValueError(f"quality key {key!r} has incompatible batch dimension")
            q = q.clamp(0.0, 1.0)
            observed = torch.ones_like(reference, dtype=torch.bool)
        return q, observed

    def _weight(self, name: str, u: torch.Tensor, q: torch.Tensor) -> torch.Tensor:
        if self.gate_mode == "none":
            return torch.ones_like(u)
        if self.gate_mode == "both":
            gate_input = torch.cat((u, q), dim=-1)
        elif self.gate_mode == "uncertainty_only":
            gate_input = u
        else:
            gate_input = q
        return torch.sigmoid(self.gate[name](gate_input))

    def _pool(self, weights: torch.Tensor, evidence: torch.Tensor) -> torch.Tensor:
        weighted_sum = (weights * evidence).sum(dim=1)
        if self.pooling == "cumulative":
            return weighted_sum
        if self.pooling == "mean":
            return weighted_sum / evidence.shape[1]
        return weighted_sum / weights.sum(dim=1).clamp_min(self.eps)

    def forward(self, batch: Mapping[str, torch.Tensor]) -> Dict[str, Any]:
        per: Dict[str, Dict[str, torch.Tensor]] = {}
        evidence_parts = []
        weight_parts = []
        uncertainty_parts = []
        quality_parts = []
        observed_parts = []
        gated_features = []
        projections = []

        for name in self.src_names:
            if name not in batch:
                raise KeyError(f"missing model source {name!r}")
            h = self.enc[name](batch[name])
            source_logits = self.head[name](h)
            source_evidence = nonnegative_evidence(source_logits)
            source_alpha = source_evidence + 1.0
            source_strength = source_alpha.sum(dim=-1, keepdim=True)
            source_u = self.n_classes / source_strength
            source_q, q_observed = self._quality(name, batch, source_u)
            source_w = self._weight(name, source_u, source_q)
            source_prob = source_alpha / source_strength
            z = F.normalize(self.proj[name](h), dim=-1)

            per[name] = {
                "h": h,
                "logits": source_logits,
                "evidence": source_evidence,
                "e": source_evidence,
                "alpha": source_alpha,
                "prob": source_prob,
                "u": source_u,
                "q": source_q,
                "q_observed": q_observed,
                "w": source_w,
            }
            evidence_parts.append(source_evidence)
            weight_parts.append(source_w)
            uncertainty_parts.append(source_u)
            quality_parts.append(source_q)
            observed_parts.append(q_observed)
            gated_features.append(source_w * h)
            projections.append(z)

        source_evidence = torch.stack(evidence_parts, dim=1)  # (B,S,K)
        source_w = torch.stack(weight_parts, dim=1)           # (B,S,1)
        source_u = torch.stack(uncertainty_parts, dim=1).squeeze(-1)
        source_q = torch.stack(quality_parts, dim=1).squeeze(-1)
        q_observed = torch.stack(observed_parts, dim=1).squeeze(-1)

        pool_evidence = self._pool(source_w, source_evidence)
        pool_alpha = pool_evidence + 1.0
        u_pool = self.n_classes / pool_alpha.sum(dim=-1, keepdim=True)

        fuse_evidence: Optional[torch.Tensor]
        if self.fuse is None:
            fuse_evidence = None
        else:
            fuse_evidence = nonnegative_evidence(self.fuse(torch.cat(gated_features, dim=-1)))

        if self.branch == "pooling_only":
            final_evidence = pool_evidence
        elif self.branch == "fuse_only":
            assert fuse_evidence is not None
            final_evidence = fuse_evidence
        else:
            assert fuse_evidence is not None
            final_evidence = pool_evidence + fuse_evidence

        alpha = final_evidence + 1.0
        strength = alpha.sum(dim=-1, keepdim=True)
        prob = alpha / strength
        # log(alpha) is a decision-logit representation because
        # softmax(log(alpha)) == alpha / sum(alpha).
        decision_logits = torch.log(alpha.clamp_min(self.eps))
        return {
            "alpha": alpha,
            "evidence": final_evidence,
            "logits": decision_logits,
            "prob": prob,
            "u": self.n_classes / strength,
            "u_pool": u_pool,
            "pool_evidence": pool_evidence,
            "fuse_evidence": fuse_evidence,
            "source_evidence": source_evidence,
            "source_u": source_u,
            "source_q": source_q,
            "source_w": source_w.squeeze(-1),
            "q_observed": q_observed,
            "W": source_w.squeeze(-1),
            "per": per,
            "projs": projections,
        }


def dirichlet_to_subjective_opinion(
    alpha: torch.Tensor, eps: float = 1e-8
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Convert Dirichlet parameters to TMC belief masses and uncertainty.

    For ``K`` classes, the trusted multi-view papers use

    ``S = sum_k alpha_k``, ``b_k = (alpha_k - 1) / S``, ``u = K / S``.

    Hence ``sum_k b_k + u = 1`` whenever ``alpha >= 1``.  The formula is from
    Han et al., *Trusted Multi-View Classification*, ICLR 2021.
    """

    if alpha.ndim != 2:
        raise ValueError("alpha must have shape (batch, classes)")
    if torch.any(alpha < 1.0 - 1e-6):
        raise ValueError("TMC/DS fusion requires Dirichlet alpha >= 1")
    strength = alpha.sum(dim=-1, keepdim=True).clamp_min(eps)
    belief = (alpha - 1.0).clamp_min(0.0) / strength
    uncertainty = alpha.shape[-1] / strength
    return belief, uncertainty


def tmc_ds_combine_two(
    alpha_a: torch.Tensor,
    alpha_b: torch.Tensor,
    eps: float = 1e-8,
    return_conflict: bool = False,
) -> torch.Tensor | Tuple[torch.Tensor, torch.Tensor]:
    r"""Exact two-opinion Dempster--Shafer combination used by official TMC.

    With belief vectors :math:`b^a,b^b` and uncertainties :math:`u^a,u^b`,
    the conflict and fused opinion are

    .. math::
       C &= \sum_{i\ne j} b_i^a b_j^b,\\
       b_k &= \frac{b_k^a b_k^b+b_k^a u^b+b_k^b u^a}{1-C},\\
       u &= \frac{u^a u^b}{1-C}.

    The fused Dirichlet is recovered through ``S=K/u``, ``e_k=b_k*S`` and
    ``alpha_k=e_k+1``.  This is the ``DS_Combin_two`` recurrence released for
    Han et al., *Trusted Multi-View Classification* (ICLR 2021).  The same
    recurrence is the Dynamic Evidential Fusion operator in the journal
    extension, Han et al., *Trusted Multi-View Classification with Dynamic
    Evidential Fusion*, IEEE TPAMI, DOI 10.1109/TPAMI.2022.3171983.
    """

    if alpha_a.shape != alpha_b.shape:
        raise ValueError("the two Dirichlet tensors must have identical shapes")
    belief_a, uncertainty_a = dirichlet_to_subjective_opinion(alpha_a, eps)
    belief_b, uncertainty_b = dirichlet_to_subjective_opinion(alpha_b, eps)
    outer = belief_a.unsqueeze(2) * belief_b.unsqueeze(1)
    conflict = outer.sum(dim=(1, 2)) - torch.diagonal(outer, dim1=1, dim2=2).sum(dim=1)
    normalizer = (1.0 - conflict).clamp_min(eps).unsqueeze(1)
    belief = (
        belief_a * belief_b
        + belief_a * uncertainty_b
        + belief_b * uncertainty_a
    ) / normalizer
    uncertainty = (uncertainty_a * uncertainty_b) / normalizer
    strength = alpha_a.shape[-1] / uncertainty.clamp_min(eps)
    alpha = belief * strength + 1.0
    if return_conflict:
        return alpha, conflict
    return alpha


def tmc_ds_combine(
    alphas: Sequence[torch.Tensor] | Mapping[str, torch.Tensor],
    eps: float = 1e-8,
    return_conflicts: bool = False,
) -> torch.Tensor | Tuple[torch.Tensor, torch.Tensor]:
    """Recursively combine two or more views using official TMC DS fusion."""

    values = list(alphas.values()) if isinstance(alphas, Mapping) else list(alphas)
    if not values:
        raise ValueError("at least one Dirichlet opinion is required")
    fused = values[0]
    conflicts = []
    for alpha in values[1:]:
        fused, conflict = tmc_ds_combine_two(fused, alpha, eps, return_conflict=True)
        conflicts.append(conflict)
    if return_conflicts:
        if conflicts:
            conflict_tensor = torch.stack(conflicts, dim=1)
        else:
            conflict_tensor = fused.new_zeros((fused.shape[0], 0))
        return fused, conflict_tensor
    return fused


def dynamic_evidential_fusion(
    alphas: Sequence[torch.Tensor] | Mapping[str, torch.Tensor],
    eps: float = 1e-8,
    return_conflicts: bool = False,
) -> torch.Tensor | Tuple[torch.Tensor, torch.Tensor]:
    """TPAMI Dynamic Evidential Fusion using its published DS recurrence.

    This named wrapper intentionally delegates to :func:`tmc_ds_combine` rather
    than adding an unreported attention or reliability heuristic.  The TPAMI
    extension uses the sample-dependent Dirichlet opinions/conflict in the same
    published recurrence; the dynamic behaviour comes from those per-sample
    opinions, not from an extra gate invented in this reproduction.
    """

    return tmc_ds_combine(alphas, eps=eps, return_conflicts=return_conflicts)


class TMCAdapter(nn.Module):
    """Heterogeneous-source adapter for the official ICLR 2021 TMC fusion.

    Each Paper46 source receives the same encoder family as the proposed model,
    so comparisons differ in the fusion rule rather than the backbone.  There
    is no SQI/reliability gate or learned fuse head in this baseline.
    """

    fusion_name = "TMC-ICLR21"

    def __init__(
        self,
        sources: Mapping[str, Mapping[str, Any]],
        n_classes: int,
        feat_dim: int = 128,
        drop: float = 0.1,
        eps: float = 1e-8,
    ):
        super().__init__()
        if len(sources) < 1:
            raise ValueError("TMCAdapter requires at least one source")
        self.source_specs = {name: dict(spec) for name, spec in sources.items()}
        self.source_names = tuple(self.source_specs)
        self.src_names = list(self.source_names)
        self.wave_sources = tuple(
            name for name, spec in self.source_specs.items() if spec.get("type") == "wave"
        )
        self.n_classes = int(n_classes)
        self.n_class = self.n_classes
        self.feat_dim = int(feat_dim)
        self.eps = float(eps)
        self.enc = nn.ModuleDict()
        self.head = nn.ModuleDict()
        for name, spec in self.source_specs.items():
            source_type = spec.get("type")
            if source_type == "wave":
                encoder = ResNet1D(int(spec["in"]), feat_dim, drop=drop)
            elif source_type == "vec":
                encoder = MLPEncoder(int(spec["in"]), feat_dim, drop=drop)
            else:
                raise ValueError(f"unsupported source type for {name!r}")
            self.enc[name] = encoder
            self.head[name] = nn.Linear(feat_dim, n_classes)

    def _fuse(
        self, alphas: Mapping[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return tmc_ds_combine(alphas, eps=self.eps, return_conflicts=True)

    def forward(self, batch: Mapping[str, torch.Tensor]) -> Dict[str, Any]:
        per: Dict[str, Dict[str, torch.Tensor]] = {}
        alphas: Dict[str, torch.Tensor] = {}
        source_u, source_evidence = [], []
        features = []
        for name in self.source_names:
            if name not in batch:
                raise KeyError(f"missing TMC source {name!r}")
            h = self.enc[name](batch[name])
            logits = self.head[name](h)
            evidence = nonnegative_evidence(logits)
            alpha = evidence + 1.0
            strength = alpha.sum(dim=-1, keepdim=True)
            uncertainty = self.n_classes / strength
            per[name] = {
                "h": h,
                "logits": logits,
                "evidence": evidence,
                "e": evidence,
                "alpha": alpha,
                "prob": alpha / strength,
                "u": uncertainty,
                "q": torch.ones_like(uncertainty),
                "q_observed": torch.zeros_like(uncertainty, dtype=torch.bool),
                "w": torch.ones_like(uncertainty),
            }
            alphas[name] = alpha
            source_u.append(uncertainty)
            source_evidence.append(evidence)
            features.append(h)

        alpha, conflicts = self._fuse(alphas)
        strength = alpha.sum(dim=-1, keepdim=True)
        evidence = alpha - 1.0
        batch_size = alpha.shape[0]
        n_sources = len(self.source_names)
        ones = alpha.new_ones((batch_size, n_sources))
        zeros_bool = torch.zeros((batch_size, n_sources), dtype=torch.bool, device=alpha.device)
        stacked_u = torch.stack(source_u, dim=1).squeeze(-1)
        stacked_evidence = torch.stack(source_evidence, dim=1)
        return {
            "alpha": alpha,
            "evidence": evidence,
            "logits": torch.log(alpha.clamp_min(self.eps)),
            "prob": alpha / strength,
            "u": self.n_classes / strength,
            "u_pool": self.n_classes / strength,
            "pool_evidence": evidence,
            "fuse_evidence": None,
            "source_evidence": stacked_evidence,
            "source_u": stacked_u,
            "source_q": ones,
            "source_w": ones,
            "q_observed": zeros_bool,
            "W": ones,
            "conflicts": conflicts,
            "per": per,
            "projs": [],
            "features": features,
        }


class TMDFAdapter(TMCAdapter):
    """TPAMI Dynamic Evidential Fusion adapter following official ``ETMC``.

    The official TPAMI repository's journal-extension class is named ``ETMC``.
    In addition to the individual source opinions, it concatenates all encoded
    source features, predicts a *pseudo-view* evidence vector, and recursively
    DS-combines the real and pseudo views.  This adapter implements precisely
    that architectural distinction; it does not add an invented reliability
    gate.  Because the pseudo-view is inserted into ``output['per']``,
    :func:`tmc_training_loss` deep-supervises it exactly like every real view.

    Source: Han et al., *Trusted Multi-View Classification with Dynamic
    Evidential Fusion*, IEEE TPAMI, DOI 10.1109/TPAMI.2022.3171983; official
    repository class ``ETMC``.
    """

    fusion_name = "TMDF-TPAMI22"

    def __init__(
        self,
        sources: Mapping[str, Mapping[str, Any]],
        n_classes: int,
        feat_dim: int = 128,
        drop: float = 0.1,
        eps: float = 1e-8,
    ):
        super().__init__(sources, n_classes, feat_dim=feat_dim, drop=drop, eps=eps)
        self.pseudo_view_name = "pseudo_view"
        self.pseudo_head = nn.Linear(feat_dim * len(self.source_names), n_classes)

    def _fuse(
        self, alphas: Mapping[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return dynamic_evidential_fusion(alphas, eps=self.eps, return_conflicts=True)

    def forward(self, batch: Mapping[str, torch.Tensor]) -> Dict[str, Any]:
        output = super().forward(batch)
        pseudo_h = torch.cat(output["features"], dim=-1)
        pseudo_logits = self.pseudo_head(pseudo_h)
        pseudo_evidence = nonnegative_evidence(pseudo_logits)
        pseudo_alpha = pseudo_evidence + 1.0
        pseudo_strength = pseudo_alpha.sum(dim=-1, keepdim=True)
        pseudo_u = self.n_classes / pseudo_strength
        output["per"][self.pseudo_view_name] = {
            "h": pseudo_h,
            "logits": pseudo_logits,
            "evidence": pseudo_evidence,
            "e": pseudo_evidence,
            "alpha": pseudo_alpha,
            "prob": pseudo_alpha / pseudo_strength,
            "u": pseudo_u,
            "q": torch.ones_like(pseudo_u),
            "q_observed": torch.zeros_like(pseudo_u, dtype=torch.bool),
            "w": torch.ones_like(pseudo_u),
        }
        fusion_alphas = {
            name: output["per"][name]["alpha"] for name in self.source_names
        }
        fusion_alphas[self.pseudo_view_name] = pseudo_alpha
        alpha, conflicts = self._fuse(fusion_alphas)
        strength = alpha.sum(dim=-1, keepdim=True)
        evidence = alpha - 1.0
        output.update(
            {
                "alpha": alpha,
                "evidence": evidence,
                "logits": torch.log(alpha.clamp_min(self.eps)),
                "prob": alpha / strength,
                "u": self.n_classes / strength,
                "u_pool": self.n_classes / strength,
                "pool_evidence": evidence,
                "conflicts": conflicts,
                "pseudo_view_evidence": pseudo_evidence,
                "pseudo_view_u": pseudo_u,
                "fusion_view_names": self.source_names + (self.pseudo_view_name,),
            }
        )
        return output


class SharedBackboneClassifier(nn.Module):
    """Concat classifier used for ODIN and shared-backbone post-hoc baselines."""

    def __init__(
        self,
        sources: Mapping[str, Mapping[str, Any]],
        n_classes: int,
        feat_dim: int = 128,
        drop: float = 0.2,
    ):
        super().__init__()
        self.source_specs = {name: dict(spec) for name, spec in sources.items()}
        self.source_names = tuple(self.source_specs)
        self.src_names = list(self.source_names)
        self.wave_sources = tuple(
            name for name, spec in self.source_specs.items() if spec.get("type") == "wave"
        )
        self.enc = nn.ModuleDict()
        for name, spec in self.source_specs.items():
            if spec.get("type") == "wave":
                self.enc[name] = ResNet1D(int(spec["in"]), feat_dim, drop=drop)
            elif spec.get("type") == "vec":
                self.enc[name] = MLPEncoder(int(spec["in"]), feat_dim, drop=drop)
            else:
                raise ValueError(f"unsupported source type for {name!r}")
        self.feature_dim = feat_dim * len(self.source_names)
        self.dropout = nn.Dropout(drop)
        self.head = nn.Linear(self.feature_dim, n_classes)

    def features(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        return torch.cat([self.enc[name](batch[name]) for name in self.source_names], dim=-1)

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        return self.head(self.dropout(self.features(batch)))


def kl_dirichlet(alpha: torch.Tensor) -> torch.Tensor:
    """KL(Dir(alpha) || Dir(1)), returned per sample."""

    beta = torch.ones_like(alpha)
    sum_alpha = alpha.sum(dim=-1, keepdim=True)
    log_b_alpha = torch.lgamma(sum_alpha).squeeze(-1) - torch.lgamma(alpha).sum(dim=-1)
    log_b_uniform = torch.lgamma(beta).sum(dim=-1) - torch.lgamma(beta.sum(dim=-1))
    return log_b_alpha + log_b_uniform + (
        (alpha - beta) * (torch.digamma(alpha) - torch.digamma(sum_alpha))
    ).sum(dim=-1)


def edl_loss(
    alpha: torch.Tensor,
    targets: torch.Tensor,
    kl_weight: float = 0.05,
    class_weights: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Expected cross-entropy under a Dirichlet plus misleading-evidence KL."""

    one_hot = F.one_hot(targets, alpha.shape[-1]).to(alpha.dtype)
    strength = alpha.sum(dim=-1, keepdim=True)
    per_sample = (one_hot * (torch.digamma(strength) - torch.digamma(alpha))).sum(dim=-1)
    alpha_without_true_evidence = one_hot + (1.0 - one_hot) * alpha
    per_sample = per_sample + kl_weight * kl_dirichlet(alpha_without_true_evidence)
    if class_weights is not None:
        per_sample = per_sample * class_weights[targets]
    return per_sample.mean()


def complementarity_loss(projections: Sequence[torch.Tensor]) -> torch.Tensor:
    """Mean absolute pairwise cosine similarity of source projections."""

    if not projections:
        return torch.tensor(0.0)
    if len(projections) == 1:
        return projections[0].new_zeros(())
    terms = []
    for i in range(len(projections)):
        for j in range(i + 1, len(projections)):
            terms.append((projections[i] * projections[j]).sum(dim=-1).abs().mean())
    return torch.stack(terms).mean()


def revision_training_loss(
    output: Mapping[str, Any],
    targets: torch.Tensor,
    kl_weight: float = 0.05,
    ce_weight: float = 0.5,
    deep_supervision_weight: float = 0.3,
    complementarity_weight: float = 0.0,
    class_weights: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Single transparent training objective for all revision branches."""

    loss = edl_loss(output["alpha"], targets, kl_weight, class_weights)
    loss = loss + ce_weight * F.cross_entropy(output["logits"], targets, weight=class_weights)
    if deep_supervision_weight > 0:
        for source in output["per"].values():
            source_loss = edl_loss(source["alpha"], targets, kl_weight, class_weights)
            source_loss = source_loss + ce_weight * F.cross_entropy(
                source["logits"], targets, weight=class_weights
            )
            loss = loss + deep_supervision_weight * source_loss
    if complementarity_weight > 0:
        loss = loss + complementarity_weight * complementarity_loss(output["projs"])
    return loss


def tmc_training_loss(
    output: Mapping[str, Any],
    targets: torch.Tensor,
    kl_weight: float = 0.05,
    class_weights: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """TMC/TMDF objective: fused EDL loss plus every view-specific EDL loss."""

    loss = edl_loss(output["alpha"], targets, kl_weight, class_weights)
    for source in output["per"].values():
        loss = loss + edl_loss(source["alpha"], targets, kl_weight, class_weights)
    return loss


def _array_batch(
    arrays: Mapping[str, np.ndarray],
    keys: Sequence[str],
    start: int,
    stop: int,
    device: torch.device,
) -> Dict[str, torch.Tensor]:
    batch: Dict[str, torch.Tensor] = {}
    for key in keys:
        if key not in arrays:
            continue
        value = torch.as_tensor(
            np.ascontiguousarray(arrays[key][start:stop]), device=device
        )
        # NumPy preprocessing often defaults to float64 whereas the encoders are
        # float32.  Cast floating model inputs consistently; preserve integer and
        # boolean arrays.
        if value.is_floating_point():
            value = value.float()
        batch[key] = value
    return batch


def _model_input_keys(model: nn.Module, arrays: Mapping[str, np.ndarray]) -> Tuple[str, ...]:
    source_names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    if not source_names:
        return tuple(key for key in arrays if key not in ("y", "patient", "subj"))
    quality_keys = []
    specs = getattr(model, "source_specs", {})
    for name in source_names:
        key = str(specs.get(name, {}).get("quality_key", f"{name}_q"))
        if key in arrays:
            quality_keys.append(key)
    return tuple(source_names) + tuple(quality_keys)


@torch.no_grad()
def predict_revision(
    model: nn.Module,
    arrays: Mapping[str, np.ndarray],
    batch_size: int = 512,
    device: Optional[torch.device | str] = None,
) -> Dict[str, np.ndarray]:
    """Batched prediction including every source's ``u``, ``q`` and weight."""

    was_training = model.training
    model.eval()
    device = torch.device(device) if device is not None else _model_device(model)
    keys = _model_input_keys(model, arrays)
    n = len(arrays[model.source_names[0]])
    collected: Dict[str, list[np.ndarray]] = {
        key: []
        for key in (
            "prob", "logits", "u", "u_pool", "source_u", "source_q", "source_w",
            "q_observed", "pool_evidence", "evidence",
        )
    }
    optional_collected: Dict[str, list[np.ndarray]] = {
        "conflicts": [],
        "pseudo_view_u": [],
        "pseudo_view_evidence": [],
    }
    for start in range(0, n, batch_size):
        batch = _array_batch(arrays, keys, start, min(n, start + batch_size), device)
        output = model(batch)
        for key in collected:
            value = output[key]
            collected[key].append(value.detach().cpu().numpy())
        for key in optional_collected:
            value = output.get(key)
            if value is not None:
                optional_collected[key].append(value.detach().cpu().numpy())
    if was_training:
        model.train()
    result = {key: np.concatenate(parts, axis=0) for key, parts in collected.items()}
    for key, parts in optional_collected.items():
        if parts:
            result[key] = np.concatenate(parts, axis=0)
    result["u"] = result["u"].reshape(-1)
    result["u_pool"] = result["u_pool"].reshape(-1)
    result["conf"] = result["prob"].max(axis=1)
    result["pred"] = result["prob"].argmax(axis=1)
    result["source_names"] = np.asarray(model.source_names, dtype=object)
    return result


def msp_ood_score(probs: np.ndarray) -> np.ndarray:
    """Maximum-softmax-probability baseline; larger means more OOD."""

    probs = np.asarray(probs)
    return 1.0 - probs.max(axis=1)


def energy_ood_score(logits: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    """Standard energy ``-T logsumexp(z/T)``; larger means more OOD."""

    if temperature <= 0:
        raise ValueError("temperature must be positive")
    logits = np.asarray(logits, dtype=np.float64)
    return -temperature * logsumexp(logits / temperature, axis=1)


def entropy_ood_score(probs: np.ndarray) -> np.ndarray:
    """Predictive Shannon entropy; larger means more OOD."""

    probs = np.clip(np.asarray(probs, dtype=np.float64), 1e-12, 1.0)
    return -(probs * np.log(probs)).sum(axis=1)


def _extract_logits(output: Any) -> torch.Tensor:
    if torch.is_tensor(output):
        return output
    if isinstance(output, Mapping):
        if "logits" in output:
            return output["logits"]
        if "prob" in output:
            return torch.log(output["prob"].clamp_min(1e-12))
    raise TypeError("model output must be logits or a mapping with 'logits'/'prob'")


def odin_ood_score(
    model: nn.Module,
    arrays: Mapping[str, np.ndarray],
    wave_keys: Optional[Sequence[str]] = None,
    temperature: float = 1000.0,
    epsilon: float = 0.0014,
    input_stds: Optional[Mapping[str, np.ndarray | float]] = None,
    batch_size: int = 256,
    device: Optional[torch.device | str] = None,
) -> Dict[str, np.ndarray]:
    """ODIN with a real input-gradient perturbation of every waveform source.

    The pseudo-label cross-entropy is differentiated with respect to waveform
    inputs, then each waveform is moved in the *negative* gradient direction
    before temperature-scaled re-evaluation.  Vector/metadata inputs are never
    perturbed.  Returned ``score = 1 - max_probability`` is high for OOD.
    """

    if temperature <= 0 or epsilon < 0:
        raise ValueError("temperature must be positive and epsilon non-negative")
    device = torch.device(device) if device is not None else _model_device(model)
    keys = _model_input_keys(model, arrays)
    if wave_keys is None:
        wave_keys = tuple(getattr(model, "wave_sources", ()))
    else:
        wave_keys = tuple(wave_keys)
    if not wave_keys:
        raise ValueError("ODIN requires at least one waveform input key")
    missing = [key for key in wave_keys if key not in arrays]
    if missing:
        raise KeyError(f"missing waveform arrays: {missing}")

    was_training = model.training
    model.eval()
    n = len(arrays[wave_keys[0]])
    scores, probabilities, perturbed_logits = [], [], []
    for start in range(0, n, batch_size):
        stop = min(n, start + batch_size)
        batch = _array_batch(arrays, keys, start, stop, device)
        differentiable = []
        for key in wave_keys:
            x = batch[key].detach().clone().to(dtype=torch.float32).requires_grad_(True)
            batch[key] = x
            differentiable.append(x)

        model.zero_grad(set_to_none=True)
        with torch.enable_grad():
            logits = _extract_logits(model(batch))
            pseudo = logits.detach().argmax(dim=1)
            loss = F.cross_entropy(logits / temperature, pseudo)
            gradients = torch.autograd.grad(loss, differentiable, only_inputs=True)

        perturbed = dict(batch)
        for key, x, gradient in zip(wave_keys, differentiable, gradients):
            signed_gradient = gradient.sign()
            if input_stds is not None and key in input_stds:
                std = torch.as_tensor(input_stds[key], dtype=x.dtype, device=x.device)
                if std.ndim == 0:
                    std = std.reshape(*([1] * x.ndim))
                elif std.ndim == 1 and x.ndim >= 3 and std.numel() == x.shape[1]:
                    # Per-channel standard deviations: (C,) -> (1,C,1,...).
                    std = std.reshape(1, -1, *([1] * (x.ndim - 2)))
                elif std.ndim == x.ndim - 1:
                    std = std.unsqueeze(0)
                else:
                    while std.ndim < x.ndim:
                        std = std.unsqueeze(-1)
                try:
                    torch.broadcast_shapes(std.shape, x.shape)
                except RuntimeError as exc:
                    raise ValueError(
                        f"input_stds[{key!r}] with shape {tuple(std.shape)} cannot "
                        f"broadcast to waveform shape {tuple(x.shape)}"
                    ) from exc
                signed_gradient = signed_gradient / std.clamp_min(1e-12)
            perturbed[key] = (x - epsilon * signed_gradient).detach()
        with torch.no_grad():
            logits_after = _extract_logits(model(perturbed)) / temperature
            probs_after = F.softmax(logits_after, dim=1)
        probabilities.append(probs_after.cpu().numpy())
        perturbed_logits.append(logits_after.cpu().numpy())
        scores.append((1.0 - probs_after.max(dim=1).values).cpu().numpy())

    model.zero_grad(set_to_none=True)
    if was_training:
        model.train()
    return {
        "score": np.concatenate(scores),
        "probs": np.concatenate(probabilities),
        "logits": np.concatenate(perturbed_logits),
    }


@torch.no_grad()
def extract_features_logits(
    model: nn.Module,
    arrays: Mapping[str, np.ndarray],
    batch_size: int = 512,
    device: Optional[torch.device | str] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Extract a shared penultimate representation and corresponding logits."""

    if not hasattr(model, "features"):
        raise TypeError("model must expose a features(batch) method")
    device = torch.device(device) if device is not None else _model_device(model)
    keys = _model_input_keys(model, arrays)
    source_names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    n = len(arrays[source_names[0] if source_names else keys[0]])
    was_training = model.training
    model.eval()
    features, logits = [], []
    for start in range(0, n, batch_size):
        batch = _array_batch(arrays, keys, start, min(n, start + batch_size), device)
        feature = model.features(batch)
        if hasattr(model, "head"):
            logit = model.head(feature)
        else:
            logit = _extract_logits(model(batch))
        features.append(feature.cpu().numpy())
        logits.append(logit.cpu().numpy())
    if was_training:
        model.train()
    return np.concatenate(features), np.concatenate(logits)


@dataclass
class MahalanobisState:
    means: np.ndarray
    precision: np.ndarray
    classes: np.ndarray
    covariance: np.ndarray
    global_mean: np.ndarray
    global_scale: np.ndarray
    covariance_mode: str
    shrinkage: Optional[float]
    ridge: float


def fit_mahalanobis(
    features: np.ndarray,
    labels: np.ndarray,
    n_classes: Optional[int] = None,
    covariance: CovarianceMode = "empirical",
    shrinkage: Optional[float] = None,
    ridge: float = 1e-3,
    standardize: bool = False,
    min_class_count: int = 2,
) -> MahalanobisState:
    """Fit class means and a pooled covariance with optional shrinkage/ridge."""

    _check_choice("covariance", covariance, ("empirical", "ledoit_wolf", "oas"))
    if ridge < 0:
        raise ValueError("ridge must be non-negative")
    if shrinkage is not None and not 0.0 <= shrinkage <= 1.0:
        raise ValueError("shrinkage must lie in [0,1]")
    x = np.asarray(features, dtype=np.float64)
    y = np.asarray(labels)
    if x.ndim != 2 or len(x) != len(y):
        raise ValueError("features must be (N,D) and aligned with labels")
    global_mean = x.mean(axis=0) if standardize else np.zeros(x.shape[1])
    global_scale = x.std(axis=0) if standardize else np.ones(x.shape[1])
    global_scale = np.where(global_scale > 1e-12, global_scale, 1.0)
    z = (x - global_mean) / global_scale
    possible = np.arange(n_classes) if n_classes is not None else np.unique(y)
    classes = np.asarray([c for c in possible if np.sum(y == c) >= min_class_count])
    if classes.size == 0:
        raise ValueError("no class has enough samples for Mahalanobis fitting")
    means = np.stack([z[y == c].mean(axis=0) for c in classes])
    residuals = np.concatenate([z[y == c] - means[i] for i, c in enumerate(classes)], axis=0)

    if covariance == "ledoit_wolf":
        cov = LedoitWolf(assume_centered=True).fit(residuals).covariance_
    elif covariance == "oas":
        cov = OAS(assume_centered=True).fit(residuals).covariance_
    else:
        denom = max(len(residuals) - len(classes), 1)
        cov = residuals.T @ residuals / denom
    cov = np.atleast_2d(cov)
    if shrinkage is not None:
        target = np.trace(cov) / cov.shape[0] * np.eye(cov.shape[0])
        cov = (1.0 - shrinkage) * cov + shrinkage * target
    cov = cov + ridge * np.eye(cov.shape[0])
    precision = np.linalg.pinv(cov, hermitian=True)
    return MahalanobisState(
        means=means,
        precision=precision,
        classes=classes,
        covariance=cov,
        global_mean=global_mean,
        global_scale=global_scale,
        covariance_mode=covariance,
        shrinkage=shrinkage,
        ridge=float(ridge),
    )


def mahalanobis_ood_score(features: np.ndarray, state: MahalanobisState) -> np.ndarray:
    """Minimum squared class-conditional Mahalanobis distance; high is OOD."""

    x = (np.asarray(features, dtype=np.float64) - state.global_mean) / state.global_scale
    distances = []
    for mean in state.means:
        delta = x - mean
        distances.append(np.einsum("ni,ij,nj->n", delta, state.precision, delta))
    return np.stack(distances, axis=1).min(axis=1)


def combine_source_ood_scores(
    scores: Mapping[str, np.ndarray],
    source_names: Sequence[str],
    weights: Optional[np.ndarray] = None,
    reference_scores: Optional[Mapping[str, np.ndarray]] = None,
    normalize_weights: bool = True,
    eps: float = 1e-8,
) -> np.ndarray:
    """Reliability-weighted source score with optional reference z-normalisation."""

    matrix = []
    for name in source_names:
        value = np.asarray(scores[name], dtype=np.float64)
        if reference_scores is not None:
            reference = np.asarray(reference_scores[name], dtype=np.float64)
            value = (value - reference.mean()) / max(reference.std(), eps)
        matrix.append(value)
    matrix = np.stack(matrix, axis=1)
    if weights is None:
        weight_matrix = np.ones_like(matrix)
    else:
        weight_matrix = np.asarray(weights, dtype=np.float64)
        if weight_matrix.shape != matrix.shape:
            raise ValueError("weights must have shape (N, number_of_sources)")
    if normalize_weights:
        weight_matrix = weight_matrix / np.maximum(weight_matrix.sum(axis=1, keepdims=True), eps)
        return (weight_matrix * matrix).sum(axis=1)
    return (weight_matrix * matrix).mean(axis=1)


@dataclass
class ViMState:
    origin: np.ndarray
    null_basis: np.ndarray
    alpha: float
    principal_dim: int


def fit_vim(
    train_features: np.ndarray,
    train_logits: np.ndarray,
    classifier_weight: np.ndarray,
    classifier_bias: np.ndarray,
    principal_dim: Optional[int] = None,
    explained_variance: float = 0.95,
) -> ViMState:
    """Fit ViM's affine origin, principal subspace and virtual-logit scale."""

    features = np.asarray(train_features, dtype=np.float64)
    logits = np.asarray(train_logits, dtype=np.float64)
    weight = np.asarray(classifier_weight, dtype=np.float64)
    bias = np.asarray(classifier_bias, dtype=np.float64).reshape(-1)
    if features.ndim != 2 or logits.ndim != 2 or len(features) != len(logits):
        raise ValueError("train_features/train_logits must be aligned 2-D arrays")
    if weight.shape != (logits.shape[1], features.shape[1]) or len(bias) != logits.shape[1]:
        raise ValueError("classifier weight/bias do not match feature and logit dimensions")
    origin = -np.linalg.pinv(weight) @ bias
    centered = features - origin
    covariance = centered.T @ centered / max(len(centered), 1)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)  # ascending
    dimension = features.shape[1]
    if principal_dim is None:
        descending = np.maximum(eigenvalues[::-1], 0.0)
        total = descending.sum()
        if total <= 0:
            principal_dim = max(1, dimension - 1)
        else:
            principal_dim = int(np.searchsorted(np.cumsum(descending) / total, explained_variance) + 1)
    principal_dim = int(np.clip(principal_dim, 1, max(1, dimension - 1)))
    null_dimension = dimension - principal_dim
    null_basis = eigenvectors[:, :null_dimension]
    residual_norm = np.linalg.norm(centered @ null_basis, axis=1)
    mean_max_logit = float(np.max(logits, axis=1).mean())
    alpha = max(mean_max_logit, 1e-12) / max(float(residual_norm.mean()), 1e-12)
    return ViMState(origin=origin, null_basis=null_basis, alpha=alpha, principal_dim=principal_dim)


def vim_ood_score(features: np.ndarray, logits: np.ndarray, state: ViMState) -> np.ndarray:
    """ViM virtual logit minus ID log-sum-exp; larger means more OOD."""

    centered = np.asarray(features, dtype=np.float64) - state.origin
    residual = np.linalg.norm(centered @ state.null_basis, axis=1)
    virtual_logit = state.alpha * residual
    return virtual_logit - logsumexp(np.asarray(logits, dtype=np.float64), axis=1)


@dataclass
class KNNState:
    index: NearestNeighbors
    n_neighbors: int
    normalize: bool


def _l2_normalize(features: np.ndarray) -> np.ndarray:
    x = np.asarray(features, dtype=np.float64)
    return x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-12)


def fit_knn(
    train_features: np.ndarray,
    n_neighbors: int = 50,
    normalize: bool = True,
    metric: str = "euclidean",
    n_jobs: Optional[int] = None,
) -> KNNState:
    """Fit the non-parametric k-nearest-neighbour OOD baseline."""

    x = np.asarray(train_features, dtype=np.float64)
    if n_neighbors < 1 or n_neighbors > len(x):
        raise ValueError("n_neighbors must be in [1, number of training samples]")
    if normalize:
        x = _l2_normalize(x)
    index = NearestNeighbors(n_neighbors=n_neighbors, metric=metric, n_jobs=n_jobs).fit(x)
    return KNNState(index=index, n_neighbors=n_neighbors, normalize=normalize)


def knn_ood_score(features: np.ndarray, state: KNNState) -> np.ndarray:
    """Distance to the k-th nearest training feature; larger means more OOD."""

    x = _l2_normalize(features) if state.normalize else np.asarray(features, dtype=np.float64)
    distances, _ = state.index.kneighbors(x, return_distance=True)
    return distances[:, -1]


@dataclass
class DICEState:
    masked_weight: np.ndarray
    bias: np.ndarray
    mask: np.ndarray
    keep_ratio: float


def fit_dice(
    train_features: np.ndarray,
    classifier_weight: np.ndarray,
    classifier_bias: np.ndarray,
    keep_ratio: float = 0.1,
) -> DICEState:
    """Fit DICE by retaining the largest mean-activation contributions globally."""

    if not 0.0 < keep_ratio <= 1.0:
        raise ValueError("keep_ratio must lie in (0,1]")
    features = np.asarray(train_features, dtype=np.float64)
    weight = np.asarray(classifier_weight, dtype=np.float64)
    bias = np.asarray(classifier_bias, dtype=np.float64).reshape(-1)
    if weight.shape[1] != features.shape[1] or weight.shape[0] != len(bias):
        raise ValueError("classifier dimensions do not match features")
    contribution = weight * features.mean(axis=0, keepdims=True)
    flat = contribution.ravel()
    keep = max(1, int(np.ceil(keep_ratio * flat.size)))
    selected = np.argpartition(flat, flat.size - keep)[flat.size - keep :]
    mask_flat = np.zeros(flat.size, dtype=bool)
    mask_flat[selected] = True
    mask = mask_flat.reshape(contribution.shape)
    return DICEState(
        masked_weight=weight * mask,
        bias=bias,
        mask=mask,
        keep_ratio=float(keep_ratio),
    )


def dice_logits(features: np.ndarray, state: DICEState) -> np.ndarray:
    return np.asarray(features, dtype=np.float64) @ state.masked_weight.T + state.bias


def dice_ood_score(
    features: np.ndarray, state: DICEState, temperature: float = 1.0
) -> np.ndarray:
    """Energy of the DICE-sparsified classifier; larger means more OOD."""

    return energy_ood_score(dice_logits(features, state), temperature=temperature)


def gen_ood_score(
    logits: Optional[np.ndarray] = None,
    probs: Optional[np.ndarray] = None,
    gamma: float = 0.1,
    top_m: Optional[int] = None,
) -> np.ndarray:
    r"""Official GEN generalized entropy, re-oriented to **OOD-high**.

    The official ``benchmark.py::generalized_entropy`` computes

    ``G = sum_{k in top-M} p_k**gamma * (1-p_k)**gamma``

    and returns ``-G`` because its benchmark API treats larger scores as ID
    confidence.  Every scorer in this module is OOD-high, so this function
    returns positive ``G``.  ``top_m=None`` uses all classes; retained
    probabilities are not re-normalised.
    """

    if gamma <= 0:
        raise ValueError("gamma must be positive")
    if (logits is None) == (probs is None):
        raise ValueError("provide exactly one of logits or probs")
    p = _softmax_np(np.asarray(logits)) if probs is None else np.asarray(probs, dtype=np.float64)
    p = np.clip(p, 1e-12, 1.0 - 1e-12)
    if top_m is not None:
        if top_m < 1:
            raise ValueError("top_m must be positive")
        top_m = min(int(top_m), p.shape[1])
        p = np.take_along_axis(p, np.argsort(p, axis=1)[:, -top_m:], axis=1)
    return (np.power(p, gamma) * np.power(1.0 - p, gamma)).sum(axis=1)


def fpr_at_tpr(
    score_id: np.ndarray, score_ood: np.ndarray, target_tpr: float = 0.95
) -> float:
    """Minimum interpolated FPR at or above the requested OOD TPR."""

    labels = np.r_[np.zeros(len(score_id), dtype=int), np.ones(len(score_ood), dtype=int)]
    scores = np.r_[score_id, score_ood]
    fpr, tpr, _ = roc_curve(labels, scores)
    eligible = np.flatnonzero(tpr >= target_tpr)
    return float(fpr[eligible[0]]) if len(eligible) else 1.0


def ood_metrics(score_id: np.ndarray, score_ood: np.ndarray) -> Dict[str, float]:
    """AUROC, AUPR-out, AUPR-in and FPR95 for scores where high means OOD."""

    score_id = np.asarray(score_id, dtype=np.float64)
    score_ood = np.asarray(score_ood, dtype=np.float64)
    labels_out = np.r_[np.zeros(len(score_id), dtype=int), np.ones(len(score_ood), dtype=int)]
    scores = np.r_[score_id, score_ood]
    labels_in = 1 - labels_out
    return {
        "auroc": float(roc_auc_score(labels_out, scores)),
        "aupr_out": float(average_precision_score(labels_out, scores)),
        "aupr_in": float(average_precision_score(labels_in, -scores)),
        "fpr95": fpr_at_tpr(score_id, score_ood, 0.95),
    }


@dataclass(frozen=True)
class TemperatureScaler:
    """Scalar post-hoc temperature fitted by validation negative log-likelihood."""

    temperature: float

    @classmethod
    def fit(
        cls,
        logits: np.ndarray,
        labels: np.ndarray,
        bounds: Tuple[float, float] = (0.05, 20.0),
    ) -> "TemperatureScaler":
        logits = np.asarray(logits, dtype=np.float64)
        labels = np.asarray(labels, dtype=int)
        if logits.ndim != 2 or len(logits) != len(labels):
            raise ValueError("logits and labels must be aligned")

        def objective(temperature: float) -> float:
            scaled = logits / temperature
            return float((-scaled[np.arange(len(labels)), labels] + logsumexp(scaled, axis=1)).mean())

        result = minimize_scalar(objective, bounds=bounds, method="bounded")
        temperature = float(result.x) if result.success else 1.0
        return cls(temperature=temperature)

    def transform_logits(self, logits: np.ndarray) -> np.ndarray:
        return np.asarray(logits, dtype=np.float64) / self.temperature

    def predict_proba(self, logits: np.ndarray) -> np.ndarray:
        return _softmax_np(self.transform_logits(logits))


def _bin_indices(confidence: np.ndarray, n_bins: int, adaptive: bool) -> Sequence[np.ndarray]:
    confidence = np.asarray(confidence, dtype=np.float64)
    if n_bins < 1:
        raise ValueError("n_bins must be positive")
    if adaptive:
        order = np.argsort(confidence, kind="mergesort")
        return [part for part in np.array_split(order, n_bins) if len(part)]
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    bin_id = np.digitize(confidence, edges[1:-1], right=True)
    return [np.flatnonzero(bin_id == index) for index in range(n_bins)]


def expected_calibration_error(
    confidence: np.ndarray,
    outcome: np.ndarray,
    n_bins: int = 15,
    adaptive: bool = False,
) -> float:
    """Fixed-width ECE or equal-frequency adaptive ECE."""

    confidence = np.asarray(confidence, dtype=np.float64)
    outcome = np.asarray(outcome, dtype=np.float64)
    if confidence.shape != outcome.shape:
        raise ValueError("confidence and outcome must have identical shapes")
    total = max(len(confidence), 1)
    ece = 0.0
    for index in _bin_indices(confidence, n_bins, adaptive):
        if len(index):
            ece += len(index) / total * abs(outcome[index].mean() - confidence[index].mean())
    return float(ece)


def classwise_ece(
    probs: np.ndarray,
    labels: np.ndarray,
    n_bins: int = 15,
    adaptive: bool = False,
) -> Tuple[float, np.ndarray]:
    """Mean one-vs-rest ECE and the per-class ECE vector."""

    probs = np.asarray(probs, dtype=np.float64)
    labels = np.asarray(labels)
    values = np.asarray(
        [
            expected_calibration_error(
                probs[:, class_id], (labels == class_id).astype(float), n_bins, adaptive
            )
            for class_id in range(probs.shape[1])
        ]
    )
    return float(values.mean()), values


def negative_log_likelihood(probs: np.ndarray, labels: np.ndarray) -> float:
    probs = np.asarray(probs, dtype=np.float64)
    labels = np.asarray(labels, dtype=int)
    return float(-np.log(np.clip(probs[np.arange(len(labels)), labels], 1e-12, 1.0)).mean())


def multiclass_brier(probs: np.ndarray, labels: np.ndarray) -> float:
    probs = np.asarray(probs, dtype=np.float64)
    labels = np.asarray(labels, dtype=int)
    one_hot = np.eye(probs.shape[1], dtype=np.float64)[labels]
    return float(np.square(probs - one_hot).sum(axis=1).mean())


def calibration_metrics(
    logits: np.ndarray,
    labels: np.ndarray,
    n_bins: int = 15,
) -> Dict[str, Any]:
    """Raw calibration metrics including fixed, adaptive and classwise ECE."""

    probs = _softmax_np(logits)
    predictions = probs.argmax(axis=1)
    confidence = probs.max(axis=1)
    correct = (predictions == labels).astype(float)
    cw_fixed, per_class_fixed = classwise_ece(probs, labels, n_bins, adaptive=False)
    cw_adaptive, per_class_adaptive = classwise_ece(probs, labels, n_bins, adaptive=True)
    return {
        "ece_fixed": expected_calibration_error(confidence, correct, n_bins, adaptive=False),
        "ece_adaptive": expected_calibration_error(confidence, correct, n_bins, adaptive=True),
        "classwise_ece_fixed": cw_fixed,
        "classwise_ece_adaptive": cw_adaptive,
        "per_class_ece_fixed": per_class_fixed,
        "per_class_ece_adaptive": per_class_adaptive,
        "nll": negative_log_likelihood(probs, labels),
        "brier": multiclass_brier(probs, labels),
        "accuracy": float(correct.mean()),
    }


def calibration_report(
    test_logits: np.ndarray,
    test_labels: np.ndarray,
    validation_logits: Optional[np.ndarray] = None,
    validation_labels: Optional[np.ndarray] = None,
    temperature: Optional[float] = None,
    n_bins: int = 15,
) -> Dict[str, Any]:
    """Side-by-side raw and temperature-scaled (TS) calibration report."""

    if temperature is None:
        if validation_logits is None or validation_labels is None:
            raise ValueError("provide temperature or validation logits/labels")
        scaler = TemperatureScaler.fit(validation_logits, validation_labels)
    else:
        if temperature <= 0:
            raise ValueError("temperature must be positive")
        scaler = TemperatureScaler(float(temperature))
    return {
        "temperature": scaler.temperature,
        "raw": calibration_metrics(test_logits, test_labels, n_bins=n_bins),
        "temperature_scaled": calibration_metrics(
            scaler.transform_logits(test_logits), test_labels, n_bins=n_bins
        ),
    }


def risk_coverage_curve(
    correct: np.ndarray, confidence: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Coverage, selective risk and stable confidence order."""

    correct = np.asarray(correct, dtype=float)
    confidence = np.asarray(confidence, dtype=float)
    if correct.shape != confidence.shape or correct.ndim != 1:
        raise ValueError("correct and confidence must be aligned vectors")
    order = np.argsort(-confidence, kind="mergesort")
    errors = 1.0 - correct[order]
    accepted = np.arange(1, len(errors) + 1)
    coverage = accepted / max(len(errors), 1)
    risk = np.cumsum(errors) / accepted
    return coverage, risk, order


def selective_metrics(
    probs: np.ndarray,
    labels: np.ndarray,
    coverages: Sequence[float] = (1.0, 0.9, 0.8, 0.5),
    risk_targets: Sequence[float] = (0.01, 0.05, 0.10),
    confidence: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """AURC plus operating points at fixed coverage and fixed empirical risk."""

    probs = np.asarray(probs, dtype=np.float64)
    labels = np.asarray(labels, dtype=int)
    predictions = probs.argmax(axis=1)
    if confidence is None:
        confidence = probs.max(axis=1)
    confidence = np.asarray(confidence, dtype=np.float64)
    correct = (predictions == labels).astype(float)
    coverage_curve, risk_curve, order = risk_coverage_curve(correct, confidence)
    aurc = float(risk_curve.mean())
    error_rate = float(1.0 - correct.mean())
    optimal_aurc = error_rate + (1.0 - error_rate) * np.log(max(1.0 - error_rate, 1e-12))

    fixed_coverage: Dict[str, Dict[str, float | int]] = {}
    for requested in coverages:
        if not 0 < requested <= 1:
            raise ValueError("fixed coverages must lie in (0,1]")
        count = max(1, min(len(labels), int(np.ceil(requested * len(labels)))))
        chosen = order[:count]
        fixed_coverage[f"{requested:.6g}"] = {
            "requested_coverage": float(requested),
            "coverage": float(count / len(labels)),
            "risk": float(1.0 - correct[chosen].mean()),
            "accuracy": float(correct[chosen].mean()),
            "threshold": float(confidence[chosen[-1]]),
            "n_accepted": int(count),
        }

    fixed_risk: Dict[str, Dict[str, float | int]] = {}
    sorted_confidence = confidence[order]
    for requested in risk_targets:
        if not 0 <= requested <= 1:
            raise ValueError("risk targets must lie in [0,1]")
        eligible = np.flatnonzero(risk_curve <= requested)
        if len(eligible):
            index = int(eligible[-1])
            fixed_risk[f"{requested:.6g}"] = {
                "requested_risk": float(requested),
                "coverage": float(coverage_curve[index]),
                "risk": float(risk_curve[index]),
                "threshold": float(sorted_confidence[index]),
                "n_accepted": int(index + 1),
            }
        else:
            fixed_risk[f"{requested:.6g}"] = {
                "requested_risk": float(requested),
                "coverage": 0.0,
                "risk": float("nan"),
                "threshold": float("inf"),
                "n_accepted": 0,
            }
    return {
        "aurc": aurc,
        "eaurc": float(aurc - optimal_aurc),
        "coverage_curve": coverage_curve,
        "risk_curve": risk_curve,
        "fixed_coverage": fixed_coverage,
        "fixed_risk": fixed_risk,
    }


@dataclass
class BootstrapResult:
    observed: float
    lower: float
    upper: float
    samples: np.ndarray
    confidence_level: float
    n_bootstrap: int
    n_patients: int
    p_two_sided_zero: Optional[float] = None


def patient_bootstrap(
    patient_ids: np.ndarray,
    statistic: Callable[[np.ndarray], float],
    n_bootstrap: int = 2000,
    confidence_level: float = 0.95,
    seed: int = 2026,
) -> BootstrapResult:
    """Patient/subject-cluster percentile bootstrap for an arbitrary statistic.

    ``statistic`` receives record indices.  Sampling a patient twice duplicates
    all of that patient's records, which is required for a true cluster
    bootstrap rather than a record-level approximation.
    """

    patient_ids = np.asarray(patient_ids)
    if patient_ids.ndim != 1 or len(patient_ids) == 0:
        raise ValueError("patient_ids must be a non-empty vector")
    if n_bootstrap < 1 or not 0 < confidence_level < 1:
        raise ValueError("invalid bootstrap count or confidence level")
    unique_patients = np.unique(patient_ids)
    groups = [np.flatnonzero(patient_ids == patient) for patient in unique_patients]
    observed = float(statistic(np.arange(len(patient_ids))))
    rng = np.random.default_rng(seed)
    samples = np.empty(n_bootstrap, dtype=np.float64)
    for index in range(n_bootstrap):
        chosen = rng.integers(0, len(groups), size=len(groups))
        record_indices = np.concatenate([groups[group_index] for group_index in chosen])
        samples[index] = float(statistic(record_indices))
    alpha = 1.0 - confidence_level
    lower, upper = np.quantile(samples, (alpha / 2.0, 1.0 - alpha / 2.0))
    p_zero = float(min(1.0, 2.0 * min(np.mean(samples <= 0), np.mean(samples >= 0))))
    return BootstrapResult(
        observed=observed,
        lower=float(lower),
        upper=float(upper),
        samples=samples,
        confidence_level=float(confidence_level),
        n_bootstrap=int(n_bootstrap),
        n_patients=int(len(unique_patients)),
        p_two_sided_zero=p_zero,
    )


def paired_patient_bootstrap(
    patient_ids: np.ndarray,
    statistic_a: Callable[[np.ndarray], float],
    statistic_b: Callable[[np.ndarray], float],
    n_bootstrap: int = 2000,
    confidence_level: float = 0.95,
    seed: int = 2026,
) -> BootstrapResult:
    """Paired patient bootstrap for ``statistic_a - statistic_b``."""

    return patient_bootstrap(
        patient_ids,
        lambda indices: statistic_a(indices) - statistic_b(indices),
        n_bootstrap=n_bootstrap,
        confidence_level=confidence_level,
        seed=seed,
    )


__all__ = [
    "BASELINE_MANIFEST",
    "OOD_SCORE_DIRECTION",
    "RevisionTrustModel",
    "TMCAdapter",
    "TMDFAdapter",
    "dirichlet_to_subjective_opinion",
    "tmc_ds_combine_two",
    "tmc_ds_combine",
    "dynamic_evidential_fusion",
    "SharedBackboneClassifier",
    "ResNet1D",
    "MLPEncoder",
    "edl_loss",
    "revision_training_loss",
    "tmc_training_loss",
    "predict_revision",
    "msp_ood_score",
    "energy_ood_score",
    "entropy_ood_score",
    "odin_ood_score",
    "extract_features_logits",
    "MahalanobisState",
    "fit_mahalanobis",
    "mahalanobis_ood_score",
    "combine_source_ood_scores",
    "ViMState",
    "fit_vim",
    "vim_ood_score",
    "KNNState",
    "fit_knn",
    "knn_ood_score",
    "DICEState",
    "fit_dice",
    "dice_logits",
    "dice_ood_score",
    "gen_ood_score",
    "fpr_at_tpr",
    "ood_metrics",
    "TemperatureScaler",
    "expected_calibration_error",
    "classwise_ece",
    "calibration_metrics",
    "calibration_report",
    "risk_coverage_curve",
    "selective_metrics",
    "BootstrapResult",
    "patient_bootstrap",
    "paired_patient_bootstrap",
]
