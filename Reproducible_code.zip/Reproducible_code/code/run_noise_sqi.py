#!/usr/bin/env python3
"""Leakage-free noise, SQI-gating and selective-prediction experiments.

This runner is intentionally separate from the originally submitted code.  It
trains (or safely reloads) compact closed-set PTB-XL checkpoints, then performs
the reviewer-requested acquisition-noise and SQI analyses under one protocol:

* official folds 1--8 train, fold 9 validation/selection, fold 10 test;
* no threshold, normalizer, covariance, coefficient, or epoch is selected on
  fold 10;
* the same deterministic base corruption is rescaled across all SNRs, so the
  dose-response curve is paired within record and seed;
* SQI6, quality, HRV8, and spec36 are recomputed from every noisy ECG; HRV
  missing values use medians fixed on clean folds 1--8 only;
* all rejection scores use one direction: larger means reject / more OOD;
* completed seed outputs and model checkpoints are atomic and resumable.

The legacy Paper46 noise helper is not imported.  It retained clean HRV/spec
under waveform corruption, used a new random draw at every SNR, and its
zero-phase 50-Hz sine is numerically zero at 100 Hz.  Here the 50-Hz component
has a random phase, and all sources derived from the ECG are recomputed.

Canonical example (three seeds, 40 epochs, all requested analyses)::

    python run_noise_sqi.py --seeds 7,13,42

Fast remote smoke (explicitly non-canonical)::

    python run_noise_sqi.py --smoke --device cuda

The script writes only compact JSON/NPZ results and compressed state-dict NPZ
checkpoints.  It never writes a waveform cache and never modifies ``code/``.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import platform
import random
import time
from collections import OrderedDict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, MutableMapping, Sequence

import numpy as np
import pandas as pd
import scipy
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import stats as scipy_stats
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score

import data_adapter as D
import revisionlib as R


SCRIPT_VERSION = "paper46-noise-sqi-v1"
DEFAULT_SEEDS = (7, 13, 42)
DEFAULT_SNRS: tuple[float | None, ...] = (None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0)
SOURCE_ORDER = ("ecg", "hrv", "spec", "sqi")
SQI_NAMES = tuple(D.SQI_NAMES)
CANONICAL_QUALITY_COEFFICIENTS = np.asarray(
    (0.2, 0.0, 0.5, 0.3, -0.5, -0.5), dtype=np.float64
)
QUALITY_INTERCEPT = -0.3
QUALITY_SLOPE = 6.0
_READONLY_FILE_HASH_CACHE: dict[str, str] = {}


class RunnerError(RuntimeError):
    """Raised when an existing artefact or experiment protocol is unsafe."""


@dataclass(frozen=True)
class QualityConfig:
    name: str
    coefficients: tuple[float, float, float, float, float, float]
    description: str
    family: str
    degenerate_with: str | None = None


@dataclass(frozen=True)
class ModelConfig:
    name: str
    family: str
    sqi_source: bool = True
    quality_gate: bool = True
    quality_config: str = "canonical"
    analysis_role: str = "primary"

    @property
    def gate_mode(self) -> str:
        return "both" if self.quality_gate else "uncertainty_only"


class IndexedSignalRows:
    """Local-row indexing over the adapter's read-only waveform mmap."""

    def __init__(self, signals: D.MillivoltSignalView, global_indices: np.ndarray):
        self.signals = signals
        self.global_indices = np.asarray(global_indices, dtype=np.int64)

    def __len__(self) -> int:
        return len(self.global_indices)

    def __getitem__(self, key: Any) -> np.ndarray:
        return self.signals[self.global_indices[key]]


def utc_timestamp() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = False


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [jsonable(item) for item in value]
    if hasattr(value, "__dataclass_fields__"):
        return jsonable(asdict(value))
    return value


def canonical_json_bytes(payload: Any) -> bytes:
    return json.dumps(
        jsonable(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_readonly_file_once(path: str | Path) -> str:
    resolved = str(Path(path).resolve())
    if resolved not in _READONLY_FILE_HASH_CACHE:
        _READONLY_FILE_HASH_CACHE[resolved] = sha256_file(resolved)
    return _READONLY_FILE_HASH_CACHE[resolved]


def sha256_array(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(array)
    return hashlib.sha256(memoryview(contiguous).cast("B")).hexdigest()


def sha256_string_sequence(values: Sequence[Any]) -> str:
    digest = hashlib.sha256()
    for value in values:
        encoded = str(value).encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "little"))
        digest.update(encoded)
    return digest.hexdigest()


def fingerprint(payload: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def atomic_json(payload: Any, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                jsonable(payload), handle, indent=2, sort_keys=True, ensure_ascii=False,
                allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(target: Path, arrays: Mapping[str, np.ndarray]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def parse_ints(text: str) -> tuple[int, ...]:
    try:
        values = tuple(int(item.strip()) for item in text.split(",") if item.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated integers") from exc
    if not values:
        raise argparse.ArgumentTypeError("at least one integer is required")
    if any(value < 0 or value >= 2**32 for value in values):
        raise argparse.ArgumentTypeError("seeds must lie in [0, 2**32)")
    return values


def parse_percentages(text: str) -> tuple[float, ...]:
    try:
        values = tuple(float(item.strip()) for item in text.split(",") if item.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated percentages") from exc
    if not values or any(
        not math.isfinite(value) or value <= 0.0 or value >= 100.0 for value in values
    ):
        raise argparse.ArgumentTypeError("percentages must lie strictly between 0 and 100")
    return values


def parse_probabilities(text: str) -> tuple[float, ...]:
    values = parse_percentages(text)
    return tuple(value / 100.0 for value in values)


def parse_snrs(text: str) -> tuple[float | None, ...]:
    values: list[float | None] = []
    for token in (part.strip().lower() for part in text.split(",")):
        if not token:
            continue
        if token == "clean":
            value: float | None = None
        else:
            try:
                value = float(token)
            except ValueError as exc:
                raise argparse.ArgumentTypeError(f"invalid SNR {token!r}") from exc
            if not math.isfinite(value):
                raise argparse.ArgumentTypeError("SNR values must be finite")
        if value not in values:
            values.append(value)
    if not values:
        raise argparse.ArgumentTypeError("at least one SNR is required")
    if None not in values:
        values.insert(0, None)
    else:
        values.remove(None)
        values.insert(0, None)
    return tuple(values)


def snr_label(snr: float | None) -> str:
    if snr is None:
        return "clean"
    return f"{snr:g}dB"


def stable_seed(seed: int, text: str) -> int:
    digest = hashlib.sha256(f"{seed}:{text}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little") % (2**32)


def quality_configs() -> OrderedDict[str, QualityConfig]:
    result: OrderedDict[str, QualityConfig] = OrderedDict()
    canonical = tuple(float(value) for value in CANONICAL_QUALITY_COEFFICIENTS)
    result["canonical"] = QualityConfig(
        "canonical", canonical,
        "Paper46 sigmoid quality: sigmoid(6*(c dot SQI - 0.3))", "canonical",
    )
    for index, sqi_name in enumerate(SQI_NAMES):
        for suffix, multiplier in (("minus20", 0.8), ("plus20", 1.2)):
            coefficients = CANONICAL_QUALITY_COEFFICIENTS.copy()
            coefficients[index] *= multiplier
            name = f"coef_{sqi_name}_{suffix}"
            degenerate = "canonical" if CANONICAL_QUALITY_COEFFICIENTS[index] == 0 else None
            result[name] = QualityConfig(
                name,
                tuple(float(value) for value in coefficients),
                f"Inference/retraining sensitivity: {sqi_name} coefficient x {multiplier:g}",
                "individual_plusminus20",
                degenerate_with=degenerate,
            )
    for suffix, multiplier in (("minus20", 0.8), ("plus20", 1.2)):
        values = CANONICAL_QUALITY_COEFFICIENTS * multiplier
        name = f"joint_{suffix}"
        result[name] = QualityConfig(
            name, tuple(float(value) for value in values),
            f"All six canonical coefficients jointly x {multiplier:g}; intercept fixed",
            "joint_plusminus20",
        )
    total_l1 = float(np.abs(CANONICAL_QUALITY_COEFFICIENTS).sum())
    uniform_signs = np.asarray((1.0, -1.0, 1.0, 1.0, -1.0, -1.0))
    uniform = uniform_signs * (total_l1 / len(uniform_signs))
    result["uniform"] = QualityConfig(
        "uniform", tuple(float(value) for value in uniform),
        "Equal absolute coefficients with favorable signs; canonical L1 norm retained",
        "alternative",
    )
    psqi = np.zeros(6, dtype=np.float64)
    psqi[2] = total_l1
    result["psqi_only"] = QualityConfig(
        "psqi_only", tuple(float(value) for value in psqi),
        "pSQI only; coefficient equals canonical total L1 norm; intercept fixed",
        "alternative",
    )
    return result


def quality_from_sqi(sqi: np.ndarray, config: QualityConfig) -> np.ndarray:
    values = np.asarray(sqi, dtype=np.float64).copy()
    if values.ndim != 2 or values.shape[1] != 6:
        raise ValueError(f"SQI must have shape (N,6), got {values.shape}")
    # This is the only nonlinear per-component transform in the submitted rule.
    values[:, 0] = np.clip(values[:, 0], 0.0, 1.0)
    coefficients = np.asarray(config.coefficients, dtype=np.float64)
    linear = values @ coefficients + QUALITY_INTERCEPT
    quality = 1.0 / (1.0 + np.exp(-QUALITY_SLOPE * linear))
    return quality.astype(np.float32)


def source_specs() -> OrderedDict[str, dict[str, Any]]:
    return OrderedDict(
        (
            ("ecg", {"type": "wave", "in": 12, "quality_key": "ecg_q"}),
            ("hrv", {"type": "vec", "in": 8, "quality_key": "ecg_q"}),
            ("spec", {"type": "vec", "in": 36, "quality_key": "ecg_q"}),
            ("sqi", {"type": "vec", "in": 6, "quality_key": "ecg_q"}),
        )
    )


def build_model(config: ModelConfig, n_classes: int) -> nn.Module:
    specs = source_specs()
    if config.family == "trust":
        return R.RevisionTrustModel(
            specs,
            n_classes,
            pooling="cumulative",
            branch="both",
            gate_mode=config.gate_mode,
            sqi_source=config.sqi_source,
            missing_quality="error" if config.quality_gate else "ones",
        )
    if config.family == "softmax":
        return R.SharedBackboneClassifier(specs, n_classes)
    raise ValueError(f"unsupported model family {config.family!r}")


def model_configs(args: argparse.Namespace, qconfigs: Mapping[str, QualityConfig]) -> list[ModelConfig]:
    configs = [
        ModelConfig("trust_full", "trust", True, True, "canonical", "primary"),
        ModelConfig("softmax_modular", "softmax", True, False, "canonical", "baseline"),
    ]
    if args.run_2x2:
        configs.extend(
            (
                ModelConfig("sqi_source0_gate0", "trust", False, False, "canonical", "2x2"),
                ModelConfig("sqi_source0_gate1", "trust", False, True, "canonical", "2x2"),
                ModelConfig("sqi_source1_gate0", "trust", True, False, "canonical", "2x2"),
            )
        )
    if args.sqi_sensitivity in ("retrained", "both"):
        for name in args.retrain_sqi_configs:
            if name not in qconfigs:
                raise RunnerError(f"unknown retrained SQI config {name!r}")
            if name == "canonical":
                continue
            if qconfigs[name].degenerate_with is not None:
                continue
            configs.append(
                ModelConfig(
                    f"trust_qretrain__{name}", "trust", True, True, name,
                    "retrained_sqi_sensitivity",
                )
            )
    unique: OrderedDict[str, ModelConfig] = OrderedDict((item.name, item) for item in configs)
    return list(unique.values())


def deterministic_limit(indices: np.ndarray, limit: int | None, seed: int) -> np.ndarray:
    indices = np.asarray(indices, dtype=np.int64)
    if limit is None or limit <= 0 or len(indices) <= limit:
        return indices
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(indices, size=limit, replace=False))


def deterministic_stratified_limit(
    indices: np.ndarray, labels: np.ndarray, limit: int | None, seed: int
) -> np.ndarray:
    indices = np.asarray(indices, dtype=np.int64)
    if limit is None or limit <= 0 or len(indices) <= limit:
        return indices
    present = np.unique(labels[indices])
    if limit < len(present):
        raise RunnerError(f"training limit {limit} is smaller than {len(present)} classes")
    rng = np.random.default_rng(seed)
    mandatory = np.asarray(
        [rng.choice(indices[labels[indices] == class_id]) for class_id in present],
        dtype=np.int64,
    )
    remaining = np.setdiff1d(indices, mandatory, assume_unique=False)
    additional = rng.choice(remaining, size=limit - len(mandatory), replace=False)
    return np.sort(np.r_[mandatory, additional])


def load_protocol(args: argparse.Namespace, seed: int) -> dict[str, Any]:
    adapter = D.open_dataset("ptbxl", args.trustfed_cache, args.cache_dir)
    if adapter.y_trainfreq is None or adapter.label_names is None:
        raise RunnerError("PTB labels are missing; run data_adapter.py --prepare-metadata first")
    adapter_manifest = Path(args.cache_dir) / "ptbxl_adapter_manifest.json"
    if not adapter_manifest.is_file():
        raise RunnerError(f"missing reproducibility manifest: {adapter_manifest}")
    manifest_payload = json.loads(adapter_manifest.read_text(encoding="utf-8"))
    manifest_signal = manifest_payload.get("source", {}).get("signals", {})
    current_signal_path = adapter.signals.path.resolve()
    current_signal_sha256 = sha256_readonly_file_once(current_signal_path)
    expected_signal_sha256 = manifest_signal.get("trustfed_manifest_reported_sha256")
    if not expected_signal_sha256:
        raise RunnerError("adapter manifest lacks the TrustFed full signal SHA256")
    if current_signal_sha256 != expected_signal_sha256:
        raise RunnerError("current PTB signal mmap checksum differs from adapter manifest")
    metadata = adapter.metadata
    folds = pd.to_numeric(metadata["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    labels = np.asarray(adapter.y_trainfreq, dtype=np.int64)
    valid = np.asarray(adapter.valid, dtype=bool)
    train_index = np.flatnonzero(valid & np.isin(folds, np.arange(1, 9)))
    val_index = np.flatnonzero(valid & (folds == 9))
    test_index = np.flatnonzero(valid & (folds == 10))
    train_index = deterministic_stratified_limit(train_index, labels, args.limit_train, seed + 1)
    val_index = deterministic_limit(val_index, args.limit_val, seed + 2)
    test_index = deterministic_limit(test_index, args.limit_test, seed + 3)
    if not len(train_index) or not len(val_index) or not len(test_index):
        raise RunnerError("train/validation/test splits must all be non-empty")
    n_classes = len(adapter.label_names)
    missing = sorted(set(range(n_classes)) - set(np.unique(labels[train_index])))
    if missing:
        raise RunnerError(f"folds 1-8 training split has no records for classes {missing}")
    patient = metadata["patient_id"].astype(str).to_numpy()
    patient_sets = [set(patient[index]) for index in (train_index, val_index, test_index)]
    if patient_sets[0] & patient_sets[1] or patient_sets[0] & patient_sets[2] or patient_sets[1] & patient_sets[2]:
        raise RunnerError("patient leakage across official folds")
    return {
        "adapter": adapter,
        "labels": labels,
        "patient": patient,
        "class_names": list(adapter.label_names),
        "train_index": train_index,
        "val_index": val_index,
        "test_index": test_index,
        "folds": folds,
        "adapter_manifest_sha256": sha256_file(adapter_manifest),
        "signals_sha256": current_signal_sha256,
        "record_id_order_sha256": sha256_string_sequence(metadata["record_id"].astype(str)),
    }


def composite_base_noise(shape: tuple[int, int, int], fs: int, rng: np.random.Generator) -> np.ndarray:
    """Deterministic composite noise before per-record SNR scaling.

    Components mirror the submitted protocol (baseline wander, broadband
    muscle-like noise, powerline, motion random walk).  Unlike the submitted
    helper, the 50-Hz component receives a random phase, so it is not identically
    zero at a 100-Hz sampling rate.
    """

    n_records, n_channels, length = shape
    time_axis = np.arange(length, dtype=np.float32) / np.float32(fs)
    noise = np.zeros(shape, dtype=np.float32)
    baseline_frequency = rng.uniform(0.15, 0.5, size=(n_records, 1, 1))
    baseline_phase = rng.uniform(0.0, 2.0 * np.pi, size=(n_records, 1, 1))
    baseline = np.sin(
        2.0 * np.pi * baseline_frequency * time_axis[None, None, :] + baseline_phase
    ).astype(np.float32)
    noise += baseline
    noise += np.float32(0.5) * rng.standard_normal(shape).astype(np.float32)
    powerline_phase = rng.uniform(0.0, 2.0 * np.pi, size=(n_records, n_channels, 1))
    powerline = np.sin(
        2.0 * np.pi * 50.0 * time_axis[None, None, :] + powerline_phase
    ).astype(np.float32)
    noise += np.float32(0.3) * powerline
    motion = np.cumsum(
        rng.standard_normal(shape).astype(np.float32) * np.float32(0.05), axis=-1
    )
    noise += motion
    return noise


def apply_target_snr(clean: np.ndarray, base_noise: np.ndarray, snr_db: float) -> tuple[np.ndarray, np.ndarray]:
    clean = np.asarray(clean, dtype=np.float32)
    base_noise = np.asarray(base_noise, dtype=np.float32)
    signal_power = np.mean(clean * clean, axis=(1, 2), keepdims=True) + 1e-8
    noise_power = np.mean(base_noise * base_noise, axis=(1, 2), keepdims=True) + 1e-8
    target_noise_power = signal_power / np.float32(10.0 ** (snr_db / 10.0))
    scaled_noise = base_noise * np.sqrt(target_noise_power / noise_power)
    noisy = (clean + scaled_noise).astype(np.float32)
    achieved = 10.0 * np.log10(
        np.maximum(signal_power.reshape(-1), 1e-20)
        / np.maximum(np.mean(scaled_noise * scaled_noise, axis=(1, 2)), 1e-20)
    )
    return noisy, achieved.astype(np.float32)


def derive_features(
    adapter: D.DatasetAdapter,
    indices: np.ndarray,
    *,
    snr: float | None,
    noise_seed: int,
    chunk_size: int,
    include_ecg: bool,
) -> dict[str, Any]:
    """Recompute all ECG-derived sources, in bounded chunks, in row order."""

    indices = np.asarray(indices, dtype=np.int64)
    n = len(indices)
    sqi = np.empty((n, 6), dtype=np.float32)
    hrv = np.empty((n, 8), dtype=np.float32)
    spec = np.empty((n, 36), dtype=np.float32)
    ecg = np.empty((n, D.N_LEADS, D.TARGET_LEN), dtype=np.float32) if include_ecg else None
    achieved_parts: list[np.ndarray] = []
    base_noise_digest = hashlib.sha256()
    rng = np.random.default_rng(noise_seed)
    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        clean = adapter.signals[indices[start:stop]]
        if snr is None:
            signal = clean
        else:
            base_noise = composite_base_noise(tuple(clean.shape), D.TARGET_FS, rng)
            base_noise_digest.update(memoryview(np.ascontiguousarray(base_noise)).cast("B"))
            signal, achieved = apply_target_snr(clean, base_noise, snr)
            achieved_parts.append(achieved)
        sqi[start:stop], _ = D.compute_sqi6(signal, fs=D.TARGET_FS)
        hrv[start:stop] = D.hrv8_chunk(signal, fs=D.TARGET_FS)
        spec[start:stop] = D.spec36_chunk(signal, fs=D.TARGET_FS)
        if ecg is not None:
            ecg[start:stop] = signal
    result = {"sqi": sqi, "hrv": hrv, "spec": spec}
    if ecg is not None:
        result["ecg"] = ecg
    if snr is not None:
        result["achieved_snr"] = np.concatenate(achieved_parts)
        result["base_noise_sha256"] = base_noise_digest.hexdigest()
    return result


def fit_hrv_medians(train_hrv: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    medians = np.empty(train_hrv.shape[1], dtype=np.float32)
    missing_counts = np.empty(train_hrv.shape[1], dtype=np.int64)
    for column in range(train_hrv.shape[1]):
        values = np.asarray(train_hrv[:, column], dtype=np.float32)
        finite = values[np.isfinite(values)]
        medians[column] = np.float32(np.median(finite) if len(finite) else 0.0)
        missing_counts[column] = int(np.sum(~np.isfinite(values)))
    return medians, missing_counts


def impute_hrv(features: MutableMapping[str, np.ndarray], medians: np.ndarray) -> int:
    hrv = np.asarray(features["hrv"], dtype=np.float32)
    missing = ~np.isfinite(hrv)
    rows, columns = np.nonzero(missing)
    if len(rows):
        hrv[rows, columns] = medians[columns]
    features["hrv"] = hrv
    if not np.isfinite(hrv).all():
        raise RunnerError("non-finite HRV remains after train-only imputation")
    if not np.isfinite(features["sqi"]).all() or not np.isfinite(features["spec"]).all():
        raise RunnerError("non-finite SQI/spec feature")
    return int(missing.sum())


def make_arrays(
    adapter: D.DatasetAdapter,
    indices: np.ndarray,
    features: Mapping[str, np.ndarray],
    labels: np.ndarray,
    qconfig: QualityConfig,
) -> dict[str, Any]:
    ecg: Any = features.get("ecg")
    if ecg is None:
        ecg = IndexedSignalRows(adapter.signals, indices)
    return {
        "ecg": ecg,
        "hrv": np.asarray(features["hrv"], dtype=np.float32),
        "spec": np.asarray(features["spec"], dtype=np.float32),
        "sqi": np.asarray(features["sqi"], dtype=np.float32),
        "ecg_q": quality_from_sqi(features["sqi"], qconfig),
        "y": np.asarray(labels[indices], dtype=np.int64),
    }


def input_keys(model: nn.Module, arrays: Mapping[str, Any]) -> tuple[str, ...]:
    names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    keys = list(names)
    if isinstance(model, R.RevisionTrustModel):
        specs = getattr(model, "source_specs", {})
        for name in names:
            quality_key = str(specs.get(name, {}).get("quality_key", f"{name}_q"))
            if quality_key in arrays and quality_key not in keys:
                keys.append(quality_key)
    return tuple(keys)


def tensor_batch(
    arrays: Mapping[str, Any], indices: np.ndarray, keys: Sequence[str], device: torch.device
) -> dict[str, torch.Tensor]:
    result: dict[str, torch.Tensor] = {}
    for key in keys:
        value = torch.as_tensor(np.ascontiguousarray(arrays[key][indices]), device=device)
        if value.is_floating_point():
            value = value.float()
        result[key] = value
    return result


def softmax_numpy(logits: np.ndarray) -> np.ndarray:
    values = np.asarray(logits, dtype=np.float64)
    values = values - values.max(axis=1, keepdims=True)
    probabilities = np.exp(values)
    probabilities /= np.maximum(probabilities.sum(axis=1, keepdims=True), 1e-300)
    return probabilities.astype(np.float32)


def macro_auc(probabilities: np.ndarray, labels: np.ndarray) -> float:
    values = []
    for class_id in range(probabilities.shape[1]):
        truth = labels == class_id
        if truth.any() and (~truth).any():
            values.append(roc_auc_score(truth, probabilities[:, class_id]))
    return float(np.mean(values)) if values else float("nan")


def class_weights(labels: np.ndarray, n_classes: int) -> np.ndarray:
    counts = np.bincount(labels, minlength=n_classes).astype(np.float64)
    values = 1.0 / np.sqrt(counts + 1.0)
    return (values / values.mean()).astype(np.float32)


@torch.no_grad()
def predict_softmax(
    model: nn.Module, arrays: Mapping[str, Any], batch_size: int, device: torch.device
) -> dict[str, np.ndarray]:
    model.eval()
    keys = input_keys(model, arrays)
    n = len(arrays[keys[0]])
    logits: list[np.ndarray] = []
    for start in range(0, n, batch_size):
        indices = np.arange(start, min(start + batch_size, n))
        logits.append(model(tensor_batch(arrays, indices, keys, device)).cpu().numpy())
    joined = np.concatenate(logits)
    probability = softmax_numpy(joined)
    return {
        "logits": joined,
        "prob": probability,
        "pred": probability.argmax(axis=1),
        "conf": probability.max(axis=1),
    }


@torch.no_grad()
def predict_trust(
    model: nn.Module,
    arrays: Mapping[str, Any],
    batch_size: int,
    device: torch.device,
    *,
    collect_features: bool,
) -> dict[str, Any]:
    model.eval()
    keys = input_keys(model, arrays)
    names = tuple(model.source_names)
    collected: dict[str, list[np.ndarray]] = {
        key: [] for key in ("prob", "logits", "u", "source_u", "source_q", "source_w")
    }
    features: dict[str, list[np.ndarray]] = {name: [] for name in names}
    n = len(arrays[names[0]])
    for start in range(0, n, batch_size):
        indices = np.arange(start, min(start + batch_size, n))
        output = model(tensor_batch(arrays, indices, keys, device))
        for key in collected:
            collected[key].append(output[key].detach().cpu().numpy())
        if collect_features:
            for name in names:
                features[name].append(output["per"][name]["h"].detach().cpu().numpy())
    result: dict[str, Any] = {
        key: np.concatenate(parts, axis=0) for key, parts in collected.items()
    }
    result["u"] = result["u"].reshape(-1)
    result["pred"] = result["prob"].argmax(axis=1)
    result["conf"] = result["prob"].max(axis=1)
    result["source_names"] = names
    if collect_features:
        result["features"] = {
            name: np.concatenate(parts, axis=0) for name, parts in features.items()
        }
    return result


def predict_model(
    model: nn.Module,
    config: ModelConfig,
    arrays: Mapping[str, Any],
    batch_size: int,
    device: torch.device,
    *,
    collect_features: bool = False,
) -> dict[str, Any]:
    if config.family == "softmax":
        return predict_softmax(model, arrays, batch_size, device)
    return predict_trust(
        model, arrays, batch_size, device, collect_features=collect_features
    )


def training_loss(
    output: Any,
    config: ModelConfig,
    targets: torch.Tensor,
    epoch: int,
    weight: torch.Tensor,
) -> torch.Tensor:
    if config.family == "softmax":
        return F.cross_entropy(output, targets, weight=weight)
    kl_weight = 0.05 * min(1.0, (epoch + 1) / 10.0)
    return R.revision_training_loss(
        output,
        targets,
        kl_weight=kl_weight,
        ce_weight=0.5,
        deep_supervision_weight=0.3,
        complementarity_weight=0.1,
        class_weights=weight,
    )


def train_model(
    model: nn.Module,
    config: ModelConfig,
    train: Mapping[str, Any],
    validation: Mapping[str, Any],
    n_classes: int,
    args: argparse.Namespace,
    seed: int,
    device: torch.device,
) -> tuple[nn.Module, dict[str, Any]]:
    set_seed(seed)
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=1e-4
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(args.epochs, 1)
    )
    weight = torch.as_tensor(class_weights(train["y"], n_classes), device=device)
    keys = input_keys(model, train)
    best_score = -float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    history: list[dict[str, Any]] = []
    started = time.time()
    for epoch in range(args.epochs):
        model.train()
        permutation = np.random.permutation(len(train["y"]))
        total_loss = 0.0
        n_batches = 0
        for start in range(0, len(permutation), args.batch_size):
            indices = permutation[start : start + args.batch_size]
            # BatchNorm cannot train on a singleton final batch.
            if len(indices) == 1:
                continue
            batch = tensor_batch(train, indices, keys, device)
            targets = torch.as_tensor(train["y"][indices], dtype=torch.long, device=device)
            output = model(batch)
            loss = training_loss(output, config, targets, epoch, weight)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total_loss += float(loss.detach().cpu())
            n_batches += 1
        scheduler.step()
        validation_raw = predict_model(
            model, config, validation, args.eval_batch_size, device
        )
        score = macro_auc(validation_raw["prob"], validation["y"])
        if not math.isfinite(score):
            score = float(accuracy_score(validation["y"], validation_raw["pred"]))
        if score > best_score:
            best_score = score
            best_state = {
                name: value.detach().cpu().clone()
                for name, value in model.state_dict().items()
            }
        record = {
            "epoch": epoch + 1,
            "loss": total_loss / max(n_batches, 1),
            "val_macro_auroc": score,
            "val_accuracy": float(accuracy_score(validation["y"], validation_raw["pred"])),
            "elapsed_seconds": time.time() - started,
        }
        history.append(record)
        print(
            f"[{config.name} seed={seed}] epoch {epoch + 1:02d}/{args.epochs} "
            f"loss={record['loss']:.4f} val_auc={score:.4f}",
            flush=True,
        )
    if best_state is None:
        raise RunnerError("training produced no non-singleton batch")
    model.load_state_dict(best_state, strict=True)
    return model, {
        "best_val_macro_auroc": best_score,
        "history": history,
        "train_seconds": time.time() - started,
        "selection": "maximum fold-9 macro-AUROC; fold 10 never inspected",
    }


def checkpoint_paths(root: Path, config: ModelConfig, seed: int) -> tuple[Path, Path]:
    directory = root / config.name
    return directory / f"seed_{seed}.npz", directory / f"seed_{seed}.json"


def checkpoint_root(args: argparse.Namespace) -> Path:
    return Path(args.checkpoint_dir) / ("smoke" if args.smoke else "canonical")


def save_checkpoint(
    model: nn.Module,
    config: ModelConfig,
    seed: int,
    checkpoint_fingerprint: str,
    checkpoint_provenance: Mapping[str, Any],
    training: Mapping[str, Any],
    root: Path,
) -> None:
    npz_path, json_path = checkpoint_paths(root, config, seed)
    state_arrays = {
        f"state::{name}": value.detach().cpu().numpy()
        for name, value in model.state_dict().items()
    }
    state_arrays["checkpoint_fingerprint"] = np.asarray(checkpoint_fingerprint)
    atomic_npz(npz_path, state_arrays)
    atomic_json(
        {
            "status": "complete",
            "checkpoint_fingerprint": checkpoint_fingerprint,
            "checkpoint_provenance": checkpoint_provenance,
            "model": asdict(config),
            "seed": seed,
            "training": training,
            "weights_sha256": sha256_file(npz_path),
            "format": "allow_pickle=False compressed NumPy state_dict",
        },
        json_path,
    )


def load_checkpoint(
    config: ModelConfig,
    seed: int,
    n_classes: int,
    expected_fingerprint: str,
    root: Path,
    device: torch.device,
) -> tuple[nn.Module, dict[str, Any]]:
    npz_path, json_path = checkpoint_paths(root, config, seed)
    if not npz_path.is_file() or not json_path.is_file():
        raise FileNotFoundError(f"incomplete checkpoint pair for {config.name} seed={seed}")
    metadata = json.loads(json_path.read_text(encoding="utf-8"))
    if metadata.get("status") != "complete":
        raise RunnerError(f"checkpoint is not marked complete: {json_path}")
    if metadata.get("checkpoint_fingerprint") != expected_fingerprint:
        raise RunnerError(
            f"checkpoint fingerprint mismatch for {config.name} seed={seed}; use --force"
        )
    if metadata.get("weights_sha256") != sha256_file(npz_path):
        raise RunnerError(f"checkpoint checksum mismatch: {npz_path}")
    model = build_model(config, n_classes)
    with np.load(npz_path, allow_pickle=False) as payload:
        stored = str(payload["checkpoint_fingerprint"].item())
        if stored != expected_fingerprint:
            raise RunnerError(f"checkpoint NPZ fingerprint mismatch: {npz_path}")
        state = {
            name[len("state::") :]: torch.from_numpy(np.array(payload[name]))
            for name in payload.files
            if name.startswith("state::")
        }
    model.load_state_dict(state, strict=True)
    model.to(device)
    model.eval()
    return model, metadata


def train_or_load_checkpoint(
    config: ModelConfig,
    seed: int,
    protocol: Mapping[str, Any],
    clean_features: Mapping[str, Mapping[str, np.ndarray]],
    qconfigs: Mapping[str, QualityConfig],
    args: argparse.Namespace,
    device: torch.device,
) -> dict[str, Any]:
    checkpoint_payload = {
        "training_protocol_version": SCRIPT_VERSION,
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "revisionlib_sha256": sha256_file(Path(R.__file__).resolve()),
        "data_adapter_sha256": sha256_file(Path(D.__file__).resolve()),
        "ptbxl_adapter_manifest_sha256": protocol["adapter_manifest_sha256"],
        "signals_sha256": protocol["signals_sha256"],
        "record_id_order_sha256": protocol["record_id_order_sha256"],
        "train_index_sha256": sha256_array(protocol["train_index"]),
        "val_index_sha256": sha256_array(protocol["val_index"]),
        "labels_sha256": sha256_array(protocol["labels"]),
        "model": asdict(config),
        "quality_rule": asdict(qconfigs[config.quality_config]),
        "seed": seed,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "n_classes": len(protocol["class_names"]),
        "class_names": protocol["class_names"],
    }
    checkpoint_fingerprint = fingerprint(checkpoint_payload)
    root = checkpoint_root(args)
    npz_path, json_path = checkpoint_paths(root, config, seed)
    if npz_path.is_file() and json_path.is_file() and not args.force:
        metadata = json.loads(json_path.read_text(encoding="utf-8"))
        if metadata.get("checkpoint_fingerprint") != checkpoint_fingerprint:
            raise RunnerError(
                f"checkpoint fingerprint mismatch for {config.name} seed={seed}; use --force"
            )
        try:
            _, metadata = load_checkpoint(
                config, seed, len(protocol["class_names"]), checkpoint_fingerprint, root, device
            )
        except RunnerError as exc:
            print(f"[recover] invalid same-generation checkpoint; retraining: {exc}", flush=True)
        else:
            print(f"[resume] checkpoint {config.name} seed={seed}", flush=True)
            return {
                "status": "reused",
                "checkpoint_fingerprint": checkpoint_fingerprint,
                "training": metadata.get("training", {}),
            }

    qconfig = qconfigs[config.quality_config]
    adapter: D.DatasetAdapter = protocol["adapter"]
    labels = protocol["labels"]
    train = make_arrays(
        adapter, protocol["train_index"], clean_features["train"], labels, qconfig
    )
    validation = make_arrays(
        adapter, protocol["val_index"], clean_features["validation"], labels, qconfig
    )
    set_seed(seed)
    model = build_model(config, len(protocol["class_names"]))
    model, training = train_model(
        model, config, train, validation, len(protocol["class_names"]), args, seed, device
    )
    save_checkpoint(
        model, config, seed, checkpoint_fingerprint, checkpoint_payload, training, root
    )
    del model, train, validation
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return {
        "status": "trained",
        "checkpoint_fingerprint": checkpoint_fingerprint,
        "training": training,
    }


def fit_density_state(
    model: nn.Module,
    train: Mapping[str, Any],
    validation: Mapping[str, Any],
    n_classes: int,
    batch_size: int,
    device: torch.device,
) -> dict[str, Any]:
    train_raw = predict_trust(
        model, train, batch_size, device, collect_features=True
    )
    val_raw = predict_trust(
        model, validation, batch_size, device, collect_features=True
    )
    states: dict[str, R.MahalanobisState] = {}
    references: dict[str, np.ndarray] = {}
    for name in train_raw["source_names"]:
        state = R.fit_mahalanobis(
            train_raw["features"][name],
            train["y"],
            n_classes=n_classes,
            covariance="ledoit_wolf",
            ridge=1e-3,
            standardize=True,
            min_class_count=2,
        )
        states[name] = state
        references[name] = R.mahalanobis_ood_score(val_raw["features"][name], state)
    vacuity_mean = float(np.mean(val_raw["u"]))
    vacuity_std = float(np.std(val_raw["u"]) + 1e-8)
    return {
        "states": states,
        "references": references,
        "source_names": tuple(train_raw["source_names"]),
        "vacuity_mean": vacuity_mean,
        "vacuity_std": vacuity_std,
        "feature_dim": {
            name: int(train_raw["features"][name].shape[1])
            for name in train_raw["source_names"]
        },
        "class_counts_used": {
            name: int(len(states[name].classes)) for name in train_raw["source_names"]
        },
        "covariance": "LedoitWolf pooled within-class residuals",
        "ridge": 1e-3,
        "standardize": True,
    }


def density_scores(raw: Mapping[str, Any], state: Mapping[str, Any]) -> np.ndarray:
    per_source = {
        name: R.mahalanobis_ood_score(raw["features"][name], state["states"][name])
        for name in state["source_names"]
    }
    return R.combine_source_ood_scores(
        per_source,
        state["source_names"],
        weights=raw["source_w"],
        reference_scores=state["references"],
        normalize_weights=True,
    )


def frozen_primary_components(
    raw: Mapping[str, Any], quality: np.ndarray, state: Mapping[str, Any]
) -> dict[str, np.ndarray]:
    density = density_scores(raw, state)
    vacuity = np.asarray(raw["u"], dtype=np.float64)
    composite = (
        (vacuity - state["vacuity_mean"]) / state["vacuity_std"] + density
    )
    return {
        "sqi_only": 1.0 - np.asarray(quality, dtype=np.float64),
        "vacuity_only": vacuity,
        "density_only": density,
        "composite": composite,
    }


def fit_sqi_composite_normalizer(components: Mapping[str, np.ndarray]) -> dict[str, float]:
    return {
        "sqi_mean": float(np.mean(components["sqi_only"])),
        "sqi_std": float(np.std(components["sqi_only"]) + 1e-8),
        "composite_mean": float(np.mean(components["composite"])),
        "composite_std": float(np.std(components["composite"]) + 1e-8),
    }


def add_sqi_composite(
    components: Mapping[str, np.ndarray], normalizer: Mapping[str, float]
) -> dict[str, np.ndarray]:
    result = {name: np.asarray(value) for name, value in components.items()}
    result["sqi_plus_composite"] = (
        (result["sqi_only"] - normalizer["sqi_mean"]) / normalizer["sqi_std"]
        + (result["composite"] - normalizer["composite_mean"])
        / normalizer["composite_std"]
    )
    return result


def classification_report(
    probabilities: np.ndarray, labels: np.ndarray, rare_ids: np.ndarray
) -> dict[str, Any]:
    prediction = probabilities.argmax(axis=1)
    n_classes = probabilities.shape[1]
    return {
        "accuracy": float(accuracy_score(labels, prediction)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, prediction)),
        "macro_f1": float(
            f1_score(
                labels, prediction, labels=np.arange(n_classes), average="macro", zero_division=0
            )
        ),
        "rare_macro_f1": float(
            f1_score(labels, prediction, labels=rare_ids, average="macro", zero_division=0)
        )
        if len(rare_ids)
        else None,
    }


def safe_spearman(left: np.ndarray, right: np.ndarray) -> dict[str, Any]:
    left = np.asarray(left).reshape(-1)
    right = np.asarray(right).reshape(-1)
    if len(left) != len(right) or len(left) < 3 or np.std(left) == 0 or np.std(right) == 0:
        return {"rho": None, "pvalue": None, "n": int(min(len(left), len(right)))}
    result = scipy_stats.spearmanr(left, right)
    return {"rho": float(result.statistic), "pvalue": float(result.pvalue), "n": len(left)}


def gate_correlation_report(
    raw: Mapping[str, Any], labels: np.ndarray, sqi: np.ndarray, quality: np.ndarray
) -> dict[str, Any]:
    correct = (raw["pred"] == labels).astype(np.float32)
    report: dict[str, Any] = {
        "mean_gate_vs_correctness": safe_spearman(raw["source_w"].mean(axis=1), correct),
        "mean_gate_vs_quality": safe_spearman(raw["source_w"].mean(axis=1), quality),
        "per_source": {},
    }
    for source_index, name in enumerate(raw["source_names"]):
        source_report: dict[str, Any] = {
            "weight_vs_correctness": safe_spearman(raw["source_w"][:, source_index], correct),
            "weight_vs_quality": safe_spearman(raw["source_w"][:, source_index], quality),
            "weight_mean": float(np.mean(raw["source_w"][:, source_index])),
            "weight_std": float(np.std(raw["source_w"][:, source_index])),
            "weight_vs_sqi": {},
        }
        for sqi_index, sqi_name in enumerate(SQI_NAMES):
            source_report["weight_vs_sqi"][sqi_name] = safe_spearman(
                raw["source_w"][:, source_index], sqi[:, sqi_index]
            )
        report["per_source"][name] = source_report
    return report


def acceptance_report(
    probabilities: np.ndarray,
    labels: np.ndarray,
    risk: np.ndarray,
    threshold: float,
    rare_ids: np.ndarray,
) -> dict[str, Any]:
    accept = np.asarray(risk) <= threshold
    reject = ~accept
    prediction = probabilities.argmax(axis=1)
    rare = np.isin(labels, rare_ids)
    payload: dict[str, Any] = {
        "threshold": float(threshold),
        "coverage": float(np.mean(accept)),
        "rejection_rate": float(np.mean(reject)),
        "alarms_per_100_records": float(100.0 * np.mean(reject)),
        "n_accepted": int(accept.sum()),
        "n_rejected": int(reject.sum()),
        "rare_rejection_rate": float(np.mean(reject[rare])) if rare.any() else None,
        "frequent_rejection_rate": float(np.mean(reject[~rare])) if (~rare).any() else None,
    }
    if accept.any():
        payload.update(
            {
                "selective_risk": float(np.mean(prediction[accept] != labels[accept])),
                "balanced_accuracy": float(
                    balanced_accuracy_score(labels[accept], prediction[accept])
                ),
                "macro_f1": float(
                    f1_score(
                        labels[accept],
                        prediction[accept],
                        labels=np.arange(probabilities.shape[1]),
                        average="macro",
                        zero_division=0,
                    )
                ),
            }
        )
    else:
        payload.update(
            {"selective_risk": None, "balanced_accuracy": None, "macro_f1": None}
        )
    return payload


def threshold_at_coverage(risk: np.ndarray, coverage: float) -> float:
    if not 0.0 < coverage <= 1.0:
        raise ValueError("coverage must lie in (0,1]")
    try:
        return float(np.quantile(np.asarray(risk), coverage, method="higher"))
    except TypeError:  # NumPy < 1.22
        return float(np.quantile(np.asarray(risk), coverage, interpolation="higher"))


def threshold_at_risk(
    probabilities: np.ndarray, labels: np.ndarray, risk: np.ndarray, target: float
) -> float:
    if not 0.0 <= target <= 1.0:
        raise ValueError("risk target must lie in [0,1]")
    prediction = probabilities.argmax(axis=1)
    order = np.argsort(risk, kind="mergesort")
    sorted_risk = np.asarray(risk)[order]
    cumulative_errors = np.cumsum(prediction[order] != labels[order])
    # A portable scalar threshold necessarily accepts every tied score.  Select
    # only at complete tie-group boundaries so the advertised fold-9 risk is
    # never made optimistic by silently truncating a tie group.
    group_ends = np.flatnonzero(
        np.r_[sorted_risk[1:] != sorted_risk[:-1], True]
    )
    group_risk = cumulative_errors[group_ends] / (group_ends + 1)
    eligible = group_ends[group_risk <= target]
    if not len(eligible):
        return -float("inf")
    return float(sorted_risk[int(eligible[-1])])


def validation_selected_operating_report(
    val_probability: np.ndarray,
    val_labels: np.ndarray,
    val_risk: np.ndarray,
    test_probability: np.ndarray,
    test_labels: np.ndarray,
    test_risk: np.ndarray,
    rare_ids: np.ndarray,
    coverages: Sequence[float],
    risk_targets: Sequence[float],
) -> dict[str, Any]:
    fixed_coverage: dict[str, Any] = {}
    for coverage in coverages:
        threshold = threshold_at_coverage(val_risk, coverage)
        fixed_coverage[f"{coverage:.6g}"] = {
            "selection_split": "fold9",
            "validation": acceptance_report(
                val_probability, val_labels, val_risk, threshold, rare_ids
            ),
            "test": acceptance_report(
                test_probability, test_labels, test_risk, threshold, rare_ids
            ),
        }
    fixed_risk: dict[str, Any] = {}
    for target in risk_targets:
        threshold = threshold_at_risk(val_probability, val_labels, val_risk, target)
        fixed_risk[f"{target:.6g}"] = {
            "selection_split": "fold9",
            "validation": acceptance_report(
                val_probability, val_labels, val_risk, threshold, rare_ids
            ),
            "test": acceptance_report(
                test_probability, test_labels, test_risk, threshold, rare_ids
            ),
        }
    correct = (test_probability.argmax(axis=1) == test_labels).astype(np.float32)
    _, risk_curve, _ = R.risk_coverage_curve(correct, -np.asarray(test_risk))
    return {
        "aurc_ranking_only": float(np.mean(risk_curve)),
        "fixed_coverage": fixed_coverage,
        "coverage_at_fixed_risk": fixed_risk,
    }


def score_method_report(
    current_val: Mapping[str, Any],
    current_test: Mapping[str, Any],
    clean_val: Mapping[str, Any],
    method: str,
    rare_ids: np.ndarray,
    args: argparse.Namespace,
) -> dict[str, Any]:
    condition_selected = validation_selected_operating_report(
        current_val["prob"], current_val["y"], current_val["scores"][method],
        current_test["prob"], current_test["y"], current_test["scores"][method],
        rare_ids, args.fixed_coverages, args.risk_targets,
    )
    clean_selected = validation_selected_operating_report(
        clean_val["prob"], clean_val["y"], clean_val["scores"][method],
        current_test["prob"], current_test["y"], current_test["scores"][method],
        rare_ids, args.fixed_coverages, args.risk_targets,
    )
    q_min_coverages = tuple(1.0 - value / 100.0 for value in args.q_min_percent)
    q_min_matched = validation_selected_operating_report(
        current_val["prob"], current_val["y"], current_val["scores"][method],
        current_test["prob"], current_test["y"], current_test["scores"][method],
        rare_ids, q_min_coverages, (),
    )["fixed_coverage"]
    alarm_threshold = threshold_at_coverage(
        clean_val["scores"][method], args.alarm_quantile
    )
    return {
        "risk_direction": "higher_is_reject",
        "condition_matched_fold9": condition_selected,
        "frozen_clean_fold9": clean_selected,
        "q_min_matched_coverage": {
            f"{q_min:g}%": q_min_matched[f"{1.0 - q_min / 100.0:.6g}"]
            for q_min in args.q_min_percent
        },
        "q_min_definition": (
            "q_min is the target percentage rejected on the same-SNR fold9; every method "
            "is compared at that matched validation coverage"
        ),
        "alarm_burden_frozen_clean_fold9": acceptance_report(
            current_test["prob"], current_test["y"], current_test["scores"][method],
            alarm_threshold, rare_ids,
        ),
        "alarm_quantile": args.alarm_quantile,
    }


def paired_weight_change(
    clean_raw: Mapping[str, Any], changed_raw: Mapping[str, Any]
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for index, name in enumerate(clean_raw["source_names"]):
        delta = changed_raw["source_w"][:, index] - clean_raw["source_w"][:, index]
        scale = float(np.std(delta, ddof=1)) if len(delta) > 1 else 0.0
        result[name] = {
            "clean_mean": float(np.mean(clean_raw["source_w"][:, index])),
            "changed_mean": float(np.mean(changed_raw["source_w"][:, index])),
            "paired_mean_delta": float(np.mean(delta)),
            "paired_median_delta": float(np.median(delta)),
            "paired_cohen_dz": float(np.mean(delta) / scale) if scale > 0 else None,
            "fraction_decreased": float(np.mean(delta < 0)),
        }
    return result


def isolated_source_corruption_report(
    model: nn.Module,
    clean_arrays: Mapping[str, Any],
    noisy_arrays: Mapping[str, Any],
    labels: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> dict[str, Any]:
    clean_raw = predict_trust(
        model, clean_arrays, batch_size, device, collect_features=False
    )
    report: dict[str, Any] = {
        "definition": (
            "Replace one source by its paired noisy-derived value while holding the other "
            "sources and shared quality at clean values; q_only changes only shared quality."
        ),
        "variants": {},
    }
    for source in SOURCE_ORDER:
        if source not in model.source_names:
            continue
        arrays = dict(clean_arrays)
        arrays[source] = noisy_arrays[source]
        changed = predict_trust(model, arrays, batch_size, device, collect_features=False)
        report["variants"][f"source_only:{source}"] = {
            "weight_change": paired_weight_change(clean_raw, changed),
            "diagnosis": classification_report(changed["prob"], labels, np.asarray([], int)),
        }
    q_only = dict(clean_arrays)
    q_only["ecg_q"] = noisy_arrays["ecg_q"]
    q_raw = predict_trust(model, q_only, batch_size, device, collect_features=False)
    report["variants"]["quality_only"] = {
        "weight_change": paired_weight_change(clean_raw, q_raw),
        "diagnosis": classification_report(q_raw["prob"], labels, np.asarray([], int)),
    }
    full_raw = predict_trust(model, noisy_arrays, batch_size, device, collect_features=False)
    report["variants"]["full_acquisition"] = {
        "weight_change": paired_weight_change(clean_raw, full_raw),
        "diagnosis": classification_report(full_raw["prob"], labels, np.asarray([], int)),
    }
    return report


def run_fingerprint_payload(
    args: argparse.Namespace, seed: int, protocol: Mapping[str, Any], models: Sequence[ModelConfig]
) -> dict[str, Any]:
    adapter_manifest = Path(args.cache_dir) / "ptbxl_adapter_manifest.json"
    return {
        "script_version": SCRIPT_VERSION,
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "revisionlib_sha256": sha256_file(Path(R.__file__).resolve()),
        "data_adapter_sha256": sha256_file(Path(D.__file__).resolve()),
        "adapter_manifest_sha256": sha256_file(adapter_manifest)
        if adapter_manifest.is_file()
        else None,
        "signals_sha256": protocol["signals_sha256"],
        "record_id_order_sha256": protocol["record_id_order_sha256"],
        "seed": seed,
        "train_index_sha256": sha256_array(protocol["train_index"]),
        "val_index_sha256": sha256_array(protocol["val_index"]),
        "test_index_sha256": sha256_array(protocol["test_index"]),
        "labels_sha256": sha256_array(protocol["labels"]),
        "class_names": protocol["class_names"],
        "models": [asdict(item) for item in models],
        "training": {
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "learning_rate": args.learning_rate,
        },
        "snrs": [snr_label(value) for value in args.snrs],
        "noise_chunk_size": args.feature_chunk_size,
        "q_min_percent": args.q_min_percent,
        "fixed_coverages": args.fixed_coverages,
        "risk_targets": args.risk_targets,
        "alarm_quantile": args.alarm_quantile,
        "rare_threshold": args.rare_threshold,
        "sqi_sensitivity": args.sqi_sensitivity,
        "retrain_sqi_configs": args.retrain_sqi_configs,
        "run_2x2": args.run_2x2,
        "source_corruption_snr": args.source_corruption_snr,
        "smoke": args.smoke,
    }


def environment_manifest(args: argparse.Namespace, device: torch.device) -> dict[str, Any]:
    return {
        "script_version": SCRIPT_VERSION,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "sklearn": sklearn.__version__,
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "device": str(device),
        "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "arguments": vars(args),
    }


def is_canonical_run(args: argparse.Namespace) -> bool:
    return bool(
        not args.smoke
        and args.epochs == 40
        and args.batch_size == 256
        and args.learning_rate == 1e-3
        and tuple(args.snrs) == DEFAULT_SNRS
        and len(set(args.seeds)) >= 3
        and args.sqi_sensitivity == "both"
        and args.run_2x2
        and tuple(args.retrain_sqi_configs)
        == ("joint_minus20", "joint_plus20", "uniform", "psqi_only")
        and tuple(args.q_min_percent) == (5.0, 10.0, 20.0, 30.0)
    )


def run_seed(args: argparse.Namespace, seed: int, device: torch.device) -> None:
    qconfigs = quality_configs()
    configs = model_configs(args, qconfigs)
    protocol = load_protocol(args, seed)
    run_payload = run_fingerprint_payload(args, seed, protocol, configs)
    run_fingerprint = fingerprint(run_payload)
    output_root = Path(args.results_dir) / ("smoke" if args.smoke else "canonical")
    json_path = output_root / f"seed_{seed}.json"
    raw_path = output_root / f"seed_{seed}_curves.npz"
    if json_path.is_file() and raw_path.is_file() and not args.force:
        existing = json.loads(json_path.read_text(encoding="utf-8"))
        if existing.get("run_fingerprint") != run_fingerprint:
            raise RunnerError(f"existing result fingerprint mismatch: {json_path}; use --force")
        if existing.get("status") != "complete":
            raise RunnerError(f"existing result is not marked complete: {json_path}")
        if existing.get("raw_npz", {}).get("sha256") != sha256_file(raw_path):
            raise RunnerError(f"existing raw NPZ checksum mismatch: {raw_path}")
        print(f"[resume] seed={seed} complete", flush=True)
        return

    print(f"[seed={seed}] recomputing clean fold features", flush=True)
    adapter: D.DatasetAdapter = protocol["adapter"]
    clean_features = {
        "train": derive_features(
            adapter, protocol["train_index"], snr=None,
            noise_seed=stable_seed(seed, "train-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
        "validation": derive_features(
            adapter, protocol["val_index"], snr=None,
            noise_seed=stable_seed(seed, "validation-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
        "test": derive_features(
            adapter, protocol["test_index"], snr=None,
            noise_seed=stable_seed(seed, "test-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
    }
    hrv_medians, train_hrv_missing = fit_hrv_medians(clean_features["train"]["hrv"])
    hrv_imputation = {
        split: impute_hrv(features, hrv_medians)
        for split, features in clean_features.items()
    }

    training_reports: dict[str, Any] = {}
    for config in configs:
        training_reports[config.name] = train_or_load_checkpoint(
            config, seed, protocol, clean_features, qconfigs, args,
            device,
        )

    config_by_name = {config.name: config for config in configs}
    canonical_config = config_by_name["trust_full"]
    canonical_model, _ = load_checkpoint(
        canonical_config,
        seed,
        len(protocol["class_names"]),
        training_reports["trust_full"]["checkpoint_fingerprint"],
        checkpoint_root(args),
        device,
    )
    canonical_q = qconfigs["canonical"]
    clean_train_arrays = make_arrays(
        adapter, protocol["train_index"], clean_features["train"],
        protocol["labels"], canonical_q,
    )
    clean_val_arrays = make_arrays(
        adapter, protocol["val_index"], clean_features["validation"],
        protocol["labels"], canonical_q,
    )
    clean_test_arrays = make_arrays(
        adapter, protocol["test_index"], clean_features["test"],
        protocol["labels"], canonical_q,
    )
    print(f"[seed={seed}] fitting clean folds1-8 source densities", flush=True)
    density_state = fit_density_state(
        canonical_model, clean_train_arrays, clean_val_arrays,
        len(protocol["class_names"]), args.eval_batch_size, device,
    )
    clean_val_raw = predict_trust(
        canonical_model, clean_val_arrays, args.eval_batch_size, device,
        collect_features=True,
    )
    clean_test_raw = predict_trust(
        canonical_model, clean_test_arrays, args.eval_batch_size, device,
        collect_features=True,
    )
    clean_val_components = frozen_primary_components(
        clean_val_raw, clean_val_arrays["ecg_q"], density_state
    )
    sqi_composite_normalizer = fit_sqi_composite_normalizer(clean_val_components)
    clean_val_scores = add_sqi_composite(clean_val_components, sqi_composite_normalizer)
    clean_test_scores = add_sqi_composite(
        frozen_primary_components(clean_test_raw, clean_test_arrays["ecg_q"], density_state),
        sqi_composite_normalizer,
    )
    clean_val_record = {
        "prob": clean_val_raw["prob"], "y": clean_val_arrays["y"],
        "scores": clean_val_scores,
    }

    train_counts = np.bincount(
        protocol["labels"][protocol["train_index"]],
        minlength=len(protocol["class_names"]),
    )
    rare_ids = np.flatnonzero(train_counts < args.rare_threshold)
    condition_reports: dict[str, Any] = {}
    inference_reports: dict[str, Any] = {}
    model_reports: dict[str, Any] = {name: {} for name in config_by_name if name != "trust_full"}
    raw_lists: dict[str, list[np.ndarray]] = {
        "trust_pred": [], "softmax_pred": [], "softmax_msp_risk": [],
        "sqi6": [], "quality": [], "vacuity": [],
        "density": [], "composite": [], "sqi_plus_composite": [], "source_w": [],
        "source_u": [],
    }
    source_corruption: dict[str, Any] | None = None

    for snr in args.snrs:
        label = snr_label(snr)
        print(f"[seed={seed}] evaluating SNR={label}", flush=True)
        if snr is None:
            val_features = clean_features["validation"]
            test_features = clean_features["test"]
        else:
            val_features = derive_features(
                adapter, protocol["val_index"], snr=snr,
                noise_seed=stable_seed(seed, "validation-paired-noise"),
                chunk_size=args.feature_chunk_size, include_ecg=True,
            )
            test_features = derive_features(
                adapter, protocol["test_index"], snr=snr,
                noise_seed=stable_seed(seed, "test-paired-noise"),
                chunk_size=args.feature_chunk_size, include_ecg=True,
            )
            impute_hrv(val_features, hrv_medians)
            impute_hrv(test_features, hrv_medians)

        val_arrays = make_arrays(
            adapter, protocol["val_index"], val_features, protocol["labels"], canonical_q
        )
        test_arrays = make_arrays(
            adapter, protocol["test_index"], test_features, protocol["labels"], canonical_q
        )
        if snr is None:
            val_raw, test_raw = clean_val_raw, clean_test_raw
            val_scores, test_scores = clean_val_scores, clean_test_scores
        else:
            val_raw = predict_trust(
                canonical_model, val_arrays, args.eval_batch_size, device,
                collect_features=True,
            )
            test_raw = predict_trust(
                canonical_model, test_arrays, args.eval_batch_size, device,
                collect_features=True,
            )
            val_scores = add_sqi_composite(
                frozen_primary_components(val_raw, val_arrays["ecg_q"], density_state),
                sqi_composite_normalizer,
            )
            test_scores = add_sqi_composite(
                frozen_primary_components(test_raw, test_arrays["ecg_q"], density_state),
                sqi_composite_normalizer,
            )
        current_val = {"prob": val_raw["prob"], "y": val_arrays["y"], "scores": val_scores}
        current_test = {"prob": test_raw["prob"], "y": test_arrays["y"], "scores": test_scores}
        score_reports = {
            method: score_method_report(
                current_val, current_test, clean_val_record, method, rare_ids, args
            )
            for method in test_scores
        }
        corruption_detection = {}
        if snr is not None:
            corruption_detection = {
                method: R.ood_metrics(clean_test_scores[method], test_scores[method])
                for method in test_scores
            }
        condition_reports[label] = {
            "snr_db": snr,
            "achieved_snr": None if snr is None else {
                "validation_mean": float(np.mean(val_features["achieved_snr"])),
                "validation_std": float(np.std(val_features["achieved_snr"])),
                "test_mean": float(np.mean(test_features["achieved_snr"])),
                "test_std": float(np.std(test_features["achieved_snr"])),
                "validation_base_noise_sha256": val_features["base_noise_sha256"],
                "test_base_noise_sha256": test_features["base_noise_sha256"],
            },
            "diagnosis": classification_report(test_raw["prob"], test_arrays["y"], rare_ids),
            "gate_correlations": gate_correlation_report(
                test_raw, test_arrays["y"], test_arrays["sqi"], test_arrays["ecg_q"]
            ),
            "selection": score_reports,
            "clean_vs_corrupted_detection": corruption_detection,
            "mean_quality": float(np.mean(test_arrays["ecg_q"])),
            "mean_vacuity": float(np.mean(test_raw["u"])),
        }
        raw_lists["trust_pred"].append(test_raw["pred"].astype(np.int16))
        raw_lists["sqi6"].append(test_arrays["sqi"].astype(np.float32))
        raw_lists["quality"].append(test_arrays["ecg_q"].astype(np.float32))
        raw_lists["vacuity"].append(test_scores["vacuity_only"].astype(np.float32))
        raw_lists["density"].append(test_scores["density_only"].astype(np.float32))
        raw_lists["composite"].append(test_scores["composite"].astype(np.float32))
        raw_lists["sqi_plus_composite"].append(
            test_scores["sqi_plus_composite"].astype(np.float32)
        )
        raw_lists["source_w"].append(test_raw["source_w"].astype(np.float32))
        raw_lists["source_u"].append(test_raw["source_u"].astype(np.float32))

        if args.sqi_sensitivity in ("inference", "both"):
            inference_reports[label] = {}
            for qname, qconfig in qconfigs.items():
                if qname == "canonical" or qconfig.degenerate_with == "canonical":
                    q_val, q_test = val_raw, test_raw
                    q_test_values = test_arrays["ecg_q"]
                else:
                    alt_val = dict(val_arrays)
                    alt_test = dict(test_arrays)
                    alt_val["ecg_q"] = quality_from_sqi(alt_val["sqi"], qconfig)
                    alt_test["ecg_q"] = quality_from_sqi(alt_test["sqi"], qconfig)
                    q_val = predict_trust(
                        canonical_model, alt_val, args.eval_batch_size, device,
                        collect_features=False,
                    )
                    q_test = predict_trust(
                        canonical_model, alt_test, args.eval_batch_size, device,
                        collect_features=False,
                    )
                    q_test_values = alt_test["ecg_q"]
                inference_reports[label][qname] = {
                    "analysis_type": "inference_only_no_parameter_update",
                    "degenerate_with": qconfig.degenerate_with,
                    "diagnosis": classification_report(q_test["prob"], test_arrays["y"], rare_ids),
                    "mean_quality": float(np.mean(q_test_values)),
                    "mean_source_weight": {
                        name: float(np.mean(q_test["source_w"][:, index]))
                        for index, name in enumerate(q_test["source_names"])
                    },
                    "fold9_accuracy": float(accuracy_score(val_arrays["y"], q_val["pred"])),
                    "selective_vacuity_fold9_selected": validation_selected_operating_report(
                        q_val["prob"], val_arrays["y"], q_val["u"],
                        q_test["prob"], test_arrays["y"], q_test["u"],
                        rare_ids, args.fixed_coverages, args.risk_targets,
                    ),
                }

        for name, config in config_by_name.items():
            if name == "trust_full":
                continue
            model, _ = load_checkpoint(
                config, seed, len(protocol["class_names"]),
                training_reports[name]["checkpoint_fingerprint"],
                checkpoint_root(args), device,
            )
            qconfig = qconfigs[config.quality_config]
            model_val = make_arrays(
                adapter, protocol["val_index"], val_features, protocol["labels"], qconfig
            )
            model_test = make_arrays(
                adapter, protocol["test_index"], test_features, protocol["labels"], qconfig
            )
            model_val_raw = predict_model(model, config, model_val, args.eval_batch_size, device)
            model_test_raw = predict_model(model, config, model_test, args.eval_batch_size, device)
            entry: dict[str, Any] = {
                "analysis_role": config.analysis_role,
                "analysis_type": "retrained_from_scratch",
                "factors": {
                    "sqi_vector_source": config.sqi_source,
                    "quality_used_by_gate": config.quality_gate,
                    "quality_config": config.quality_config,
                },
                "diagnosis": classification_report(model_test_raw["prob"], model_test["y"], rare_ids),
                "fold9_accuracy": float(accuracy_score(model_val["y"], model_val_raw["pred"])),
            }
            if config.family == "trust":
                entry["gate_correlations"] = gate_correlation_report(
                    model_test_raw, model_test["y"], model_test["sqi"], model_test["ecg_q"]
                )
                entry["selective_vacuity_fold9_selected"] = (
                    validation_selected_operating_report(
                        model_val_raw["prob"], model_val["y"], model_val_raw["u"],
                        model_test_raw["prob"], model_test["y"], model_test_raw["u"],
                        rare_ids, args.fixed_coverages, args.risk_targets,
                    )
                )
            else:
                msp_val = 1.0 - model_val_raw["conf"]
                msp_test = 1.0 - model_test_raw["conf"]
                entry["selective_msp"] = validation_selected_operating_report(
                    model_val_raw["prob"], model_val["y"], msp_val,
                    model_test_raw["prob"], model_test["y"], msp_test,
                    rare_ids, args.fixed_coverages, args.risk_targets,
                )
                raw_lists["softmax_pred"].append(model_test_raw["pred"].astype(np.int16))
                raw_lists["softmax_msp_risk"].append(msp_test.astype(np.float32))
            model_reports[name][label] = entry
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()

        if snr is not None and float(snr) == float(args.source_corruption_snr):
            source_corruption = isolated_source_corruption_report(
                canonical_model, clean_test_arrays, test_arrays, test_arrays["y"],
                args.eval_batch_size, device,
            )
            source_corruption["snr_db"] = snr

        if snr is not None:
            del val_features, test_features
        gc.collect()

    if source_corruption is None:
        raise RunnerError(
            "source-corruption SNR is absent from --snrs; include it or change "
            "--source-corruption-snr"
        )
    raw_arrays: dict[str, np.ndarray] = {
        "snr_db": np.asarray([np.nan if value is None else value for value in args.snrs]),
        "snr_label": np.asarray([snr_label(value) for value in args.snrs]),
        "test_y": protocol["labels"][protocol["test_index"]].astype(np.int16),
        "test_index": protocol["test_index"].astype(np.int64),
        "test_record_id": adapter.metadata.iloc[protocol["test_index"]]["record_id"].astype(str).to_numpy(),
        "test_patient": protocol["patient"][protocol["test_index"]].astype(str),
        "rare_ids": rare_ids.astype(np.int16),
        "class_names": np.asarray(protocol["class_names"], dtype=str),
    }
    for name, values in raw_lists.items():
        if values:
            # softmax contains one entry per condition; all other lists do too.
            raw_arrays[name] = np.stack(values)
    atomic_npz(raw_path, raw_arrays)
    payload = {
        "status": "complete",
        "run_fingerprint": run_fingerprint,
        "seed": seed,
        "canonical": is_canonical_run(args),
        "full_fold_run": not args.smoke,
        "split": {
            "train": len(protocol["train_index"]),
            "validation": len(protocol["val_index"]),
            "test": len(protocol["test_index"]),
            "rule": "official PTB-XL folds 1-8 / 9 / 10",
        },
        "n_classes": len(protocol["class_names"]),
        "class_names": protocol["class_names"],
        "rare_definition": f"folds1-8 record count < {args.rare_threshold}",
        "rare_ids": rare_ids,
        "rare_names": [protocol["class_names"][index] for index in rare_ids],
        "quality_configs": {name: asdict(config) for name, config in qconfigs.items()},
        "training": training_reports,
        "hrv_imputation": {
            "fit_split": "folds1-8 only",
            "medians": hrv_medians,
            "train_missing_per_column": train_hrv_missing,
            "imputed_values_by_clean_split": hrv_imputation,
        },
        "density": {
            key: value for key, value in density_state.items()
            if key not in ("states", "references")
        },
        "sqi_composite_normalizer": {
            **sqi_composite_normalizer,
            "fit_split": "clean fold9 only",
            "formula": "z_fold9(1-quality) + z_fold9(composite)",
        },
        "conditions": condition_reports,
        "sqi_coefficient_sensitivity_inference_only": inference_reports,
        "trained_model_robustness": model_reports,
        "source_sqi_input_x_quality_gate_2x2": {
            "source0_gate0": "trained_model_robustness.sqi_source0_gate0",
            "source0_gate1": "trained_model_robustness.sqi_source0_gate1",
            "source1_gate0": "trained_model_robustness.sqi_source1_gate0",
            "source1_gate1": "conditions (primary trust_full)",
            "gate0_definition": "uncertainty-only gate",
            "gate1_definition": "uncertainty + shared ECG quality gate",
        }
        if args.run_2x2
        else None,
        "retrained_sqi_model_names": [
            config.name for config in configs
            if config.analysis_role == "retrained_sqi_sensitivity"
        ],
        "source_corruption": source_corruption,
        "protocol_guards": {
            "thresholds_fold9_only": True,
            "density_fit_folds1_8_only": True,
            "density_reference_clean_fold9_only": True,
            "hrv_imputation_folds1_8_only": True,
            "test_tuning": False,
            "all_noisy_ecg_sources_recomputed": ["sqi6", "quality", "hrv8", "spec36"],
            "noise_realisation_paired_across_snr": True,
            "score_direction": "higher means reject / more OOD",
        },
        "noise_protocol": {
            "components": [
                "baseline wander 0.15-0.5 Hz", "broadband muscle-like Gaussian",
                "50 Hz random-phase powerline", "motion random walk",
            ],
            "scaling": "per-record composite noise power to exact requested SNR",
            "legacy_difference": (
                "random powerline phase prevents the zero-at-Nyquist defect; the same base "
                "noise is paired across SNR; all derived sources are recomputed"
            ),
        },
        "raw_npz": {
            "path": str(raw_path),
            "sha256": sha256_file(raw_path),
            "axis_convention": (
                "condition-first in --snrs order; then record; source_w has final source axis; "
                "source_u has final source axis; sqi6 has final SQI axis"
            ),
        },
        "environment": environment_manifest(args, device),
        "created_at_utc": utc_timestamp(),
    }
    atomic_json(payload, json_path)
    print(f"[saved] {json_path}", flush=True)
    del canonical_model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--seeds", type=parse_ints, default=DEFAULT_SEEDS)
    parser.add_argument(
        "--worker-seed", type=int,
        help=(
            "execute only this member of --seeds; keeps the complete canonical "
            "seed declaration while allowing independent remote workers"
        ),
    )
    parser.add_argument(
        "--snrs", type=parse_snrs, default=DEFAULT_SNRS,
        help="comma list containing clean and SNR dB values",
    )
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--eval-batch-size", type=int, default=512)
    parser.add_argument("--feature-chunk-size", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--rare-threshold", type=int, default=50)
    parser.add_argument(
        "--q-min-percent", type=parse_percentages, default=(5.0, 10.0, 20.0, 30.0),
        help="fold-9 target rejection percentages; compared at matched validation coverage",
    )
    parser.add_argument(
        "--fixed-coverages", type=parse_probabilities,
        default=(0.95, 0.90, 0.80, 0.70, 0.50),
        help="percent coverages, e.g. 95,90,80,70,50",
    )
    parser.add_argument(
        "--risk-targets", type=parse_probabilities, default=(0.01, 0.05, 0.10),
        help="percent selective-risk targets, e.g. 1,5,10",
    )
    parser.add_argument("--alarm-quantile", type=float, default=0.95)
    parser.add_argument("--source-corruption-snr", type=float, default=0.0)
    parser.add_argument(
        "--sqi-sensitivity", choices=("inference", "retrained", "both", "none"),
        default="both",
        help="inference-only coefficient perturbations, independently retrained variants, or both",
    )
    parser.add_argument(
        "--retrain-sqi-configs",
        default="core",
        help="comma config names, core, or all; used when sensitivity includes retrained",
    )
    parser.add_argument(
        "--run-2x2", action=argparse.BooleanOptionalAction, default=True,
        help="train the SQI vector-source x quality-gate 2x2 factorial",
    )
    parser.add_argument("--limit-train", type=int)
    parser.add_argument("--limit-val", type=int)
    parser.add_argument("--limit-test", type=int)
    parser.add_argument(
        "--smoke", action="store_true",
        help="non-canonical: one seed, one epoch, limited splits, clean/6/0 dB",
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--trustfed-cache", default=str(D.DEFAULT_TRUSTFED_CACHE))
    parser.add_argument("--cache-dir", default="/root/Paper46_revision/cache")
    parser.add_argument("--checkpoint-dir", default="/root/Paper46_revision/checkpoints/noise_sqi")
    parser.add_argument("--results-dir", default="/root/Paper46_revision/results/noise_sqi")
    return parser


def validate_args(args: argparse.Namespace) -> None:
    if args.epochs < 1 or args.batch_size < 2 or args.eval_batch_size < 1:
        raise SystemExit("epochs must be positive, train batch >=2, eval batch positive")
    if (
        args.feature_chunk_size < 1
        or not math.isfinite(args.learning_rate)
        or args.learning_rate <= 0
    ):
        raise SystemExit("feature chunk size and learning rate must be positive")
    if not 0.0 < args.alarm_quantile < 1.0:
        raise SystemExit("--alarm-quantile must lie in (0,1)")
    if not math.isfinite(args.source_corruption_snr):
        raise SystemExit("--source-corruption-snr must be finite")
    if args.rare_threshold < 1:
        raise SystemExit("--rare-threshold must be positive")
    for name in ("limit_train", "limit_val", "limit_test"):
        value = getattr(args, name)
        if value is not None and value <= 0:
            raise SystemExit(f"--{name.replace('_', '-')} must be positive")
    qconfigs = quality_configs()
    requested = tuple(
        item.strip() for item in str(args.retrain_sqi_configs).split(",") if item.strip()
    )
    expanded: list[str] = []
    for name in requested:
        if name == "core":
            expanded.extend(("joint_minus20", "joint_plus20", "uniform", "psqi_only"))
        elif name == "all":
            expanded.extend(key for key in qconfigs if key != "canonical")
        else:
            expanded.append(name)
    names = tuple(dict.fromkeys(expanded))
    unknown = sorted(set(names) - set(qconfigs))
    if unknown:
        raise SystemExit(f"unknown --retrain-sqi-configs: {unknown}")
    args.retrain_sqi_configs = names
    if args.sqi_sensitivity in ("retrained", "both") and not args.smoke:
        if len(set(args.seeds)) < 3:
            raise SystemExit("retrained SQI sensitivity requires at least three distinct seeds")
    if args.worker_seed is not None and args.worker_seed not in set(args.seeds):
        raise SystemExit("--worker-seed must be one of the declared --seeds")
    if args.source_corruption_snr not in [value for value in args.snrs if value is not None]:
        raise SystemExit("--source-corruption-snr must be included in --snrs")
    if not args.smoke and any(
        value is not None for value in (args.limit_train, args.limit_val, args.limit_test)
    ):
        raise SystemExit("split limits are allowed only with --smoke; canonical runs use full folds")


def apply_smoke_overrides(args: argparse.Namespace) -> None:
    if not args.smoke:
        return
    args.seeds = (args.seeds[0],)
    args.epochs = 1
    args.limit_train = args.limit_train or 512
    args.limit_val = args.limit_val or 256
    args.limit_test = args.limit_test or 256
    args.snrs = (None, 6.0, 0.0)
    args.source_corruption_snr = 0.0
    # Exercise inference sensitivity and the 2x2 branches without training four
    # extra coefficient variants in the first remote smoke.
    if args.sqi_sensitivity in ("retrained", "both"):
        args.sqi_sensitivity = "inference"


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    apply_smoke_overrides(args)
    validate_args(args)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    print(
        json.dumps(
            jsonable(
                {
                    "script_version": SCRIPT_VERSION,
                    "canonical": is_canonical_run(args),
                    "full_fold_run": not args.smoke,
                    "seeds": args.seeds,
                    "worker_seed": args.worker_seed,
                    "snrs": [snr_label(value) for value in args.snrs],
                    "epochs": args.epochs,
                    "batch_size": args.batch_size,
                    "sqi_sensitivity": args.sqi_sensitivity,
                    "retrain_sqi_configs": args.retrain_sqi_configs,
                    "run_2x2": args.run_2x2,
                    "device": str(device),
                }
            ),
            indent=2,
        ),
        flush=True,
    )
    run_seeds = (args.worker_seed,) if args.worker_seed is not None else args.seeds
    for seed in run_seeds:
        set_seed(seed)
        run_seed(args, seed, device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
