#!/usr/bin/env python3
"""Strict audit and aggregation for the reviewer-promised PTB-XL extensions.

This auditor is intentionally independent from the frozen 212-run auditor.  It
checks the additional experiment root against a closed, explicit contract:

* the full closed-protocol eta x auxiliary-loss Pareto grid (18 x 5 runs);
* strict-tau80 one-factor eta and auxiliary-loss sweeps (9 x 5 runs);
* two alternative redundancy objectives in closed and strict-tau80 (20 runs);
* global, sample-normalized, and stop-gradient gate controls in both protocols
  (30 runs);
* four capacity-matched source-count controls (12 runs); and
* TMC/TMDF with one through four sources (24 runs).

The exact total is 49 method/protocol groups and 221 JSON/raw/OOD triplets.
Every result is tied to its run fingerprint, code hashes, checksum-declared
artifacts, frozen split/label reference, finite scalar metrics, and safe NPZ
contents.  Representation diagnostics and the structural properties of the
two special gates are audited rather than merely trusted from JSON.

The source-count interpretation emitted by this program is deliberately
conservative.  The frozen cumulative/normalized/mean source-count matrix and
the TMC/TMDF source-count fits change both input information and parameter
count.  They must not be described as a pure causal effect of source number.
Only the separately labelled ``capmatch_s*`` controls approximately match total
trainable capacity, and even those do not equalize input information.

Run this file on the remote training server.  It is not a training program and
never modifies input results.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
import time
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


AUDITOR_VERSION = "paper46-promised-extension-audit-v2"
FINGERPRINT_SCHEMA = "paper46-ptbxl-missing-extensions-fingerprint-v1"
RUNNER_VERSION = "paper46-ptbxl-missing-extensions-v1"

FIVE_SEEDS = (7, 13, 42, 99, 2026)
THREE_SEEDS = (7, 42, 2026)
ETA_TEXT = ("0", "0.01", "0.03", "0.1", "0.3", "1")
AUX_TEXT = ("0", "0.3", "1")

PROTOCOLS: dict[str, dict[str, Any]] = {
    "closed": {
        "directory": ("closed",),
        "payload_protocol": "closed",
        "tau": None,
        "n_classes": 70,
        "train_n": 17418,
        "validation_n": 2183,
        "test_n": 2198,
        "cross_dataset": True,
        "ood_lengths": {"validation": 2183, "id": 2198, "chapman": 45150},
        "out_scenarios": ("chapman",),
        "split_requirements": {
            "protocol": "closed",
            "train": 17418,
            "validation": 2183,
            "test": 2198,
        },
    },
    "strict:tau80": {
        "directory": ("strict", "tau80"),
        "payload_protocol": "strict",
        "tau": 80,
        "n_classes": 47,
        "train_n": 16677,
        "validation_n": 2086,
        "test_n": 2105,
        "cross_dataset": False,
        "ood_lengths": {
            "validation": 2086,
            "id": 2105,
            "all": 93,
            "pure": 22,
            "mixed": 71,
        },
        "out_scenarios": ("all", "pure", "mixed"),
        "split_requirements": {
            "threshold": 80,
            "n_heldout_codes": 23,
            "counts.train_id": 16677,
            "counts.val_id": 2086,
            "counts.test_id": 2105,
            "counts.test_ood": 93,
            "counts.test_ood_pure": 22,
            "counts.test_ood_mixed": 71,
        },
    },
}

PLAN_DEFAULTS: dict[str, Any] = {
    "family": "trust",
    "pooling": "cumulative",
    "branch": "both",
    "gate_mode": "both",
    "sqi_source": True,
    "source_count": 4,
    "complementarity_weight": 0.1,
    "complementarity_mode": "absolute_cosine",
    "auxiliary_classification_weight": 0.3,
    "gate_architecture": "independent_sigmoid",
    "detach_gate_uncertainty": False,
    "capacity_match": False,
    "representation_diagnostics": False,
}

DIAGNOSIS_METRICS = (
    "diagnosis.accuracy",
    "diagnosis.balanced_accuracy",
    "diagnosis.macro_f1",
    "diagnosis.weighted_f1",
    "diagnosis.macro_auroc",
    "diagnosis.macro_auprc",
    "diagnosis.rare_macro_f1",
    "diagnosis.rare_macro_auroc",
    "diagnosis.rare_macro_auprc",
    "diagnosis.calibration.temperature",
    "diagnosis.calibration.raw.ece_fixed",
    "diagnosis.calibration.raw.ece_adaptive",
    "diagnosis.calibration.raw.classwise_ece_fixed",
    "diagnosis.calibration.raw.classwise_ece_adaptive",
    "diagnosis.calibration.raw.nll",
    "diagnosis.calibration.raw.brier",
    "diagnosis.calibration.temperature_scaled.ece_fixed",
    "diagnosis.calibration.temperature_scaled.ece_adaptive",
    "diagnosis.calibration.temperature_scaled.classwise_ece_fixed",
    "diagnosis.calibration.temperature_scaled.classwise_ece_adaptive",
    "diagnosis.calibration.temperature_scaled.nll",
    "diagnosis.calibration.temperature_scaled.brier",
    "diagnosis.selective_primary.aurc",
    "diagnosis.selective_primary.eaurc",
    "diagnosis.selective_max_probability.aurc",
    "diagnosis.selective_max_probability.eaurc",
)

RARE_DIAGNOSIS_METRICS = frozenset(
    {
        "diagnosis.rare_macro_f1",
        "diagnosis.rare_macro_auroc",
        "diagnosis.rare_macro_auprc",
    }
)

OOD_DETECTORS = ("vacuity", "density", "composite", "composite_robust")
OOD_METRICS = ("auroc", "aupr_out", "aupr_in", "fpr95")
OPERATING_METRICS = (
    "validation_quantile",
    "threshold",
    "id_test_false_positive_rate",
    "ood_test_true_positive_rate",
)

SUMMARY_METRICS = DIAGNOSIS_METRICS + tuple(
    f"ood.{detector}.primary.{metric}"
    for detector in OOD_DETECTORS
    for metric in OOD_METRICS
)

PAIR_METRICS = (
    "diagnosis.accuracy",
    "diagnosis.balanced_accuracy",
    "diagnosis.macro_f1",
    "diagnosis.macro_auroc",
    "diagnosis.rare_macro_f1",
    "diagnosis.rare_macro_auroc",
    "diagnosis.calibration.raw.ece_fixed",
    "diagnosis.calibration.temperature_scaled.ece_fixed",
    "diagnosis.selective_primary.aurc",
    "ood.vacuity.primary.auroc",
    "ood.density.primary.auroc",
    "ood.composite.primary.auroc",
    "ood.composite.primary.fpr95",
)

HEX64 = re.compile(r"[0-9a-f]{64}")
SEED_JSON = re.compile(r"seed_(\d+)\.json")
_MISSING = object()


class AuditError(RuntimeError):
    """Raised for an invalid command-level audit configuration."""


def numeric_text(value: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise AuditError(f"non-finite coefficient in internal contract: {value}")
    return result


def plan(tag: str, **changes: Any) -> dict[str, Any]:
    result = {"tag": tag, **PLAN_DEFAULTS}
    result.update(changes)
    return result


def build_expected_config() -> dict[str, Any]:
    """Return the literal reviewer-promise matrix; no observed-data inference."""

    groups: list[dict[str, Any]] = []

    # Complete two-dimensional Pareto grid, closed protocol only.
    for eta_text in ETA_TEXT:
        for aux_text in AUX_TEXT:
            tag = f"pareto_eta_{eta_text}_aux_{aux_text}"
            groups.append(
                {
                    "protocol": "closed",
                    "tag": tag,
                    "seeds": list(FIVE_SEEDS),
                    "family": "pareto",
                    "model": plan(
                        tag,
                        complementarity_weight=numeric_text(eta_text),
                        auxiliary_classification_weight=numeric_text(aux_text),
                        representation_diagnostics=True,
                    ),
                }
            )

    # Strict held-out-code protocol retains prespecified one-factor sweeps.
    for eta_text in ETA_TEXT:
        tag = f"eta_{eta_text}"
        groups.append(
            {
                "protocol": "strict:tau80",
                "tag": tag,
                "seeds": list(FIVE_SEEDS),
                "family": "eta_sensitivity",
                "model": plan(
                    tag,
                    complementarity_weight=numeric_text(eta_text),
                    representation_diagnostics=True,
                ),
            }
        )
    for aux_text in AUX_TEXT:
        tag = f"aux_{aux_text}"
        groups.append(
            {
                "protocol": "strict:tau80",
                "tag": tag,
                "seeds": list(FIVE_SEEDS),
                "family": "aux_sensitivity",
                "model": plan(
                    tag,
                    auxiliary_classification_weight=numeric_text(aux_text),
                ),
            }
        )

    for protocol in ("closed", "strict:tau80"):
        alternatives = {
            "alt_crosscorr": "cross_correlation",
            "alt_linear_cka": "linear_cka",
        }
        for tag, mode in alternatives.items():
            groups.append(
                {
                    "protocol": protocol,
                    "tag": tag,
                    "seeds": list(FIVE_SEEDS),
                    "family": "alternative_regularizer",
                    "model": plan(
                        tag,
                        complementarity_mode=mode,
                        representation_diagnostics=True,
                    ),
                }
            )

        gates = {
            "gate_global": {
                "gate_architecture": "global_sigmoid",
            },
            "gate_sample_normalized": {
                "gate_architecture": "sample_softmax",
            },
            "gate_detached": {
                "detach_gate_uncertainty": True,
            },
        }
        for tag, changes in gates.items():
            groups.append(
                {
                    "protocol": protocol,
                    "tag": tag,
                    "seeds": list(FIVE_SEEDS),
                    "family": "gate_control",
                    "model": plan(tag, **changes),
                }
            )

    for source_count in (1, 2, 3, 4):
        tag = f"capmatch_s{source_count}"
        groups.append(
            {
                "protocol": "closed",
                "tag": tag,
                "seeds": list(THREE_SEEDS),
                "family": "capacity_matched_source_count",
                "model": plan(
                    tag,
                    source_count=source_count,
                    capacity_match=True,
                ),
            }
        )

    for method_family in ("tmc", "tmdf"):
        for source_count in (1, 2, 3, 4):
            tag = f"{method_family}_s{source_count}"
            groups.append(
                {
                    "protocol": "closed",
                    "tag": tag,
                    "seeds": list(THREE_SEEDS),
                    "family": "tmc_tmdf_source_count",
                    "model": plan(
                        tag,
                        family=method_family,
                        source_count=source_count,
                        complementarity_weight=0.0,
                        auxiliary_classification_weight=0.0,
                    ),
                }
            )

    expected_records = sum(len(group["seeds"]) for group in groups)
    if len(groups) != 49 or expected_records != 221:
        raise AuditError(
            "internal promised-extension matrix drift: "
            f"groups={len(groups)}, records={expected_records}"
        )
    return {
        "schema_version": 1,
        "auditor_version": AUDITOR_VERSION,
        "runner_version": RUNNER_VERSION,
        "fingerprint_schema": FINGERPRINT_SCHEMA,
        "expected_group_count": len(groups),
        "expected_record_count": expected_records,
        "groups": groups,
        "protocols": PROTOCOLS,
        "required_artifacts": ["json", "raw_npz", "ood_npz"],
        "reject_unexpected_json_or_npz": True,
        "require_uniform_code_hashes": True,
        "interpretation_constraints": [
            "Do not interpret the frozen cumulative/normalized/mean x S1..S4 "
            "matrix as a pure causal effect of source number: information and "
            "trainable capacity both change.",
            "Do not interpret TMC/TMDF x S1..S4 as a pure source-number causal "
            "effect for the same reason.",
            "The capmatch_s* controls approximately match total trainable "
            "capacity but still change input information; report the recorded "
            "parameter gap and use associational language.",
            "The closed eta x auxiliary-weight test surface is descriptive. "
            "Do not choose an operating point from test diagnosis, Chapman, "
            "or held-out-code results; any selected setting must be frozen "
            "from fold-9 ID criteria declared separately.",
        ],
    }


def jsonable(value: Any) -> Any:
    if value is _MISSING:
        return None
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, set):
        return [jsonable(item) for item in sorted(value, key=str)]
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    return value


def sha256_object(value: Any) -> str:
    encoded = json.dumps(
        jsonable(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(
                jsonable(payload),
                handle,
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
                allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_csv(path: Path, rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: jsonable(row.get(key)) for key in fields})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def nested_get(value: Any, dotted: str, default: Any = _MISSING) -> Any:
    current = value
    for key in dotted.split("."):
        if not isinstance(current, Mapping) or key not in current:
            return default
        current = current[key]
    return current


def values_equal(actual: Any, expected: Any) -> bool:
    if isinstance(actual, bool) or isinstance(expected, bool):
        return actual is expected
    if isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        return bool(
            math.isfinite(float(actual))
            and math.isfinite(float(expected))
            and math.isclose(float(actual), float(expected), rel_tol=1e-12, abs_tol=1e-12)
        )
    return jsonable(actual) == jsonable(expected)


def finite_number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float, np.number)):
        return None
    result = float(value)
    return result if math.isfinite(result) else None


def add_issue(
    issues: list[dict[str, Any]],
    code: str,
    path: Path | str | None = None,
    **details: Any,
) -> None:
    row: dict[str, Any] = {"code": code}
    if path is not None:
        row["path"] = str(path)
    row.update(jsonable(details))
    issues.append(row)


def expected_paths(
    root: Path, config: Mapping[str, Any]
) -> dict[tuple[str, str, int], dict[str, Path]]:
    result: dict[tuple[str, str, int], dict[str, Path]] = {}
    for group in config["groups"]:
        protocol = str(group["protocol"])
        directory = root.joinpath(*PROTOCOLS[protocol]["directory"], str(group["tag"]))
        for seed in group["seeds"]:
            identity = (protocol, str(group["tag"]), int(seed))
            result[identity] = {
                "json": directory / f"seed_{seed}.json",
                "raw_npz": directory / f"seed_{seed}_raw.npz",
                "ood_npz": directory / f"seed_{seed}_ood_scores.npz",
            }
    return result


def expected_groups_by_identity(config: Mapping[str, Any]) -> dict[tuple[str, str, int], Mapping[str, Any]]:
    result: dict[tuple[str, str, int], Mapping[str, Any]] = {}
    for group in config["groups"]:
        for seed in group["seeds"]:
            identity = (str(group["protocol"]), str(group["tag"]), int(seed))
            if identity in result:
                raise AuditError(f"duplicate internal expected identity: {identity}")
            result[identity] = group
    return result


def inspect_extra_files(
    root: Path,
    output_dir: Path,
    allowed: set[Path],
    issues: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    output_resolved = output_dir.resolve()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in (".json", ".npz"):
            continue
        resolved = path.resolve()
        if resolved == output_resolved or output_resolved in resolved.parents:
            continue
        row = {
            "path": str(path),
            "relative_path": str(path.relative_to(root)),
            "bytes": int(path.stat().st_size),
            "sha256": sha256_file(path),
            "expected": resolved in allowed,
        }
        rows.append(row)
        if resolved not in allowed:
            add_issue(issues, "unexpected_json_or_npz", path)
    return rows


def load_json(path: Path, issues: list[dict[str, Any]]) -> Mapping[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        add_issue(issues, "json_unreadable", path, error=f"{type(exc).__name__}: {exc}")
        return None
    if not isinstance(payload, Mapping):
        add_issue(issues, "json_root_not_mapping", path, actual_type=type(payload).__name__)
        return None
    return payload


def load_npz(path: Path, issues: list[dict[str, Any]]) -> dict[str, np.ndarray] | None:
    """Fully decompress with allow_pickle=False, exercising ZIP CRC checks."""

    try:
        with zipfile.ZipFile(path, "r") as zipped:
            names = [item.filename for item in zipped.infolist()]
            if len(names) != len(set(names)):
                raise AuditError("duplicate ZIP members")
            bad_member = zipped.testzip()
            if bad_member is not None:
                raise AuditError(f"CRC failure in {bad_member}")
        with np.load(path, allow_pickle=False) as archive:
            result = {name: np.asarray(archive[name]) for name in archive.files}
    except Exception as exc:
        add_issue(issues, "npz_unreadable_or_unsafe", path, error=f"{type(exc).__name__}: {exc}")
        return None
    for name, value in result.items():
        if value.dtype.hasobject:
            add_issue(issues, "npz_object_dtype", path, array=name, dtype=str(value.dtype))
        if np.issubdtype(value.dtype, np.number) and not np.isfinite(value).all():
            add_issue(issues, "npz_nonfinite", path, array=name)
    return result


def check_scalar(
    payload: Mapping[str, Any],
    dotted: str,
    issues: list[dict[str, Any]],
    path: Path,
    lower: float | None = None,
    upper: float | None = None,
) -> float | None:
    value = nested_get(payload, dotted)
    number = finite_number(value)
    if number is None:
        add_issue(issues, "missing_or_nonfinite_metric", path, metric=dotted, actual=value)
        return None
    if lower is not None and number < lower - 1e-12:
        add_issue(issues, "metric_below_bound", path, metric=dotted, actual=number, lower=lower)
    if upper is not None and number > upper + 1e-12:
        add_issue(issues, "metric_above_bound", path, metric=dotted, actual=number, upper=upper)
    return number


def check_model_contract(
    payload: Mapping[str, Any],
    group: Mapping[str, Any],
    path: Path,
    issues: list[dict[str, Any]],
) -> None:
    actual = payload.get("model")
    expected = group["model"]
    if not isinstance(actual, Mapping):
        add_issue(issues, "model_contract_absent", path)
        return
    for key, expected_value in expected.items():
        actual_value = actual.get(key, _MISSING)
        if actual_value is _MISSING or not values_equal(actual_value, expected_value):
            add_issue(
                issues,
                "model_contract_mismatch",
                path,
                field=key,
                expected=expected_value,
                actual=None if actual_value is _MISSING else actual_value,
            )
    extras = sorted(set(actual) - set(expected))
    if extras:
        add_issue(issues, "unexpected_model_contract_fields", path, fields=extras)


def check_fingerprint(
    payload: Mapping[str, Any],
    path: Path,
    issues: list[dict[str, Any]],
) -> Mapping[str, Any] | None:
    if payload.get("fingerprint_schema") != FINGERPRINT_SCHEMA:
        add_issue(
            issues,
            "fingerprint_schema_mismatch",
            path,
            expected=FINGERPRINT_SCHEMA,
            actual=payload.get("fingerprint_schema"),
        )
    definition = payload.get("run_definition")
    if not isinstance(definition, Mapping):
        add_issue(issues, "run_definition_absent", path)
        return None
    expected_fingerprint = sha256_object(definition)
    stored = payload.get("run_fingerprint")
    if stored != expected_fingerprint:
        add_issue(
            issues,
            "run_fingerprint_mismatch",
            path,
            expected=expected_fingerprint,
            actual=stored,
        )
    linked = {
        "script_version": nested_get(payload, "environment.script_version"),
        "arguments": nested_get(payload, "environment.arguments"),
        "model": payload.get("model"),
        "seed": payload.get("seed"),
        "protocol": payload.get("protocol"),
        "tau": payload.get("tau"),
        "split": payload.get("split"),
        "n_classes": payload.get("n_classes"),
        "class_names": payload.get("class_names"),
    }
    for key, expected in linked.items():
        if not values_equal(definition.get(key, _MISSING), expected):
            add_issue(
                issues,
                "run_definition_payload_mismatch",
                path,
                field=key,
                expected=expected,
                actual=definition.get(key),
            )
    code_hashes = definition.get("code_sha256")
    required_code = {
        "run_ptbxl_revision.py",
        "base_run_ptbxl_revision.py",
        "revisionlib.py",
        "data_adapter.py",
    }
    if not isinstance(code_hashes, Mapping) or set(code_hashes) != required_code:
        add_issue(
            issues,
            "code_hash_manifest_mismatch",
            path,
            expected=sorted(required_code),
            actual=sorted(code_hashes) if isinstance(code_hashes, Mapping) else None,
        )
    else:
        for name, digest in code_hashes.items():
            if not isinstance(digest, str) or HEX64.fullmatch(digest) is None:
                add_issue(issues, "malformed_code_hash", path, file=name, actual=digest)
        linked_hashes = {
            "run_ptbxl_revision.py": nested_get(payload, "environment.script_sha256"),
            "revisionlib.py": nested_get(payload, "environment.revisionlib_sha256"),
            "data_adapter.py": nested_get(payload, "environment.data_adapter_sha256"),
        }
        for name, digest in linked_hashes.items():
            if code_hashes.get(name) != digest:
                add_issue(
                    issues,
                    "environment_code_hash_mismatch",
                    path,
                    file=name,
                    definition=code_hashes.get(name),
                    environment=digest,
                )
    return definition


def check_common_configuration(
    payload: Mapping[str, Any],
    protocol: str,
    tag: str,
    seed: int,
    path: Path,
    issues: list[dict[str, Any]],
) -> None:
    spec = PROTOCOLS[protocol]
    requirements = {
        "status": "complete",
        "seed": seed,
        "protocol": spec["payload_protocol"],
        "tau": spec["tau"],
        "n_classes": spec["n_classes"],
        "run_definition.protocol": spec["payload_protocol"],
        "environment.script_version": RUNNER_VERSION,
        "environment.arguments.seed": seed,
        "environment.arguments.protocol": spec["payload_protocol"],
        "environment.arguments.tau": 80,
        "environment.arguments.cross_dataset": spec["cross_dataset"],
        "environment.arguments.epochs": 40,
        "environment.arguments.batch_size": 256,
        "environment.arguments.eval_batch_size": 512,
        "environment.arguments.learning_rate": 0.001,
        "environment.arguments.rare_threshold": 50,
        "environment.arguments.ensemble_members": 5,
        "environment.arguments.bootstrap": 0,
        "environment.arguments.profile": False,
        "environment.arguments.force": False,
        "environment.arguments.limit_train": None,
        "environment.arguments.limit_val": None,
        "environment.arguments.limit_test": None,
        "environment.arguments.limit_ood": None,
        "environment.arguments.limit_chapman": None,
        "environment.arguments.device": "cuda",
        "environment.device": "cuda",
        "environment.cuda_available": True,
        "environment.score_direction": "higher means more OOD for every OOD score",
        "environment.arguments.cache_dir": "/root/Paper46_revision/cache",
        "environment.arguments.trustfed_cache": "/root/autodl-tmp/TrustFedECG/cache",
    }
    for dotted, expected in requirements.items():
        actual = nested_get(payload, dotted)
        if not values_equal(actual, expected):
            add_issue(
                issues,
                "configuration_mismatch",
                path,
                field=dotted,
                expected=expected,
                actual=None if actual is _MISSING else actual,
            )
    models = nested_get(payload, "environment.arguments.models")
    if not isinstance(models, Sequence) or isinstance(models, (str, bytes)) or tag not in models:
        add_issue(issues, "tag_absent_from_arguments_models", path, tag=tag, actual=models)
    for dotted, expected in spec["split_requirements"].items():
        actual = nested_get(payload.get("split"), dotted)
        if not values_equal(actual, expected):
            add_issue(
                issues,
                "split_contract_mismatch",
                path,
                field=dotted,
                expected=expected,
                actual=None if actual is _MISSING else actual,
            )
    class_names = payload.get("class_names")
    if not isinstance(class_names, Sequence) or isinstance(class_names, (str, bytes)):
        add_issue(issues, "class_names_absent", path)
    elif len(class_names) != spec["n_classes"] or len(set(map(str, class_names))) != len(class_names):
        add_issue(
            issues,
            "class_names_invalid",
            path,
            expected_count=spec["n_classes"],
            actual_count=len(class_names),
        )
    rare_definition = payload.get("rare_definition")
    if rare_definition != "folds 1-8 model-label record count < 50":
        add_issue(issues, "rare_definition_mismatch", path, actual=rare_definition)
    parameter_count = payload.get("parameter_count")
    if not isinstance(parameter_count, Mapping):
        add_issue(issues, "parameter_count_absent", path)
    else:
        for key in ("total", "trainable"):
            value = parameter_count.get(key)
            if (
                isinstance(value, bool)
                or not isinstance(value, int)
                or value <= 0
            ):
                add_issue(
                    issues,
                    "parameter_count_invalid",
                    path,
                    field=key,
                    actual=value,
                )


def check_training(
    payload: Mapping[str, Any],
    group: Mapping[str, Any],
    path: Path,
    issues: list[dict[str, Any]],
) -> None:
    training = payload.get("training")
    if not isinstance(training, Mapping):
        add_issue(issues, "training_report_absent", path)
        return
    for key in ("best_val_macro_auroc", "train_seconds"):
        value = finite_number(training.get(key))
        if value is None:
            add_issue(issues, "training_scalar_nonfinite", path, field=key, actual=training.get(key))
    if training.get("selection") != "maximum fold-9 macro-AUROC; no fold-10 or OOD data":
        add_issue(issues, "training_selection_mismatch", path, actual=training.get("selection"))
    history = training.get("history")
    if not isinstance(history, Sequence) or isinstance(history, (str, bytes)) or len(history) != 40:
        add_issue(
            issues,
            "training_history_length_mismatch",
            path,
            expected=40,
            actual=len(history) if isinstance(history, Sequence) else None,
        )
    else:
        for expected_epoch, row in enumerate(history, start=1):
            if not isinstance(row, Mapping) or row.get("epoch") != expected_epoch:
                add_issue(issues, "training_history_epoch_mismatch", path, epoch=expected_epoch)
                continue
            for key in ("loss", "val_macro_auroc", "val_accuracy", "elapsed_seconds"):
                if finite_number(row.get(key)) is None:
                    add_issue(
                        issues,
                        "training_history_nonfinite",
                        path,
                        epoch=expected_epoch,
                        field=key,
                        actual=row.get(key),
                    )

    if group["family"] == "capacity_matched_source_count":
        capacity = training.get("capacity_matching")
        if not isinstance(capacity, Mapping):
            add_issue(issues, "capacity_match_manifest_absent", path)
        else:
            source_count = group["model"]["source_count"]
            requirements = {
                "source_count": source_count,
                "reference": "four-source RevisionTrustModel with fuse_hidden=256",
                "matched_component": "active learned Fuse hidden width",
            }
            for key, expected in requirements.items():
                if not values_equal(capacity.get(key), expected):
                    add_issue(
                        issues,
                        "capacity_match_manifest_mismatch",
                        path,
                        field=key,
                        expected=expected,
                        actual=capacity.get(key),
                    )
            for key in (
                "fuse_hidden",
                "target_total_parameters",
                "actual_total_parameters",
                "absolute_gap",
                "relative_gap",
            ):
                if finite_number(capacity.get(key)) is None:
                    add_issue(issues, "capacity_match_nonfinite", path, field=key)
            relative_gap = finite_number(capacity.get("relative_gap"))
            if relative_gap is not None and abs(relative_gap) > 0.05:
                add_issue(
                    issues,
                    "capacity_match_exceeds_five_percent",
                    path,
                    relative_gap=relative_gap,
                )


def check_representation_diagnostics(
    payload: Mapping[str, Any],
    group: Mapping[str, Any],
    protocol: str,
    path: Path,
    issues: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    required = bool(group["model"]["representation_diagnostics"])
    diagnostics = nested_get(payload, "training.representation_diagnostics")
    if not required:
        return []
    if not isinstance(diagnostics, Mapping):
        add_issue(issues, "representation_diagnostics_absent", path)
        return []
    spec = PROTOCOLS[protocol]
    fixed = {
        "fit_split": "folds 1-8 only",
        "evaluation_split": "fold 9 only",
        "n_train": spec["train_n"],
        "n_validation": spec["validation_n"],
    }
    for key, expected in fixed.items():
        if not values_equal(diagnostics.get(key), expected):
            add_issue(
                issues,
                "representation_diagnostic_contract_mismatch",
                path,
                field=key,
                expected=expected,
                actual=diagnostics.get(key),
            )
    output_rows: list[dict[str, Any]] = []
    expected_sources = {"ecg", "hrv", "spec", "sqi"}
    expected_pairs = {
        tuple(sorted((left, right)))
        for index, left in enumerate(sorted(expected_sources))
        for right in sorted(expected_sources)[index + 1 :]
    }
    pairwise = diagnostics.get("pairwise")
    if not isinstance(pairwise, Sequence) or isinstance(pairwise, (str, bytes)) or len(pairwise) != 6:
        add_issue(
            issues,
            "representation_pair_count_mismatch",
            path,
            expected=6,
            actual=len(pairwise) if isinstance(pairwise, Sequence) else None,
        )
    else:
        seen_pairs: set[tuple[str, str]] = set()
        for row in pairwise:
            if not isinstance(row, Mapping):
                add_issue(issues, "representation_pair_invalid", path)
                continue
            left, right = str(row.get("left")), str(row.get("right"))
            identity = tuple(sorted((left, right)))
            if left == right or identity in seen_pairs:
                add_issue(issues, "representation_pair_duplicate", path, pair=list(identity))
            seen_pairs.add(identity)
            cosine = finite_number(row.get("mean_absolute_cosine"))
            cka = finite_number(row.get("linear_cka_normalized_hsic"))
            if cosine is None or not 0.0 <= cosine <= 1.000001:
                add_issue(issues, "representation_cosine_invalid", path, pair=list(identity), value=cosine)
            if cka is None or not -1e-8 <= cka <= 1.000001:
                add_issue(issues, "representation_cka_invalid", path, pair=list(identity), value=cka)
            output_rows.append(
                {
                    "kind": "pairwise",
                    "left_or_source": left,
                    "right": right,
                    "mean_absolute_cosine": cosine,
                    "linear_cka_normalized_hsic": cka,
                }
            )
        if seen_pairs != expected_pairs:
            add_issue(
                issues,
                "representation_pair_identity_mismatch",
                path,
                expected=[list(value) for value in sorted(expected_pairs)],
                actual=[list(value) for value in sorted(seen_pairs)],
            )
    probes = diagnostics.get("source_linear_probes")
    if not isinstance(probes, Sequence) or isinstance(probes, (str, bytes)) or len(probes) != 4:
        add_issue(
            issues,
            "representation_probe_count_mismatch",
            path,
            expected=4,
            actual=len(probes) if isinstance(probes, Sequence) else None,
        )
    else:
        sources: set[str] = set()
        for row in probes:
            if not isinstance(row, Mapping):
                add_issue(issues, "representation_probe_invalid", path)
                continue
            source = str(row.get("source"))
            if source in sources:
                add_issue(issues, "representation_probe_duplicate", path, source=source)
            sources.add(source)
            if row.get("probe") != "train-only linear ridge classifier with intercept":
                add_issue(issues, "representation_probe_protocol_mismatch", path, source=source)
            if not values_equal(row.get("ridge"), 0.001):
                add_issue(issues, "representation_probe_ridge_mismatch", path, source=source)
            auc = finite_number(row.get("fold9_macro_auroc"))
            accuracy = finite_number(row.get("fold9_accuracy"))
            if auc is None or not 0.0 <= auc <= 1.0:
                add_issue(issues, "representation_probe_auc_invalid", path, source=source, value=auc)
            if accuracy is None or not 0.0 <= accuracy <= 1.0:
                add_issue(
                    issues,
                    "representation_probe_accuracy_invalid",
                    path,
                    source=source,
                    value=accuracy,
                )
            output_rows.append(
                {
                    "kind": "linear_probe",
                    "left_or_source": source,
                    "right": "",
                    "fold9_macro_auroc": auc,
                    "fold9_accuracy": accuracy,
                }
            )
        if sources != expected_sources:
            add_issue(
                issues,
                "representation_probe_source_mismatch",
                path,
                expected=sorted(expected_sources),
                actual=sorted(sources),
            )
    return output_rows


def check_json_metrics(
    payload: Mapping[str, Any],
    protocol: str,
    path: Path,
    issues: list[dict[str, Any]],
) -> dict[str, float]:
    metrics: dict[str, float] = {}
    strict_without_rare_classes = protocol == "strict:tau80"
    if strict_without_rare_classes:
        rare_ids = payload.get("rare_ids", _MISSING)
        if (
            not isinstance(rare_ids, Sequence)
            or isinstance(rare_ids, (str, bytes))
            or len(rare_ids) != 0
        ):
            add_issue(
                issues,
                "strict_rare_ids_contract_mismatch",
                path,
                expected=[],
                actual=None if rare_ids is _MISSING else rare_ids,
            )
        rare_n_defined = nested_get(payload, "diagnosis.rare_n_defined")
        if rare_n_defined != 0:
            add_issue(
                issues,
                "strict_rare_n_defined_mismatch",
                path,
                expected=0,
                actual=None if rare_n_defined is _MISSING else rare_n_defined,
            )
    probability_metrics = {
        "diagnosis.accuracy",
        "diagnosis.balanced_accuracy",
        "diagnosis.macro_f1",
        "diagnosis.weighted_f1",
        "diagnosis.macro_auroc",
        "diagnosis.macro_auprc",
        "diagnosis.rare_macro_f1",
        "diagnosis.rare_macro_auroc",
        "diagnosis.rare_macro_auprc",
        "diagnosis.calibration.raw.ece_fixed",
        "diagnosis.calibration.raw.ece_adaptive",
        "diagnosis.calibration.raw.classwise_ece_fixed",
        "diagnosis.calibration.raw.classwise_ece_adaptive",
        "diagnosis.calibration.temperature_scaled.ece_fixed",
        "diagnosis.calibration.temperature_scaled.ece_adaptive",
        "diagnosis.calibration.temperature_scaled.classwise_ece_fixed",
        "diagnosis.calibration.temperature_scaled.classwise_ece_adaptive",
        "diagnosis.selective_primary.aurc",
        "diagnosis.selective_max_probability.aurc",
    }
    for dotted in DIAGNOSIS_METRICS:
        if strict_without_rare_classes and dotted in RARE_DIAGNOSIS_METRICS:
            value = nested_get(payload, dotted)
            if value is _MISSING:
                add_issue(issues, "strict_rare_metric_missing", path, metric=dotted)
            elif value is not None:
                add_issue(
                    issues,
                    "strict_rare_metric_must_be_null",
                    path,
                    metric=dotted,
                    actual=value,
                )
            continue
        value = check_scalar(
            payload,
            dotted,
            issues,
            path,
            lower=0.0 if dotted in probability_metrics else None,
            upper=1.0 if dotted in probability_metrics else None,
        )
        if value is not None:
            metrics[dotted] = value
    temperature = metrics.get("diagnosis.calibration.temperature")
    if temperature is not None and temperature <= 0:
        add_issue(issues, "calibration_temperature_not_positive", path, value=temperature)
    for dotted in (
        "diagnosis.calibration.raw.nll",
        "diagnosis.calibration.raw.brier",
        "diagnosis.calibration.temperature_scaled.nll",
        "diagnosis.calibration.temperature_scaled.brier",
    ):
        value = metrics.get(dotted)
        if value is not None and value < 0:
            add_issue(issues, "negative_calibration_loss", path, metric=dotted, value=value)

    diagnosis = payload.get("diagnosis")
    if isinstance(diagnosis, Mapping):
        classwise = diagnosis.get("classwise")
        class_names = payload.get("class_names")
        n_classes = int(PROTOCOLS[protocol]["n_classes"])
        if (
            not isinstance(classwise, Sequence)
            or isinstance(classwise, (str, bytes))
            or len(classwise) != n_classes
        ):
            add_issue(
                issues,
                "classwise_report_length_mismatch",
                path,
                expected=n_classes,
                actual=len(classwise) if isinstance(classwise, Sequence) else None,
            )
        else:
            for class_id, row in enumerate(classwise):
                if not isinstance(row, Mapping):
                    add_issue(issues, "classwise_row_invalid", path, class_id=class_id)
                    continue
                expected_name = (
                    str(class_names[class_id])
                    if isinstance(class_names, Sequence) and not isinstance(class_names, (str, bytes))
                    else None
                )
                if row.get("class_id") != class_id or str(row.get("class_name")) != expected_name:
                    add_issue(
                        issues,
                        "classwise_identity_mismatch",
                        path,
                        class_id=class_id,
                        expected_name=expected_name,
                        actual_id=row.get("class_id"),
                        actual_name=row.get("class_name"),
                    )
                for key in (
                    "train_records",
                    "val_records",
                    "test_records",
                    "train_patients",
                    "val_patients",
                    "test_patients",
                ):
                    count = row.get(key)
                    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                        add_issue(
                            issues,
                            "classwise_support_invalid",
                            path,
                            class_id=class_id,
                            field=key,
                            value=count,
                        )
                for key in ("precision", "recall", "f1"):
                    number = finite_number(row.get(key))
                    if number is None or not 0.0 <= number <= 1.0:
                        add_issue(
                            issues,
                            "classwise_metric_invalid",
                            path,
                            class_id=class_id,
                            field=key,
                            value=number,
                        )
        for selective_name in ("selective_primary", "selective_max_probability"):
            fixed = nested_get(diagnosis, f"{selective_name}.fixed_coverage")
            if not isinstance(fixed, Mapping):
                add_issue(issues, "fixed_coverage_report_absent", path, selector=selective_name)
                continue
            for coverage in ("1", "0.9", "0.8", "0.5"):
                row = fixed.get(coverage)
                if not isinstance(row, Mapping):
                    add_issue(
                        issues,
                        "fixed_coverage_cell_absent",
                        path,
                        selector=selective_name,
                        coverage=coverage,
                    )
                    continue
                for key in ("coverage", "balanced_accuracy", "macro_f1"):
                    value = finite_number(row.get(key))
                    if value is None or not 0.0 <= value <= 1.0:
                        add_issue(
                            issues,
                            "fixed_coverage_metric_invalid",
                            path,
                            selector=selective_name,
                            coverage=coverage,
                            metric=key,
                            value=value,
                        )
            fixed_risk = nested_get(diagnosis, f"{selective_name}.coverage_at_fixed_risk")
            if not isinstance(fixed_risk, Mapping):
                add_issue(
                    issues,
                    "fixed_risk_report_absent",
                    path,
                    selector=selective_name,
                )
                continue
            for requested in ("0.01", "0.05", "0.1"):
                row = fixed_risk.get(requested)
                if not isinstance(row, Mapping):
                    add_issue(
                        issues,
                        "fixed_risk_cell_absent",
                        path,
                        selector=selective_name,
                        requested_risk=requested,
                    )
                    continue
                coverage = finite_number(row.get("coverage"))
                accepted = row.get("n_accepted")
                if coverage is None or not 0.0 <= coverage <= 1.0:
                    add_issue(
                        issues,
                        "fixed_risk_coverage_invalid",
                        path,
                        selector=selective_name,
                        requested_risk=requested,
                        value=coverage,
                    )
                if isinstance(accepted, bool) or not isinstance(accepted, int) or accepted < 0:
                    add_issue(
                        issues,
                        "fixed_risk_accepted_count_invalid",
                        path,
                        selector=selective_name,
                        requested_risk=requested,
                        value=accepted,
                    )
                elif accepted == 0:
                    if coverage != 0.0 or row.get("risk") is not None or row.get("threshold") is not None:
                        add_issue(
                            issues,
                            "fixed_risk_empty_cell_inconsistent",
                            path,
                            selector=selective_name,
                            requested_risk=requested,
                        )
                else:
                    for key in ("risk", "threshold"):
                        if finite_number(row.get(key)) is None:
                            add_issue(
                                issues,
                                "fixed_risk_metric_invalid",
                                path,
                                selector=selective_name,
                                requested_risk=requested,
                                metric=key,
                                value=row.get(key),
                            )

    report = payload.get("ood")
    if not isinstance(report, Mapping):
        add_issue(issues, "ood_report_absent", path)
        return metrics
    for detector in OOD_DETECTORS:
        detector_report = report.get(detector)
        if not isinstance(detector_report, Mapping):
            add_issue(issues, "ood_detector_absent", path, detector=detector)
            continue
        primary = detector_report.get("primary")
        if not isinstance(primary, Mapping):
            add_issue(issues, "ood_primary_absent", path, detector=detector)
        else:
            for metric in OOD_METRICS:
                dotted = f"ood.{detector}.primary.{metric}"
                value = finite_number(primary.get(metric))
                if value is None or not 0.0 <= value <= 1.0:
                    add_issue(
                        issues,
                        "ood_metric_invalid",
                        path,
                        detector=detector,
                        metric=metric,
                        value=value,
                    )
                else:
                    metrics[dotted] = value
        operating = detector_report.get("operating_point")
        if not isinstance(operating, Mapping):
            add_issue(issues, "ood_operating_point_absent", path, detector=detector)
        else:
            for metric in OPERATING_METRICS:
                value = finite_number(operating.get(metric))
                if value is None:
                    add_issue(
                        issues,
                        "ood_operating_metric_invalid",
                        path,
                        detector=detector,
                        metric=metric,
                        value=operating.get(metric),
                    )
                elif metric != "threshold" and not 0.0 <= value <= 1.0:
                    add_issue(
                        issues,
                        "ood_operating_metric_out_of_bounds",
                        path,
                        detector=detector,
                        metric=metric,
                        value=value,
                    )
        strata = detector_report.get("strata")
        if not isinstance(strata, Mapping):
            add_issue(issues, "ood_strata_absent", path, detector=detector)
        else:
            for scenario in PROTOCOLS[protocol]["out_scenarios"]:
                row = strata.get(scenario)
                if not isinstance(row, Mapping):
                    add_issue(
                        issues,
                        "ood_stratum_absent",
                        path,
                        detector=detector,
                        scenario=scenario,
                    )
                    continue
                for metric in OOD_METRICS:
                    value = finite_number(row.get(metric))
                    if value is None or not 0.0 <= value <= 1.0:
                        add_issue(
                            issues,
                            "ood_stratum_metric_invalid",
                            path,
                            detector=detector,
                            scenario=scenario,
                            metric=metric,
                            value=value,
                        )
    coefficient = report.get("coefficient_sensitivity")
    if not isinstance(coefficient, Mapping):
        add_issue(issues, "ood_coefficient_sensitivity_absent", path)
    else:
        for value in ("0.0", "0.5", "1.0", "2.0"):
            row = coefficient.get(value)
            if not isinstance(row, Mapping):
                add_issue(issues, "ood_coefficient_cell_absent", path, coefficient=value)
                continue
            for section, required in (
                ("metrics", OOD_METRICS),
                ("operating_point", OPERATING_METRICS),
            ):
                values = row.get(section)
                if not isinstance(values, Mapping):
                    add_issue(
                        issues,
                        "ood_coefficient_section_absent",
                        path,
                        coefficient=value,
                        section=section,
                    )
                    continue
                for metric in required:
                    number = finite_number(values.get(metric))
                    if number is None:
                        add_issue(
                            issues,
                            "ood_coefficient_metric_invalid",
                            path,
                            coefficient=value,
                            section=section,
                            metric=metric,
                            value=values.get(metric),
                        )
                    elif metric != "threshold" and not 0.0 <= number <= 1.0:
                        add_issue(
                            issues,
                            "ood_coefficient_metric_out_of_bounds",
                            path,
                            coefficient=value,
                            section=section,
                            metric=metric,
                            value=number,
                        )
    return metrics


def check_artifact_manifest(
    payload: Mapping[str, Any],
    paths: Mapping[str, Path],
    issues: list[dict[str, Any]],
) -> None:
    artifacts = payload.get("artifacts")
    if not isinstance(artifacts, Mapping):
        add_issue(issues, "artifact_manifest_absent", paths["json"])
        return
    if set(artifacts) != {"raw_npz", "ood_npz"}:
        add_issue(
            issues,
            "artifact_manifest_roles_mismatch",
            paths["json"],
            expected=["ood_npz", "raw_npz"],
            actual=sorted(artifacts),
        )
    for role in ("raw_npz", "ood_npz"):
        declared = artifacts.get(role)
        artifact = paths[role]
        if not isinstance(declared, Mapping):
            add_issue(issues, "artifact_role_manifest_absent", paths["json"], role=role)
            continue
        expected = {
            "filename": artifact.name,
            "bytes": int(artifact.stat().st_size) if artifact.is_file() else None,
            "sha256": sha256_file(artifact) if artifact.is_file() else None,
        }
        for key, value in expected.items():
            if declared.get(key) != value:
                add_issue(
                    issues,
                    "artifact_manifest_mismatch",
                    paths["json"],
                    role=role,
                    field=key,
                    expected=value,
                    actual=declared.get(key),
                )


def require_array(
    archive: Mapping[str, np.ndarray],
    name: str,
    shape: tuple[int, ...] | None,
    path: Path,
    issues: list[dict[str, Any]],
) -> np.ndarray | None:
    value = archive.get(name)
    if value is None:
        add_issue(issues, "npz_array_absent", path, array=name)
        return None
    if shape is not None and tuple(value.shape) != shape:
        add_issue(
            issues,
            "npz_shape_mismatch",
            path,
            array=name,
            expected=list(shape),
            actual=list(value.shape),
        )
    return value


def check_raw_npz(
    archive: Mapping[str, np.ndarray],
    protocol: str,
    group: Mapping[str, Any],
    payload: Mapping[str, Any],
    path: Path,
    issues: list[dict[str, Any]],
) -> dict[str, Any]:
    spec = PROTOCOLS[protocol]
    n_val = int(spec["validation_n"])
    n_test = int(spec["test_n"])
    n_classes = int(spec["n_classes"])
    source_count = int(group["model"]["source_count"])
    required_shapes = {
        "val_prob": (n_val, n_classes),
        "val_logits": (n_val, n_classes),
        "val_y": (n_val,),
        "test_prob": (n_test, n_classes),
        "test_logits": (n_test, n_classes),
        "test_y": (n_test,),
        "test_patient": (n_test,),
        "class_names": (n_classes,),
        "val_u": (n_val,),
        "test_u": (n_test,),
        "val_source_u": (n_val, source_count),
        "test_source_u": (n_test, source_count),
        "val_source_q": (n_val, source_count),
        "test_source_q": (n_test, source_count),
        "val_source_w": (n_val, source_count),
        "test_source_w": (n_test, source_count),
        "val_q_observed": (n_val, source_count),
        "test_q_observed": (n_test, source_count),
    }
    arrays: dict[str, np.ndarray | None] = {
        name: require_array(archive, name, shape, path, issues)
        for name, shape in required_shapes.items()
    }
    rare_ids = require_array(archive, "rare_ids", None, path, issues)
    for split in ("val", "test"):
        probability = arrays[f"{split}_prob"]
        if probability is not None:
            if np.any(probability < -1e-6) or np.any(probability > 1.0 + 1e-6):
                add_issue(issues, "probability_out_of_bounds", path, split=split)
            if probability.ndim == 2 and not np.allclose(
                probability.sum(axis=1), 1.0, rtol=1e-5, atol=1e-5
            ):
                add_issue(issues, "probability_rows_not_normalized", path, split=split)
        labels = arrays[f"{split}_y"]
        if labels is not None:
            if not np.issubdtype(labels.dtype, np.integer):
                add_issue(issues, "label_dtype_not_integer", path, split=split, dtype=str(labels.dtype))
            if labels.size and (int(labels.min()) < 0 or int(labels.max()) >= n_classes):
                add_issue(issues, "label_out_of_range", path, split=split)
    class_names = arrays["class_names"]
    if class_names is not None and list(map(str, class_names.tolist())) != list(
        map(str, payload.get("class_names", []))
    ):
        add_issue(issues, "raw_class_names_payload_mismatch", path)
    patients = arrays["test_patient"]
    if patients is not None:
        if patients.dtype.kind not in ("U", "S"):
            add_issue(issues, "test_patient_dtype_not_string", path, dtype=str(patients.dtype))
        elif any(not str(value).strip() for value in patients.tolist()):
            add_issue(issues, "empty_test_patient_identifier", path)
    for split in ("val", "test"):
        observed_quality = arrays[f"{split}_q_observed"]
        if observed_quality is not None and observed_quality.dtype != np.dtype(bool):
            add_issue(
                issues,
                "q_observed_dtype_not_boolean",
                path,
                split=split,
                dtype=str(observed_quality.dtype),
            )
    if rare_ids is not None:
        if rare_ids.ndim != 1 or not np.issubdtype(rare_ids.dtype, np.integer):
            add_issue(issues, "rare_ids_invalid", path, shape=list(rare_ids.shape), dtype=str(rare_ids.dtype))
        elif rare_ids.size and (int(rare_ids.min()) < 0 or int(rare_ids.max()) >= n_classes):
            add_issue(issues, "rare_ids_out_of_range", path)
        if rare_ids.tolist() != payload.get("rare_ids"):
            add_issue(issues, "raw_rare_ids_payload_mismatch", path)

    weight_diagnostics: dict[str, Any] = {}
    for split in ("val", "test"):
        weights = arrays[f"{split}_source_w"]
        if weights is None or weights.ndim != 2:
            continue
        if np.any(weights < -1e-7) or np.any(weights > 1.0 + 1e-7):
            add_issue(issues, "source_weight_out_of_bounds", path, split=split)
        row_sum = weights.sum(axis=1)
        weight_diagnostics[f"{split}_mean_sum"] = float(row_sum.mean())
        weight_diagnostics[f"{split}_min_sum"] = float(row_sum.min())
        weight_diagnostics[f"{split}_max_sum"] = float(row_sum.max())
        weight_diagnostics[f"{split}_mean_per_source"] = weights.mean(axis=0).tolist()
        tag = str(group["tag"])
        if tag == "gate_sample_normalized" and not np.allclose(
            row_sum, 1.0, rtol=1e-6, atol=1e-6
        ):
            add_issue(issues, "normalized_gate_rows_do_not_sum_to_one", path, split=split)
        if tag == "gate_global":
            spread = np.ptp(weights, axis=0)
            weight_diagnostics[f"{split}_max_within_source_spread"] = float(spread.max())
            if np.any(spread > 1e-7):
                add_issue(
                    issues,
                    "global_gate_is_sample_dependent",
                    path,
                    split=split,
                    max_spread=float(spread.max()),
                )
    return weight_diagnostics


def check_ood_npz(
    archive: Mapping[str, np.ndarray],
    protocol: str,
    group: Mapping[str, Any],
    path: Path,
    issues: list[dict[str, Any]],
) -> None:
    spec = PROTOCOLS[protocol]
    for detector in OOD_DETECTORS:
        for split, expected_length in spec["ood_lengths"].items():
            name = f"{detector}__{split}"
            value = require_array(archive, name, (int(expected_length),), path, issues)
            if value is not None and not np.issubdtype(value.dtype, np.number):
                add_issue(issues, "ood_score_not_numeric", path, array=name, dtype=str(value.dtype))
    source_count = int(group["model"]["source_count"])
    for split, expected_length in spec["ood_lengths"].items():
        name = f"source_w__{split}"
        value = require_array(
            archive,
            name,
            (int(expected_length), source_count),
            path,
            issues,
        )
        if value is not None and (
            np.any(value < -1e-7) or np.any(value > 1.0 + 1e-7)
        ):
            add_issue(issues, "ood_source_weight_out_of_bounds", path, array=name)
        if value is not None and group["tag"] == "gate_sample_normalized" and not np.allclose(
            value.sum(axis=1), 1.0, rtol=1e-6, atol=1e-6
        ):
            add_issue(issues, "normalized_ood_gate_rows_do_not_sum_to_one", path, split=split)
        if value is not None and group["tag"] == "gate_global" and np.any(
            np.ptp(value, axis=0) > 1e-7
        ):
            add_issue(issues, "global_ood_gate_is_sample_dependent", path, split=split)


def reference_paths(reference_root: Path, protocol: str) -> tuple[Path, Path]:
    directory = reference_root.joinpath(*PROTOCOLS[protocol]["directory"], "trust_full")
    return directory / "seed_7.json", directory / "seed_7_raw.npz"


def load_references(
    reference_root: Path, issues: list[dict[str, Any]]
) -> dict[str, dict[str, Any]]:
    references: dict[str, dict[str, Any]] = {}
    for protocol in PROTOCOLS:
        json_path, raw_path = reference_paths(reference_root, protocol)
        if not json_path.is_file():
            add_issue(issues, "reference_json_absent", json_path)
            continue
        if not raw_path.is_file():
            add_issue(issues, "reference_raw_absent", raw_path)
            continue
        payload = load_json(json_path, issues)
        raw = load_npz(raw_path, issues)
        if payload is None or raw is None:
            continue
        required = ("val_y", "test_y", "test_patient", "class_names", "rare_ids")
        if any(name not in raw for name in required):
            add_issue(issues, "reference_array_absent", raw_path, required=list(required))
            continue
        references[protocol] = {
            "json_path": str(json_path),
            "raw_path": str(raw_path),
            "json_sha256": sha256_file(json_path),
            "raw_sha256": sha256_file(raw_path),
            "split": payload.get("split"),
            "class_names": payload.get("class_names"),
            "rare_ids": payload.get("rare_ids"),
            "rare_names": payload.get("rare_names"),
            "arrays": {name: raw[name] for name in required},
        }
    return references


def check_reference_alignment(
    payload: Mapping[str, Any],
    raw: Mapping[str, np.ndarray],
    protocol: str,
    reference: Mapping[str, Any] | None,
    json_path: Path,
    raw_path: Path,
    issues: list[dict[str, Any]],
) -> None:
    if reference is None:
        add_issue(issues, "reference_alignment_unavailable", json_path, protocol=protocol)
        return
    for key in ("split", "class_names", "rare_ids", "rare_names"):
        if not values_equal(payload.get(key), reference.get(key)):
            add_issue(issues, "formal_reference_json_mismatch", json_path, field=key)
    for name, expected in reference["arrays"].items():
        actual = raw.get(name)
        if actual is None or not np.array_equal(actual, expected):
            add_issue(issues, "formal_reference_array_mismatch", raw_path, array=name)


def t_critical_95(n: int) -> float:
    table = {
        2: 12.706204736,
        3: 4.302652730,
        4: 3.182446305,
        5: 2.776445105,
    }
    return table.get(n, 1.959963985)


def summarize(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    n = int(len(array))
    mean = float(array.mean())
    if n > 1:
        standard_deviation = float(array.std(ddof=1))
        half = t_critical_95(n) * standard_deviation / math.sqrt(n)
    else:
        standard_deviation = 0.0
        half = 0.0
    return {
        "n": n,
        "mean": mean,
        "sd": standard_deviation,
        "ci95_low": mean - half,
        "ci95_high": mean + half,
        "min": float(array.min()),
        "max": float(array.max()),
    }


def aggregate_records(records: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    grouped: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[(str(record["protocol"]), str(record["tag"]))].append(record)
    csv_rows: list[dict[str, Any]] = []
    structured: dict[str, Any] = {}
    for (protocol, tag), rows in sorted(grouped.items()):
        group_payload: dict[str, Any] = {
            "protocol": protocol,
            "tag": tag,
            "seeds": sorted(int(row["seed"]) for row in rows),
            "metrics": {},
        }
        for metric in SUMMARY_METRICS:
            values = [row["metrics"].get(metric) for row in rows]
            finite = [float(value) for value in values if finite_number(value) is not None]
            if not finite:
                continue
            stats = summarize(finite)
            group_payload["metrics"][metric] = stats
            csv_rows.append({"protocol": protocol, "tag": tag, "metric": metric, **stats})
        structured[f"{protocol}|{tag}"] = group_payload
    return csv_rows, structured


def aggregate_feature_diagnostics(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    metric_names = (
        "mean_absolute_cosine",
        "linear_cka_normalized_hsic",
        "fold9_macro_auroc",
        "fold9_accuracy",
    )
    grouped: dict[tuple[str, str, str, str, str, str], list[float]] = defaultdict(list)
    for row in rows:
        for metric in metric_names:
            value = finite_number(row.get(metric))
            if value is None:
                continue
            identity = (
                str(row.get("protocol")),
                str(row.get("tag")),
                str(row.get("kind")),
                str(row.get("left_or_source")),
                str(row.get("right", "")),
                metric,
            )
            grouped[identity].append(value)
    csv_rows: list[dict[str, Any]] = []
    structured: dict[str, Any] = {}
    for identity, values in sorted(grouped.items()):
        protocol, tag, kind, left, right, metric = identity
        stats = summarize(values)
        row = {
            "protocol": protocol,
            "tag": tag,
            "kind": kind,
            "left_or_source": left,
            "right": right,
            "metric": metric,
            **stats,
        }
        csv_rows.append(row)
        structured["|".join(identity)] = row
    return csv_rows, structured


def aggregate_weight_diagnostics(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    metrics = (
        "val_mean_sum",
        "val_min_sum",
        "val_max_sum",
        "val_max_within_source_spread",
        "test_mean_sum",
        "test_min_sum",
        "test_max_sum",
        "test_max_within_source_spread",
    )
    grouped: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    for row in rows:
        for metric in metrics:
            value = finite_number(row.get(metric))
            if value is not None:
                grouped[(str(row["protocol"]), str(row["tag"]), metric)].append(value)
    output: list[dict[str, Any]] = []
    for (protocol, tag, metric), values in sorted(grouped.items()):
        output.append(
            {
                "protocol": protocol,
                "tag": tag,
                "metric": metric,
                **summarize(values),
            }
        )
    return output


def paired_effects(records: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_identity = {
        (str(row["protocol"]), str(row["tag"]), int(row["seed"])): row
        for row in records
    }
    tags_by_protocol: dict[str, set[str]] = defaultdict(set)
    for protocol, tag, _ in by_identity:
        tags_by_protocol[protocol].add(tag)
    output: list[dict[str, Any]] = []
    details: list[dict[str, Any]] = []
    for protocol, tags in sorted(tags_by_protocol.items()):
        for tag in sorted(tags):
            if protocol == "closed":
                baseline_tag = "pareto_eta_0.1_aux_0.3"
            elif tag.startswith("aux_"):
                baseline_tag = "aux_0.3"
            else:
                baseline_tag = "eta_0.1"
            if tag == baseline_tag or baseline_tag not in tags:
                continue
            common_seeds = sorted(
                seed
                for p, t, seed in by_identity
                if p == protocol
                and t == tag
                and (protocol, baseline_tag, seed) in by_identity
            )
            for metric in PAIR_METRICS:
                deltas = []
                seed_values = []
                for seed in common_seeds:
                    candidate = by_identity[(protocol, tag, seed)]["metrics"].get(metric)
                    baseline = by_identity[(protocol, baseline_tag, seed)]["metrics"].get(metric)
                    if finite_number(candidate) is None or finite_number(baseline) is None:
                        continue
                    delta = float(candidate) - float(baseline)
                    deltas.append(delta)
                    seed_values.append(
                        {
                            "seed": seed,
                            "candidate": float(candidate),
                            "baseline": float(baseline),
                            "delta": delta,
                        }
                    )
                if not deltas:
                    continue
                stats = summarize(deltas)
                row = {
                    "protocol": protocol,
                    "candidate": tag,
                    "baseline": baseline_tag,
                    "metric": metric,
                    **stats,
                    "positive": int(sum(value > 0 for value in deltas)),
                    "negative": int(sum(value < 0 for value in deltas)),
                    "zero": int(sum(value == 0 for value in deltas)),
                }
                output.append(row)
                details.append({**row, "seed_values": seed_values})
    return output, details


def expected_task_names() -> tuple[str, ...]:
    names: list[str] = []
    for eta_text in ETA_TEXT:
        for seed in FIVE_SEEDS:
            names.append(f"closed_pareto_eta{eta_text}_seed{seed}")
    for seed in FIVE_SEEDS:
        names.append(f"strict_eta_full_seed{seed}")
        names.append(f"strict_aux_primary_seed{seed}")
    for protocol in ("closed", "strict"):
        for seed in FIVE_SEEDS:
            names.append(f"{protocol}_objective_alternatives_seed{seed}")
            names.append(f"{protocol}_gate_architecture_seed{seed}")
    for seed in THREE_SEEDS:
        names.append(f"closed_capacity_matched_source_count_seed{seed}")
        names.append(f"closed_tmc_tmdf_source_count_seed{seed}")
    if len(names) != 66 or len(set(names)) != 66:
        raise AuditError(f"internal task-name matrix drift: {len(names)}")
    return tuple(names)


def audit_launcher_logs(log_dir: Path, issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not log_dir.is_dir():
        add_issue(issues, "launcher_log_directory_absent", log_dir)
        return rows
    names = expected_task_names()
    expected_exit_paths = {log_dir / f"{name}.exit" for name in names}
    observed_exit_paths = set(log_dir.glob("*.exit"))
    for unexpected in sorted(observed_exit_paths - expected_exit_paths):
        add_issue(issues, "unexpected_task_exit_file", unexpected)
    for name in names:
        command_path = log_dir / f"{name}.command.txt"
        log_path = log_dir / f"{name}.log"
        exit_path = log_dir / f"{name}.exit"
        row: dict[str, Any] = {"task": name}
        for role, path in (
            ("command", command_path),
            ("log", log_path),
            ("exit", exit_path),
        ):
            if not path.is_file():
                add_issue(issues, "task_log_artifact_absent", path, task=name, role=role)
                row[f"{role}_present"] = False
            else:
                row[f"{role}_present"] = True
                row[f"{role}_bytes"] = int(path.stat().st_size)
                row[f"{role}_sha256"] = sha256_file(path)
        if exit_path.is_file():
            status = exit_path.read_text(encoding="utf-8", errors="replace").strip()
            row["exit_status"] = status
            if status != "0":
                add_issue(issues, "task_nonzero_exit", exit_path, task=name, status=status)
        if command_path.is_file():
            command = command_path.read_text(encoding="utf-8", errors="replace")
            if "run_ptbxl_missing_extensions.py" not in command:
                add_issue(issues, "task_command_runner_mismatch", command_path, task=name)
        if log_path.is_file():
            log_text = log_path.read_text(encoding="utf-8", errors="replace")
            failure_tokens = (
                "Traceback (most recent call last)",
                "CUDA out of memory",
                "torch.OutOfMemoryError",
                "Killed",
                "FAILED:",
            )
            found = [token for token in failure_tokens if token in log_text]
            if found:
                add_issue(issues, "task_log_failure_token", log_path, task=name, tokens=found)
        rows.append(row)
    marker = log_dir / "missing_matrix.complete"
    if not marker.is_file() or not marker.read_text(encoding="utf-8", errors="replace").strip():
        add_issue(issues, "launcher_complete_marker_absent", marker)
    manifest = log_dir / "missing_matrix_manifest.txt"
    if not manifest.is_file():
        add_issue(issues, "launcher_manifest_absent", manifest)
    else:
        text = manifest.read_text(encoding="utf-8", errors="replace")
        for expected in (
            "expected_task_processes=66",
            "expected_new_results_and_fits=221",
            "epochs=40",
            "batch_size=256",
        ):
            if expected not in text:
                add_issue(
                    issues,
                    "launcher_manifest_contract_mismatch",
                    manifest,
                    expected_text=expected,
                )
    return rows


def audit_current_code(
    experiment_dir: Path,
    observed_manifests: Mapping[str, Mapping[str, Any]],
    auditor_path: Path,
    issues: list[dict[str, Any]],
) -> dict[str, Any]:
    mapping = {
        "run_ptbxl_revision.py": experiment_dir / "run_ptbxl_missing_extensions.py",
        "base_run_ptbxl_revision.py": experiment_dir / "run_ptbxl_revision.py",
        "revisionlib.py": experiment_dir / "revisionlib.py",
        "data_adapter.py": experiment_dir / "data_adapter.py",
    }
    result: dict[str, Any] = {
        "auditor": {
            "path": str(auditor_path.resolve()),
            "sha256": sha256_file(auditor_path),
        },
        "files": {},
    }
    manifest = next(iter(observed_manifests.values())) if len(observed_manifests) == 1 else None
    for role, path in mapping.items():
        if not path.is_file():
            add_issue(issues, "current_code_file_absent", path, role=role)
            result["files"][role] = {"path": str(path), "present": False}
            continue
        digest = sha256_file(path)
        expected = manifest.get(role) if isinstance(manifest, Mapping) else None
        result["files"][role] = {
            "path": str(path.resolve()),
            "present": True,
            "sha256": digest,
            "run_manifest_sha256": expected,
            "matches_run_manifest": digest == expected,
        }
        if expected is None or digest != expected:
            add_issue(
                issues,
                "current_code_hash_differs_from_run",
                path,
                role=role,
                current=digest,
                run_manifest=expected,
            )
    return result


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--results-dir",
        default="/dev/shm/Paper46_revision_results_missing/ptbxl",
        help="separate 221-run extension result root",
    )
    parser.add_argument(
        "--reference-results-dir",
        default="/root/Paper46_revision/results_final/ptbxl",
        help="frozen 212-run result root used only for exact split/label alignment",
    )
    parser.add_argument(
        "--output-dir",
        default="/dev/shm/Paper46_aggregate_final/promised_extensions",
    )
    parser.add_argument(
        "--log-dir",
        default="/root/Paper46_revision/logs_final/ptbxl_missing",
        help="launcher commands, logs, exit files, manifest, and completion marker",
    )
    parser.add_argument(
        "--experiment-dir",
        default="/root/Paper46_revision/experiments",
        help="deployed code directory whose hashes must equal every run definition",
    )
    parser.add_argument(
        "--fail-on-incomplete",
        action="store_true",
        help="return exit status 2 if any strict audit issue is found",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    root = Path(args.results_dir).expanduser().resolve()
    reference_root = Path(args.reference_results_dir).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    log_dir = Path(args.log_dir).expanduser().resolve()
    experiment_dir = Path(args.experiment_dir).expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"extension result root is absent: {root}")
    if root == reference_root:
        raise SystemExit("extension and frozen reference roots must be different")
    if output_dir == root or root in output_dir.parents:
        raise SystemExit("output directory must be outside the extension result root")

    started = time.time()
    config = build_expected_config()
    paths_by_identity = expected_paths(root, config)
    groups_by_identity = expected_groups_by_identity(config)
    allowed = {
        path.resolve()
        for paths in paths_by_identity.values()
        for path in paths.values()
    }
    issues: list[dict[str, Any]] = []
    input_manifest = inspect_extra_files(root, output_dir, allowed, issues)
    references = load_references(reference_root, issues)

    records: list[dict[str, Any]] = []
    feature_rows: list[dict[str, Any]] = []
    weight_rows: list[dict[str, Any]] = []
    code_manifests: dict[str, list[str]] = defaultdict(list)
    code_manifest_values: dict[str, Mapping[str, Any]] = {}

    for identity in sorted(paths_by_identity):
        protocol, tag, seed = identity
        paths = paths_by_identity[identity]
        group = groups_by_identity[identity]
        issue_start = len(issues)
        for role, path in paths.items():
            if not path.is_file():
                add_issue(issues, "expected_artifact_absent", path, role=role, identity=list(identity))
        if not all(path.is_file() for path in paths.values()):
            continue

        payload = load_json(paths["json"], issues)
        raw = load_npz(paths["raw_npz"], issues)
        ood = load_npz(paths["ood_npz"], issues)
        if payload is None or raw is None or ood is None:
            continue

        check_common_configuration(payload, protocol, tag, seed, paths["json"], issues)
        check_model_contract(payload, group, paths["json"], issues)
        definition = check_fingerprint(payload, paths["json"], issues)
        if definition is not None and isinstance(definition.get("code_sha256"), Mapping):
            code_key = sha256_object(definition["code_sha256"])
            code_manifests[code_key].append(str(paths["json"]))
            code_manifest_values[code_key] = definition["code_sha256"]
        result_directory = nested_get(payload, "environment.arguments.results_dir")
        try:
            result_directory_resolved = Path(str(result_directory)).expanduser().resolve()
        except Exception:
            result_directory_resolved = None
        if result_directory_resolved != root:
            add_issue(
                issues,
                "run_results_directory_mismatch",
                paths["json"],
                expected=str(root),
                actual=result_directory,
            )
        check_training(payload, group, paths["json"], issues)
        diagnostic_rows = check_representation_diagnostics(
            payload, group, protocol, paths["json"], issues
        )
        for row in diagnostic_rows:
            feature_rows.append({"protocol": protocol, "tag": tag, "seed": seed, **row})
        metrics = check_json_metrics(payload, protocol, paths["json"], issues)
        check_artifact_manifest(payload, paths, issues)
        weight_diagnostics = check_raw_npz(
            raw, protocol, group, payload, paths["raw_npz"], issues
        )
        check_ood_npz(ood, protocol, group, paths["ood_npz"], issues)
        check_reference_alignment(
            payload,
            raw,
            protocol,
            references.get(protocol),
            paths["json"],
            paths["raw_npz"],
            issues,
        )
        weight_rows.append(
            {
                "protocol": protocol,
                "tag": tag,
                "seed": seed,
                **{
                    key: json.dumps(value, separators=(",", ":"))
                    if isinstance(value, list)
                    else value
                    for key, value in weight_diagnostics.items()
                },
            }
        )
        records.append(
            {
                "protocol": protocol,
                "tag": tag,
                "seed": seed,
                "family": group["family"],
                "source_count": group["model"]["source_count"],
                "json_path": str(paths["json"]),
                "raw_npz_path": str(paths["raw_npz"]),
                "ood_npz_path": str(paths["ood_npz"]),
                "run_fingerprint": payload.get("run_fingerprint"),
                "parameter_total": nested_get(payload, "parameter_count.total"),
                "parameter_trainable": nested_get(payload, "parameter_count.trainable"),
                "metrics": metrics,
                "complete": len(issues) == issue_start,
            }
        )

    if len(code_manifests) != 1:
        add_issue(
            issues,
            "nonuniform_code_hash_manifests",
            manifests={key: len(value) for key, value in code_manifests.items()},
        )
    elif sum(len(value) for value in code_manifests.values()) != 221:
        add_issue(
            issues,
            "code_manifest_record_count_mismatch",
            expected=221,
            actual=sum(len(value) for value in code_manifests.values()),
        )
    current_code = audit_current_code(
        experiment_dir,
        code_manifest_values,
        Path(__file__),
        issues,
    )
    task_logs = audit_launcher_logs(log_dir, issues)

    observed_json = sum(1 for row in input_manifest if row["relative_path"].endswith(".json"))
    observed_npz = sum(1 for row in input_manifest if row["relative_path"].endswith(".npz"))
    if observed_json != 221:
        add_issue(issues, "json_count_mismatch", expected=221, actual=observed_json)
    if observed_npz != 442:
        add_issue(issues, "npz_count_mismatch", expected=442, actual=observed_npz)
    if len(records) != 221:
        add_issue(issues, "loaded_record_count_mismatch", expected=221, actual=len(records))
    if len(feature_rows) != 1400:
        add_issue(
            issues,
            "representation_diagnostic_row_count_mismatch",
            expected=1400,
            actual=len(feature_rows),
        )
    if len(weight_rows) != 221:
        add_issue(
            issues,
            "source_weight_diagnostic_row_count_mismatch",
            expected=221,
            actual=len(weight_rows),
        )

    summary_rows, structured_summary = aggregate_records(records)
    pair_rows, pair_details = paired_effects(records)
    feature_summary_rows, structured_feature_summary = aggregate_feature_diagnostics(feature_rows)
    weight_summary_rows = aggregate_weight_diagnostics(weight_rows)
    if len(structured_summary) != 49:
        add_issue(
            issues,
            "aggregated_group_count_mismatch",
            expected=49,
            actual=len(structured_summary),
        )
    record_rows: list[dict[str, Any]] = []
    for record in records:
        record_rows.append(
            {
                key: value
                for key, value in record.items()
                if key != "metrics"
            }
            | {metric: record["metrics"].get(metric) for metric in SUMMARY_METRICS}
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(output_dir / "expected_config.json", config)
    atomic_json(output_dir / "summary.json", structured_summary)
    atomic_json(output_dir / "paired_effects.json", pair_details)
    atomic_json(output_dir / "representation_diagnostics_summary.json", structured_feature_summary)
    atomic_json(output_dir / "input_files.json", input_manifest)
    atomic_json(output_dir / "task_logs.json", task_logs)
    atomic_json(output_dir / "code_manifest.json", current_code)
    atomic_csv(
        output_dir / "records.csv",
        record_rows,
        (
            "protocol",
            "tag",
            "seed",
            "family",
            "source_count",
            "complete",
            "parameter_total",
            "parameter_trainable",
            "run_fingerprint",
            *SUMMARY_METRICS,
            "json_path",
            "raw_npz_path",
            "ood_npz_path",
        ),
    )
    atomic_csv(
        output_dir / "summary.csv",
        summary_rows,
        ("protocol", "tag", "metric", "n", "mean", "sd", "ci95_low", "ci95_high", "min", "max"),
    )
    atomic_csv(
        output_dir / "paired_effects.csv",
        pair_rows,
        (
            "protocol",
            "candidate",
            "baseline",
            "metric",
            "n",
            "mean",
            "sd",
            "ci95_low",
            "ci95_high",
            "min",
            "max",
            "positive",
            "negative",
            "zero",
        ),
    )
    atomic_csv(
        output_dir / "representation_diagnostics.csv",
        feature_rows,
        (
            "protocol",
            "tag",
            "seed",
            "kind",
            "left_or_source",
            "right",
            "mean_absolute_cosine",
            "linear_cka_normalized_hsic",
            "fold9_macro_auroc",
            "fold9_accuracy",
        ),
    )
    atomic_csv(
        output_dir / "representation_diagnostics_summary.csv",
        feature_summary_rows,
        (
            "protocol",
            "tag",
            "kind",
            "left_or_source",
            "right",
            "metric",
            "n",
            "mean",
            "sd",
            "ci95_low",
            "ci95_high",
            "min",
            "max",
        ),
    )
    weight_fields = (
        "protocol",
        "tag",
        "seed",
        "val_mean_sum",
        "val_min_sum",
        "val_max_sum",
        "val_mean_per_source",
        "val_max_within_source_spread",
        "test_mean_sum",
        "test_min_sum",
        "test_max_sum",
        "test_mean_per_source",
        "test_max_within_source_spread",
    )
    atomic_csv(output_dir / "source_weight_diagnostics.csv", weight_rows, weight_fields)
    atomic_csv(
        output_dir / "source_weight_diagnostics_summary.csv",
        weight_summary_rows,
        ("protocol", "tag", "metric", "n", "mean", "sd", "ci95_low", "ci95_high", "min", "max"),
    )

    issue_counts: dict[str, int] = defaultdict(int)
    for issue in issues:
        issue_counts[str(issue["code"])] += 1
    manifest = {
        "schema_version": 1,
        "auditor_version": AUDITOR_VERSION,
        "created_at_unix": time.time(),
        "elapsed_seconds": time.time() - started,
        "results_dir": str(root),
        "reference_results_dir": str(reference_root),
        "log_dir": str(log_dir),
        "experiment_dir": str(experiment_dir),
        "output_dir": str(output_dir),
        "complete": len(issues) == 0,
        "expected_group_count": 49,
        "expected_record_count": 221,
        "loaded_record_count": len(records),
        "input_json_count": observed_json,
        "input_npz_count": observed_npz,
        "uniform_code_manifest_count": len(code_manifests),
        "reference_files": {
            protocol: {
                key: value
                for key, value in reference.items()
                if key != "arrays"
            }
            for protocol, reference in references.items()
        },
        "current_code": current_code,
        "task_log_count": len(task_logs),
        "representation_diagnostic_row_count": len(feature_rows),
        "source_weight_diagnostic_row_count": len(weight_rows),
        "issue_count": len(issues),
        "issue_counts": dict(sorted(issue_counts.items())),
        "issues": issues,
        "interpretation_constraints": config["interpretation_constraints"],
        "outputs": [
            "expected_config.json",
            "records.csv",
            "summary.csv",
            "summary.json",
            "paired_effects.csv",
            "paired_effects.json",
            "representation_diagnostics.csv",
            "representation_diagnostics_summary.csv",
            "representation_diagnostics_summary.json",
            "source_weight_diagnostics.csv",
            "source_weight_diagnostics_summary.csv",
            "input_files.json",
            "task_logs.json",
            "code_manifest.json",
        ],
    }
    atomic_json(output_dir / "audit_manifest.json", manifest)
    print(
        json.dumps(
            {
                "complete": manifest["complete"],
                "expected_records": 221,
                "loaded_records": len(records),
                "issue_count": len(issues),
                "output_dir": str(output_dir),
            },
            sort_keys=True,
        ),
        flush=True,
    )
    if args.fail_on_incomplete and issues:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
