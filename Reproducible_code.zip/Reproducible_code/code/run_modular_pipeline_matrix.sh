#!/usr/bin/env bash
# Run the inference-only Modular Softmax+SQI+Mahalanobis control on AutoDL.
#
# All mutable artifacts, temporary files, Python bytecode, results, logs, and
# audit outputs live in /dev/shm.  The launcher never trains a neural model,
# never writes a result to /root, and never shuts down the server.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
EVALUATOR="${EXPERIMENT_DIR}/evaluate_modular_pipeline.py"
AUDITOR="${EXPERIMENT_DIR}/audit_modular_pipeline.py"

PTB_RESULTS_DIR="${PTB_RESULTS_DIR:-${REVISION_ROOT}/results_final/ptbxl}"
NOISE_RESULTS_DIR="${NOISE_RESULTS_DIR:-${REVISION_ROOT}/results_final/noise_sqi}"
NOISE_CHECKPOINT_DIR="${NOISE_CHECKPOINT_DIR:-${REVISION_ROOT}/checkpoints_final/noise_sqi}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"

SHM_ROOT="${SHM_ROOT:-/dev/shm/Paper46_modular_pipeline}"
OUTPUT_DIR="${OUTPUT_DIR:-${SHM_ROOT}/results}"
AUDIT_DIR="${AUDIT_DIR:-${SHM_ROOT}/audit}"
TMP_DIR="${TMP_DIR:-${SHM_ROOT}/tmp}"
PYCACHE_DIR="${PYCACHE_DIR:-${SHM_ROOT}/pycache}"
LOG_DIR="${LOG_DIR:-/dev/shm/Paper46_logs_missing/modular_pipeline}"
EVAL_BATCH_SIZE="${EVAL_BATCH_SIZE:-512}"
FEATURE_CHUNK_SIZE="${FEATURE_CHUNK_SIZE:-256}"
CPU_THREADS_PER_WORKER="${CPU_THREADS_PER_WORKER:-16}"
DEVICE="${DEVICE:-cuda}"

PTB_SEEDS=(7 13 42 99 2026)
NOISE_SEEDS=(7 13 42)
EXPECTED_WORKERS=8

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

for required in \
  "${PYTHON}" \
  "${EVALUATOR}" \
  "${AUDITOR}" \
  "${CACHE_DIR}/ptbxl_adapter_manifest.json" \
  "${CACHE_DIR}/chapman_adapter_manifest.json" \
  "${CACHE_DIR}/ptbxl_metadata.csv" \
  "${CACHE_DIR}/chapman_metadata.csv" \
  "${CACHE_DIR}/ptbxl_y_legacy.npy" \
  "${CACHE_DIR}/ptbxl_y_trainfreq.npy" \
  "${CACHE_DIR}/ptbxl_quality.npy" \
  "${CACHE_DIR}/chapman_quality.npy" \
  "${CACHE_DIR}/ptbxl_strict_ood_tau80.npz" \
  "${TRUSTFED_CACHE}/ptbxl_signals.npy" \
  "${TRUSTFED_CACHE}/chapman_signals.npy"; do
  [[ -e "${required}" ]] || die "required input is absent: ${required}"
done

for seed in "${PTB_SEEDS[@]}"; do
  for required in \
    "${PTB_RESULTS_DIR}/closed/softmax_modular/seed_${seed}.json" \
    "${PTB_RESULTS_DIR}/closed/softmax_modular/seed_${seed}_raw.npz" \
    "${PTB_RESULTS_DIR}/closed/softmax_modular/seed_${seed}_ood_scores.npz" \
    "${PTB_RESULTS_DIR}/strict/tau80/softmax_modular/seed_${seed}.json" \
    "${PTB_RESULTS_DIR}/strict/tau80/softmax_modular/seed_${seed}_raw.npz" \
    "${PTB_RESULTS_DIR}/strict/tau80/softmax_modular/seed_${seed}_ood_scores.npz"; do
    [[ -s "${required}" ]] || die "formal PTB input is absent/empty: ${required}"
  done
done

for seed in "${NOISE_SEEDS[@]}"; do
  for required in \
    "${NOISE_RESULTS_DIR}/canonical/seed_${seed}.json" \
    "${NOISE_RESULTS_DIR}/canonical/seed_${seed}_curves.npz" \
    "${NOISE_CHECKPOINT_DIR}/canonical/softmax_modular/seed_${seed}.json" \
    "${NOISE_CHECKPOINT_DIR}/canonical/softmax_modular/seed_${seed}.npz"; do
    [[ -s "${required}" ]] || die "formal noise input is absent/empty: ${required}"
  done
done

[[ "${CPU_THREADS_PER_WORKER}" =~ ^[1-9][0-9]*$ ]] \
  || die "CPU_THREADS_PER_WORKER must be a positive integer"
[[ "${EVAL_BATCH_SIZE}" =~ ^[1-9][0-9]*$ ]] \
  || die "EVAL_BATCH_SIZE must be a positive integer"
[[ "${FEATURE_CHUNK_SIZE}" =~ ^[1-9][0-9]*$ ]] \
  || die "FEATURE_CHUNK_SIZE must be a positive integer"

mkdir -p \
  "${OUTPUT_DIR}/ptb" \
  "${OUTPUT_DIR}/noise" \
  "${AUDIT_DIR}" \
  "${TMP_DIR}" \
  "${PYCACHE_DIR}" \
  "${LOG_DIR}"

export TMPDIR="${TMP_DIR}"
export PYTHONPYCACHEPREFIX="${PYCACHE_DIR}"
export PYTHONDONTWRITEBYTECODE=1

# Syntax validation is remote and places any bytecode in /dev/shm.
"${PYTHON}" -m py_compile "${EVALUATOR}" "${AUDITOR}"

{
  date --iso-8601=seconds
  printf 'launcher=%s\n' "$0"
  printf 'python='; "${PYTHON}" --version
  printf 'host='; hostname
  printf 'output_dir=%s\n' "${OUTPUT_DIR}"
  printf 'audit_dir=%s\n' "${AUDIT_DIR}"
  printf 'log_dir=%s\n' "${LOG_DIR}"
  printf 'expected_workers=%s\n' "${EXPECTED_WORKERS}"
  printf 'cpu_threads_per_worker=%s\n' "${CPU_THREADS_PER_WORKER}"
  printf 'device=%s\n' "${DEVICE}"
  sha256sum "${EVALUATOR}" "${AUDITOR}" "$0"
  nvidia-smi --query-gpu=index,name,driver_version,memory.total \
    --format=csv,noheader
} > "${LOG_DIR}/matrix_manifest.txt"

COMMON=(
  --experiment-dir "${EXPERIMENT_DIR}"
  --ptb-results-dir "${PTB_RESULTS_DIR}"
  --noise-results-dir "${NOISE_RESULTS_DIR}"
  --noise-checkpoint-dir "${NOISE_CHECKPOINT_DIR}"
  --cache-dir "${CACHE_DIR}"
  --trustfed-cache "${TRUSTFED_CACHE}"
  --output-dir "${OUTPUT_DIR}"
  --quality-quantile 0.05
  --mahalanobis-quantile 0.95
  --fixed-coverages 0.95,0.90,0.80,0.70,0.50
  --risk-targets 0.01,0.05,0.10
  --rare-threshold 50
  --feature-chunk-size "${FEATURE_CHUNK_SIZE}"
  --eval-batch-size "${EVAL_BATCH_SIZE}"
  --device "${DEVICE}"
)

run_worker() {
  local name="$1"
  shift
  local command=("${PYTHON}" "${EVALUATOR}" "$@" "${COMMON[@]}")
  local command_file="${LOG_DIR}/${name}.command.txt"
  local log_file="${LOG_DIR}/${name}.log"
  local exit_file="${LOG_DIR}/${name}.exit"
  printf '%q ' "${command[@]}" > "${command_file}"
  printf '\n' >> "${command_file}"
  set +e
  OMP_NUM_THREADS="${CPU_THREADS_PER_WORKER}" \
  MKL_NUM_THREADS="${CPU_THREADS_PER_WORKER}" \
  OPENBLAS_NUM_THREADS="${CPU_THREADS_PER_WORKER}" \
  NUMEXPR_NUM_THREADS="${CPU_THREADS_PER_WORKER}" \
    "${command[@]}" > "${log_file}" 2>&1
  local status=$?
  set -e
  printf '%s\n' "${status}" > "${exit_file}"
  return "${status}"
}

pids=()
names=()
for seed in "${PTB_SEEDS[@]}"; do
  name="ptb_seed${seed}"
  run_worker "${name}" --mode ptb --ptb-seeds "${seed}" &
  pids+=("$!")
  names+=("${name}")
done
for seed in "${NOISE_SEEDS[@]}"; do
  name="noise_seed${seed}"
  run_worker "${name}" --mode noise --noise-seeds "${seed}" &
  pids+=("$!")
  names+=("${name}")
done

failed=0
for index in "${!pids[@]}"; do
  if ! wait "${pids[${index}]}"; then
    printf 'FAILED: worker %s\n' "${names[${index}]}" >&2
    failed=$((failed + 1))
  fi
done

worker_exit_count=0
for name in "${names[@]}"; do
  exit_file="${LOG_DIR}/${name}.exit"
  [[ -s "${exit_file}" ]] || die "missing worker exit file: ${exit_file}"
  worker_exit_count=$((worker_exit_count + 1))
  status="$(tr -d '[:space:]' < "${exit_file}")"
  if [[ "${status}" != "0" ]]; then
    printf 'FAILED: %s reported exit %s\n' "${name}" "${status}" >&2
    failed=$((failed + 1))
  fi
done
[[ "${worker_exit_count}" -eq "${EXPECTED_WORKERS}" ]] \
  || die "expected ${EXPECTED_WORKERS} worker exits, found ${worker_exit_count}"
actual_exit_count="$(find "${LOG_DIR}" -maxdepth 1 -type f -name '*.exit' | wc -l | tr -d '[:space:]')"
[[ "${actual_exit_count}" -eq "${EXPECTED_WORKERS}" ]] \
  || die "expected exactly ${EXPECTED_WORKERS} .exit files in ${LOG_DIR}, found ${actual_exit_count}"
[[ "${failed}" -eq 0 ]] || die "${failed} worker failure observation(s)"

# Finalization is intentionally serial: it validates all 8 seed pairs, writes
# the cross-seed summary, and atomically publishes the result manifest.
finalize_command=("${PYTHON}" "${EVALUATOR}" --mode finalize "${COMMON[@]}")
printf '%q ' "${finalize_command[@]}" > "${LOG_DIR}/finalize.command.txt"
printf '\n' >> "${LOG_DIR}/finalize.command.txt"
"${finalize_command[@]}" > "${LOG_DIR}/finalize.log" 2>&1
printf '0\n' > "${LOG_DIR}/finalize.status"
[[ -s "${OUTPUT_DIR}/manifest.json" ]] || die "final manifest is absent"
[[ -s "${OUTPUT_DIR}/summary.json" ]] || die "cross-seed summary is absent"

# The independent auditor does not import the evaluator.  It reconstructs all
# thresholds, masks, scientific metrics, cross-seed summaries, and SHA chains.
audit_command=(
  "${PYTHON}" "${AUDITOR}"
  --output-dir "${OUTPUT_DIR}"
  --experiment-dir "${EXPERIMENT_DIR}"
  --ptb-results-dir "${PTB_RESULTS_DIR}"
  --noise-results-dir "${NOISE_RESULTS_DIR}"
  --noise-checkpoint-dir "${NOISE_CHECKPOINT_DIR}"
  --cache-dir "${CACHE_DIR}"
  --trustfed-cache "${TRUSTFED_CACHE}"
  --audit-report "${AUDIT_DIR}/audit.json"
)
printf '%q ' "${audit_command[@]}" > "${LOG_DIR}/audit.command.txt"
printf '\n' >> "${LOG_DIR}/audit.command.txt"
"${audit_command[@]}" > "${LOG_DIR}/audit.log" 2>&1
printf '0\n' > "${LOG_DIR}/audit.status"
[[ -s "${AUDIT_DIR}/audit.json" ]] || die "strict audit report is absent"

"${PYTHON}" -c \
  'import json,sys; p=json.load(open(sys.argv[1], encoding="utf-8")); raise SystemExit(0 if p.get("status")=="complete" and p.get("error_count")==0 else 1)' \
  "${AUDIT_DIR}/audit.json" \
  || die "strict audit JSON is not complete/error-free"

date --iso-8601=seconds > "${AUDIT_DIR}/modular_pipeline_audit.complete"
date --iso-8601=seconds > "${LOG_DIR}/modular_pipeline.complete"
date --iso-8601=seconds > "${SHM_ROOT}/modular_pipeline.complete"

printf 'Modular pipeline complete: 5 PTB + 3 noise workers; strict audit passed.\n'
printf 'Results: %s\n' "${OUTPUT_DIR}"
printf 'Audit:   %s\n' "${AUDIT_DIR}"
printf 'Logs:    %s\n' "${LOG_DIR}"
printf 'Server remains running; this launcher contains no shutdown action.\n'
