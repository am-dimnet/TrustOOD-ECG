#!/usr/bin/env python3
"""Stream MHEALTH and WESAD archives into compact Paper46 caches.

This utility intentionally never extracts an archive.  It opens one MHEALTH log
or one WESAD subject pickle at a time, keeps only the deterministic 8-second
windows required by the revision experiments, and writes the exact array keys
consumed by ``code/exp_multimodal.py``:

* ``mhealth_proc.npz``: ``ecg, motion, y, subj``;
* ``wesad_mm.npz``: ``ecg, ppg, acc, y, subj``.

Extra ``window_start`` and ``label_purity`` arrays make the caches auditable and
are ignored by the existing loader.  Waveforms are stored as float16 after
per-window, per-channel standardisation; labels and subject indices are int16.

The WESAD archive contains Python pickles.  Only use an archive downloaded from
the official dataset source: pickle is unsafe for untrusted input.

Examples
--------
Read-only archive/shape audit::

    python prepare_wearables.py --audit --dataset all

Create both caches and manifests::

    python prepare_wearables.py --prepare --dataset all \
        --out-dir /root/autodl-tmp/Dataset/wearable
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
import pickle
import re
import tempfile
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

import numpy as np
from scipy.signal import resample_poly


SCHEMA_VERSION = "paper46-wearables-v1"

DEFAULT_MHEALTH_ZIP = Path("/root/autodl-tmp/Dataset/stress_raw/MHEALTH.zip")
DEFAULT_WESAD_ZIP = Path("/root/autodl-tmp/Dataset/stress_raw/WESAD.zip")
DEFAULT_OUT_DIR = Path("/root/autodl-tmp/Dataset/wearable")

WINDOW_SECONDS = 8
MIN_LABEL_PURITY = 0.80

MHEALTH_FS = 50
MHEALTH_WINDOW = WINDOW_SECONDS * MHEALTH_FS
MHEALTH_SUBJECTS = tuple(range(1, 11))

# Official MHEALTH 24-column layout (zero-based indices below).
MHEALTH_ECG_COLUMNS = (3, 4)
MHEALTH_MOTION_COLUMNS = tuple(range(0, 3)) + tuple(range(5, 23))
MHEALTH_LABEL_COLUMN = 23
MHEALTH_COLUMN_GROUPS = {
    "chest_acc": [0, 1, 2],
    "ecg": [3, 4],
    "left_ankle_acc": [5, 6, 7],
    "left_ankle_gyro": [8, 9, 10],
    "left_ankle_magnetometer": [11, 12, 13],
    "right_lower_arm_acc": [14, 15, 16],
    "right_lower_arm_gyro": [17, 18, 19],
    "right_lower_arm_magnetometer": [20, 21, 22],
    "activity_label": [23],
}
MHEALTH_LABEL_MAP = {label: label - 1 for label in range(1, 13)}

WESAD_SUBJECTS = tuple(f"S{i}" for i in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17))
WESAD_FS_ECG = 700
WESAD_FS_ECG_OUT = 100
WESAD_FS_PPG = 64
WESAD_FS_ACC = 32
WESAD_ECG_RAW_WINDOW = WINDOW_SECONDS * WESAD_FS_ECG
WESAD_ECG_WINDOW = WINDOW_SECONDS * WESAD_FS_ECG_OUT
WESAD_PPG_WINDOW = WINDOW_SECONDS * WESAD_FS_PPG
WESAD_ACC_WINDOW = WINDOW_SECONDS * WESAD_FS_ACC
WESAD_LABEL_MAP = {1: 0, 2: 1, 3: 2, 4: 3}


@dataclass(frozen=True)
class WindowSelection:
    indices: np.ndarray
    labels: np.ndarray
    purity: np.ndarray
    total_full_windows: int
    rejected_background: int
    rejected_impure: int
    discarded_tail_samples: int


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def _sha256(path: Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _member_record(info: zipfile.ZipInfo) -> Dict[str, Any]:
    return {
        "name": info.filename,
        "crc32": f"{info.CRC:08x}",
        "compressed_bytes": int(info.compress_size),
        "uncompressed_bytes": int(info.file_size),
    }


def _zscore_channels(x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """Standardise ``(..., channels, time)`` independently by channel/window."""

    x = np.asarray(x, dtype=np.float32)
    mean = x.mean(axis=-1, keepdims=True, dtype=np.float64).astype(np.float32)
    std = x.std(axis=-1, keepdims=True, dtype=np.float64).astype(np.float32)
    return (x - mean) / (std + eps)


def _select_windows(
    labels: np.ndarray,
    samples_per_window: int,
    allowed: Mapping[int, int],
    min_purity: float,
    max_full_windows: int | None = None,
) -> WindowSelection:
    labels = np.asarray(labels).reshape(-1)
    if labels.size and not np.all(np.isfinite(labels)):
        raise ValueError("label stream contains NaN or infinity")
    rounded = np.rint(labels).astype(np.int64)
    if labels.size and not np.allclose(labels, rounded):
        raise ValueError("label stream contains non-integral values")

    available = len(rounded) // samples_per_window
    n_full = available if max_full_windows is None else min(available, int(max_full_windows))
    if n_full <= 0:
        return WindowSelection(
            indices=np.empty(0, np.int64),
            labels=np.empty(0, np.int16),
            purity=np.empty(0, np.float16),
            total_full_windows=0,
            rejected_background=0,
            rejected_impure=0,
            discarded_tail_samples=len(rounded),
        )

    blocks = rounded[: n_full * samples_per_window].reshape(n_full, samples_per_window)
    keep: list[int] = []
    mapped: list[int] = []
    purities: list[float] = []
    rejected_background = 0
    rejected_impure = 0
    for index, block in enumerate(blocks):
        values, counts = np.unique(block, return_counts=True)
        winner_at = int(np.argmax(counts))
        winner = int(values[winner_at])
        purity = float(counts[winner_at] / samples_per_window)
        if winner not in allowed:
            rejected_background += 1
            continue
        if purity < min_purity:
            rejected_impure += 1
            continue
        keep.append(index)
        mapped.append(int(allowed[winner]))
        purities.append(purity)

    return WindowSelection(
        indices=np.asarray(keep, np.int64),
        labels=np.asarray(mapped, np.int16),
        purity=np.asarray(purities, np.float16),
        total_full_windows=n_full,
        rejected_background=rejected_background,
        rejected_impure=rejected_impure,
        discarded_tail_samples=len(rounded) - n_full * samples_per_window,
    )


def _discover_mhealth(zf: zipfile.ZipFile) -> list[Tuple[int, zipfile.ZipInfo]]:
    pattern = re.compile(r"^mhealth_subject(\d+)\.log$", re.IGNORECASE)
    found: Dict[int, zipfile.ZipInfo] = {}
    for info in zf.infolist():
        if info.is_dir():
            continue
        match = pattern.match(Path(info.filename.replace("\\", "/")).name)
        if not match:
            continue
        subject = int(match.group(1))
        if subject in found:
            raise ValueError(
                f"duplicate MHEALTH log for subject {subject}: "
                f"{found[subject].filename!r} and {info.filename!r}"
            )
        found[subject] = info
    missing = sorted(set(MHEALTH_SUBJECTS) - set(found))
    extra = sorted(set(found) - set(MHEALTH_SUBJECTS))
    if missing or extra:
        raise ValueError(f"MHEALTH archive subjects mismatch: missing={missing}, extra={extra}")
    return [(subject, found[subject]) for subject in MHEALTH_SUBJECTS]


def _discover_wesad(zf: zipfile.ZipFile) -> list[Tuple[str, zipfile.ZipInfo]]:
    found: Dict[str, zipfile.ZipInfo] = {}
    for info in zf.infolist():
        if info.is_dir():
            continue
        normal = info.filename.replace("\\", "/")
        for subject in WESAD_SUBJECTS:
            if normal.endswith(f"/{subject}/{subject}.pkl") or normal == f"{subject}/{subject}.pkl":
                if subject in found:
                    raise ValueError(
                        f"duplicate WESAD pickle for {subject}: "
                        f"{found[subject].filename!r} and {info.filename!r}"
                    )
                found[subject] = info
                break
    missing = sorted(set(WESAD_SUBJECTS) - set(found))
    if missing:
        raise ValueError(f"WESAD archive is missing subjects: {missing}")
    return [(subject, found[subject]) for subject in WESAD_SUBJECTS]


def _load_mhealth_log(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> np.ndarray:
    with zf.open(info, "r") as handle:
        raw = np.loadtxt(handle, dtype=np.float32)
    if raw.ndim == 1:
        raw = raw[None, :]
    if raw.ndim != 2 or raw.shape[1] != 24:
        raise ValueError(f"{info.filename}: expected (N,24), got {raw.shape}")
    if not np.all(np.isfinite(raw)):
        raise ValueError(f"{info.filename}: contains NaN or infinity")
    return raw


def _mhealth_subject(
    raw: np.ndarray,
    subject_index: int,
    min_purity: float,
    materialize: bool,
) -> Tuple[Dict[str, np.ndarray], Dict[str, Any]]:
    selection = _select_windows(
        raw[:, MHEALTH_LABEL_COLUMN],
        MHEALTH_WINDOW,
        MHEALTH_LABEL_MAP,
        min_purity,
    )
    chosen = selection.indices
    starts = chosen * MHEALTH_WINDOW
    result: Dict[str, np.ndarray] = {}
    if materialize:
        full = raw[: selection.total_full_windows * MHEALTH_WINDOW].reshape(
            selection.total_full_windows, MHEALTH_WINDOW, 24
        )
        accepted = full[chosen]
        ecg = accepted[:, :, MHEALTH_ECG_COLUMNS].transpose(0, 2, 1)
        motion = accepted[:, :, MHEALTH_MOTION_COLUMNS].transpose(0, 2, 1)
        result = {
            "ecg": _zscore_channels(ecg).astype(np.float16),
            "motion": _zscore_channels(motion).astype(np.float16),
            "y": selection.labels,
            "subj": np.full(len(chosen), subject_index, np.int16),
            "window_start": starts.astype(np.int64),
            "label_purity": selection.purity,
        }
    report = {
        "rows": int(len(raw)),
        "duration_seconds": float(len(raw) / MHEALTH_FS),
        "total_full_windows": selection.total_full_windows,
        "accepted_windows": int(len(chosen)),
        "rejected_background": selection.rejected_background,
        "rejected_impure": selection.rejected_impure,
        "discarded_tail_samples": selection.discarded_tail_samples,
        "label_counts": {str(k): int(v) for k, v in Counter(selection.labels.tolist()).items()},
    }
    return result, report


def _wesad_arrays(data: Mapping[str, Any], subject: str) -> Tuple[np.ndarray, ...]:
    try:
        ecg = np.asarray(data["signal"]["chest"]["ECG"], dtype=np.float32).reshape(-1)
        ppg = np.asarray(data["signal"]["wrist"]["BVP"], dtype=np.float32).reshape(-1)
        acc = np.asarray(data["signal"]["wrist"]["ACC"], dtype=np.float32)
        labels = np.asarray(data["label"]).reshape(-1)
    except (KeyError, TypeError) as exc:
        raise ValueError(f"{subject}: unexpected WESAD pickle schema") from exc
    if acc.ndim != 2 or acc.shape[1] != 3:
        raise ValueError(f"{subject}: expected wrist ACC shape (N,3), got {acc.shape}")
    for name, array in (("ECG", ecg), ("BVP", ppg), ("ACC", acc), ("label", labels)):
        if not np.all(np.isfinite(array)):
            raise ValueError(f"{subject}: {name} contains NaN or infinity")
    return ecg, ppg, acc, labels


def _wesad_subject(
    data: Mapping[str, Any],
    subject: str,
    subject_index: int,
    min_purity: float,
    materialize: bool,
) -> Tuple[Dict[str, np.ndarray], Dict[str, Any]]:
    ecg, ppg, acc, labels = _wesad_arrays(data, subject)
    stream_windows = min(
        len(ecg) // WESAD_ECG_RAW_WINDOW,
        len(ppg) // WESAD_PPG_WINDOW,
        len(acc) // WESAD_ACC_WINDOW,
        len(labels) // WESAD_ECG_RAW_WINDOW,
    )
    selection = _select_windows(
        labels,
        WESAD_ECG_RAW_WINDOW,
        WESAD_LABEL_MAP,
        min_purity,
        max_full_windows=stream_windows,
    )
    chosen = selection.indices
    starts = chosen * WESAD_ECG_RAW_WINDOW
    result: Dict[str, np.ndarray] = {}
    if materialize:
        ecg_blocks = ecg[: stream_windows * WESAD_ECG_RAW_WINDOW].reshape(
            stream_windows, WESAD_ECG_RAW_WINDOW
        )[chosen]
        ppg_blocks = ppg[: stream_windows * WESAD_PPG_WINDOW].reshape(
            stream_windows, WESAD_PPG_WINDOW
        )[chosen]
        acc_blocks = acc[: stream_windows * WESAD_ACC_WINDOW].reshape(
            stream_windows, WESAD_ACC_WINDOW, 3
        )[chosen]

        # 700 -> 100 Hz is an exact 1/7 ratio.  resample_poly includes an
        # anti-aliasing FIR, unlike simple stride-based decimation.
        ecg_100 = resample_poly(ecg_blocks, up=1, down=7, axis=-1)
        if ecg_100.shape[-1] != WESAD_ECG_WINDOW:
            raise RuntimeError(
                f"{subject}: ECG resampling produced {ecg_100.shape[-1]} samples, "
                f"expected {WESAD_ECG_WINDOW}"
            )
        result = {
            "ecg": _zscore_channels(ecg_100[:, None, :]).astype(np.float16),
            "ppg": _zscore_channels(ppg_blocks[:, None, :]).astype(np.float16),
            "acc": _zscore_channels(acc_blocks.transpose(0, 2, 1)).astype(np.float16),
            "y": selection.labels,
            "subj": np.full(len(chosen), subject_index, np.int16),
            "window_start": starts.astype(np.int64),
            "label_purity": selection.purity,
        }
    report = {
        "samples": {
            "ecg_700hz": int(len(ecg)),
            "ppg_64hz": int(len(ppg)),
            "acc_32hz": int(len(acc)),
            "labels_700hz": int(len(labels)),
        },
        "common_duration_seconds": float(stream_windows * WINDOW_SECONDS),
        "total_full_windows": selection.total_full_windows,
        "accepted_windows": int(len(chosen)),
        "rejected_background": selection.rejected_background,
        "rejected_impure": selection.rejected_impure,
        "discarded_label_tail_samples": selection.discarded_tail_samples,
        "label_counts": {str(k): int(v) for k, v in Counter(selection.labels.tolist()).items()},
    }
    return result, report


def _concatenate(parts: Sequence[Mapping[str, np.ndarray]], keys: Iterable[str]) -> Dict[str, np.ndarray]:
    if not parts:
        raise ValueError("no subject windows were accepted")
    output: Dict[str, np.ndarray] = {}
    for key in keys:
        arrays = [np.asarray(part[key]) for part in parts]
        output[key] = np.concatenate(arrays, axis=0)
    lengths = {key: len(value) for key, value in output.items()}
    if len(set(lengths.values())) != 1:
        raise RuntimeError(f"cache arrays have inconsistent first dimensions: {lengths}")
    return output


def _atomic_npz(path: Path, arrays: Mapping[str, np.ndarray], force: bool) -> None:
    if path.exists() and not force:
        raise FileExistsError(f"refusing to overwrite {path}; pass --force explicitly")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    os.close(descriptor)
    temporary_path = Path(temporary)
    try:
        with temporary_path.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def _check_output_targets(paths: Sequence[Path], force: bool) -> None:
    existing = [str(path) for path in paths if path.exists()]
    if existing and not force:
        joined = ", ".join(existing)
        raise FileExistsError(f"refusing to overwrite {joined}; pass --force explicitly")


def _atomic_json(path: Path, payload: Mapping[str, Any], force: bool) -> None:
    if path.exists() and not force:
        raise FileExistsError(f"refusing to overwrite {path}; pass --force explicitly")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(_jsonable(payload), handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def _array_manifest(arrays: Mapping[str, np.ndarray]) -> Dict[str, Any]:
    return {
        key: {
            "shape": list(value.shape),
            "dtype": str(value.dtype),
            "uncompressed_bytes": int(value.nbytes),
        }
        for key, value in arrays.items()
    }


def run_mhealth(
    zip_path: Path,
    out_dir: Path,
    min_purity: float,
    prepare: bool,
    force: bool,
) -> Dict[str, Any]:
    if not zip_path.is_file():
        raise FileNotFoundError(zip_path)
    cache = out_dir / "mhealth_proc.npz"
    manifest_path = out_dir / "mhealth_proc.manifest.json"
    if prepare:
        _check_output_targets((cache, manifest_path), force)
    parts: list[Dict[str, np.ndarray]] = []
    subjects: list[Dict[str, Any]] = []
    with zipfile.ZipFile(zip_path) as zf:
        members = _discover_mhealth(zf)
        for subject_index, (subject_id, info) in enumerate(members):
            raw = _load_mhealth_log(zf, info)
            arrays, report = _mhealth_subject(raw, subject_index, min_purity, materialize=prepare)
            report.update(
                {
                    "subject_id": f"S{subject_id}",
                    "subject_index": subject_index,
                    "archive_member": _member_record(info),
                }
            )
            subjects.append(report)
            if prepare:
                parts.append(arrays)
            del raw, arrays
            gc.collect()

    manifest: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "dataset": "MHEALTH",
        "mode": "prepare" if prepare else "audit",
        "input_zip": str(zip_path.resolve()),
        "input_zip_bytes": int(zip_path.stat().st_size),
        "interface": "Paper46 code/trustlib.py::load_mhealth",
        "window": {
            "seconds": WINDOW_SECONDS,
            "hop_seconds": WINDOW_SECONDS,
            "minimum_label_purity": min_purity,
            "input_sampling_hz": MHEALTH_FS,
            "output_sampling_hz": MHEALTH_FS,
            "samples": MHEALTH_WINDOW,
        },
        "columns_zero_based": MHEALTH_COLUMN_GROUPS,
        "motion_columns_zero_based": list(MHEALTH_MOTION_COLUMNS),
        "label_map": MHEALTH_LABEL_MAP,
        "subject_index_map": {f"S{subject}": index for index, subject in enumerate(MHEALTH_SUBJECTS)},
        "subjects": subjects,
        "total_accepted_windows": int(sum(item["accepted_windows"] for item in subjects)),
    }
    if prepare:
        arrays = _concatenate(
            parts,
            ("ecg", "motion", "y", "subj", "window_start", "label_purity"),
        )
        _atomic_npz(cache, arrays, force=force)
        manifest.update(
            {
                "cache": str(cache.resolve()),
                "cache_bytes": int(cache.stat().st_size),
                "cache_sha256": _sha256(cache),
                "arrays": _array_manifest(arrays),
                "manifest": str(manifest_path.resolve()),
            }
        )
        _atomic_json(manifest_path, manifest, force=force)
    return manifest


def run_wesad(
    zip_path: Path,
    out_dir: Path,
    min_purity: float,
    prepare: bool,
    force: bool,
) -> Dict[str, Any]:
    if not zip_path.is_file():
        raise FileNotFoundError(zip_path)
    cache = out_dir / "wesad_mm.npz"
    manifest_path = out_dir / "wesad_mm.manifest.json"
    if prepare:
        _check_output_targets((cache, manifest_path), force)
    parts: list[Dict[str, np.ndarray]] = []
    subjects: list[Dict[str, Any]] = []
    with zipfile.ZipFile(zip_path) as zf:
        members = _discover_wesad(zf)
        for subject_index, (subject_id, info) in enumerate(members):
            # Sequential unpickling directly from ZipExtFile: no temporary subject
            # pickle and never more than one raw subject resident in memory.
            with zf.open(info, "r") as handle:
                data = pickle.load(handle, encoding="latin1")
            arrays, report = _wesad_subject(
                data,
                subject_id,
                subject_index,
                min_purity,
                materialize=prepare,
            )
            report.update(
                {
                    "subject_id": subject_id,
                    "subject_index": subject_index,
                    "archive_member": _member_record(info),
                }
            )
            subjects.append(report)
            if prepare:
                parts.append(arrays)
            del data, arrays
            gc.collect()

    manifest: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "dataset": "WESAD",
        "mode": "prepare" if prepare else "audit",
        "input_zip": str(zip_path.resolve()),
        "input_zip_bytes": int(zip_path.stat().st_size),
        "interface": "Paper46 code/exp_multimodal.py::wesad_mm.npz",
        "window": {
            "seconds": WINDOW_SECONDS,
            "hop_seconds": WINDOW_SECONDS,
            "minimum_label_purity": min_purity,
            "ecg": {"input_hz": WESAD_FS_ECG, "output_hz": WESAD_FS_ECG_OUT, "samples": WESAD_ECG_WINDOW},
            "ppg": {"input_hz": WESAD_FS_PPG, "output_hz": WESAD_FS_PPG, "samples": WESAD_PPG_WINDOW},
            "acc": {"input_hz": WESAD_FS_ACC, "output_hz": WESAD_FS_ACC, "samples": WESAD_ACC_WINDOW},
        },
        "label_map": WESAD_LABEL_MAP,
        "class_names": ["baseline", "stress", "amusement", "meditation"],
        "subject_index_map": {subject: index for index, subject in enumerate(WESAD_SUBJECTS)},
        "subjects": subjects,
        "total_accepted_windows": int(sum(item["accepted_windows"] for item in subjects)),
    }
    if prepare:
        arrays = _concatenate(
            parts,
            ("ecg", "ppg", "acc", "y", "subj", "window_start", "label_purity"),
        )
        _atomic_npz(cache, arrays, force=force)
        manifest.update(
            {
                "cache": str(cache.resolve()),
                "cache_bytes": int(cache.stat().st_size),
                "cache_sha256": _sha256(cache),
                "arrays": _array_manifest(arrays),
                "manifest": str(manifest_path.resolve()),
            }
        )
        _atomic_json(manifest_path, manifest, force=force)
    return manifest


def _resolve_wesad_default(path: Path) -> Path:
    if path != DEFAULT_WESAD_ZIP or path.exists():
        return path
    legacy = Path("/root/autodl-tmp/Dataset/wearable/_downloads/WESAD.zip")
    return legacy if legacy.exists() else path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Audit or stream-prepare MHEALTH/WESAD caches without extracting ZIP archives."
    )
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--audit", action="store_true", help="read and validate archives; write nothing")
    action.add_argument("--prepare", action="store_true", help="write compressed caches and JSON manifests")
    parser.add_argument("--dataset", choices=("mhealth", "wesad", "all"), default="all")
    parser.add_argument("--mhealth-zip", type=Path, default=DEFAULT_MHEALTH_ZIP)
    parser.add_argument("--wesad-zip", type=Path, default=DEFAULT_WESAD_ZIP)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--min-label-purity", type=float, default=MIN_LABEL_PURITY)
    parser.add_argument(
        "--force",
        action="store_true",
        help="atomically replace existing cache/manifest files (prepare mode only)",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not 0.5 <= args.min_label_purity <= 1.0:
        raise SystemExit("--min-label-purity must be between 0.5 and 1.0")
    if args.audit and args.force:
        raise SystemExit("--force is only valid with --prepare")

    summaries: Dict[str, Any] = {}
    if args.dataset in ("mhealth", "all"):
        summaries["mhealth"] = run_mhealth(
            args.mhealth_zip,
            args.out_dir,
            args.min_label_purity,
            prepare=args.prepare,
            force=args.force,
        )
    if args.dataset in ("wesad", "all"):
        summaries["wesad"] = run_wesad(
            _resolve_wesad_default(args.wesad_zip),
            args.out_dir,
            args.min_label_purity,
            prepare=args.prepare,
            force=args.force,
        )
    print(json.dumps(_jsonable(summaries), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
