#!/usr/bin/env bash
# Reproduce the complete PTB-XL revision matrix on the AutoDL server.
# This script intentionally refuses to run without the server-side raw cache.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
RESULTS_DIR="${RESULTS_DIR:-${REVISION_ROOT}/results_final/ptbxl}"
LOG_DIR="${LOG_DIR:-${REVISION_ROOT}/logs_final/ptbxl}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
MAX_PARALLEL="${MAX_PARALLEL:-20}"
EPOCHS="${EPOCHS:-40}"
BATCH_SIZE="${BATCH_SIZE:-256}"
EVAL_BATCH_SIZE="${EVAL_BATCH_SIZE:-512}"

RUNNER="${EXPERIMENT_DIR}/run_ptbxl_revision.py"
SEEDS=(7 13 42 99 2026)
ABLATION_SEEDS=(7 42 2026)

if [[ ! -f "${TRUSTFED_CACHE}/ptbxl_signals.npy" ]]; then
  echo "Refusing to run: AutoDL PTB-XL cache is absent at ${TRUSTFED_CACHE}" >&2
  exit 2
fi
if [[ ! -f "${RUNNER}" ]]; then
  echo "Runner is absent: ${RUNNER}" >&2
  exit 2
fi
if [[ ! "${MAX_PARALLEL}" =~ ^[1-9][0-9]*$ ]]; then
  echo "MAX_PARALLEL must be a positive integer" >&2
  exit 2
fi

mkdir -p "${RESULTS_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile \
  "${EXPERIMENT_DIR}/data_adapter.py" \
  "${EXPERIMENT_DIR}/revisionlib.py" \
  "${RUNNER}"

{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'host='; hostname
  printf 'max_parallel=%s\n' "${MAX_PARALLEL}"
  printf 'epochs=%s\n' "${EPOCHS}"
  printf 'batch_size=%s\n' "${BATCH_SIZE}"
  sha256sum "${EXPERIMENT_DIR}"/*.py
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/ptbxl_matrix_manifest.txt"

COMMON=(
  --epochs "${EPOCHS}"
  --batch-size "${BATCH_SIZE}"
  --eval-batch-size "${EVAL_BATCH_SIZE}"
  --cache-dir "${CACHE_DIR}"
  --trustfed-cache "${TRUSTFED_CACHE}"
  --results-dir "${RESULTS_DIR}"
)

run_task() {
  local name="$1"
  shift
  local exit_file="${LOG_DIR}/${name}.exit"
  local log_file="${LOG_DIR}/${name}.log"
  local command_file="${LOG_DIR}/${name}.command.txt"
  printf '%q ' "${PYTHON}" "${RUNNER}" "$@" > "${command_file}"
  printf '\n' >> "${command_file}"
  set +e
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${PYTHON}" "${RUNNER}" "$@" > "${log_file}" 2>&1
  local status=$?
  printf '%s\n' "${status}" > "${exit_file}"
  return "${status}"
}

launch_task() {
  while (( $(jobs -rp | wc -l) >= MAX_PARALLEL )); do
    wait -n || true
  done
  run_task "$@" &
}

# Five-seed canonical comparisons. Closed-set jobs also evaluate all valid
# Chapman records as cross-dataset OOD; strict jobs use original multilabel SCP
# code sets and report all/pure/mixed OOD strata.
for seed in "${SEEDS[@]}"; do
  launch_task "closed_main_seed${seed}" \
    --protocol closed --models main --seed "${seed}" --cross-dataset --profile \
    "${COMMON[@]}"
  launch_task "strict80_main_seed${seed}" \
    --protocol strict --tau 80 --models main --seed "${seed}" --profile \
    "${COMMON[@]}"
done

# Three-seed mechanism, gate, SQI, regularizer and source-count studies.
for seed in "${ABLATION_SEEDS[@]}"; do
  launch_task "closed_ablation_seed${seed}" \
    --protocol closed --models ablations --seed "${seed}" --cross-dataset \
    "${COMMON[@]}"
  launch_task "strict80_ablation_seed${seed}" \
    --protocol strict --tau 80 --models ablations --seed "${seed}" \
    "${COMMON[@]}"
  launch_task "closed_source_count_seed${seed}" \
    --protocol closed --models source_count --seed "${seed}" --cross-dataset \
    "${COMMON[@]}"
done

# Held-out-code frequency sensitivity. The three controls isolate the proposed
# evidential score from a modular Softmax/post-hoc system and a nonlinear,
# parameter-matched concatenation model.
for tau in 40 160; do
  for seed in "${ABLATION_SEEDS[@]}"; do
    launch_task "strict${tau}_sensitivity_seed${seed}" \
      --protocol strict --tau "${tau}" \
      --models trust_full,softmax_modular,concat_matched \
      --seed "${seed}" "${COMMON[@]}"
  done
done

wait || true

failed=0
expected=0
for exit_file in "${LOG_DIR}"/*.exit; do
  [[ -e "${exit_file}" ]] || continue
  expected=$((expected + 1))
  status="$(tr -d '[:space:]' < "${exit_file}")"
  if [[ "${status}" != "0" ]]; then
    echo "FAILED: ${exit_file} (exit ${status})" >&2
    failed=$((failed + 1))
  fi
done

if (( expected != 25 )); then
  echo "FAILED: expected 25 task exit files, found ${expected}" >&2
  exit 3
fi
if (( failed != 0 )); then
  echo "FAILED: ${failed} PTB-XL task(s) failed" >&2
  exit 1
fi

date --iso-8601=seconds > "${LOG_DIR}/ptbxl_matrix.complete"
echo "All 25 PTB-XL revision tasks completed successfully."
