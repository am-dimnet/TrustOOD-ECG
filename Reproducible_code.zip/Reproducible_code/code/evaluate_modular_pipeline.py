#!/usr/bin/env python3
"""Inference-only end-to-end modular control requested by the reviewers.

The control is deliberately *not* another learned model.  It composes the
already-trained ``softmax_modular`` classifier with two conventional referral
stages in one fixed hierarchy::

    low SQI (q < q_min) -> quality referral
    else Mahalanobis > d_max -> novelty/OOD referral
    else -> Softmax diagnosis

Both ``q_min`` and ``d_max`` are selected on PTB-XL fold 9 only.  Fold 10,
strict held-out-code OOD records, Chapman, and every noisy fold-10 condition
are evaluation-only.  The PTB-XL/Chapman evaluation reuses the exact formal
five-seed raw predictions and OAS Mahalanobis arrays.  The noise evaluation
loads the exact formal three-seed Softmax checkpoints, fits OAS Mahalanobis on
folds 1--8, freezes the hierarchy on *clean* fold 9, and performs inference on
the paired SNR series produced by ``run_noise_sqi.py``.  No optimiser or model
training function is called by this script.

Every seed result is an atomic JSON/NPZ pair with a content fingerprint and
SHA-256 artifact manifest.  Separate workers may evaluate different seeds;
run ``--mode finalize`` after all workers finish to create the top-level
completion manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import time
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

import numpy as np
import scipy
import sklearn
import torch
from scipy import stats as scipy_stats
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

import data_adapter as D
import revisionlib as R
import run_noise_sqi as N
import run_ptbxl_revision as B


SCRIPT_VERSION = "paper46-modular-pipeline-v1"
FINGERPRINT_SCHEMA = "paper46-modular-pipeline-fingerprint-v1"
MANIFEST_SCHEMA = "paper46-modular-pipeline-manifest-v1"
PTB_SEEDS = (7, 13, 42, 99, 2026)
NOISE_SEEDS = (7, 13, 42)
DEFAULT_SNRS: tuple[float | None, ...] = N.DEFAULT_SNRS
DETECTOR = "Mahalanobis:oas"
STAGE_ACCEPT = np.int8(0)
STAGE_QUALITY = np.int8(1)
STAGE_MAHALANOBIS = np.int8(2)


class PipelineError(RuntimeError):
    """A protocol, provenance, or artifact invariant was violated."""


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    return value


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(
        jsonable(value), sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                jsonable(payload), handle, indent=2, sort_keys=True,
                ensure_ascii=False, allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(path: Path, arrays: Mapping[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def artifact_entry(path: Path) -> dict[str, Any]:
    return {
        "filename": path.name,
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def input_entry(root_kind: str, root: Path, path: Path) -> dict[str, Any]:
    resolved_root = root.resolve()
    resolved_path = path.resolve()
    try:
        relative = resolved_path.relative_to(resolved_root)
    except ValueError as exc:
        raise PipelineError(f"{path} does not belong to declared root {root}") from exc
    return {
        "root_kind": root_kind,
        "relative_path": relative.as_posix(),
        "bytes": int(resolved_path.stat().st_size),
        "sha256": sha256_file(resolved_path),
    }


def parse_ints(text: str) -> tuple[int, ...]:
    try:
        values = tuple(int(item.strip()) for item in text.split(",") if item.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated integers") from exc
    if not values or len(values) != len(set(values)):
        raise argparse.ArgumentTypeError("seeds must be a non-empty unique list")
    return values


def parse_floats(text: str) -> tuple[float, ...]:
    try:
        values = tuple(float(item.strip()) for item in text.split(",") if item.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated numbers") from exc
    if not values or any(not math.isfinite(value) for value in values):
        raise argparse.ArgumentTypeError("values must be finite and non-empty")
    return values


def quantile_higher(values: np.ndarray, quantile: float) -> float:
    try:
        return float(np.quantile(values, quantile, method="higher"))
    except TypeError:  # NumPy < 1.22
        return float(np.quantile(values, quantile, interpolation="higher"))


def ensure_vector(name: str, value: np.ndarray, length: int | None = None) -> np.ndarray:
    array = np.asarray(value)
    if array.ndim != 1:
        raise PipelineError(f"{name} must be one-dimensional, got {array.shape}")
    if length is not None and len(array) != length:
        raise PipelineError(f"{name} has {len(array)} rows, expected {length}")
    if array.dtype.kind in "fc" and not np.isfinite(array).all():
        raise PipelineError(f"{name} contains non-finite values")
    return array


def validate_quality(name: str, value: np.ndarray, length: int | None = None) -> np.ndarray:
    quality = ensure_vector(name, np.asarray(value, dtype=np.float64), length)
    if np.any((quality < 0.0) | (quality > 1.0)):
        raise PipelineError(f"{name} is outside [0,1]")
    return quality


def fit_hierarchy(
    quality: np.ndarray,
    mahalanobis: np.ndarray,
    quality_quantile: float,
    mahalanobis_quantile: float,
) -> dict[str, Any]:
    quality = validate_quality("validation quality", quality)
    mahalanobis = ensure_vector("validation Mahalanobis", mahalanobis, len(quality)).astype(float)
    q_min = quantile_higher(quality, quality_quantile)
    quality_pass = quality >= q_min
    if not quality_pass.any():
        raise PipelineError("quality threshold rejects every validation record")
    d_max = quantile_higher(mahalanobis[quality_pass], mahalanobis_quantile)
    return {
        "quality_quantile": float(quality_quantile),
        "q_min": q_min,
        "mahalanobis_quantile_after_quality": float(mahalanobis_quantile),
        "d_max": d_max,
        "validation_n": int(len(quality)),
        "validation_quality_pass": int(quality_pass.sum()),
        "selection_split": "PTB-XL fold 9 only",
        "tie_rule": "q >= q_min and Mahalanobis <= d_max are accepted",
    }


def hierarchy_stage(
    quality: np.ndarray, mahalanobis: np.ndarray, q_min: float, d_max: float
) -> np.ndarray:
    quality = validate_quality("quality", quality)
    mahalanobis = ensure_vector("Mahalanobis", mahalanobis, len(quality)).astype(float)
    stage = np.full(len(quality), STAGE_ACCEPT, dtype=np.int8)
    quality_reject = quality < q_min
    stage[quality_reject] = STAGE_QUALITY
    stage[(~quality_reject) & (mahalanobis > d_max)] = STAGE_MAHALANOBIS
    return stage


def classification_metrics(
    prediction: np.ndarray,
    labels: np.ndarray,
    stage: np.ndarray,
    rare_ids: np.ndarray,
    n_classes: int,
) -> dict[str, Any]:
    prediction = ensure_vector("prediction", prediction).astype(np.int64)
    labels = ensure_vector("labels", labels, len(prediction)).astype(np.int64)
    stage = ensure_vector("stage", stage, len(prediction)).astype(np.int8)
    accepted = stage == STAGE_ACCEPT
    rejected = ~accepted
    rare = np.isin(labels, np.asarray(rare_ids, dtype=np.int64))
    if n_classes < 1 or np.any(labels < 0) or np.any(labels >= n_classes):
        raise PipelineError("labels are outside the declared model class range")
    if np.any(prediction < 0) or np.any(prediction >= n_classes):
        raise PipelineError("predictions are outside the declared model class range")
    all_classes = np.arange(n_classes)
    result: dict[str, Any] = {
        "n": int(len(labels)),
        "n_accepted": int(accepted.sum()),
        "coverage": float(accepted.mean()),
        "rejection_rate": float(rejected.mean()),
        "referrals_per_100_records": float(100.0 * rejected.mean()),
        "quality_rejection_rate": float(np.mean(stage == STAGE_QUALITY)),
        "mahalanobis_rejection_rate": float(np.mean(stage == STAGE_MAHALANOBIS)),
        "rare_rejection_rate": float(rejected[rare].mean()) if rare.any() else None,
        "frequent_rejection_rate": float(rejected[~rare].mean()) if (~rare).any() else None,
        "base_accuracy": float(accuracy_score(labels, prediction)),
        "base_balanced_accuracy": float(balanced_accuracy_score(labels, prediction)),
        "base_macro_f1": float(
            f1_score(labels, prediction, labels=all_classes, average="macro", zero_division=0)
        ),
    }
    if accepted.any():
        result.update(
            {
                "selective_risk": float(np.mean(prediction[accepted] != labels[accepted])),
                "selective_accuracy": float(accuracy_score(labels[accepted], prediction[accepted])),
                "selective_balanced_accuracy": float(
                    balanced_accuracy_score(labels[accepted], prediction[accepted])
                ),
                "selective_macro_f1": float(
                    f1_score(
                        labels[accepted], prediction[accepted], labels=all_classes,
                        average="macro", zero_division=0,
                    )
                ),
            }
        )
    else:
        result.update(
            {
                "selective_risk": None,
                "selective_accuracy": None,
                "selective_balanced_accuracy": None,
                "selective_macro_f1": None,
            }
        )
    return result


def ood_operating_metrics(id_stage: np.ndarray, ood_stage: np.ndarray) -> dict[str, Any]:
    id_stage = ensure_vector("ID stage", id_stage).astype(np.int8)
    ood_stage = ensure_vector("OOD stage", ood_stage).astype(np.int8)
    id_reject = id_stage != STAGE_ACCEPT
    ood_reject = ood_stage != STAGE_ACCEPT
    true_negative = int((~id_reject).sum())
    false_positive = int(id_reject.sum())
    true_positive = int(ood_reject.sum())
    false_negative = int((~ood_reject).sum())
    return {
        "id_n": int(len(id_stage)),
        "ood_n": int(len(ood_stage)),
        "id_false_positive_rate": float(id_reject.mean()),
        "ood_true_positive_rate": float(ood_reject.mean()),
        "id_false_alarms_per_100_records": float(100.0 * id_reject.mean()),
        "ood_detections_per_100_records": float(100.0 * ood_reject.mean()),
        "id_quality_referral_rate": float(np.mean(id_stage == STAGE_QUALITY)),
        "id_mahalanobis_referral_rate": float(np.mean(id_stage == STAGE_MAHALANOBIS)),
        "ood_quality_detection_rate": float(np.mean(ood_stage == STAGE_QUALITY)),
        "ood_mahalanobis_detection_rate": float(np.mean(ood_stage == STAGE_MAHALANOBIS)),
        "detection_accuracy": float(
            (true_negative + true_positive) / max(len(id_stage) + len(ood_stage), 1)
        ),
        "detection_balanced_accuracy": float(
            0.5 * (true_negative / max(len(id_stage), 1) + true_positive / max(len(ood_stage), 1))
        ),
        "confusion": {
            "true_negative": true_negative,
            "false_positive": false_positive,
            "true_positive": true_positive,
            "false_negative": false_negative,
        },
    }


def threshold_for_coverage(
    quality: np.ndarray, mahalanobis: np.ndarray, q_min: float, target: float
) -> dict[str, Any]:
    if not 0.0 < target <= 1.0:
        raise ValueError("coverage target must lie in (0,1]")
    quality_pass = np.asarray(quality) >= q_min
    maximum = float(quality_pass.mean())
    if not quality_pass.any():
        finite_scores = np.asarray(mahalanobis, dtype=np.float64)
        d_max = float(np.nextafter(finite_scores.min(), -np.inf))
        return {"d_max": d_max, "maximum_coverage_after_quality": 0.0}
    if target >= maximum:
        accepted_scores = np.asarray(mahalanobis, dtype=np.float64)[quality_pass]
        d_max = float(np.nextafter(accepted_scores.max(), np.inf))
    else:
        conditional = float(np.clip(target / maximum, 0.0, 1.0))
        d_max = quantile_higher(np.asarray(mahalanobis)[quality_pass], conditional)
    return {"d_max": d_max, "maximum_coverage_after_quality": maximum}


def threshold_for_risk(
    quality: np.ndarray,
    mahalanobis: np.ndarray,
    prediction: np.ndarray,
    labels: np.ndarray,
    q_min: float,
    target: float,
) -> float:
    if not 0.0 <= target <= 1.0:
        raise ValueError("risk target must lie in [0,1]")
    eligible = np.flatnonzero(np.asarray(quality) >= q_min)
    if not len(eligible):
        scores = np.asarray(mahalanobis, dtype=np.float64)
        return float(np.nextafter(scores.min(), -np.inf))
    scores = np.asarray(mahalanobis)[eligible]
    order = np.argsort(scores, kind="mergesort")
    ordered = eligible[order]
    sorted_scores = scores[order]
    errors = (np.asarray(prediction)[ordered] != np.asarray(labels)[ordered]).astype(int)
    cumulative = np.cumsum(errors)
    group_ends = np.flatnonzero(np.r_[sorted_scores[1:] != sorted_scores[:-1], True])
    risks = cumulative[group_ends] / (group_ends + 1)
    permitted = group_ends[risks <= target]
    if len(permitted):
        return float(sorted_scores[int(permitted[-1])])
    return float(np.nextafter(sorted_scores.min(), -np.inf))


def selective_operating_points(
    val_quality: np.ndarray,
    val_mahalanobis: np.ndarray,
    val_prediction: np.ndarray,
    val_labels: np.ndarray,
    test_quality: np.ndarray,
    test_mahalanobis: np.ndarray,
    test_prediction: np.ndarray,
    test_labels: np.ndarray,
    rare_ids: np.ndarray,
    n_classes: int,
    q_min: float,
    coverages: Sequence[float],
    risk_targets: Sequence[float],
) -> dict[str, Any]:
    fixed_coverage: dict[str, Any] = {}
    for target in coverages:
        selected = threshold_for_coverage(val_quality, val_mahalanobis, q_min, target)
        d_max = selected["d_max"]
        fixed_coverage[f"{target:.6g}"] = {
            "selection_split": "fold 9 only",
            "target_coverage": float(target),
            "d_max": d_max,
            "maximum_coverage_after_quality": selected["maximum_coverage_after_quality"],
            "validation": classification_metrics(
                val_prediction, val_labels,
                hierarchy_stage(val_quality, val_mahalanobis, q_min, d_max), rare_ids,
                n_classes,
            ),
            "test": classification_metrics(
                test_prediction, test_labels,
                hierarchy_stage(test_quality, test_mahalanobis, q_min, d_max), rare_ids,
                n_classes,
            ),
        }
    fixed_risk: dict[str, Any] = {}
    for target in risk_targets:
        d_max = threshold_for_risk(
            val_quality, val_mahalanobis, val_prediction, val_labels, q_min, target
        )
        fixed_risk[f"{target:.6g}"] = {
            "selection_split": "fold 9 only",
            "target_risk": float(target),
            "d_max": d_max,
            "validation": classification_metrics(
                val_prediction, val_labels,
                hierarchy_stage(val_quality, val_mahalanobis, q_min, d_max), rare_ids,
                n_classes,
            ),
            "test": classification_metrics(
                test_prediction, test_labels,
                hierarchy_stage(test_quality, test_mahalanobis, q_min, d_max), rare_ids,
                n_classes,
            ),
        }
    return {"fixed_coverage": fixed_coverage, "coverage_at_fixed_risk": fixed_risk}


def decision_latency_ms(
    quality: np.ndarray, mahalanobis: np.ndarray, q_min: float, d_max: float,
    repeats: int = 200,
) -> dict[str, Any]:
    quality = np.asarray(quality)
    mahalanobis = np.asarray(mahalanobis)
    durations = []
    for _ in range(repeats):
        started = time.perf_counter()
        hierarchy_stage(quality, mahalanobis, q_min, d_max)
        durations.append(time.perf_counter() - started)
    return {
        "records": int(len(quality)),
        "repeats": int(repeats),
        "median_batch_ms": float(np.median(durations) * 1000.0),
        "median_ms_per_record": float(np.median(durations) * 1000.0 / max(len(quality), 1)),
        "scope": "two threshold comparisons and hierarchy assignment; excludes neural and Mahalanobis feature scoring",
    }


def code_input_entries(experiment_dir: Path) -> list[dict[str, Any]]:
    names = (
        "evaluate_modular_pipeline.py", "run_ptbxl_revision.py",
        "run_noise_sqi.py", "revisionlib.py", "data_adapter.py",
    )
    return [input_entry("code", experiment_dir, experiment_dir / name) for name in names]


def ptb_namespace(args: argparse.Namespace, seed: int, protocol: str) -> SimpleNamespace:
    return SimpleNamespace(
        protocol=protocol, tau=80, seed=seed,
        limit_train=None, limit_val=None, limit_test=None, limit_ood=None,
        trustfed_cache=str(args.trustfed_cache), cache_dir=str(args.cache_dir),
    )


def formal_ptb_paths(root: Path, protocol: str, seed: int) -> tuple[Path, Path, Path]:
    directory = root / ("closed" if protocol == "closed" else "strict/tau80") / "softmax_modular"
    return (
        directory / f"seed_{seed}.json",
        directory / f"seed_{seed}_raw.npz",
        directory / f"seed_{seed}_ood_scores.npz",
    )


def verify_formal_ptb(
    args: argparse.Namespace, protocol: str, seed: int,
) -> tuple[dict[str, Any], dict[str, np.ndarray], dict[str, np.ndarray], dict[str, Any], list[dict[str, Any]]]:
    json_path, raw_path, ood_path = formal_ptb_paths(args.ptb_results_dir, protocol, seed)
    for path in (json_path, raw_path, ood_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    if payload.get("status") != "complete":
        raise PipelineError(f"formal result is incomplete: {json_path}")
    if payload.get("fingerprint_schema") != B.RUN_FINGERPRINT_SCHEMA:
        raise PipelineError(f"formal fingerprint schema mismatch: {json_path}")
    if B.sha256_object(payload.get("run_definition")) != payload.get("run_fingerprint"):
        raise PipelineError(f"formal result fingerprint mismatch: {json_path}")
    if payload.get("model", {}).get("tag") != "softmax_modular" or payload.get("seed") != seed:
        raise PipelineError(f"wrong formal model/seed: {json_path}")
    expected_protocol = "closed" if protocol == "closed" else "strict"
    if payload.get("protocol") != expected_protocol:
        raise PipelineError(f"wrong formal protocol: {json_path}")
    if protocol == "strict80" and payload.get("tau") != 80:
        raise PipelineError(f"wrong strict threshold: {json_path}")
    for role, path in (("raw_npz", raw_path), ("ood_npz", ood_path)):
        declared = payload.get("artifacts", {}).get(role, {})
        if (
            declared.get("filename") != path.name
            or declared.get("bytes") != path.stat().st_size
            or declared.get("sha256") != sha256_file(path)
        ):
            raise PipelineError(f"formal {role} checksum mismatch: {path}")
    with np.load(raw_path, allow_pickle=False) as archive:
        raw = {name: np.array(archive[name]) for name in archive.files}
    with np.load(ood_path, allow_pickle=False) as archive:
        ood = {name: np.array(archive[name]) for name in archive.files}
    namespace = ptb_namespace(args, seed, expected_protocol)
    protocol_data = B.load_protocol(namespace)
    labels = np.asarray(protocol_data["labels"], dtype=np.int64)
    label_map = protocol_data["label_map"]

    def mapped(indices: np.ndarray) -> np.ndarray:
        selected = labels[np.asarray(indices, dtype=np.int64)]
        if label_map is not None:
            selected = np.asarray([label_map[int(value)] for value in selected], dtype=np.int64)
        return selected

    expected_val = mapped(protocol_data["val_index"])
    expected_test = mapped(protocol_data["test_index"])
    if not np.array_equal(raw.get("val_y"), expected_val):
        raise PipelineError(f"formal validation label alignment failed: {json_path}")
    if not np.array_equal(raw.get("test_y"), expected_test):
        raise PipelineError(f"formal test label alignment failed: {json_path}")
    if list(np.asarray(raw.get("class_names"), dtype=str)) != list(protocol_data["class_names"]):
        raise PipelineError(f"formal class-name alignment failed: {json_path}")
    inputs = [
        input_entry("ptb_results", args.ptb_results_dir, path)
        for path in (json_path, raw_path, ood_path)
    ]
    return payload, raw, ood, protocol_data, inputs


def ptb_quality_views(
    args: argparse.Namespace, protocol: str, protocol_data: Mapping[str, Any]
) -> dict[str, np.ndarray]:
    adapter: D.DatasetAdapter = protocol_data["adapter"]
    if adapter.quality is None:
        raise PipelineError("PTB-XL quality sidecar is missing")
    views = {
        "validation": validate_quality(
            "PTB validation quality", adapter.quality[protocol_data["val_index"]]
        ),
        "id": validate_quality("PTB test quality", adapter.quality[protocol_data["test_index"]]),
    }
    if protocol == "closed":
        chapman = D.open_dataset("chapman", args.trustfed_cache, args.cache_dir)
        if chapman.quality is None:
            raise PipelineError("Chapman quality sidecar is missing")
        views["chapman"] = validate_quality(
            "Chapman quality", chapman.quality[np.flatnonzero(chapman.valid)]
        )
    else:
        for name, indices in protocol_data["ood_indices"].items():
            views[name] = validate_quality(f"strict-{name} quality", adapter.quality[indices])
    return views


def evaluate_ptb_seed(args: argparse.Namespace, seed: int, device: torch.device) -> None:
    del device  # PTB evaluation consumes already-computed formal arrays only.
    target_dir = args.output_dir / "ptb"
    json_path = target_dir / f"seed_{seed}.json"
    npz_path = target_dir / f"seed_{seed}_arrays.npz"
    protocols: dict[str, Any] = {}
    output_arrays: dict[str, np.ndarray] = {}
    all_inputs: list[dict[str, Any]] = code_input_entries(args.experiment_dir)
    profile_payload: dict[str, Any] = {}

    for protocol_name in ("closed", "strict80"):
        payload, raw, ood, protocol_data, inputs = verify_formal_ptb(
            args, protocol_name, seed
        )
        all_inputs.extend(inputs)
        qualities = ptb_quality_views(args, protocol_name, protocol_data)
        prefix = "closed" if protocol_name == "closed" else "strict80"
        score_names = ["validation", "id"]
        score_names.extend(("chapman",) if protocol_name == "closed" else ("all", "pure", "mixed"))
        scores = {
            name: ensure_vector(
                f"{prefix}/{DETECTOR}/{name}", ood[f"{DETECTOR}__{name}"], len(qualities[name])
            ).astype(np.float64)
            for name in score_names
        }
        thresholds = fit_hierarchy(
            qualities["validation"], scores["validation"],
            args.quality_quantile, args.mahalanobis_quantile,
        )
        stages = {
            name: hierarchy_stage(
                qualities[name], scores[name], thresholds["q_min"], thresholds["d_max"]
            )
            for name in score_names
        }
        val_prediction = np.asarray(raw["val_prob"]).argmax(axis=1).astype(np.int16)
        test_prediction = np.asarray(raw["test_prob"]).argmax(axis=1).astype(np.int16)
        rare_ids = np.asarray(raw["rare_ids"], dtype=np.int16)
        n_classes = int(payload["n_classes"])
        diagnosis = {
            "validation": classification_metrics(
                val_prediction, raw["val_y"], stages["validation"], rare_ids, n_classes
            ),
            "test": classification_metrics(
                test_prediction, raw["test_y"], stages["id"], rare_ids, n_classes
            ),
        }
        selective = selective_operating_points(
            qualities["validation"], scores["validation"], val_prediction, raw["val_y"],
            qualities["id"], scores["id"], test_prediction, raw["test_y"], rare_ids,
            n_classes,
            thresholds["q_min"], args.fixed_coverages, args.risk_targets,
        )
        ood_report: dict[str, Any] = {}
        for name in score_names[2:]:
            ood_report[name] = {
                "mahalanobis_ranking": R.ood_metrics(scores["id"], scores[name]),
                "hierarchical_operating_point": ood_operating_metrics(stages["id"], stages[name]),
            }
        protocols[prefix] = {
            "pipeline": "SQI referral -> OAS Mahalanobis rejection -> Softmax diagnosis",
            "detector": DETECTOR,
            "thresholds": thresholds,
            "diagnosis": diagnosis,
            "selective_operating_points": selective,
            "ood": ood_report,
            "rare_definition": payload.get("rare_definition"),
            "rare_ids": rare_ids,
            "rare_names": payload.get("rare_names", []),
            "split": payload.get("split"),
            "n_classes": payload.get("n_classes"),
            "parameter_count": payload.get("parameter_count"),
            "formal_neural_profile": payload.get("profiling"),
            "hierarchy_decision_profile": decision_latency_ms(
                qualities["id"], scores["id"], thresholds["q_min"], thresholds["d_max"]
            ),
        }
        profile_payload[prefix] = {
            "parameter_count": payload.get("parameter_count"),
            "formal_neural_profile": payload.get("profiling"),
            "hierarchy_decision_profile": protocols[prefix]["hierarchy_decision_profile"],
            "note": (
                "The formal neural profile and the measured decision-only overhead are reported "
                "separately; the formal PTB checkpoints were intentionally not retained, so no "
                "new end-to-end timing is fabricated."
            ),
        }
        output_arrays.update(
            {
                f"{prefix}_val_quality": qualities["validation"].astype(np.float32),
                f"{prefix}_val_mahalanobis": scores["validation"].astype(np.float64),
                f"{prefix}_val_prediction": val_prediction,
                f"{prefix}_val_y": np.asarray(raw["val_y"], dtype=np.int16),
                f"{prefix}_test_quality": qualities["id"].astype(np.float32),
                f"{prefix}_test_mahalanobis": scores["id"].astype(np.float64),
                f"{prefix}_test_prediction": test_prediction,
                f"{prefix}_test_y": np.asarray(raw["test_y"], dtype=np.int16),
                f"{prefix}_rare_ids": rare_ids,
                f"{prefix}_val_stage": stages["validation"],
                f"{prefix}_test_stage": stages["id"],
            }
        )
        for name in score_names[2:]:
            output_arrays[f"{prefix}_{name}_quality"] = qualities[name].astype(np.float32)
            output_arrays[f"{prefix}_{name}_mahalanobis"] = scores[name].astype(np.float64)
            output_arrays[f"{prefix}_{name}_stage"] = stages[name]

    sidecars = (
        "ptbxl_adapter_manifest.json", "chapman_adapter_manifest.json",
        "ptbxl_metadata.csv", "chapman_metadata.csv",
        "ptbxl_y_legacy.npy", "ptbxl_y_trainfreq.npy",
        "ptbxl_quality.npy", "chapman_quality.npy", "ptbxl_strict_ood_tau80.npz",
        "ptbxl_labels.json",
    )
    for name in sidecars:
        path = args.cache_dir / name
        if not path.is_file():
            raise FileNotFoundError(path)
        all_inputs.append(input_entry("cache", args.cache_dir, path))
    run_definition = {
        "script_version": SCRIPT_VERSION,
        "fingerprint_schema": FINGERPRINT_SCHEMA,
        "domain": "ptb_closed_chapman_and_strict80",
        "seed": seed,
        "method": "softmax_modular+sqi+mahalanobis+hierarchical_rejection",
        "configuration": {
            "detector": DETECTOR,
            "quality_quantile": args.quality_quantile,
            "mahalanobis_quantile": args.mahalanobis_quantile,
            "fixed_coverages": args.fixed_coverages,
            "risk_targets": args.risk_targets,
            "threshold_fit": "fold 9 only",
        },
        "input_artifacts": sorted(
            all_inputs, key=lambda row: (row["root_kind"], row["relative_path"])
        ),
    }
    fingerprint = canonical_hash(run_definition)
    if json_path.exists() or npz_path.exists():
        if not args.force and json_path.is_file() and npz_path.is_file():
            existing = json.loads(json_path.read_text(encoding="utf-8"))
            declared = existing.get("artifacts", {}).get("arrays_npz", {})
            if (
                existing.get("run_fingerprint") == fingerprint
                and existing.get("status") == "complete"
                and declared.get("sha256") == sha256_file(npz_path)
            ):
                print(f"[resume] modular PTB seed={seed}", flush=True)
                return
        if not args.force:
            raise PipelineError(
                f"existing modular PTB output is incomplete/incompatible: {json_path}; use --force"
            )
    atomic_npz(npz_path, output_arrays)
    result = {
        "status": "complete",
        "fingerprint_schema": FINGERPRINT_SCHEMA,
        "run_definition": run_definition,
        "run_fingerprint": fingerprint,
        "seed": seed,
        "domain": "ptb",
        "protocols": protocols,
        "parameter_and_latency": profile_payload,
        "protocol_guards": {
            "neural_training_or_parameter_update_performed": False,
            "posthoc_density_reused_from_formal_result": True,
            "thresholds_fit_on_fold9_only": True,
            "test_or_ood_threshold_tuning": False,
            "strict_ood_used_for_selection": False,
            "chapman_used_for_selection": False,
            "score_direction": "higher Mahalanobis means more OOD",
            "hierarchy_order": ["quality", "Mahalanobis", "classification"],
        },
        "stage_encoding": {"0": "accepted diagnosis", "1": "quality referral", "2": "Mahalanobis/OOD referral"},
        "artifacts": {"arrays_npz": artifact_entry(npz_path)},
        "created_at_unix": time.time(),
    }
    atomic_json(json_path, result)
    print(f"[saved] {json_path}", flush=True)


def noise_namespace(args: argparse.Namespace) -> SimpleNamespace:
    return SimpleNamespace(
        trustfed_cache=str(args.trustfed_cache), cache_dir=str(args.cache_dir),
        limit_train=None, limit_val=None, limit_test=None,
    )


def verify_noise_inputs(
    args: argparse.Namespace, seed: int, protocol: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, np.ndarray], N.ModelConfig, str, list[dict[str, Any]]]:
    result_json = args.noise_results_dir / "canonical" / f"seed_{seed}.json"
    curves_path = args.noise_results_dir / "canonical" / f"seed_{seed}_curves.npz"
    checkpoint_root = args.noise_checkpoint_dir / "canonical"
    checkpoint_json = checkpoint_root / "softmax_modular" / f"seed_{seed}.json"
    checkpoint_npz = checkpoint_root / "softmax_modular" / f"seed_{seed}.npz"
    for path in (result_json, curves_path, checkpoint_json, checkpoint_npz):
        if not path.is_file():
            raise FileNotFoundError(path)
    formal = json.loads(result_json.read_text(encoding="utf-8"))
    if (
        formal.get("status") != "complete"
        or formal.get("seed") != seed
        or not formal.get("canonical")
        or not formal.get("full_fold_run")
    ):
        raise PipelineError(f"invalid formal noise result: {result_json}")
    if formal.get("raw_npz", {}).get("sha256") != sha256_file(curves_path):
        raise PipelineError(f"formal noise curves checksum mismatch: {curves_path}")
    checkpoint = json.loads(checkpoint_json.read_text(encoding="utf-8"))
    checkpoint_fingerprint = formal.get("training", {}).get("softmax_modular", {}).get(
        "checkpoint_fingerprint"
    )
    if (
        checkpoint.get("status") != "complete"
        or checkpoint.get("checkpoint_fingerprint") != checkpoint_fingerprint
        or checkpoint.get("weights_sha256") != sha256_file(checkpoint_npz)
    ):
        raise PipelineError(f"invalid formal Softmax checkpoint: {checkpoint_json}")
    config = N.ModelConfig(
        "softmax_modular", "softmax", True, False, "canonical", "baseline"
    )
    if checkpoint.get("model") != asdict(config):
        raise PipelineError(f"checkpoint model declaration mismatch: {checkpoint_json}")
    provenance = checkpoint.get("checkpoint_provenance", {})
    expected = {
        "training_protocol_version": N.SCRIPT_VERSION,
        "seed": seed,
        "n_classes": len(protocol["class_names"]),
        "class_names": list(protocol["class_names"]),
        "signals_sha256": protocol["signals_sha256"],
        "record_id_order_sha256": protocol["record_id_order_sha256"],
        "train_index_sha256": N.sha256_array(protocol["train_index"]),
        "val_index_sha256": N.sha256_array(protocol["val_index"]),
        "labels_sha256": N.sha256_array(protocol["labels"]),
    }
    for key, value in expected.items():
        if provenance.get(key) != value:
            raise PipelineError(f"checkpoint provenance mismatch for {key}: {checkpoint_json}")
    with np.load(curves_path, allow_pickle=False) as archive:
        curves = {name: np.array(archive[name]) for name in archive.files}
    expected_labels = protocol["labels"][protocol["test_index"]].astype(np.int16)
    if not np.array_equal(curves.get("test_y"), expected_labels):
        raise PipelineError(f"formal noise test-label alignment failed: {curves_path}")
    if not np.array_equal(
        curves.get("test_index"), np.asarray(protocol["test_index"], dtype=np.int64)
    ):
        raise PipelineError(f"formal noise test-index alignment failed: {curves_path}")
    expected_record_ids = (
        protocol["adapter"].metadata.iloc[protocol["test_index"]]["record_id"]
        .astype(str).to_numpy()
    )
    if not np.array_equal(np.asarray(curves.get("test_record_id"), dtype=str), expected_record_ids):
        raise PipelineError(f"formal noise record-order alignment failed: {curves_path}")
    inputs = [
        input_entry("noise_results", args.noise_results_dir, result_json),
        input_entry("noise_results", args.noise_results_dir, curves_path),
        input_entry("noise_checkpoints", args.noise_checkpoint_dir, checkpoint_json),
        input_entry("noise_checkpoints", args.noise_checkpoint_dir, checkpoint_npz),
    ]
    return formal, curves, config, str(checkpoint_fingerprint), inputs


def extract_softmax(
    model: torch.nn.Module,
    arrays: Mapping[str, Any],
    batch_size: int,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    started = time.perf_counter()
    features, logits = R.extract_features_logits(model, arrays, batch_size, device)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - started
    probability = N.softmax_numpy(logits)
    prediction = probability.argmax(axis=1).astype(np.int16)
    return features, logits, prediction, elapsed


def score_mahalanobis(features: np.ndarray, state: R.MahalanobisState) -> tuple[np.ndarray, float]:
    started = time.perf_counter()
    score = R.mahalanobis_ood_score(features, state)
    return score, time.perf_counter() - started


def evaluate_noise_seed(args: argparse.Namespace, seed: int, device: torch.device) -> None:
    # Re-establish the exact per-seed RNG and deterministic backend state used
    # by run_noise_sqi.main before reproducing its formal checkpoint outputs.
    # This is needed even for inference: N.set_seed also disables TF32 and
    # nondeterministic cuDNN paths, which can otherwise change an argmax at a
    # near-tied decision boundary.  SharedBackboneClassifier's dropout is an
    # identity in eval mode, so extracting logits as head(features) remains
    # equivalent to the formal model forward pass.
    N.set_seed(seed)
    target_dir = args.output_dir / "noise"
    json_path = target_dir / f"seed_{seed}.json"
    npz_path = target_dir / f"seed_{seed}_arrays.npz"
    protocol = N.load_protocol(noise_namespace(args), seed)
    formal, formal_curves, config, checkpoint_fingerprint, inputs = verify_noise_inputs(
        args, seed, protocol
    )
    inputs.extend(code_input_entries(args.experiment_dir))
    adapter_manifest = args.cache_dir / "ptbxl_adapter_manifest.json"
    if not adapter_manifest.is_file():
        raise FileNotFoundError(adapter_manifest)
    for sidecar in (
        adapter_manifest,
        args.cache_dir / "ptbxl_metadata.csv",
        args.cache_dir / "ptbxl_y_legacy.npy",
        args.cache_dir / "ptbxl_y_trainfreq.npy",
        args.cache_dir / "ptbxl_labels.json",
    ):
        if not sidecar.is_file():
            raise FileNotFoundError(sidecar)
        inputs.append(input_entry("cache", args.cache_dir, sidecar))
    signal_path = protocol["adapter"].signals.path.resolve()
    try:
        signal_relative = signal_path.relative_to(args.trustfed_cache.resolve())
    except ValueError as exc:
        raise PipelineError("PTB signal mmap is outside the declared TrustFed cache") from exc
    inputs.append(
        {
            "root_kind": "trustfed_cache",
            "relative_path": signal_relative.as_posix(),
            "bytes": int(signal_path.stat().st_size),
            # N.load_protocol has already hashed this exact read-only file and
            # matched it to the adapter manifest, so do not hash 2.6 GB twice.
            "sha256": protocol["signals_sha256"],
        }
    )
    snr_values = tuple(DEFAULT_SNRS)
    run_definition = {
        "script_version": SCRIPT_VERSION,
        "fingerprint_schema": FINGERPRINT_SCHEMA,
        "domain": "paired_snr_noise",
        "seed": seed,
        "method": "softmax_modular+sqi+mahalanobis+hierarchical_rejection",
        "configuration": {
            "detector": DETECTOR,
            "covariance": "oas",
            "ridge": 1e-3,
            "standardize": True,
            "quality_quantile": args.quality_quantile,
            "mahalanobis_quantile": args.mahalanobis_quantile,
            "fixed_coverages": args.fixed_coverages,
            "risk_targets": args.risk_targets,
            "rare_threshold": args.rare_threshold,
            "snrs": [N.snr_label(value) for value in snr_values],
            "threshold_fit": "clean fold 9 only and frozen across all SNRs",
        },
        "input_artifacts": sorted(
            inputs, key=lambda row: (row["root_kind"], row["relative_path"])
        ),
    }
    fingerprint = canonical_hash(run_definition)
    if json_path.exists() or npz_path.exists():
        if not args.force and json_path.is_file() and npz_path.is_file():
            existing = json.loads(json_path.read_text(encoding="utf-8"))
            declared = existing.get("artifacts", {}).get("arrays_npz", {})
            if (
                existing.get("run_fingerprint") == fingerprint
                and existing.get("status") == "complete"
                and declared.get("sha256") == sha256_file(npz_path)
            ):
                print(f"[resume] modular noise seed={seed}", flush=True)
                return
        if not args.force:
            raise PipelineError(
                f"existing modular noise output is incomplete/incompatible: {json_path}; use --force"
            )
    qconfig = N.quality_configs()["canonical"]
    adapter: D.DatasetAdapter = protocol["adapter"]
    print(f"[noise seed={seed}] deriving clean folds 1-8/9/10", flush=True)
    clean_features = {
        "train": N.derive_features(
            adapter, protocol["train_index"], snr=None,
            noise_seed=N.stable_seed(seed, "train-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
        "validation": N.derive_features(
            adapter, protocol["val_index"], snr=None,
            noise_seed=N.stable_seed(seed, "validation-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
        "test": N.derive_features(
            adapter, protocol["test_index"], snr=None,
            noise_seed=N.stable_seed(seed, "test-clean"),
            chunk_size=args.feature_chunk_size, include_ecg=False,
        ),
    }
    hrv_medians, train_missing = N.fit_hrv_medians(clean_features["train"]["hrv"])
    imputed = {
        split: N.impute_hrv(features, hrv_medians)
        for split, features in clean_features.items()
    }
    arrays = {
        split: N.make_arrays(adapter, protocol[f"{('val' if split == 'validation' else split)}_index"], features, protocol["labels"], qconfig)
        for split, features in clean_features.items()
    }
    checkpoint_root = args.noise_checkpoint_dir / "canonical"
    model, _ = N.load_checkpoint(
        config, seed, len(protocol["class_names"]), checkpoint_fingerprint,
        checkpoint_root, device,
    )
    if any(parameter.requires_grad and parameter.grad is not None for parameter in model.parameters()):
        raise PipelineError("loaded checkpoint unexpectedly carries gradients")
    print(f"[noise seed={seed}] fitting OAS Mahalanobis on folds 1-8", flush=True)
    train_features, _, _, train_extract_seconds = extract_softmax(
        model, arrays["train"], args.eval_batch_size, device
    )
    state = R.fit_mahalanobis(
        train_features, arrays["train"]["y"], n_classes=len(protocol["class_names"]),
        covariance="oas", ridge=1e-3, standardize=True, min_class_count=2,
    )
    val_features, _, val_prediction, val_extract_seconds = extract_softmax(
        model, arrays["validation"], args.eval_batch_size, device
    )
    val_score, val_score_seconds = score_mahalanobis(val_features, state)
    val_quality = validate_quality("clean fold9 quality", arrays["validation"]["ecg_q"])
    val_y = np.asarray(arrays["validation"]["y"], dtype=np.int16)
    thresholds = fit_hierarchy(
        val_quality, val_score, args.quality_quantile, args.mahalanobis_quantile
    )
    train_counts = np.bincount(
        protocol["labels"][protocol["train_index"]], minlength=len(protocol["class_names"])
    )
    rare_ids = np.flatnonzero(train_counts < args.rare_threshold).astype(np.int16)
    condition_quality: list[np.ndarray] = []
    condition_score: list[np.ndarray] = []
    condition_prediction: list[np.ndarray] = []
    condition_stage: list[np.ndarray] = []
    reports: dict[str, Any] = {}
    extraction_seconds: dict[str, float] = {}
    scoring_seconds: dict[str, float] = {}
    clean_test_features: np.ndarray | None = None

    for snr in snr_values:
        label = N.snr_label(snr)
        print(f"[noise seed={seed}] inference SNR={label}", flush=True)
        if snr is None:
            test_features_payload = clean_features["test"]
            test_arrays = arrays["test"]
        else:
            test_features_payload = N.derive_features(
                adapter, protocol["test_index"], snr=snr,
                noise_seed=N.stable_seed(seed, "test-paired-noise"),
                chunk_size=args.feature_chunk_size, include_ecg=True,
            )
            N.impute_hrv(test_features_payload, hrv_medians)
            test_arrays = N.make_arrays(
                adapter, protocol["test_index"], test_features_payload,
                protocol["labels"], qconfig,
            )
        test_features, _, test_prediction, extraction = extract_softmax(
            model, test_arrays, args.eval_batch_size, device
        )
        test_score, scoring = score_mahalanobis(test_features, state)
        test_quality = validate_quality(f"{label} fold10 quality", test_arrays["ecg_q"])
        test_stage = hierarchy_stage(
            test_quality, test_score, thresholds["q_min"], thresholds["d_max"]
        )
        test_y = np.asarray(test_arrays["y"], dtype=np.int16)
        condition_quality.append(test_quality.astype(np.float32))
        condition_score.append(test_score.astype(np.float64))
        condition_prediction.append(test_prediction)
        condition_stage.append(test_stage)
        extraction_seconds[label] = extraction
        scoring_seconds[label] = scoring
        reports[label] = {
            "snr_db": snr,
            "threshold_source": "clean fold 9; frozen across every SNR",
            "main_hierarchy": classification_metrics(
                test_prediction, test_y, test_stage, rare_ids,
                len(protocol["class_names"]),
            ),
            "selective_operating_points": selective_operating_points(
                val_quality, val_score, val_prediction, val_y,
                test_quality, test_score, test_prediction, test_y, rare_ids,
                len(protocol["class_names"]),
                thresholds["q_min"], args.fixed_coverages, args.risk_targets,
            ),
            "mean_quality": float(test_quality.mean()),
            "mean_mahalanobis": float(test_score.mean()),
        }
        if snr is None:
            clean_test_features = test_features
        else:
            del test_features_payload
    stacked_quality = np.stack(condition_quality)
    stacked_prediction = np.stack(condition_prediction)
    expected_snr = np.asarray([np.nan if value is None else value for value in snr_values])
    if not np.allclose(formal_curves.get("snr_db"), expected_snr, equal_nan=True):
        raise PipelineError("formal noise SNR ordering differs from the frozen protocol")
    if not np.array_equal(formal_curves.get("softmax_pred"), stacked_prediction):
        raise PipelineError(
            "reloaded Softmax checkpoint predictions do not exactly reproduce formal noise curves"
        )
    if not np.allclose(
        formal_curves.get("quality"), stacked_quality, rtol=0.0, atol=1e-6
    ):
        raise PipelineError("rederived paired-SNR quality differs from formal noise curves")
    if clean_test_features is None:
        raise PipelineError("clean noise condition was not evaluated")
    test_y = np.asarray(arrays["test"]["y"], dtype=np.int16)
    parameter_count = int(sum(parameter.numel() for parameter in model.parameters()))
    decision_profile = decision_latency_ms(
        condition_quality[0], condition_score[0], thresholds["q_min"], thresholds["d_max"]
    )
    condition_ms_per_record = {
        label: 1000.0 * (extraction_seconds[label] + scoring_seconds[label]) / len(test_y)
        + decision_profile["median_ms_per_record"]
        for label in extraction_seconds
    }
    profile = {
        "parameter_count": {"total": parameter_count, "trainable": parameter_count},
        "feature_extraction": {
            "clean_fold9_seconds": val_extract_seconds,
            "clean_fold9_ms_per_record": 1000.0 * val_extract_seconds / len(val_y),
            "condition_fold10_seconds": extraction_seconds,
            "condition_fold10_ms_per_record": {
                label: 1000.0 * seconds / len(test_y)
                for label, seconds in extraction_seconds.items()
            },
        },
        "mahalanobis_scoring": {
            "clean_fold9_seconds": val_score_seconds,
            "clean_fold9_ms_per_record": 1000.0 * val_score_seconds / len(val_y),
            "condition_fold10_seconds": scoring_seconds,
            "condition_fold10_ms_per_record": {
                label: 1000.0 * seconds / len(test_y)
                for label, seconds in scoring_seconds.items()
            },
        },
        "hierarchy_decision": decision_profile,
        "end_to_end_model_plus_mahalanobis_plus_decision_ms_per_record": condition_ms_per_record,
        "timing_note": (
            "Wall-clock measurements are inference-only after the checkpoint is loaded; feature "
            "derivation and covariance fitting are reported as offline preparation, not latency."
        ),
        "offline_preparation": {
            "folds1_8_feature_extraction_seconds": train_extract_seconds,
            "covariance": "OAS pooled within-class residual covariance",
            "ridge": 1e-3,
            "standardize": True,
            "feature_dim": int(train_features.shape[1]),
            "classes_used": int(len(state.classes)),
        },
    }
    output_arrays = {
        "snr_db": expected_snr,
        "val_quality": val_quality.astype(np.float32),
        "val_mahalanobis": val_score.astype(np.float64),
        "val_prediction": val_prediction.astype(np.int16),
        "val_y": val_y,
        "test_quality": stacked_quality,
        "test_mahalanobis": np.stack(condition_score),
        "test_prediction": stacked_prediction,
        "test_stage": np.stack(condition_stage),
        "test_y": test_y,
        "rare_ids": rare_ids,
    }
    atomic_npz(npz_path, output_arrays)
    result = {
        "status": "complete",
        "fingerprint_schema": FINGERPRINT_SCHEMA,
        "run_definition": run_definition,
        "run_fingerprint": fingerprint,
        "seed": seed,
        "domain": "noise",
        "thresholds": thresholds,
        "conditions": reports,
        "parameter_and_latency": profile,
        "hrv_imputation": {
            "fit_split": "folds 1-8 only",
            "medians": hrv_medians,
            "train_missing_per_column": train_missing,
            "clean_imputed_values": imputed,
        },
        "formal_reproduction_checks": {
            "softmax_predictions_exact": True,
            "quality_allclose_atol_1e-6": True,
            "test_record_order_and_labels_exact": True,
        },
        "protocol_guards": {
            "neural_training_or_parameter_update_performed": False,
            "checkpoint_loaded_read_only": True,
            "posthoc_density_fit_performed": True,
            "density_fit_on_folds1_8_only": True,
            "thresholds_fit_on_clean_fold9_only": True,
            "test_or_noise_threshold_tuning": False,
            "same_paired_noise_source_as_formal_experiment": True,
            "all_ecg_derived_sources_recomputed_at_each_snr": True,
            "score_direction": "higher Mahalanobis means more OOD",
            "hierarchy_order": ["quality", "Mahalanobis", "classification"],
        },
        "stage_encoding": {"0": "accepted diagnosis", "1": "quality referral", "2": "Mahalanobis/OOD referral"},
        "artifacts": {"arrays_npz": artifact_entry(npz_path)},
        "created_at_unix": time.time(),
    }
    atomic_json(json_path, result)
    print(f"[saved] {json_path}", flush=True)
    del model, train_features, clean_test_features
    if device.type == "cuda":
        torch.cuda.empty_cache()


def flatten_numeric(value: Any, prefix: str = "") -> dict[str, float]:
    """Flatten scientific scalar outputs while excluding profiles/metadata."""

    result: dict[str, float] = {}
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key in {
                "formal_neural_profile", "hierarchy_decision_profile", "parameter_count",
                "split", "rare_names", "pipeline", "detector", "selection_split",
                "threshold_source", "tie_rule",
            }:
                continue
            child = f"{prefix}.{key}" if prefix else str(key)
            result.update(flatten_numeric(item, child))
        return result
    if isinstance(value, bool) or value is None:
        return result
    if isinstance(value, (int, float, np.integer, np.floating)):
        numeric = float(value)
        if math.isfinite(numeric):
            result[prefix] = numeric
    return result


def aggregate_scientific_results(
    payloads: Mapping[str, Sequence[Mapping[str, Any]]]
) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "status": "complete",
        "schema": "paper46-modular-pipeline-summary-v1",
        "method": "softmax_modular+sqi+mahalanobis+hierarchical_rejection",
        "statistics": {},
    }
    for domain, records in payloads.items():
        source_key = "protocols" if domain == "ptb" else "conditions"
        flattened = [flatten_numeric(record[source_key]) for record in records]
        common = set.intersection(*(set(item) for item in flattened)) if flattened else set()
        domain_rows: dict[str, Any] = {}
        for path in sorted(common):
            values = np.asarray([item[path] for item in flattened], dtype=np.float64)
            n = len(values)
            mean = float(values.mean())
            sd = float(values.std(ddof=1)) if n > 1 else 0.0
            half_width = (
                float(scipy_stats.t.ppf(0.975, n - 1) * sd / math.sqrt(n))
                if n > 1 else 0.0
            )
            domain_rows[path] = {
                "n": n, "mean": mean, "sd": sd,
                "ci95_low": mean - half_width, "ci95_high": mean + half_width,
                "values": values,
            }
        summary["statistics"][domain] = domain_rows
    return summary


def finalize(args: argparse.Namespace) -> None:
    inventory: list[dict[str, Any]] = []
    seed_payloads: dict[str, list[Mapping[str, Any]]] = {"ptb": [], "noise": []}
    for domain, seeds in (("ptb", PTB_SEEDS), ("noise", NOISE_SEEDS)):
        for seed in seeds:
            json_path = args.output_dir / domain / f"seed_{seed}.json"
            npz_path = args.output_dir / domain / f"seed_{seed}_arrays.npz"
            if not json_path.is_file() or not npz_path.is_file():
                raise PipelineError(f"cannot finalize: missing {domain} seed={seed} pair")
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            if (
                payload.get("status") != "complete"
                or payload.get("fingerprint_schema") != FINGERPRINT_SCHEMA
                or canonical_hash(payload.get("run_definition")) != payload.get("run_fingerprint")
            ):
                raise PipelineError(f"cannot finalize: invalid {json_path}")
            seed_payloads[domain].append(payload)
            declared = payload.get("artifacts", {}).get("arrays_npz", {})
            if (
                declared.get("filename") != npz_path.name
                or declared.get("bytes") != npz_path.stat().st_size
                or declared.get("sha256") != sha256_file(npz_path)
            ):
                raise PipelineError(f"cannot finalize: artifact mismatch {npz_path}")
            inventory.extend(
                (
                    {
                        "domain": domain, "seed": seed, "role": "json",
                        "relative_path": json_path.relative_to(args.output_dir).as_posix(),
                        "bytes": json_path.stat().st_size, "sha256": sha256_file(json_path),
                    },
                    {
                        "domain": domain, "seed": seed, "role": "arrays_npz",
                        "relative_path": npz_path.relative_to(args.output_dir).as_posix(),
                        "bytes": npz_path.stat().st_size, "sha256": sha256_file(npz_path),
                    },
                )
            )
    summary_path = args.output_dir / "summary.json"
    atomic_json(summary_path, aggregate_scientific_results(seed_payloads))
    inventory.append(
        {
            "domain": "aggregate", "seed": 0, "role": "summary_json",
            "relative_path": summary_path.relative_to(args.output_dir).as_posix(),
            "bytes": summary_path.stat().st_size, "sha256": sha256_file(summary_path),
        }
    )
    definition = {
        "schema": MANIFEST_SCHEMA,
        "script_version": SCRIPT_VERSION,
        "expected": {"ptb_seeds": PTB_SEEDS, "noise_seeds": NOISE_SEEDS},
        "inventory": inventory,
    }
    manifest = {
        "status": "complete",
        "schema": MANIFEST_SCHEMA,
        "definition": definition,
        "fingerprint": canonical_hash(definition),
        "counts": {
            "ptb_results": len(PTB_SEEDS), "noise_results": len(NOISE_SEEDS),
            "summary_files": 1, "files": len(inventory),
        },
        "protocol_guards": {
            "neural_training_or_parameter_update_performed": False,
            "all_thresholds_validation_only": True,
            "server_shutdown_requested": False,
        },
        "environment": {
            "python": platform.python_version(), "platform": platform.platform(),
            "numpy": np.__version__, "scipy": scipy.__version__,
            "sklearn": sklearn.__version__, "torch": torch.__version__,
        },
        "created_at_unix": time.time(),
    }
    atomic_json(args.output_dir / "manifest.json", manifest)
    print(f"[complete] {args.output_dir / 'manifest.json'}", flush=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--mode", choices=("all", "ptb", "noise", "finalize"), default="all")
    parser.add_argument("--ptb-seeds", type=parse_ints, default=PTB_SEEDS)
    parser.add_argument("--noise-seeds", type=parse_ints, default=NOISE_SEEDS)
    parser.add_argument("--quality-quantile", type=float, default=0.05)
    parser.add_argument("--mahalanobis-quantile", type=float, default=0.95)
    parser.add_argument("--fixed-coverages", type=parse_floats, default=(0.95, 0.90, 0.80, 0.70, 0.50))
    parser.add_argument("--risk-targets", type=parse_floats, default=(0.01, 0.05, 0.10))
    parser.add_argument("--rare-threshold", type=int, default=50)
    parser.add_argument("--feature-chunk-size", type=int, default=256)
    parser.add_argument("--eval-batch-size", type=int, default=512)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--experiment-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--ptb-results-dir", type=Path, default=Path("/root/Paper46_revision/results_final/ptbxl"))
    parser.add_argument("--noise-results-dir", type=Path, default=Path("/root/Paper46_revision/results_final/noise_sqi"))
    parser.add_argument("--noise-checkpoint-dir", type=Path, default=Path("/root/Paper46_revision/checkpoints_final/noise_sqi"))
    parser.add_argument("--cache-dir", type=Path, default=Path("/root/Paper46_revision/cache"))
    parser.add_argument("--trustfed-cache", type=Path, default=Path(D.DEFAULT_TRUSTFED_CACHE))
    parser.add_argument("--output-dir", type=Path, default=Path("/root/Paper46_revision/results_final/modular_pipeline"))
    return parser


def validate_args(args: argparse.Namespace) -> None:
    if args.mode in ("all", "ptb") and not set(args.ptb_seeds).issubset(PTB_SEEDS):
        raise SystemExit(f"PTB seeds must be a subset of {PTB_SEEDS}")
    if args.mode in ("all", "noise") and not set(args.noise_seeds).issubset(NOISE_SEEDS):
        raise SystemExit(f"noise seeds must be a subset of {NOISE_SEEDS}")
    if not 0.0 < args.quality_quantile < 1.0 or not 0.0 < args.mahalanobis_quantile < 1.0:
        raise SystemExit("quality and Mahalanobis quantiles must lie in (0,1)")
    if any(not 0.0 < value <= 1.0 for value in args.fixed_coverages):
        raise SystemExit("fixed coverages must lie in (0,1]")
    if any(not 0.0 <= value <= 1.0 for value in args.risk_targets):
        raise SystemExit("risk targets must lie in [0,1]")
    if args.rare_threshold < 1 or args.feature_chunk_size < 1 or args.eval_batch_size < 1:
        raise SystemExit("rare threshold and batch/chunk sizes must be positive")
    args.experiment_dir = args.experiment_dir.resolve()
    args.ptb_results_dir = args.ptb_results_dir.resolve()
    args.noise_results_dir = args.noise_results_dir.resolve()
    args.noise_checkpoint_dir = args.noise_checkpoint_dir.resolve()
    args.cache_dir = args.cache_dir.resolve()
    args.trustfed_cache = args.trustfed_cache.resolve()
    args.output_dir = args.output_dir.resolve()


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    validate_args(args)
    if args.mode == "finalize":
        finalize(args)
        return 0
    device = torch.device(args.device)
    if args.mode in ("all", "noise") and device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    if args.mode in ("all", "ptb"):
        for seed in args.ptb_seeds:
            evaluate_ptb_seed(args, seed, device)
    if args.mode in ("all", "noise"):
        for seed in args.noise_seeds:
            evaluate_noise_seed(args, seed, device)
    if args.mode == "all" and tuple(args.ptb_seeds) == PTB_SEEDS and tuple(args.noise_seeds) == NOISE_SEEDS:
        finalize(args)
    else:
        print("[partial] run --mode finalize after all canonical seed workers complete", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
