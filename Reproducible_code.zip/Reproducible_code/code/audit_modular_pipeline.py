#!/usr/bin/env python3
"""Strict independent audit for ``evaluate_modular_pipeline.py`` outputs.

The audit fails closed.  It verifies the exact five PTB and three noise seed
pairs, every result and upstream SHA-256, canonical fingerprints, NPZ dtypes
and shapes, fold-9-only threshold reconstruction, hierarchy masks, diagnosis,
selective-risk, and OOD operating metrics.  It never trains or updates a model.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from scipy import stats as scipy_stats
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
    roc_curve,
)


FINGERPRINT_SCHEMA = "paper46-modular-pipeline-fingerprint-v1"
MANIFEST_SCHEMA = "paper46-modular-pipeline-manifest-v1"
PTB_SEEDS = (7, 13, 42, 99, 2026)
NOISE_SEEDS = (7, 13, 42)
STAGE_ACCEPT = np.int8(0)
STAGE_QUALITY = np.int8(1)
STAGE_MAHALANOBIS = np.int8(2)
PTB_LAYOUT = {
    "closed": {"val": 2183, "test": 2198, "ood": {"chapman": 45150}, "classes": 70},
    "strict80": {
        "val": 2086, "test": 2105,
        "ood": {"all": 93, "pure": 22, "mixed": 71}, "classes": 47,
    },
}
NOISE_SNRS = ("clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB")
_SHA256_CACHE: dict[tuple[str, int, int], str] = {}


class AuditError(RuntimeError):
    """The result bundle is not complete or reproducible."""


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    return value


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(
        jsonable(value), sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def sha256_file(path: str | Path) -> str:
    resolved = Path(path).resolve()
    stat = resolved.stat()
    key = (str(resolved), int(stat.st_size), int(stat.st_mtime_ns))
    cached = _SHA256_CACHE.get(key)
    if cached is not None:
        return cached
    digest = hashlib.sha256()
    with resolved.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    value = digest.hexdigest()
    _SHA256_CACHE[key] = value
    return value


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                jsonable(payload), handle, indent=2, sort_keys=True,
                ensure_ascii=False, allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def quantile_higher(values: np.ndarray, quantile: float) -> float:
    try:
        return float(np.quantile(values, quantile, method="higher"))
    except TypeError:
        return float(np.quantile(values, quantile, interpolation="higher"))


def hierarchy_stage(
    quality: np.ndarray, mahalanobis: np.ndarray, q_min: float, d_max: float
) -> np.ndarray:
    quality = np.asarray(quality, dtype=np.float64)
    mahalanobis = np.asarray(mahalanobis, dtype=np.float64)
    if quality.ndim != 1 or mahalanobis.shape != quality.shape:
        raise AuditError("quality/Mahalanobis shape mismatch")
    if not np.isfinite(quality).all() or not np.isfinite(mahalanobis).all():
        raise AuditError("non-finite quality/Mahalanobis value")
    if np.any((quality < 0.0) | (quality > 1.0)):
        raise AuditError("quality outside [0,1]")
    stage = np.zeros(len(quality), dtype=np.int8)
    quality_reject = quality < q_min
    stage[quality_reject] = STAGE_QUALITY
    stage[(~quality_reject) & (mahalanobis > d_max)] = STAGE_MAHALANOBIS
    return stage


def classification_metrics(
    prediction: np.ndarray, labels: np.ndarray, stage: np.ndarray,
    rare_ids: np.ndarray, n_classes: int,
) -> dict[str, Any]:
    prediction = np.asarray(prediction, dtype=np.int64)
    labels = np.asarray(labels, dtype=np.int64)
    stage = np.asarray(stage, dtype=np.int8)
    if prediction.ndim != 1 or labels.shape != prediction.shape or stage.shape != prediction.shape:
        raise AuditError("classification arrays are not aligned vectors")
    if np.any((labels < 0) | (labels >= n_classes)) or np.any(
        (prediction < 0) | (prediction >= n_classes)
    ):
        raise AuditError("label/prediction outside declared class range")
    accepted = stage == STAGE_ACCEPT
    rejected = ~accepted
    rare = np.isin(labels, np.asarray(rare_ids, dtype=np.int64))
    classes = np.arange(n_classes)
    result: dict[str, Any] = {
        "n": int(len(labels)),
        "n_accepted": int(accepted.sum()),
        "coverage": float(accepted.mean()),
        "rejection_rate": float(rejected.mean()),
        "referrals_per_100_records": float(100.0 * rejected.mean()),
        "quality_rejection_rate": float(np.mean(stage == STAGE_QUALITY)),
        "mahalanobis_rejection_rate": float(np.mean(stage == STAGE_MAHALANOBIS)),
        "rare_rejection_rate": float(rejected[rare].mean()) if rare.any() else None,
        "frequent_rejection_rate": float(rejected[~rare].mean()) if (~rare).any() else None,
        "base_accuracy": float(accuracy_score(labels, prediction)),
        "base_balanced_accuracy": float(balanced_accuracy_score(labels, prediction)),
        "base_macro_f1": float(
            f1_score(labels, prediction, labels=classes, average="macro", zero_division=0)
        ),
    }
    if accepted.any():
        result.update(
            {
                "selective_risk": float(np.mean(prediction[accepted] != labels[accepted])),
                "selective_accuracy": float(accuracy_score(labels[accepted], prediction[accepted])),
                "selective_balanced_accuracy": float(
                    balanced_accuracy_score(labels[accepted], prediction[accepted])
                ),
                "selective_macro_f1": float(
                    f1_score(
                        labels[accepted], prediction[accepted], labels=classes,
                        average="macro", zero_division=0,
                    )
                ),
            }
        )
    else:
        result.update(
            {
                "selective_risk": None, "selective_accuracy": None,
                "selective_balanced_accuracy": None, "selective_macro_f1": None,
            }
        )
    return result


def ood_operating_metrics(id_stage: np.ndarray, ood_stage: np.ndarray) -> dict[str, Any]:
    id_stage = np.asarray(id_stage, dtype=np.int8)
    ood_stage = np.asarray(ood_stage, dtype=np.int8)
    id_reject = id_stage != STAGE_ACCEPT
    ood_reject = ood_stage != STAGE_ACCEPT
    tn, fp = int((~id_reject).sum()), int(id_reject.sum())
    tp, fn = int(ood_reject.sum()), int((~ood_reject).sum())
    return {
        "id_n": int(len(id_stage)), "ood_n": int(len(ood_stage)),
        "id_false_positive_rate": float(id_reject.mean()),
        "ood_true_positive_rate": float(ood_reject.mean()),
        "id_false_alarms_per_100_records": float(100.0 * id_reject.mean()),
        "ood_detections_per_100_records": float(100.0 * ood_reject.mean()),
        "id_quality_referral_rate": float(np.mean(id_stage == STAGE_QUALITY)),
        "id_mahalanobis_referral_rate": float(np.mean(id_stage == STAGE_MAHALANOBIS)),
        "ood_quality_detection_rate": float(np.mean(ood_stage == STAGE_QUALITY)),
        "ood_mahalanobis_detection_rate": float(np.mean(ood_stage == STAGE_MAHALANOBIS)),
        "detection_accuracy": float((tn + tp) / max(len(id_stage) + len(ood_stage), 1)),
        "detection_balanced_accuracy": float(
            0.5 * (tn / max(len(id_stage), 1) + tp / max(len(ood_stage), 1))
        ),
        "confusion": {
            "true_negative": tn, "false_positive": fp,
            "true_positive": tp, "false_negative": fn,
        },
    }


def fpr_at_tpr(id_score: np.ndarray, ood_score: np.ndarray, target: float = 0.95) -> float:
    labels = np.r_[np.zeros(len(id_score), dtype=int), np.ones(len(ood_score), dtype=int)]
    scores = np.r_[id_score, ood_score]
    fpr, tpr, _ = roc_curve(labels, scores)
    eligible = np.flatnonzero(tpr >= target)
    return float(fpr[eligible[0]]) if len(eligible) else 1.0


def ood_ranking(id_score: np.ndarray, ood_score: np.ndarray) -> dict[str, float]:
    id_score = np.asarray(id_score, dtype=np.float64)
    ood_score = np.asarray(ood_score, dtype=np.float64)
    labels_out = np.r_[np.zeros(len(id_score), dtype=int), np.ones(len(ood_score), dtype=int)]
    scores = np.r_[id_score, ood_score]
    labels_in = 1 - labels_out
    return {
        "auroc": float(roc_auc_score(labels_out, scores)),
        "aupr_out": float(average_precision_score(labels_out, scores)),
        "aupr_in": float(average_precision_score(labels_in, -scores)),
        "fpr95": fpr_at_tpr(id_score, ood_score),
    }


def threshold_for_coverage(
    quality: np.ndarray, mahalanobis: np.ndarray, q_min: float, target: float
) -> dict[str, Any]:
    quality_pass = np.asarray(quality) >= q_min
    maximum = float(quality_pass.mean())
    scores = np.asarray(mahalanobis, dtype=np.float64)
    if not quality_pass.any():
        return {
            "d_max": float(np.nextafter(scores.min(), -np.inf)),
            "maximum_coverage_after_quality": 0.0,
        }
    if target >= maximum:
        d_max = float(np.nextafter(scores[quality_pass].max(), np.inf))
    else:
        d_max = quantile_higher(scores[quality_pass], float(np.clip(target / maximum, 0.0, 1.0)))
    return {"d_max": d_max, "maximum_coverage_after_quality": maximum}


def threshold_for_risk(
    quality: np.ndarray, mahalanobis: np.ndarray, prediction: np.ndarray,
    labels: np.ndarray, q_min: float, target: float,
) -> float:
    scores = np.asarray(mahalanobis, dtype=np.float64)
    eligible = np.flatnonzero(np.asarray(quality) >= q_min)
    if not len(eligible):
        return float(np.nextafter(scores.min(), -np.inf))
    eligible_scores = scores[eligible]
    order = np.argsort(eligible_scores, kind="mergesort")
    ordered = eligible[order]
    sorted_scores = eligible_scores[order]
    errors = (np.asarray(prediction)[ordered] != np.asarray(labels)[ordered]).astype(int)
    cumulative = np.cumsum(errors)
    group_ends = np.flatnonzero(np.r_[sorted_scores[1:] != sorted_scores[:-1], True])
    permitted = group_ends[cumulative[group_ends] / (group_ends + 1) <= target]
    if len(permitted):
        return float(sorted_scores[int(permitted[-1])])
    return float(np.nextafter(sorted_scores.min(), -np.inf))


def selective_operating_points(
    val_quality: np.ndarray, val_score: np.ndarray, val_prediction: np.ndarray,
    val_y: np.ndarray, test_quality: np.ndarray, test_score: np.ndarray,
    test_prediction: np.ndarray, test_y: np.ndarray, rare_ids: np.ndarray,
    n_classes: int, q_min: float, coverages: Sequence[float], risk_targets: Sequence[float],
) -> dict[str, Any]:
    fixed_coverage: dict[str, Any] = {}
    for target in coverages:
        selected = threshold_for_coverage(val_quality, val_score, q_min, target)
        d_max = selected["d_max"]
        fixed_coverage[f"{target:.6g}"] = {
            "selection_split": "fold 9 only", "target_coverage": float(target),
            "d_max": d_max,
            "maximum_coverage_after_quality": selected["maximum_coverage_after_quality"],
            "validation": classification_metrics(
                val_prediction, val_y, hierarchy_stage(val_quality, val_score, q_min, d_max),
                rare_ids, n_classes,
            ),
            "test": classification_metrics(
                test_prediction, test_y, hierarchy_stage(test_quality, test_score, q_min, d_max),
                rare_ids, n_classes,
            ),
        }
    fixed_risk: dict[str, Any] = {}
    for target in risk_targets:
        d_max = threshold_for_risk(
            val_quality, val_score, val_prediction, val_y, q_min, target
        )
        fixed_risk[f"{target:.6g}"] = {
            "selection_split": "fold 9 only", "target_risk": float(target), "d_max": d_max,
            "validation": classification_metrics(
                val_prediction, val_y, hierarchy_stage(val_quality, val_score, q_min, d_max),
                rare_ids, n_classes,
            ),
            "test": classification_metrics(
                test_prediction, test_y, hierarchy_stage(test_quality, test_score, q_min, d_max),
                rare_ids, n_classes,
            ),
        }
    return {"fixed_coverage": fixed_coverage, "coverage_at_fixed_risk": fixed_risk}


def flatten_numeric(value: Any, prefix: str = "") -> dict[str, float]:
    result: dict[str, float] = {}
    if isinstance(value, Mapping):
        for key, item in value.items():
            if key in {
                "formal_neural_profile", "hierarchy_decision_profile", "parameter_count",
                "split", "rare_names", "pipeline", "detector", "selection_split",
                "threshold_source", "tie_rule",
            }:
                continue
            child = f"{prefix}.{key}" if prefix else str(key)
            result.update(flatten_numeric(item, child))
        return result
    if isinstance(value, bool) or value is None:
        return result
    if isinstance(value, (int, float, np.integer, np.floating)):
        numeric = float(value)
        if math.isfinite(numeric):
            result[prefix] = numeric
    return result


def aggregate_scientific_results(
    payloads: Mapping[str, Sequence[Mapping[str, Any]]]
) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "status": "complete",
        "schema": "paper46-modular-pipeline-summary-v1",
        "method": "softmax_modular+sqi+mahalanobis+hierarchical_rejection",
        "statistics": {},
    }
    for domain, records in payloads.items():
        source_key = "protocols" if domain == "ptb" else "conditions"
        flattened = [flatten_numeric(record[source_key]) for record in records]
        common = set.intersection(*(set(item) for item in flattened)) if flattened else set()
        rows: dict[str, Any] = {}
        for path in sorted(common):
            values = np.asarray([item[path] for item in flattened], dtype=np.float64)
            n = len(values)
            mean = float(values.mean())
            sd = float(values.std(ddof=1)) if n > 1 else 0.0
            half_width = (
                float(scipy_stats.t.ppf(0.975, n - 1) * sd / math.sqrt(n))
                if n > 1 else 0.0
            )
            rows[path] = {
                "n": n, "mean": mean, "sd": sd,
                "ci95_low": mean - half_width, "ci95_high": mean + half_width,
                "values": values.tolist(),
            }
        summary["statistics"][domain] = rows
    return summary


def compare(expected: Any, actual: Any, path: str, errors: list[str]) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping):
            errors.append(f"{path}: expected mapping, found {type(actual).__name__}")
            return
        if set(expected) != set(actual):
            errors.append(
                f"{path}: key mismatch expected={sorted(expected)} actual={sorted(actual)}"
            )
            return
        for key in expected:
            compare(expected[key], actual[key], f"{path}.{key}", errors)
        return
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(expected) != len(actual):
            errors.append(f"{path}: list mismatch")
            return
        for index, (left, right) in enumerate(zip(expected, actual)):
            compare(left, right, f"{path}[{index}]", errors)
        return
    if expected is None or actual is None:
        if expected is not actual:
            errors.append(f"{path}: expected {expected!r}, found {actual!r}")
        return
    if isinstance(expected, (int, float, np.integer, np.floating)) and not isinstance(expected, bool):
        try:
            left, right = float(expected), float(actual)
        except (TypeError, ValueError):
            errors.append(f"{path}: numeric type mismatch")
            return
        if not math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-12):
            errors.append(f"{path}: expected {left:.17g}, found {right:.17g}")
        return
    if expected != actual:
        errors.append(f"{path}: expected {expected!r}, found {actual!r}")


def verify_upstream_inputs(
    definition: Mapping[str, Any], roots: Mapping[str, Path], errors: list[str], label: str
) -> None:
    inputs = definition.get("input_artifacts")
    if not isinstance(inputs, list) or not inputs:
        errors.append(f"{label}: missing input artifact inventory")
        return
    identities: set[tuple[str, str]] = set()
    for index, item in enumerate(inputs):
        if not isinstance(item, Mapping):
            errors.append(f"{label}: input {index} is not a mapping")
            continue
        root_kind = item.get("root_kind")
        relative = item.get("relative_path")
        if root_kind not in roots or not isinstance(relative, str):
            errors.append(f"{label}: invalid input root/path at index {index}")
            continue
        identity = (str(root_kind), relative)
        if identity in identities:
            errors.append(f"{label}: duplicate input identity {identity}")
            continue
        identities.add(identity)
        root = roots[str(root_kind)].resolve()
        candidate = (root / relative).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            errors.append(f"{label}: path escapes root: {relative}")
            continue
        if not candidate.is_file():
            errors.append(f"{label}: missing upstream input {candidate}")
            continue
        if item.get("bytes") != candidate.stat().st_size:
            errors.append(f"{label}: upstream byte mismatch {candidate}")
        if item.get("sha256") != sha256_file(candidate):
            errors.append(f"{label}: upstream SHA mismatch {candidate}")


def load_result_pair(
    output_dir: Path, domain: str, seed: int, roots: Mapping[str, Path], errors: list[str]
) -> tuple[dict[str, Any] | None, dict[str, np.ndarray] | None]:
    json_path = output_dir / domain / f"seed_{seed}.json"
    npz_path = output_dir / domain / f"seed_{seed}_arrays.npz"
    if not json_path.is_file() or not npz_path.is_file():
        errors.append(f"{domain} seed={seed}: missing JSON/NPZ pair")
        return None, None
    try:
        payload = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{domain} seed={seed}: unreadable JSON: {type(exc).__name__}")
        return None, None
    if payload.get("status") != "complete" or payload.get("domain") != domain:
        errors.append(f"{domain} seed={seed}: invalid status/domain")
    if payload.get("seed") != seed or payload.get("fingerprint_schema") != FINGERPRINT_SCHEMA:
        errors.append(f"{domain} seed={seed}: invalid seed/fingerprint schema")
    definition = payload.get("run_definition")
    if not isinstance(definition, Mapping) or canonical_hash(definition) != payload.get("run_fingerprint"):
        errors.append(f"{domain} seed={seed}: run fingerprint mismatch")
    else:
        if definition.get("seed") != seed:
            errors.append(f"{domain} seed={seed}: definition seed mismatch")
        verify_upstream_inputs(definition, roots, errors, f"{domain} seed={seed}")
    declared = payload.get("artifacts", {}).get("arrays_npz", {})
    if (
        declared.get("filename") != npz_path.name
        or declared.get("bytes") != npz_path.stat().st_size
        or declared.get("sha256") != sha256_file(npz_path)
    ):
        errors.append(f"{domain} seed={seed}: output NPZ manifest mismatch")
    try:
        with np.load(npz_path, allow_pickle=False) as archive:
            arrays = {name: np.array(archive[name]) for name in archive.files}
    except Exception as exc:
        errors.append(f"{domain} seed={seed}: unreadable NPZ: {type(exc).__name__}: {exc}")
        return payload, None
    for name, value in arrays.items():
        if value.dtype.hasobject:
            errors.append(f"{domain} seed={seed}: object dtype array {name}")
        if value.dtype.kind in "fc" and not np.isfinite(value).all() and name != "snr_db":
            errors.append(f"{domain} seed={seed}: non-finite array {name}")
    return payload, arrays


def audit_ptb_seed(
    payload: Mapping[str, Any], arrays: Mapping[str, np.ndarray], seed: int,
    errors: list[str],
) -> None:
    definition = payload.get("run_definition", {})
    config = definition.get("configuration", {})
    if definition.get("domain") != "ptb_closed_chapman_and_strict80":
        errors.append(f"ptb seed={seed}: wrong definition domain")
        return
    if config.get("detector") != "Mahalanobis:oas" or config.get("threshold_fit") != "fold 9 only":
        errors.append(f"ptb seed={seed}: detector/threshold protocol mismatch")
    quality_quantile = float(config.get("quality_quantile", -1))
    mahalanobis_quantile = float(config.get("mahalanobis_quantile", -1))
    coverages = tuple(float(value) for value in config.get("fixed_coverages", ()))
    risk_targets = tuple(float(value) for value in config.get("risk_targets", ()))
    guards = payload.get("protocol_guards", {})
    required_guards = {
        "neural_training_or_parameter_update_performed": False,
        "posthoc_density_reused_from_formal_result": True,
        "thresholds_fit_on_fold9_only": True,
        "test_or_ood_threshold_tuning": False,
        "strict_ood_used_for_selection": False,
        "chapman_used_for_selection": False,
    }
    for key, value in required_guards.items():
        if guards.get(key) != value:
            errors.append(f"ptb seed={seed}: protocol guard {key} mismatch")

    exact_keys: set[str] = set()
    for protocol, layout in PTB_LAYOUT.items():
        exact_keys.update(
            {
                f"{protocol}_val_quality", f"{protocol}_val_mahalanobis",
                f"{protocol}_val_prediction", f"{protocol}_val_y", f"{protocol}_val_stage",
                f"{protocol}_test_quality", f"{protocol}_test_mahalanobis",
                f"{protocol}_test_prediction", f"{protocol}_test_y", f"{protocol}_test_stage",
                f"{protocol}_rare_ids",
            }
        )
        for name in layout["ood"]:
            exact_keys.update(
                {
                    f"{protocol}_{name}_quality", f"{protocol}_{name}_mahalanobis",
                    f"{protocol}_{name}_stage",
                }
            )
    if set(arrays) != exact_keys:
        errors.append(
            f"ptb seed={seed}: NPZ key mismatch missing={sorted(exact_keys-set(arrays))} "
            f"extra={sorted(set(arrays)-exact_keys)}"
        )

    for protocol, layout in PTB_LAYOUT.items():
        base_keys = {
            f"{protocol}_val_quality", f"{protocol}_val_mahalanobis",
            f"{protocol}_val_prediction", f"{protocol}_val_y", f"{protocol}_val_stage",
            f"{protocol}_test_quality", f"{protocol}_test_mahalanobis",
            f"{protocol}_test_prediction", f"{protocol}_test_y", f"{protocol}_test_stage",
            f"{protocol}_rare_ids",
        }
        for name in layout["ood"]:
            base_keys.update(
                {
                    f"{protocol}_{name}_quality", f"{protocol}_{name}_mahalanobis",
                    f"{protocol}_{name}_stage",
                }
            )
        missing = sorted(base_keys - set(arrays))
        if missing:
            errors.append(f"ptb seed={seed}/{protocol}: missing arrays {missing}")
            continue
        expected_lengths = {"val": layout["val"], "test": layout["test"], **layout["ood"]}
        for split, length in expected_lengths.items():
            for suffix in ("quality", "mahalanobis"):
                key = f"{protocol}_{split}_{suffix}"
                if arrays[key].shape != (length,):
                    errors.append(
                        f"ptb seed={seed}/{protocol}: {key} shape {arrays[key].shape}, expected {(length,)}"
                    )
            if arrays[f"{protocol}_{split}_quality"].dtype != np.dtype(np.float32):
                errors.append(f"ptb seed={seed}/{protocol}: {split} quality dtype is not float32")
            if arrays[f"{protocol}_{split}_mahalanobis"].dtype != np.dtype(np.float64):
                errors.append(f"ptb seed={seed}/{protocol}: {split} Mahalanobis dtype is not float64")
            if arrays[f"{protocol}_{split}_stage"].dtype != np.dtype(np.int8):
                errors.append(f"ptb seed={seed}/{protocol}: {split} stage dtype is not int8")
        for split in ("val", "test"):
            if arrays[f"{protocol}_{split}_prediction"].dtype != np.dtype(np.int16):
                errors.append(f"ptb seed={seed}/{protocol}: {split} prediction dtype is not int16")
            if arrays[f"{protocol}_{split}_y"].dtype != np.dtype(np.int16):
                errors.append(f"ptb seed={seed}/{protocol}: {split} label dtype is not int16")
        if arrays[f"{protocol}_rare_ids"].dtype != np.dtype(np.int16):
            errors.append(f"ptb seed={seed}/{protocol}: rare_ids dtype is not int16")
        val_q = arrays[f"{protocol}_val_quality"]
        val_d = arrays[f"{protocol}_val_mahalanobis"]
        q_min = quantile_higher(val_q, quality_quantile)
        quality_pass = val_q >= q_min
        d_max = quantile_higher(val_d[quality_pass], mahalanobis_quantile)
        stored_thresholds = payload.get("protocols", {}).get(protocol, {}).get("thresholds", {})
        compare(q_min, stored_thresholds.get("q_min"), f"ptb.{seed}.{protocol}.q_min", errors)
        compare(d_max, stored_thresholds.get("d_max"), f"ptb.{seed}.{protocol}.d_max", errors)
        stages: dict[str, np.ndarray] = {}
        for split in expected_lengths:
            stage = hierarchy_stage(
                arrays[f"{protocol}_{split}_quality"],
                arrays[f"{protocol}_{split}_mahalanobis"], q_min, d_max,
            )
            stages[split] = stage
            stored_stage = arrays[f"{protocol}_{split}_stage"]
            if not np.array_equal(stage, stored_stage):
                errors.append(f"ptb seed={seed}/{protocol}: {split} hierarchy stage mismatch")
        rare_ids = arrays[f"{protocol}_rare_ids"]
        n_classes = int(layout["classes"])
        expected_diagnosis = {
            "validation": classification_metrics(
                arrays[f"{protocol}_val_prediction"], arrays[f"{protocol}_val_y"],
                stages["val"], rare_ids, n_classes,
            ),
            "test": classification_metrics(
                arrays[f"{protocol}_test_prediction"], arrays[f"{protocol}_test_y"],
                stages["test"], rare_ids, n_classes,
            ),
        }
        stored_protocol = payload.get("protocols", {}).get(protocol, {})
        compare(
            expected_diagnosis, stored_protocol.get("diagnosis"),
            f"ptb.{seed}.{protocol}.diagnosis", errors,
        )
        expected_selective = selective_operating_points(
            val_q, val_d, arrays[f"{protocol}_val_prediction"], arrays[f"{protocol}_val_y"],
            arrays[f"{protocol}_test_quality"], arrays[f"{protocol}_test_mahalanobis"],
            arrays[f"{protocol}_test_prediction"], arrays[f"{protocol}_test_y"],
            rare_ids, n_classes, q_min, coverages, risk_targets,
        )
        compare(
            expected_selective, stored_protocol.get("selective_operating_points"),
            f"ptb.{seed}.{protocol}.selective", errors,
        )
        for name in layout["ood"]:
            expected_ood = {
                "mahalanobis_ranking": ood_ranking(
                    arrays[f"{protocol}_test_mahalanobis"],
                    arrays[f"{protocol}_{name}_mahalanobis"],
                ),
                "hierarchical_operating_point": ood_operating_metrics(
                    stages["test"], stages[name]
                ),
            }
            compare(
                expected_ood, stored_protocol.get("ood", {}).get(name),
                f"ptb.{seed}.{protocol}.ood.{name}", errors,
            )


def audit_noise_seed(
    payload: Mapping[str, Any], arrays: Mapping[str, np.ndarray], seed: int,
    errors: list[str],
) -> None:
    definition = payload.get("run_definition", {})
    config = definition.get("configuration", {})
    if definition.get("domain") != "paired_snr_noise":
        errors.append(f"noise seed={seed}: wrong definition domain")
        return
    if (
        config.get("detector") != "Mahalanobis:oas"
        or config.get("covariance") != "oas"
        or config.get("threshold_fit") != "clean fold 9 only and frozen across all SNRs"
    ):
        errors.append(f"noise seed={seed}: detector/threshold protocol mismatch")
    required_shapes = {
        "snr_db": (7,), "val_quality": (2183,), "val_mahalanobis": (2183,),
        "val_prediction": (2183,), "val_y": (2183,),
        "test_quality": (7, 2198), "test_mahalanobis": (7, 2198),
        "test_prediction": (7, 2198), "test_stage": (7, 2198),
        "test_y": (2198,), "rare_ids": None,
    }
    if set(arrays) != set(required_shapes):
        errors.append(
            f"noise seed={seed}: NPZ key mismatch "
            f"missing={sorted(set(required_shapes)-set(arrays))} "
            f"extra={sorted(set(arrays)-set(required_shapes))}"
        )
    for name, shape in required_shapes.items():
        if name not in arrays:
            errors.append(f"noise seed={seed}: missing array {name}")
        elif shape is not None and arrays[name].shape != shape:
            errors.append(f"noise seed={seed}: {name} shape {arrays[name].shape}, expected {shape}")
    expected_dtypes = {
        "snr_db": np.dtype(np.float64), "val_quality": np.dtype(np.float32),
        "val_mahalanobis": np.dtype(np.float64), "val_prediction": np.dtype(np.int16),
        "val_y": np.dtype(np.int16), "test_quality": np.dtype(np.float32),
        "test_mahalanobis": np.dtype(np.float64), "test_prediction": np.dtype(np.int16),
        "test_stage": np.dtype(np.int8), "test_y": np.dtype(np.int16),
        "rare_ids": np.dtype(np.int16),
    }
    for name, dtype in expected_dtypes.items():
        if name in arrays and arrays[name].dtype != dtype:
            errors.append(f"noise seed={seed}: {name} dtype {arrays[name].dtype}, expected {dtype}")
    if any(name not in arrays for name in required_shapes):
        return
    expected_snr = np.asarray([np.nan, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0])
    if not np.allclose(arrays["snr_db"], expected_snr, equal_nan=True):
        errors.append(f"noise seed={seed}: SNR values/order mismatch")
    if tuple(config.get("snrs", ())) != NOISE_SNRS:
        errors.append(f"noise seed={seed}: SNR labels/order mismatch")
    quality_quantile = float(config.get("quality_quantile", -1))
    mahalanobis_quantile = float(config.get("mahalanobis_quantile", -1))
    val_q, val_d = arrays["val_quality"], arrays["val_mahalanobis"]
    q_min = quantile_higher(val_q, quality_quantile)
    quality_pass = val_q >= q_min
    d_max = quantile_higher(val_d[quality_pass], mahalanobis_quantile)
    compare(q_min, payload.get("thresholds", {}).get("q_min"), f"noise.{seed}.q_min", errors)
    compare(d_max, payload.get("thresholds", {}).get("d_max"), f"noise.{seed}.d_max", errors)
    coverages = tuple(float(value) for value in config.get("fixed_coverages", ()))
    risk_targets = tuple(float(value) for value in config.get("risk_targets", ()))
    rare_ids = arrays["rare_ids"]
    for index, label in enumerate(NOISE_SNRS):
        stage = hierarchy_stage(arrays["test_quality"][index], arrays["test_mahalanobis"][index], q_min, d_max)
        if not np.array_equal(stage, arrays["test_stage"][index]):
            errors.append(f"noise seed={seed}/{label}: hierarchy stage mismatch")
        expected_main = classification_metrics(
            arrays["test_prediction"][index], arrays["test_y"], stage,
            rare_ids, 70,
        )
        stored = payload.get("conditions", {}).get(label, {})
        compare(expected_main, stored.get("main_hierarchy"), f"noise.{seed}.{label}.main", errors)
        expected_selective = selective_operating_points(
            val_q, val_d, arrays["val_prediction"], arrays["val_y"],
            arrays["test_quality"][index], arrays["test_mahalanobis"][index],
            arrays["test_prediction"][index], arrays["test_y"], rare_ids, 70,
            q_min, coverages, risk_targets,
        )
        compare(
            expected_selective, stored.get("selective_operating_points"),
            f"noise.{seed}.{label}.selective", errors,
        )
        compare(
            float(np.asarray(arrays["test_quality"][index], dtype=np.float64).mean()),
            stored.get("mean_quality"),
            f"noise.{seed}.{label}.mean_quality", errors,
        )
        compare(
            float(arrays["test_mahalanobis"][index].mean()), stored.get("mean_mahalanobis"),
            f"noise.{seed}.{label}.mean_mahalanobis", errors,
        )
    guards = payload.get("protocol_guards", {})
    required_guards = {
        "neural_training_or_parameter_update_performed": False,
        "checkpoint_loaded_read_only": True,
        "posthoc_density_fit_performed": True,
        "density_fit_on_folds1_8_only": True,
        "thresholds_fit_on_clean_fold9_only": True,
        "test_or_noise_threshold_tuning": False,
        "same_paired_noise_source_as_formal_experiment": True,
        "all_ecg_derived_sources_recomputed_at_each_snr": True,
    }
    for key, value in required_guards.items():
        if guards.get(key) != value:
            errors.append(f"noise seed={seed}: protocol guard {key} mismatch")
    checks = payload.get("formal_reproduction_checks", {})
    if not all(checks.get(key) is True for key in (
        "softmax_predictions_exact", "quality_allclose_atol_1e-6",
        "test_record_order_and_labels_exact",
    )):
        errors.append(f"noise seed={seed}: formal reproduction checks are not all true")


def audit_manifest(output_dir: Path, errors: list[str]) -> dict[str, Any] | None:
    path = output_dir / "manifest.json"
    if not path.is_file():
        errors.append("top-level manifest.json is missing")
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"manifest is unreadable: {type(exc).__name__}")
        return None
    if payload.get("status") != "complete" or payload.get("schema") != MANIFEST_SCHEMA:
        errors.append("manifest status/schema mismatch")
    definition = payload.get("definition")
    if not isinstance(definition, Mapping) or canonical_hash(definition) != payload.get("fingerprint"):
        errors.append("manifest fingerprint mismatch")
        return payload
    expected_identities = {
        (domain, seed, role)
        for domain, seeds in (("ptb", PTB_SEEDS), ("noise", NOISE_SEEDS))
        for seed in seeds for role in ("json", "arrays_npz")
    }
    expected_identities.add(("aggregate", 0, "summary_json"))
    inventory = definition.get("inventory", [])
    observed: set[tuple[str, int, str]] = set()
    for item in inventory:
        identity = (item.get("domain"), item.get("seed"), item.get("role"))
        if identity in observed:
            errors.append(f"duplicate manifest identity {identity}")
            continue
        observed.add(identity)
        relative = item.get("relative_path")
        if not isinstance(relative, str):
            errors.append(f"manifest item has invalid path: {identity}")
            continue
        candidate = (output_dir / relative).resolve()
        try:
            candidate.relative_to(output_dir.resolve())
        except ValueError:
            errors.append(f"manifest path escapes output root: {relative}")
            continue
        if not candidate.is_file():
            errors.append(f"manifest file missing: {candidate}")
            continue
        if item.get("bytes") != candidate.stat().st_size or item.get("sha256") != sha256_file(candidate):
            errors.append(f"manifest size/SHA mismatch: {candidate}")
    if observed != expected_identities:
        errors.append(
            f"manifest identity mismatch missing={sorted(expected_identities-observed, key=str)} "
            f"extra={sorted(observed-expected_identities, key=str)}"
        )
    if payload.get("counts") != {
        "ptb_results": 5, "noise_results": 3, "summary_files": 1, "files": 17,
    }:
        errors.append("manifest counts mismatch")
    summary_path = output_dir / "summary.json"
    if summary_path.is_file():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"summary is unreadable: {type(exc).__name__}")
        else:
            if (
                summary.get("status") != "complete"
                or summary.get("schema") != "paper46-modular-pipeline-summary-v1"
                or set(summary.get("statistics", {})) != {"ptb", "noise"}
            ):
                errors.append("summary status/schema/domain mismatch")
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("/root/Paper46_revision/results_final/modular_pipeline"))
    parser.add_argument("--experiment-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--ptb-results-dir", type=Path, default=Path("/root/Paper46_revision/results_final/ptbxl"))
    parser.add_argument("--noise-results-dir", type=Path, default=Path("/root/Paper46_revision/results_final/noise_sqi"))
    parser.add_argument("--noise-checkpoint-dir", type=Path, default=Path("/root/Paper46_revision/checkpoints_final/noise_sqi"))
    parser.add_argument("--cache-dir", type=Path, default=Path("/root/Paper46_revision/cache"))
    parser.add_argument("--trustfed-cache", type=Path, default=Path("/root/autodl-tmp/TrustFedECG/cache"))
    parser.add_argument("--audit-report", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    args.output_dir = args.output_dir.resolve()
    roots = {
        "code": args.experiment_dir.resolve(),
        "ptb_results": args.ptb_results_dir.resolve(),
        "noise_results": args.noise_results_dir.resolve(),
        "noise_checkpoints": args.noise_checkpoint_dir.resolve(),
        "cache": args.cache_dir.resolve(),
        "trustfed_cache": args.trustfed_cache.resolve(),
    }
    audit_report = (
        args.audit_report.resolve()
        if args.audit_report is not None
        else args.output_dir / "audit.json"
    )
    errors: list[str] = []
    started = time.time()
    manifest = audit_manifest(args.output_dir, errors)
    audited = {"ptb": 0, "noise": 0}
    seed_payloads: dict[str, list[Mapping[str, Any]]] = {"ptb": [], "noise": []}
    for domain, seeds in (("ptb", PTB_SEEDS), ("noise", NOISE_SEEDS)):
        for seed in seeds:
            payload, arrays = load_result_pair(args.output_dir, domain, seed, roots, errors)
            if payload is None or arrays is None:
                continue
            seed_payloads[domain].append(payload)
            before = len(errors)
            if domain == "ptb":
                audit_ptb_seed(payload, arrays, seed, errors)
            else:
                audit_noise_seed(payload, arrays, seed, errors)
            if len(errors) == before:
                audited[domain] += 1
    if all(len(seed_payloads[domain]) == len(seeds) for domain, seeds in (
        ("ptb", PTB_SEEDS), ("noise", NOISE_SEEDS),
    )):
        summary_path = args.output_dir / "summary.json"
        if summary_path.is_file():
            try:
                stored_summary = json.loads(summary_path.read_text(encoding="utf-8"))
            except Exception as exc:
                errors.append(f"summary content is unreadable: {type(exc).__name__}")
            else:
                compare(
                    aggregate_scientific_results(seed_payloads), stored_summary,
                    "summary", errors,
                )
    report = {
        "status": "complete" if not errors else "failed",
        "schema": "paper46-modular-pipeline-audit-v1",
        "audited": audited,
        "expected": {"ptb": 5, "noise": 3},
        "manifest_present": manifest is not None,
        "error_count": len(errors),
        "errors": errors,
        "checks": [
            "exact canonical seed/file matrix",
            "top-level and seed fingerprints",
            "output and upstream SHA-256 inventories",
            "allow_pickle=False NPZ readability and non-object dtypes",
            "fold-9 threshold reconstruction",
            "hierarchy-stage reconstruction",
            "diagnosis/selective/OOD metric reconstruction",
            "cross-seed mean/SD/t-interval summary reconstruction",
            "no-training and no-test-tuning guards",
        ],
        "elapsed_seconds": time.time() - started,
    }
    atomic_json(audit_report, report)
    if errors:
        for error in errors:
            print(f"[ERROR] {error}")
        print(f"[failed] {len(errors)} audit error(s); report={audit_report}")
        return 1
    print(
        f"[complete] strict modular-pipeline audit passed: "
        f"ptb={audited['ptb']}/5 noise={audited['noise']}/3 report={audit_report}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
