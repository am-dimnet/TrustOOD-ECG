#!/usr/bin/env bash
# Run every three-seed MHEALTH and WESAD LOSO fold on AutoDL.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
DATA_ROOT="${DATA_ROOT:-/root/autodl-tmp/Paper54/data_processed}"
RESULTS_DIR="${RESULTS_DIR:-${REVISION_ROOT}/results_final/wearables}"
LOG_DIR="${LOG_DIR:-${REVISION_ROOT}/logs_final/wearables}"
MAX_PARALLEL="${MAX_PARALLEL:-8}"
EPOCHS="${EPOCHS:-30}"
BATCH_SIZE="${BATCH_SIZE:-128}"
RUNNER="${EXPERIMENT_DIR}/run_wearables_revision.py"

SEEDS=(7 42 2026)
MHEALTH_SUBJECTS=(S1 S2 S3 S4 S5 S6 S7 S8 S9 S10)
WESAD_SUBJECTS=(S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S13 S14 S15 S16 S17)

if [[ ! -f "${DATA_ROOT}/mhealth/S1.npz" || ! -f "${DATA_ROOT}/wesad/S2.npz" ]]; then
  echo "Refusing to run: per-subject AutoDL wearable caches are absent" >&2
  exit 2
fi
if [[ ! "${MAX_PARALLEL}" =~ ^[1-9][0-9]*$ ]]; then
  echo "MAX_PARALLEL must be a positive integer" >&2
  exit 2
fi

mkdir -p "${RESULTS_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile "${EXPERIMENT_DIR}/revisionlib.py" "${RUNNER}"
{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'host='; hostname
  printf 'max_parallel=%s\n' "${MAX_PARALLEL}"
  printf 'epochs=%s\n' "${EPOCHS}"
  printf 'batch_size=%s\n' "${BATCH_SIZE}"
  printf 'CUBLAS_WORKSPACE_CONFIG=%s\n' ':4096:8'
  sha256sum "${RUNNER}" "${EXPERIMENT_DIR}/revisionlib.py"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/wearables_matrix_manifest.txt"

run_task() {
  local dataset="$1"
  local subject="$2"
  local seed="$3"
  local name="${dataset}_${subject}_seed${seed}"
  local exit_file="${LOG_DIR}/${name}.exit"
  local log_file="${LOG_DIR}/${name}.log"
  local command_file="${LOG_DIR}/${name}.command.txt"
  local command=(
    "${PYTHON}" "${RUNNER}"
    --dataset "${dataset}"
    --heldout-subject "${subject}"
    --models all
    --seed "${seed}"
    --epochs "${EPOCHS}"
    --batch-size "${BATCH_SIZE}"
    --data-root "${DATA_ROOT}"
    --results-dir "${RESULTS_DIR}"
  )
  printf '%q ' "${command[@]}" > "${command_file}"
  printf '\n' >> "${command_file}"
  set +e
  CUBLAS_WORKSPACE_CONFIG=:4096:8 \
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${command[@]}" > "${log_file}" 2>&1
  local status=$?
  printf '%s\n' "${status}" > "${exit_file}"
  return "${status}"
}

launch_task() {
  while (( $(jobs -rp | wc -l) >= MAX_PARALLEL )); do
    wait -n || true
  done
  run_task "$@" &
}

for seed in "${SEEDS[@]}"; do
  for subject in "${MHEALTH_SUBJECTS[@]}"; do
    launch_task mhealth "${subject}" "${seed}"
  done
  for subject in "${WESAD_SUBJECTS[@]}"; do
    launch_task wesad "${subject}" "${seed}"
  done
done

wait || true

failed=0
expected=0
for exit_file in "${LOG_DIR}"/*.exit; do
  [[ -e "${exit_file}" ]] || continue
  expected=$((expected + 1))
  status="$(tr -d '[:space:]' < "${exit_file}")"
  if [[ "${status}" != "0" ]]; then
    echo "FAILED: ${exit_file} (exit ${status})" >&2
    failed=$((failed + 1))
  fi
done
if (( expected != 75 )); then
  echo "FAILED: expected 75 task exit files, found ${expected}" >&2
  exit 3
fi
if (( failed != 0 )); then
  echo "FAILED: ${failed} wearable task(s) failed" >&2
  exit 1
fi

date --iso-8601=seconds > "${LOG_DIR}/wearables_matrix.complete"
echo "All 75 three-seed wearable LOSO tasks completed successfully."
