#!/usr/bin/env bash
# Run the three-seed, inference-only noise-shift calibration study on AutoDL.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
RUNNER="${EXPERIMENT_DIR}/infer_noise_shift_calibration.py"
AUDITOR="${EXPERIMENT_DIR}/audit_noise_shift_calibration.py"
OUTPUT_DIR="${OUTPUT_DIR:-/dev/shm/Paper46_noise_shift_calibration/results}"
LOG_DIR="${LOG_DIR:-/dev/shm/Paper46_logs_missing/noise_shift}"
CHECKPOINT_ROOT="${CHECKPOINT_ROOT:-${REVISION_ROOT}/checkpoints_final/noise_sqi/canonical}"
CANONICAL_RESULTS_ROOT="${CANONICAL_RESULTS_ROOT:-${REVISION_ROOT}/results_final/noise_sqi/canonical}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
SEEDS=(7 13 42)

if [[ ! -f "${TRUSTFED_CACHE}/ptbxl_signals.npy" ]]; then
  echo "Refusing to run: PTB-XL signal cache is absent" >&2
  exit 2
fi
for path in "${RUNNER}" "${AUDITOR}"; do
  [[ -f "${path}" ]] || { echo "Missing script: ${path}" >&2; exit 2; }
done

mkdir -p "${OUTPUT_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile "${RUNNER}" "${AUDITOR}"
{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'expected_seeds=7,13,42\n'
  printf 'training=none (inference only)\n'
  sha256sum "${RUNNER}" "${AUDITOR}" \
    "${EXPERIMENT_DIR}/run_noise_sqi.py" \
    "${EXPERIMENT_DIR}/revisionlib.py" \
    "${EXPERIMENT_DIR}/data_adapter.py"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/noise_shift_calibration_manifest.txt"

run_seed() {
  local seed="$1"
  local name="noise_shift_seed${seed}"
  local command=(
    "${PYTHON}" -u "${RUNNER}"
    --seeds 7,13,42 --worker-seed "${seed}" --device cuda
    --trustfed-cache "${TRUSTFED_CACHE}" --cache-dir "${CACHE_DIR}"
    --checkpoint-root "${CHECKPOINT_ROOT}"
    --canonical-results-root "${CANONICAL_RESULTS_ROOT}"
    --output-dir "${OUTPUT_DIR}"
    --eval-batch-size 512 --feature-chunk-size 256
    --calibration-bins 15 --rare-threshold 50
  )
  printf '%q ' "${command[@]}" > "${LOG_DIR}/${name}.command.txt"
  printf '\n' >> "${LOG_DIR}/${name}.command.txt"
  set +e
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${command[@]}" > "${LOG_DIR}/${name}.log" 2>&1
  local status=$?
  set -e
  printf '%s\n' "${status}" > "${LOG_DIR}/${name}.exit"
  return "${status}"
}

pids=()
for seed in "${SEEDS[@]}"; do
  run_seed "${seed}" &
  pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=$((failed + 1))
  fi
done
if (( failed != 0 )); then
  echo "Noise-shift calibration failed in ${failed} seed worker(s)" >&2
  exit 1
fi

for seed in "${SEEDS[@]}"; do
  [[ -s "${OUTPUT_DIR}/seed_${seed}.json" ]] || exit 3
  [[ -s "${OUTPUT_DIR}/seed_${seed}_calibration.npz" ]] || exit 3
done
"${PYTHON}" - "${OUTPUT_DIR}/manifest.json" <<'PY'
import json
import sys
from pathlib import Path
payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
if payload.get("complete") is not True or payload.get("observed_seeds") != [7, 13, 42]:
    raise SystemExit("incomplete calibration manifest")
PY

date --iso-8601=seconds > "${LOG_DIR}/noise_shift_calibration.complete"
echo "All three inference-only noise-shift calibration workers completed."
