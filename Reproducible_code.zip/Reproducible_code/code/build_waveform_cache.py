#!/usr/bin/env python3
"""Build the PTB-XL and Chapman waveform caches used by this study.

The output interface is intentionally identical to the cache interface consumed
by ``data_adapter.py``:

* ``ptbxl_signals.npy`` and ``chapman_signals.npy`` contain int16 microvolts in
  ``(record, 12, 1000)`` order.
* ``ptbxl_meta.csv`` and ``chapman_meta.csv`` preserve the authoritative source
  row order and record identifiers.
* ``preprocess_manifest.json`` records source paths, dimensions, software
  versions, failure counts, and SHA-256 digests.

Raw data are never included in this repository. Download the official datasets
under their respective terms before running this program. Existing cache files
are never replaced unless ``--force`` is supplied.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import tempfile
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import scipy
import wfdb
from scipy.signal import decimate


FORMAT_VERSION = "paper46-waveform-cache-v1"
TARGET_FS = 100
TARGET_LEN = 1000
N_LEADS = 12
MICROVOLTS_PER_MILLIVOLT = 1000.0


class CacheBuildError(RuntimeError):
    """Raised when an input or output violates the canonical cache contract."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def to_int16_microvolts(signal_mv: np.ndarray) -> np.ndarray:
    values = np.rint(np.asarray(signal_mv, dtype=np.float64) * MICROVOLTS_PER_MILLIVOLT)
    return np.clip(values, -32768, 32767).astype(np.int16)


def atomic_save_npy(path: Path, array: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            np.save(handle, array, allow_pickle=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            frame.to_csv(handle, index=False, lineterminator="\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def read_ptb_record(task: tuple[int, str, str]) -> tuple[int, np.ndarray | None, str | None]:
    index, root_text, relative_name = task
    try:
        record = wfdb.rdrecord(str(Path(root_text) / relative_name))
        signal = np.asarray(record.p_signal, dtype=np.float64)
        if signal.shape != (TARGET_LEN, N_LEADS):
            return index, None, f"unexpected shape {signal.shape}"
        if not np.isfinite(signal).all():
            signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)
        return index, to_int16_microvolts(signal.T), None
    except Exception as exc:  # noqa: BLE001
        return index, None, f"{type(exc).__name__}: {exc}"


def read_chapman_record(task: tuple[int, str]) -> tuple[int, np.ndarray | None, str | None]:
    index, record_path = task
    try:
        record = wfdb.rdrecord(record_path)
        signal = np.asarray(record.p_signal, dtype=np.float64)
        if signal.ndim != 2 or signal.shape[1] != N_LEADS:
            return index, None, f"unexpected shape {signal.shape}"
        if not np.isfinite(signal).all():
            signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)
        downsampled = decimate(signal, 5, axis=0, ftype="fir", zero_phase=True)
        if downsampled.shape[0] < TARGET_LEN:
            downsampled = np.pad(
                downsampled,
                ((0, TARGET_LEN - downsampled.shape[0]), (0, 0)),
                mode="constant",
            )
        downsampled = downsampled[:TARGET_LEN]
        return index, to_int16_microvolts(downsampled.T), None
    except Exception as exc:  # noqa: BLE001
        return index, None, f"{type(exc).__name__}: {exc}"


def map_records(
    function: Any,
    tasks: list[Any],
    workers: int,
    label: str,
) -> Iterable[tuple[int, np.ndarray | None, str | None]]:
    if workers == 1:
        for task in tasks:
            yield function(task)
        return
    with ProcessPoolExecutor(max_workers=workers) as executor:
        for completed, result in enumerate(executor.map(function, tasks, chunksize=64), start=1):
            if completed % 5000 == 0:
                print(f"[{label}] processed {completed}/{len(tasks)}", flush=True)
            yield result


def build_ptbxl(root: Path, workers: int) -> tuple[np.ndarray, pd.DataFrame, list[dict[str, Any]]]:
    database_path = root / "ptbxl_database.csv"
    if not database_path.is_file():
        raise FileNotFoundError(database_path)
    database = pd.read_csv(database_path, index_col="ecg_id")
    required = {
        "filename_lr",
        "patient_id",
        "age",
        "sex",
        "site",
        "device",
        "strat_fold",
    }
    missing = sorted(required - set(database.columns))
    if missing:
        raise CacheBuildError(f"PTB-XL metadata is missing columns: {missing}")

    tasks = [
        (index, str(root), str(relative_name))
        for index, relative_name in enumerate(database["filename_lr"].tolist())
    ]
    signals = np.zeros((len(tasks), N_LEADS, TARGET_LEN), dtype=np.int16)
    valid = np.zeros(len(tasks), dtype=bool)
    failures: list[dict[str, Any]] = []
    for index, signal, error in map_records(read_ptb_record, tasks, workers, "PTB-XL"):
        if signal is None:
            failures.append({"index": int(index), "error": str(error)})
        else:
            signals[index] = signal
            valid[index] = True

    metadata = pd.DataFrame(
        {
            "record_id": database.index.astype(str).to_numpy(),
            "patient_id": database["patient_id"].to_numpy(),
            "age": database["age"].to_numpy(),
            "sex": database["sex"].to_numpy(),
            "site": database["site"].to_numpy(),
            "device": database["device"].to_numpy(),
            "strat_fold": database["strat_fold"].to_numpy(),
            "valid": valid,
            "dataset": "ptbxl",
        }
    )
    return signals, metadata, failures


def parse_chapman_demographics(record_path: Path) -> tuple[float, str]:
    age = np.nan
    sex = "Unknown"
    try:
        for line in record_path.with_suffix(".hea").read_text(
            encoding="utf-8", errors="replace"
        ).splitlines():
            if line.startswith("#Age:"):
                value = line.split(":", 1)[1].strip()
                if value not in {"", "NaN", "Unknown"}:
                    age = float(value)
            elif line.startswith("#Sex:"):
                sex = line.split(":", 1)[1].strip() or "Unknown"
    except (OSError, ValueError):
        pass
    return age, sex


def build_chapman(root: Path, workers: int) -> tuple[np.ndarray, pd.DataFrame, list[dict[str, Any]]]:
    record_root = root / "WFDBRecords"
    if not record_root.is_dir():
        raise FileNotFoundError(record_root)
    headers = sorted(record_root.rglob("*.hea"))
    if not headers:
        raise CacheBuildError(f"no Chapman WFDB headers found below {record_root}")
    record_paths = [path.with_suffix("") for path in headers]
    tasks = [(index, str(path)) for index, path in enumerate(record_paths)]
    signals = np.zeros((len(tasks), N_LEADS, TARGET_LEN), dtype=np.int16)
    valid = np.zeros(len(tasks), dtype=bool)
    failures: list[dict[str, Any]] = []
    for index, signal, error in map_records(read_chapman_record, tasks, workers, "Chapman"):
        if signal is None:
            failures.append({"index": int(index), "error": str(error)})
        else:
            signals[index] = signal
            valid[index] = True

    demographics = [parse_chapman_demographics(path) for path in record_paths]
    record_ids = [path.name for path in record_paths]
    metadata = pd.DataFrame(
        {
            "record_id": record_ids,
            "patient_id": record_ids,
            "age": [item[0] for item in demographics],
            "sex": [item[1] for item in demographics],
            "site": np.nan,
            "device": "unknown",
            "strat_fold": -1,
            "valid": valid,
            "dataset": "chapman",
        }
    )
    return signals, metadata, failures


def output_paths(cache_dir: Path, dataset: str) -> tuple[Path, Path]:
    return cache_dir / f"{dataset}_signals.npy", cache_dir / f"{dataset}_meta.csv"


def assert_replace_policy(paths: Iterable[Path], force: bool) -> None:
    existing = [path for path in paths if path.exists()]
    if existing and not force:
        names = ", ".join(str(path) for path in existing)
        raise CacheBuildError(f"refusing to replace existing cache files without --force: {names}")


def save_dataset(
    cache_dir: Path,
    dataset: str,
    signals: np.ndarray,
    metadata: pd.DataFrame,
    failures: list[dict[str, Any]],
    source_root: Path,
    force: bool,
) -> dict[str, Any]:
    signal_path, metadata_path = output_paths(cache_dir, dataset)
    assert_replace_policy((signal_path, metadata_path), force)
    atomic_save_npy(signal_path, signals)
    atomic_write_csv(metadata_path, metadata)
    return {
        "source_root": str(source_root.resolve()),
        "row_order": (
            "ptbxl_database.csv order"
            if dataset == "ptbxl"
            else "sorted WFDBRecords/**/*.hea path order"
        ),
        "n_records": int(len(metadata)),
        "n_valid": int(metadata["valid"].sum()),
        "n_failed": int(len(failures)),
        "signals_shape": list(signals.shape),
        "signals_dtype": str(signals.dtype),
        "signals_file": str(signal_path.resolve()),
        "signals_size_bytes": signal_path.stat().st_size,
        "signals_sha256": sha256_file(signal_path),
        "metadata_file": str(metadata_path.resolve()),
        "metadata_size_bytes": metadata_path.stat().st_size,
        "metadata_sha256": sha256_file(metadata_path),
        "failures": failures,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ptbxl-root", type=Path, required=True)
    parser.add_argument("--chapman-root", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=20)
    parser.add_argument("--only", choices=("ptbxl", "chapman", "all"), default="all")
    parser.add_argument("--force", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.workers <= 0:
        raise CacheBuildError("--workers must be a positive integer")
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = args.cache_dir / "preprocess_manifest.json"
    manifest: dict[str, Any] = {}
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.update(
        {
            "format_version": FORMAT_VERSION,
            "updated_at_utc": utc_now(),
            "target_fs_hz": TARGET_FS,
            "target_length": TARGET_LEN,
            "n_leads": N_LEADS,
            "dtype": "int16",
            "unit": "microvolt",
            "chapman_resample": "scipy.signal.decimate(q=5, ftype=fir, zero_phase=True)",
            "software": {
                "python": platform.python_version(),
                "numpy": np.__version__,
                "pandas": pd.__version__,
                "scipy": scipy.__version__,
                "wfdb": wfdb.__version__,
            },
        }
    )

    if args.only in {"ptbxl", "all"}:
        signals, metadata, failures = build_ptbxl(args.ptbxl_root, args.workers)
        manifest["ptbxl"] = save_dataset(
            args.cache_dir,
            "ptbxl",
            signals,
            metadata,
            failures,
            args.ptbxl_root,
            args.force,
        )
        print(
            f"[PTB-XL] records={len(metadata)} valid={int(metadata['valid'].sum())} "
            f"failed={len(failures)}",
            flush=True,
        )

    if args.only in {"chapman", "all"}:
        signals, metadata, failures = build_chapman(args.chapman_root, args.workers)
        manifest["chapman"] = save_dataset(
            args.cache_dir,
            "chapman",
            signals,
            metadata,
            failures,
            args.chapman_root,
            args.force,
        )
        print(
            f"[Chapman] records={len(metadata)} valid={int(metadata['valid'].sum())} "
            f"failed={len(failures)}",
            flush=True,
        )

    atomic_write_json(manifest_path, manifest)
    print(f"[saved] {manifest_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
