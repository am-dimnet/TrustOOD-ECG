"""Generate the five structural figures used by the revised manuscript.

Run from any directory:
    python Reproducible_code/code/generate_structural_figures.py

To write a verification copy without touching the manuscript assets:
    python Reproducible_code/code/generate_structural_figures.py \
        --output-dir /tmp/paper46_structural_figures

The script reads no experiment outputs and writes exactly these assets:
fig1.png, fig_framework.pdf, fig_pipeline.pdf, fig_cacf.pdf, and
fig_decision_flow.pdf.
"""

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = PROJECT_ROOT / "Revision1" / "Manuscript" / "figures" / "latest16"
OUT = DEFAULT_OUT


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUT,
        help="Directory for the five generated structural assets.",
    )
    return parser.parse_args()

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 9.0,
        "mathtext.fontset": "dejavusans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.unicode_minus": False,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.06,
    }
)

COLORS = {
    "navy": "#17365D",
    "blue": "#DCEAF7",
    "blue2": "#BFDCEC",
    "green": "#DDF1DD",
    "orange": "#FCE8CE",
    "rose": "#F7DEDE",
    "purple": "#E8E0F2",
    "gray": "#F0F1F2",
    "gray2": "#D7DADD",
    "ink": "#23272B",
    "muted": "#5B6570",
}


def canvas(figsize, xlim, ylim):
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.axis("off")
    return fig, ax


def box(ax, x, y, w, h, text, fc, *, ec=None, fs=8.5, lw=1.15,
        radius=0.13, weight="normal", color=None, ls="-"):
    patch = FancyBboxPatch(
        (x, y), w, h,
        boxstyle=f"round,pad=0.035,rounding_size={radius}",
        facecolor=fc,
        edgecolor=ec or COLORS["ink"],
        linewidth=lw,
        linestyle=ls,
        zorder=2,
    )
    ax.add_patch(patch)
    ax.text(
        x + w / 2,
        y + h / 2,
        text,
        ha="center",
        va="center",
        fontsize=fs,
        fontweight=weight,
        color=color or COLORS["ink"],
        linespacing=1.12,
        zorder=3,
    )
    return {"x": x, "y": y, "w": w, "h": h}


def pt(node, side, frac=0.5):
    if side == "left":
        return node["x"], node["y"] + node["h"] * frac
    if side == "right":
        return node["x"] + node["w"], node["y"] + node["h"] * frac
    if side == "top":
        return node["x"] + node["w"] * frac, node["y"] + node["h"]
    if side == "bottom":
        return node["x"] + node["w"] * frac, node["y"]
    raise ValueError(side)


def arrow(ax, start, end, *, color=None, lw=1.2, ls="-", rad=0.0,
          label=None, label_pos=0.5, label_offset=(0, 0), mutation=11):
    arr = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=mutation,
        linewidth=lw,
        linestyle=ls,
        color=color or COLORS["ink"],
        connectionstyle=f"arc3,rad={rad}",
        shrinkA=1.5,
        shrinkB=1.5,
        zorder=1,
    )
    ax.add_patch(arr)
    if label:
        x = start[0] + (end[0] - start[0]) * label_pos + label_offset[0]
        y = start[1] + (end[1] - start[1]) * label_pos + label_offset[1]
        ax.text(x, y, label, ha="center", va="center", fontsize=7.2,
                color=COLORS["muted"], zorder=4,
                bbox=dict(facecolor="white", edgecolor="none", pad=0.5))


def title(ax, text, x, y):
    ax.text(x, y, text, ha="center", va="center", fontsize=11.5,
            fontweight="bold", color=COLORS["navy"])


def save(fig, name, *, dpi=None):
    path = OUT / name
    metadata = (
        {"Creator": "generate_structural_figures.py", "CreationDate": None}
        if path.suffix.lower() == ".pdf"
        else {"Software": "generate_structural_figures.py"}
    )
    fig.savefig(path, dpi=dpi, facecolor="white", metadata=metadata)
    plt.close(fig)


def make_fig1():
    fig, ax = canvas((13.6, 5.35), (0, 22), (0, 10))
    title(ax, "TrustOOD-ECG: dataset-aware sources, complete fusion, and task-specific interfaces", 11, 9.55)

    datasets = box(
        ax, 0.35, 2.15, 3.40, 6.15,
        "Dataset-specific sources\n\n"
        "PTB-XL\nwaveform | HRV | spectrum | SQI\n\n"
        "MHEALTH\nECG | motion\n\n"
        "WESAD\nECG | PPG | motion",
        COLORS["purple"], fs=7.8, ec="#5E4C84"
    )
    local = box(
        ax, 4.45, 4.55, 2.70, 2.0,
        "Source encoder + head\n" r"$h_s=f_s(x^{(s)})$" "\n"
        r"$e_s\geq0,\quad u_s=K/(K+\Vert e_s\Vert_1)$",
        COLORS["gray"], fs=7.6
    )
    gate = box(
        ax, 7.85, 4.55, 2.60, 2.0,
        "Contribution gate\n" r"$[u_s,q_s]\mapsto w_s$" "\n"
        r"$w_s=\sigma(g_s([u_s,q_s]))$",
        COLORS["orange"], fs=7.7, ec="#A96A16"
    )
    pool = box(
        ax, 11.15, 6.25, 3.00, 1.55,
        "Cumulative pool\n" r"$e_{\rm pool}=\sum_s w_s e_s$",
        COLORS["blue2"], fs=7.9, ec="#2B6F93"
    )
    fuse = box(
        ax, 11.15, 3.25, 3.00, 1.90,
        "Interaction residual\n" r"$c=[w_1h_1\Vert\cdots\Vert w_Mh_M]$" "\n"
        r"$e_{\rm Fuse}={\rm softplus}({\rm Fuse}(c))$",
        COLORS["blue"], fs=7.4, ec="#2B6F93"
    )
    fused = box(
        ax, 14.85, 4.55, 2.45, 2.0,
        r"$e^\star=e_{\rm pool}+e_{\rm Fuse}$" "\n"
        r"$\alpha^\star=e^\star+\mathbf{1}$" "\n"
        r"$p^\star,\ u^\star$",
        "#CBE8F3", fs=8.1, ec="#225D78", weight="bold"
    )
    density = box(
        ax, 14.05, 1.05, 3.25, 1.65,
        "Validation-standardised\nfeature density\n"
        r"$d^\star=\sum_s\rho_s z_{\rm val}(d_s)$" "\n"
        r"$R_{\rm OOD}=z_{\rm val}(u^\star)+d^\star$",
        COLORS["gray"], fs=7.3
    )

    diagnosis = box(ax, 19.10, 7.15, 2.55, 1.20,
                    "Known-class probabilities\n" r"$p^\star$",
                    COLORS["green"], fs=8.4, ec="#3A7D44")
    selective = box(ax, 19.10, 5.40, 2.55, 1.20,
                    "Selective ranking\n" r"$u^\star$",
                    COLORS["green"], fs=8.4, ec="#3A7D44")
    quality = box(ax, 19.10, 3.65, 2.55, 1.20,
                  "Low-quality detection\nmeasured $q$",
                  COLORS["orange"], fs=8.4, ec="#A96A16")
    ood = box(ax, 19.10, 1.45, 2.55, 1.35,
              "OOD ranking\n" r"$R_{\rm OOD}$",
              COLORS["rose"], fs=8.6, ec="#A84A4A")

    arrow(ax, pt(datasets, "right"), pt(local, "left"))
    arrow(ax, pt(local, "right"), pt(gate, "left"))
    arrow(ax, pt(gate, "right", 0.70), pt(pool, "left", 0.42), rad=-0.08)
    arrow(ax, pt(gate, "right", 0.30), pt(fuse, "left", 0.58), rad=0.08)
    arrow(ax, pt(pool, "right"), pt(fused, "left", 0.72), rad=-0.06)
    arrow(ax, pt(fuse, "right"), pt(fused, "left", 0.28), rad=0.06)
    arrow(ax, pt(fused, "right", 0.75), pt(diagnosis, "left"), rad=-0.12)
    arrow(ax, pt(fused, "right", 0.48), pt(selective, "left"), rad=0.02)
    arrow(ax, pt(gate, "bottom", 0.50), pt(quality, "left", 0.52),
          color=COLORS["muted"], ls="--", rad=0.30)
    arrow(ax, pt(local, "bottom", 0.35), pt(density, "left", 0.70),
          color=COLORS["muted"], ls="--", rad=0.14)
    arrow(ax, pt(gate, "bottom", 0.72), pt(density, "left", 0.32),
          color=COLORS["muted"], ls="--", rad=0.10)
    arrow(ax, pt(fused, "bottom", 0.62), pt(density, "top", 0.75),
          color=COLORS["muted"], ls="--", rad=0.02, label=r"$u^\star$",
          label_offset=(0.25, 0.0))
    arrow(ax, pt(density, "right"), pt(ood, "left"))

    ax.text(
        11, 0.32,
        "Diagnosis, selective prediction, acquisition quality, and OOD detection use different declared scores.",
        ha="center", va="center", fontsize=8.1, color=COLORS["muted"], style="italic"
    )
    save(fig, "fig1.png", dpi=320)


def make_framework():
    fig, ax = canvas((14.0, 5.35), (0, 24), (0, 10))
    title(ax, "Complete inference architecture", 12, 9.55)

    src = box(ax, 0.35, 6.30, 2.35, 1.55,
              "Each source\n" r"$x^{(s)},q_s$",
              COLORS["purple"], fs=7.9, ec="#5E4C84")
    enc = box(ax, 3.25, 6.30, 2.35, 1.55,
              "Encoder\n" r"$h_s=f_s(x^{(s)})\in\mathbb{R}^{128}$",
              COLORS["gray"], fs=7.8)
    head = box(ax, 6.20, 6.30, 2.95, 1.55,
               "Evidential head\n" r"$e_s={\rm softplus}(A_sh_s+a_s)$" "\n"
               r"$u_s=K/(K+\Vert e_s\Vert_1)$",
               "#FFF1C9", fs=7.4, ec="#A96A16")
    gate = box(ax, 9.80, 6.30, 2.65, 1.55,
               "Gate\n" r"$w_s=\sigma(g_s([u_s,q_s]))$",
               COLORS["orange"], fs=7.8, ec="#A96A16")

    pool = box(ax, 13.05, 7.05, 3.00, 1.35,
               "Pool branch\n" r"$e_{\rm pool}=\sum_s w_s e_s$",
               COLORS["blue2"], fs=7.9, ec="#2B6F93")
    fuse = box(ax, 13.05, 4.65, 3.00, 1.65,
               "Fuse branch\n" r"$c=[w_1h_1\Vert\cdots\Vert w_Mh_M]$" "\n"
               r"$e_{\rm Fuse}={\rm softplus}({\rm Fuse}(c))$",
               COLORS["blue"], fs=7.3, ec="#2B6F93")
    merged = box(ax, 16.80, 6.10, 2.85, 1.85,
                 r"$e^\star=e_{\rm pool}+e_{\rm Fuse}$" "\n"
                 r"$\alpha^\star=e^\star+\mathbf{1}$" "\n"
                 r"$p_k^\star=\alpha_k^\star/\sum_j\alpha_j^\star$" "\n"
                 r"$u^\star=K/\sum_j\alpha_j^\star$",
                 "#CBE8F3", fs=7.3, ec="#225D78")

    diag = box(ax, 20.40, 7.65, 3.20, 1.15,
               "Diagnosis\n$\\arg\\max_k p_k^\\star$; no rejection",
               COLORS["green"], fs=7.8, ec="#3A7D44")
    sel = box(ax, 20.40, 6.05, 3.20, 1.15,
              "Selective ranking\n$u^\\star$", COLORS["green"], fs=7.9, ec="#3A7D44")
    qual = box(ax, 20.40, 4.45, 3.20, 1.15,
               "Low-quality flag\n$q<q_{\\min}$", COLORS["orange"], fs=7.9, ec="#A96A16")

    distance = box(
        ax, 3.25, 1.70, 4.75, 2.25,
        "Source-standardised\nclass-conditional density\n"
        r"$\Delta_{s,k}=\bar h_s-\mu_{s,k}$" "\n"
        r"$d_s=\min_k\Delta_{s,k}^{\top}(\Sigma_s^{\rm LW}+10^{-3}I)^{\dagger}\Delta_{s,k}$",
        COLORS["gray"], fs=7.3
    )
    aggregate = box(
        ax, 8.65, 1.70, 4.40, 2.25,
        "Source-weighted density aggregation\n"
        r"$\rho_s=w_s/(\sum_jw_j+10^{-8})$" "\n"
        r"$d^\star=\sum_s\rho_s z_{\rm val}(d_s)$",
        COLORS["gray"], fs=7.5
    )
    ood = box(
        ax, 13.70, 1.70, 4.15, 2.25,
        "Composite OOD ranking\n"
        r"$R_{\rm OOD}=z_{\rm val}(u^\star)+d^\star$" "\n"
        "larger is more OOD-like",
        COLORS["rose"], fs=7.6, ec="#A84A4A"
    )
    state = box(
        ax, 18.55, 1.70, 5.05, 2.25,
        "Fitting provenance\ntraining ID: feature and density states\nvalidation ID: score normalisers\nand declared thresholds",
        "#F7F7F7", fs=7.4, ec="#777777", ls="--"
    )

    for a, b in ((src, enc), (enc, head), (head, gate)):
        arrow(ax, pt(a, "right"), pt(b, "left"))
    arrow(ax, pt(gate, "right", 0.68), pt(pool, "left"), rad=-0.05)
    arrow(ax, pt(gate, "right", 0.32), pt(fuse, "left"), rad=0.05)
    arrow(ax, pt(pool, "right"), pt(merged, "left", 0.72), rad=-0.06)
    arrow(ax, pt(fuse, "right"), pt(merged, "left", 0.28), rad=0.06)
    arrow(ax, pt(merged, "right", 0.72), pt(diag, "left"), rad=-0.10)
    arrow(ax, pt(merged, "right", 0.47), pt(sel, "left"), rad=0.0)
    arrow(ax, pt(src, "bottom", 0.35), pt(qual, "left", 0.50),
          color=COLORS["muted"], ls="--", rad=0.32)
    arrow(ax, pt(enc, "bottom", 0.45), pt(distance, "top", 0.35),
          color=COLORS["muted"], ls="--")
    arrow(ax, pt(gate, "bottom", 0.58), pt(aggregate, "top", 0.42),
          color=COLORS["muted"], ls="--")
    arrow(ax, pt(distance, "right"), pt(aggregate, "left"))
    arrow(ax, pt(aggregate, "right"), pt(ood, "left"))
    arrow(ax, pt(merged, "bottom", 0.55), pt(ood, "top", 0.60),
          color=COLORS["muted"], ls="--", rad=0.05)
    arrow(ax, pt(ood, "right"), pt(state, "left"),
          color=COLORS["muted"], ls="--", mutation=9)
    save(fig, "fig_framework.pdf")


def make_pipeline():
    fig, ax = canvas((14.0, 5.00), (0, 24), (0, 9.4))
    title(ax, "Dataset-specific preprocessing and source assembly", 12, 9.05)

    lane_y = [6.45, 3.75, 1.05]
    lane_names = ["PTB-XL", "MHEALTH", "WESAD"]
    lane_colors = [COLORS["purple"], COLORS["blue"], COLORS["green"]]
    inputs = [
        "WFDB v1.0.3\n21,799 records\n100 Hz, 12 x 1000",
        "ECG 50 Hz\nmotion 32 Hz\nsubject-wise LOSO",
        "ECG 700 Hz\nPPG 64 Hz | motion 32 Hz\nsubject-wise LOSO",
    ]
    prep = [
        "Release-level deduplication\nNo additional waveform filter\nNo per-record z-normalisation",
        "ECG 50 -> 140 Hz; 0.5-40 Hz\nmotion high-pass 0.3 Hz\n8-s windows, 2-s hop",
        "ECG 700 -> 140 Hz; 0.5-40 Hz\nPPG 0.5-8 Hz; motion high-pass 0.3 Hz\n8-s windows, 2-s hop",
    ]
    assembled = [
        "Waveform\n8 HRV | 36 spectrum | 6 SQI\nshared measured ECG quality",
        "ECG + motion\nsource-specific quality",
        "ECG + PPG + motion\nsource-specific quality",
    ]

    final_nodes = []
    for y, name, col, inp, pr, assm in zip(lane_y, lane_names, lane_colors, inputs, prep, assembled):
        lab = box(ax, 0.25, y + 0.20, 1.85, 1.15, name, col, fs=8.8,
                  ec="#4A5560", weight="bold")
        raw = box(ax, 2.65, y, 3.40, 1.55, inp, COLORS["gray"], fs=7.6)
        process = box(ax, 6.65, y, 4.90, 1.55, pr, COLORS["orange"], fs=7.5, ec="#A96A16")
        source = box(ax, 12.15, y, 4.45, 1.55, assm, COLORS["green"], fs=7.5, ec="#3A7D44")
        final = box(ax, 17.20, y, 2.70, 1.55, "Model-ready\nsource tensors", COLORS["blue2"], fs=8.0, ec="#2B6F93")
        model = box(ax, 20.55, y, 3.05, 1.55,
                    "TrustOOD-ECG\nDataset-matched\n$M$ and $K$",
                    "#CBE8F3", fs=7.6, ec="#225D78", weight="bold")
        final_nodes.append(final)
        arrow(ax, pt(lab, "right"), pt(raw, "left"))
        arrow(ax, pt(raw, "right"), pt(process, "left"))
        arrow(ax, pt(process, "right"), pt(source, "left"))
        arrow(ax, pt(source, "right"), pt(final, "left"))
        arrow(ax, pt(final, "right"), pt(model, "left"))

    ax.text(
        12, 0.25,
        "The three lanes intentionally differ; no generic filter or normalisation step is asserted for every dataset.",
        ha="center", va="center", fontsize=8.1, color=COLORS["muted"], style="italic"
    )
    save(fig, "fig_pipeline.pdf")


def make_cacf():
    fig, ax = canvas((13.2, 4.75), (0, 22), (0, 9))
    title(ax, "Reliability-gated pseudo-count pooling with a learned interaction residual", 11, 8.60)

    source = box(ax, 0.40, 4.95, 2.90, 1.65,
                 "Each source, $s=1,\ldots,M$\n" r"$h_s,\ e_s,\ u_s,\ q_s$",
                 COLORS["purple"], fs=8.0, ec="#5E4C84")
    gate = box(ax, 4.00, 4.95, 3.05, 1.65,
               "Learned contribution\n" r"$w_s=\sigma(g_s([u_s,q_s]))$",
               COLORS["orange"], fs=8.0, ec="#A96A16")
    pool = box(ax, 8.05, 6.15, 3.35, 1.35,
               "Pseudo-count branch\n" r"$e_{\rm pool}=\sum_{s=1}^{M}w_s e_s$",
               COLORS["blue2"], fs=8.0, ec="#2B6F93")
    fuse = box(ax, 8.05, 3.65, 3.35, 1.75,
               "Interaction branch\n" r"$c=[w_1h_1\Vert\cdots\Vert w_Mh_M]$" "\n"
               r"$e_{\rm Fuse}={\rm softplus}({\rm Fuse}(c))$",
               COLORS["blue"], fs=7.6, ec="#2B6F93")

    circ = Circle((12.55, 5.55), 0.36, facecolor="#CBE8F3", edgecolor="#225D78", lw=1.2, zorder=2)
    ax.add_patch(circ)
    ax.text(12.55, 5.55, "+", ha="center", va="center", fontsize=15, color=COLORS["navy"], zorder=3)
    full = box(ax, 13.45, 4.75, 3.15, 1.65,
               r"$e^\star=e_{\rm pool}+e_{\rm Fuse}$" "\n"
               r"$\alpha^\star=e^\star+\mathbf{1}$",
               "#CBE8F3", fs=8.2, ec="#225D78")
    result = box(ax, 17.40, 4.55, 4.15, 2.05,
                 r"$p_k^\star=\alpha_k^\star/\sum_j\alpha_j^\star$" "\n"
                 r"$u^\star=K/\sum_j\alpha_j^\star$" "\n"
                 "used by declared task interfaces",
                 COLORS["green"], fs=7.9, ec="#3A7D44")

    regulariser = box(
        ax, 3.10, 0.75, 15.80, 1.75,
        "Training only: representation-redundancy surrogate\n"
        r"$z_{i,s}=\frac{{\rm ReLU}(P_sh_{i,s}+\beta_s)}{\Vert {\rm ReLU}(P_sh_{i,s}+\beta_s)\Vert_2+10^{-8}}$"
        "      "
        r"$\mathcal{L}_{\rm comp}=\frac{2}{BM(M-1)}\sum_i\sum_{s<t}|z_{i,s}^{\top}z_{i,t}|$",
        "#F7F7F7", fs=7.4, ec="#777777", ls="--"
    )

    arrow(ax, pt(source, "right"), pt(gate, "left"))
    arrow(ax, pt(gate, "right", 0.68), pt(pool, "left"), rad=-0.08)
    arrow(ax, pt(gate, "right", 0.32), pt(fuse, "left"), rad=0.08)
    arrow(ax, pt(pool, "right"), (12.20, 5.75), rad=-0.05)
    arrow(ax, pt(fuse, "right"), (12.20, 5.35), rad=0.05)
    arrow(ax, (12.91, 5.55), pt(full, "left"))
    arrow(ax, pt(full, "right"), pt(result, "left"))
    arrow(ax, pt(source, "bottom", 0.35), pt(regulariser, "top", 0.08),
          color=COLORS["muted"], ls="--", mutation=9)

    ax.text(
        11, 0.25,
        "The additive operation accumulates Dirichlet pseudo-counts; it is not Dempster-Shafer combination. "
        "$w_s$ is not a calibrated source-correctness probability.",
        ha="center", va="center", fontsize=8.0, color=COLORS["muted"], style="italic"
    )
    save(fig, "fig_cacf.pdf")


def make_decision_flow():
    fig, ax = canvas((13.4, 6.10), (0, 22), (0, 10))
    title(ax, "Distinct evaluation interfaces and the optional retrospective hierarchy", 11, 9.60)

    scores = box(ax, 9.10, 8.00, 3.80, 1.15,
                 "Available outputs\n" r"$p^\star,\ u^\star,\ q,\ R_{\rm OOD}$",
                 "#CBE8F3", fs=8.5, ec="#225D78", weight="bold")
    branches = [
        box(ax, 0.45, 6.15, 4.25, 1.20, "Closed diagnosis\n$\\arg\\max_k p_k^\\star$; no rejection", COLORS["green"], fs=7.9, ec="#3A7D44"),
        box(ax, 5.25, 6.15, 3.65, 1.20, "Selective prediction\nrank by $u^\\star$", COLORS["green"], fs=8.0, ec="#3A7D44"),
        box(ax, 9.45, 6.15, 3.65, 1.20, "Quality detection\n$q<q_{\\min}$", COLORS["orange"], fs=8.0, ec="#A96A16"),
        box(ax, 13.65, 6.15, 7.90, 1.20, "OOD detection\nrank by $R_{\\rm OOD}$; use fixed $\\tau_{\\rm OOD}$ only for a declared operating point", COLORS["rose"], fs=7.6, ec="#A84A4A"),
    ]
    for node in branches:
        arrow(ax, pt(scores, "bottom"), pt(node, "top"), color=COLORS["muted"], lw=1.0, rad=0.0)

    ax.text(11, 5.45, "When a single retrospective action is required:", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color=COLORS["navy"])

    start = box(ax, 0.45, 3.55, 2.40, 1.15, "record and\ndeclared thresholds", COLORS["gray"], fs=7.8)
    qcheck = box(ax, 3.45, 3.55, 2.50, 1.15, "$q<q_{\\min}$?", COLORS["orange"], fs=8.6, ec="#A96A16")
    qout = box(ax, 3.50, 1.15, 2.40, 1.15, "low-quality\nflag", COLORS["orange"], fs=8.1, ec="#A96A16")
    rcheck = box(ax, 7.10, 3.55, 2.90, 1.15, "$R_{\\rm OOD}>\\tau_{\\rm OOD}$?", COLORS["rose"], fs=8.3, ec="#A84A4A")
    rout = box(ax, 7.35, 1.15, 2.40, 1.15, "OOD / unknown\nflag", COLORS["rose"], fs=8.1, ec="#A84A4A")
    ucheck = box(ax, 11.25, 3.55, 3.05, 1.15, "$u^\\star>\\tau_{\\rm sel}(c)$?", COLORS["green"], fs=8.3, ec="#3A7D44")
    uout = box(ax, 11.55, 1.15, 2.45, 1.15, "selective\nabstention", COLORS["green"], fs=8.1, ec="#3A7D44")
    accept = box(ax, 16.40, 3.55, 4.60, 1.15, "known-class prediction\n$\\arg\\max_k p_k^\\star$", "#CBE8F3", fs=8.1, ec="#225D78")

    arrow(ax, pt(start, "right"), pt(qcheck, "left"))
    arrow(ax, pt(qcheck, "bottom"), pt(qout, "top"), label="yes", label_offset=(0.25, 0))
    arrow(ax, pt(qcheck, "right"), pt(rcheck, "left"), label="no", label_offset=(0, 0.25))
    arrow(ax, pt(rcheck, "bottom"), pt(rout, "top"), label="yes", label_offset=(0.25, 0))
    arrow(ax, pt(rcheck, "right"), pt(ucheck, "left"), label="no", label_offset=(0, 0.25))
    arrow(ax, pt(ucheck, "bottom"), pt(uout, "top"), label="yes", label_offset=(0.25, 0))
    arrow(ax, pt(ucheck, "right"), pt(accept, "left"), label="no", label_offset=(0, 0.25))

    ax.text(
        11, 0.35,
        "These are algorithmic outcomes for retrospective evaluation, not prospective operating or deployment rules.",
        ha="center", va="center", fontsize=8.3, color=COLORS["muted"], style="italic"
    )
    save(fig, "fig_decision_flow.pdf")


if __name__ == "__main__":
    args = parse_args()
    OUT = args.output_dir.expanduser().resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    make_fig1()
    make_framework()
    make_pipeline()
    make_cacf()
    make_decision_flow()
    print(f"Wrote structural figures to {OUT}")
