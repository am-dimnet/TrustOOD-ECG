#!/usr/bin/env python3
"""Generate the eleven quantitative figures used by the revised manuscript.

The five structural figures are maintained separately because they are diagrams,
not data plots. This script reads only independently audited aggregate outputs;
it never reads waveforms, identifiers, checkpoints, or raw predictions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd


BLUE = "#4477AA"
CYAN = "#66CCEE"
GREEN = "#228833"
YELLOW = "#CCBB44"
RED = "#CC6677"
PURPLE = "#AA3377"
GREY = "#777777"
BLACK = "#222222"
LIGHT = "#E9EEF4"

METHOD_COLORS = {
    "TrustOOD-ECG": RED,
    "Softmax": BLUE,
    "Matched concat.": CYAN,
    "Deep ensemble": GREEN,
    "Pool only": YELLOW,
    "Gated Fuse only": PURPLE,
    "TMC": GREY,
    "TMDF/ETMC": BLACK,
}

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["DejaVu Serif"],
        "mathtext.fontset": "dejavuserif",
        "font.size": 8.2,
        "axes.titlesize": 9.0,
        "axes.labelsize": 8.4,
        "legend.fontsize": 7.0,
        "xtick.labelsize": 7.4,
        "ytick.labelsize": 7.4,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.20,
        "grid.linewidth": 0.55,
        "axes.axisbelow": True,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.035,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)


def parse_args() -> argparse.Namespace:
    here = Path(__file__).resolve()
    package = here.parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reference-root",
        type=Path,
        default=package / "reference_outputs",
        help="Root containing aggregates/ and manuscript_tables/.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def read_csv(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def one(df: pd.DataFrame, **filters) -> pd.Series:
    out = df
    for key, value in filters.items():
        if value is None:
            out = out[out[key].isna()]
        else:
            out = out[out[key] == value]
    if len(out) != 1:
        raise RuntimeError(f"Expected one row for {filters}, found {len(out)}")
    return out.iloc[0]


def require_n(rows: list[pd.Series], expected: int, context: str,
              column: str = "n") -> None:
    observed = [int(row[column]) for row in rows]
    if any(value != expected for value in observed):
        raise RuntimeError(f"{context}: expected {column}={expected}, found {observed}")


def require_seed_rows(df: pd.DataFrame, expected: set[int], context: str) -> None:
    observed = {int(seed) for seed in df["seed"].unique()}
    if observed != expected:
        raise RuntimeError(f"{context}: expected seeds {sorted(expected)}, found {sorted(observed)}")


def finish(fig: plt.Figure, output: Path) -> None:
    fig.savefig(
        output,
        metadata={"Creator": "generate_manuscript_figures.py", "CreationDate": None},
    )
    plt.close(fig)


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.13, 1.06, label, transform=ax.transAxes, fontweight="bold", va="top")


def horizontal_metric(
    ax: plt.Axes,
    labels: list[str],
    means: list[float],
    sds: list[float],
    title: str,
    xlim: tuple[float, float],
    higher_better: bool,
    show_labels: bool,
) -> None:
    y = np.arange(len(labels))
    for yi, label, mean, sd in zip(y, labels, means, sds):
        color = METHOD_COLORS[label]
        ax.errorbar(mean, yi, xerr=sd, fmt="o", ms=4.2, lw=1.0, capsize=2.0,
                    color=color, ecolor=color)
    ax.set_yticks(y)
    ax.set_yticklabels(labels if show_labels else [""] * len(labels))
    ax.invert_yaxis()
    ax.set_xlim(*xlim)
    arrow = r"$\uparrow$" if higher_better else r"$\downarrow$"
    ax.set_title(f"{title} {arrow}")
    ax.xaxis.set_major_locator(MaxNLocator(4))


def fig_main_compare(seed: pd.DataFrame, out: Path) -> None:
    specs = [
        ("TrustOOD-ECG", "trust_full"),
        ("Softmax", "softmax_modular"),
        ("Matched concat.", "concat_matched"),
        ("Deep ensemble", "deep_ensemble"),
        ("Pool only", "pool_only"),
        ("Gated Fuse only", "fuse_only"),
        ("TMC", "tmc"),
        ("TMDF/ETMC", "tmdf"),
    ]
    metrics = [
        ("diagnosis.macro_auroc", "Macro-AUROC", (0.84, 0.92), True),
        ("diagnosis.rare_macro_auroc", "Rare AUROC", (0.78, 0.92), True),
        ("diagnosis.calibration.raw.ece_fixed", "Raw ECE", (0.0, 0.40), False),
        ("diagnosis.selective_primary.aurc", "AURC", (0.27, 0.55), False),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.35), sharey=False)
    labels = [s[0] for s in specs]
    for idx, (ax, (metric, title, xlim, higher)) in enumerate(zip(axes.flat, metrics)):
        rows = [one(seed, method=m, protocol="closed", metric=metric) for _, m in specs]
        require_n(rows, 5, f"main comparison: {metric}")
        horizontal_metric(ax, labels, [r["mean"] for r in rows], [r["sd"] for r in rows],
                          title, xlim, higher, idx % 2 == 0)
        panel_label(ax, f"({chr(97 + idx)})")
    fig.suptitle("Closed PTB-XL comparison (five seeds; error bars are sample SD)", y=1.01)
    fig.subplots_adjust(left=0.19, right=0.99, top=0.90, bottom=0.10, wspace=0.14, hspace=0.32)
    finish(fig, out / "fig_main_compare.pdf")


def fig_rare_scatter(classwise: pd.DataFrame, dist: pd.DataFrame, out: Path) -> None:
    base = classwise[(classwise.method == "trust_full") &
                     (classwise.protocol == "closed") &
                     (classwise.dataset == "ptbxl") &
                     (classwise.split == "test")]
    auc = base[base.metric == "auroc"][["class_id", "mean", "sd"]].rename(
        columns={"mean": "auroc", "sd": "auroc_sd"})
    ap = base[base.metric == "auprc"][["class_id", "mean", "sd"]].rename(
        columns={"mean": "auprc", "sd": "auprc_sd"})
    d = dist.merge(auc, on="class_id").merge(ap, on="class_id")
    require_n([row for _, row in base.iterrows()], 5, "classwise metrics")
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 5.0), sharex=True)
    for ax, metric, sd_col, title in [
        (axes[0], "auroc", "auroc_sd", "Per-class AUROC"),
        (axes[1], "auprc", "auprc_sd", "Per-class AUPRC"),
    ]:
        for rare, color, marker, label in [
            (False, BLUE, "o", "Frequent (train support >= 50)"),
            (True, RED, "^", "Rare (train support < 50)"),
        ]:
            q = d[d.is_rare == rare]
            ax.errorbar(q.train_records, q[metric], yerr=q[sd_col], fmt=marker, ms=3.2,
                        capsize=1.3, lw=0.55, alpha=0.82, color=color, label=label)
        ax.set_ylabel(title)
        ax.set_ylim(-0.10, 1.10)
        ax.axvline(50, color=BLACK, lw=0.8, ls="--")
    axes[0].axhline(0.5, color=GREY, lw=0.7, ls=":")
    axes[0].legend(loc="lower right", frameon=True)
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Folds 1-8 training records (log scale)")
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    fig.suptitle("TrustOOD-ECG classwise discrimination (five-seed means ± SD)", y=1.005)
    fig.subplots_adjust(left=0.18, right=0.98, top=0.93, bottom=0.10, hspace=0.24)
    finish(fig, out / "fig_rare_scatter.pdf")


def fig_ablation(seed: pd.DataFrame, ext: pd.DataFrame, out: Path) -> None:
    methods = [
        ("Pool", "pool_only"), ("Gated Fuse only", "fuse_only"),
        ("Pool+Fuse", "trust_full"),
        ("Concat.", "concat_matched"), ("TMC", "tmc"), ("TMDF/ETMC", "tmdf"),
    ]
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 4.85))
    x = np.arange(len(methods))
    for metric, label, color, offset in [
        ("diagnosis.macro_auroc", "Macro-AUROC", BLUE, -0.09),
        ("diagnosis.selective_primary.aurc", "AURC (lower is better)", RED, 0.09),
    ]:
        rows = [one(seed, method=m, protocol="closed", metric=metric) for _, m in methods]
        require_n(rows, 5, f"fusion controls: {metric}")
        axes[0].errorbar(x + offset, [r["mean"] for r in rows],
                         yerr=[r["sd"] for r in rows], fmt="o-", ms=3.8,
                         lw=1.0, capsize=2, label=label, color=color)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([a for a, _ in methods], rotation=24, ha="right")
    axes[0].set_ylim(0.28, 0.92)
    axes[0].legend(loc="center right")
    axes[0].set_title("Fusion and prior-work controls (five seeds)")

    etas = [0, 0.01, 0.03, 0.1, 0.3, 1.0]
    tags = [f"pareto_eta_{e:g}_aux_0.3" for e in etas]
    for metric, label, color in [
        ("diagnosis.macro_auroc", "Closed macro-AUROC", BLUE),
        ("ood.composite.primary.auroc", "Chapman-Ningbo OOD AUROC", RED),
    ]:
        rows = [one(ext, protocol="closed", tag=t, metric=metric) for t in tags]
        require_n(rows, 5, f"redundancy sensitivity: {metric}")
        axes[1].errorbar(np.arange(len(etas)), [r["mean"] for r in rows],
                         yerr=[r["sd"] for r in rows], marker="o", lw=1.1,
                         capsize=2, label=label, color=color)
    axes[1].axvline(3, color=GREY, ls="--", lw=0.8, label=r"Default $\eta=0.1$")
    axes[1].set_xticks(np.arange(len(etas)))
    axes[1].set_xticklabels([f"{e:g}" for e in etas])
    axes[1].set_xlabel(
        "Redundancy coefficient $\\eta$\n(auxiliary loss weight = 0.3)"
    )
    axes[1].set_ylim(0.55, 0.91)
    axes[1].legend(loc="center right")
    axes[1].set_title("Redundancy sensitivity (five seeds)")
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    fig.subplots_adjust(left=0.18, right=0.98, top=0.96, bottom=0.11, hspace=0.42)
    finish(fig, out / "fig_ablation.pdf")


OOD_METHODS = [
    ("Trust composite", "trust_full", "composite"),
    ("TMDF/ETMC", "tmdf", "composite"),
    ("ViM", "softmax_modular", "ViM"),
    ("Mahalanobis-LW", "softmax_modular", "Mahalanobis:ledoit_wolf"),
    ("deep-kNN", "softmax_modular", "deep-kNN"),
    ("Energy", "softmax_modular", "Energy"),
    ("ODIN", "softmax_modular", "ODIN"),
    ("DICE", "softmax_modular", "DICE"),
    ("GEN", "softmax_modular", "GEN"),
]


def ood_rows(df: pd.DataFrame, protocol: str, scenario: str, category: str,
             metric: str) -> list[pd.Series]:
    return [one(df, method=m, protocol=protocol, detector=det, scenario=scenario,
                ood_category=category, metric=metric) for _, m, det in OOD_METHODS]


def fig_ood_openset(ood: pd.DataFrame, out: Path) -> None:
    scenarios = [
        ("strict:tau80", "all", "aggregate", r"Strict $\tau=80$ held-out codes"),
        ("closed", "chapman", "cross", "PTB-XL to Chapman-Ningbo"),
    ]
    labels = [a for a, _, _ in OOD_METHODS]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.75), sharey=False)
    for col, (protocol, scenario, cat, title) in enumerate(scenarios):
        for row_idx, (metric, mtitle, xlim, higher) in enumerate([
            ("auroc", "AUROC", (0.49, 0.73), True),
            ("fpr95", "Retrospective FPR95", (0.72, 0.98), False),
        ]):
            ax = axes[row_idx, col]
            rows = ood_rows(ood, protocol, scenario, cat, metric)
            require_n(rows, 5, f"OOD comparison: {protocol}/{scenario}/{metric}")
            y = np.arange(len(labels))
            for yi, label, r in zip(y, labels, rows):
                color = RED if label == "Trust composite" else BLUE
                ax.errorbar(r["mean"], yi, xerr=r["sd"], fmt="o", ms=3.8,
                            capsize=1.8, color=color, ecolor=color)
            ax.set_yticks(y)
            ax.set_yticklabels(labels if col == 0 else [""] * len(labels))
            ax.invert_yaxis()
            ax.set_xlim(*xlim)
            arrow = r"$\uparrow$" if higher else r"$\downarrow$"
            ax.set_title(f"{title}\n{mtitle} {arrow}")
            panel_label(ax, f"({chr(97 + row_idx * 2 + col)})")
    fig.suptitle("OOD comparisons (five seeds; error bars are sample SD)", y=1.005)
    fig.subplots_adjust(left=0.20, right=0.99, top=0.88, bottom=0.08, wspace=0.15, hspace=0.34)
    finish(fig, out / "fig_ood_openset.pdf")


def fig_ood_effects(paired: pd.DataFrame, out: Path) -> None:
    comparisons = [
        ("TMDF/ETMC", "tmdf", "composite"),
        ("ViM", "softmax_modular", "ViM"),
        ("Mahalanobis-LW", "softmax_modular", "Mahalanobis:ledoit_wolf"),
        ("deep-kNN", "softmax_modular", "deep-kNN"),
        ("Energy", "softmax_modular", "Energy"),
        ("ODIN", "softmax_modular", "ODIN"),
        ("DICE", "softmax_modular", "DICE"),
        ("GEN", "softmax_modular", "GEN"),
    ]
    scenarios = [
        ("strict:tau80", "all", r"Strict $\tau=80$"),
        ("closed", "chapman", "Chapman-Ningbo shift"),
    ]
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 5.0), sharex=False)
    for ax, (protocol, scenario, title) in zip(axes, scenarios):
        rows = []
        for label, method_b, detector_b in comparisons:
            r = one(paired, protocol=protocol, scenario=scenario,
                    method_a="trust_full", detector_a="composite",
                    method_b=method_b, detector_b=detector_b, metric="auroc")
            rows.append((label, r))
        require_n([row for _, row in rows], 5, f"paired OOD effects: {protocol}/{scenario}")
        if any(int(row["holm_family_size"]) != 59 for _, row in rows):
            raise RuntimeError("Paired OOD effects must use the prespecified 59-comparison Holm family")
        y = np.arange(len(rows))
        for yi, (label, r) in zip(y, rows):
            significant = float(r["pvalue_holm"]) < 0.05
            color = RED if significant else BLUE
            ax.errorbar(r["mean"], yi,
                        xerr=[[r["mean"] - r["ci_low"]], [r["ci_high"] - r["mean"]]],
                        fmt="o", ms=4.0, mfc=color if significant else "white",
                        mec=color, ecolor=color, capsize=2, lw=1.0)
        ax.axvline(0, color=BLACK, lw=0.8, ls="--")
        ax.set_yticks(y)
        ax.set_yticklabels([x[0] for x in rows])
        ax.invert_yaxis()
        ax.set_title(title)
        ax.set_xlabel("Paired AUROC difference: Trust composite - comparator")
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    fig.suptitle("Five-seed paired effects (95% Student-t CI; filled if Holm p < 0.05)", y=1.005)
    fig.subplots_adjust(left=0.34, right=0.98, top=0.92, bottom=0.10, hspace=0.38)
    finish(fig, out / "fig_ood_hist.pdf")


def fig_calibration(cal: pd.DataFrame, out: Path) -> None:
    methods = [("TrustOOD-ECG", "trust_full"), ("Softmax", "softmax_modular"),
               ("Deep ensemble", "deep_ensemble")]
    metrics = [("ece_fixed", "ECE", (0, 0.27)), ("nll", "NLL", (1.85, 2.65)),
               ("brier", "Brier score", (0.64, 0.79))]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.75))
    x = np.arange(len(methods))
    w = 0.34
    for idx, (ax, (metric, title, ylim)) in enumerate(zip(axes, metrics)):
        for j, (variant, label, color) in enumerate([
            ("raw", "Raw", BLUE), ("TS", "Temperature-scaled", RED)
        ]):
            rows = [one(cal, method=m, protocol="closed", dataset="ptbxl", split="test",
                        calibration_variant=variant, metric=metric) for _, m in methods]
            require_n(rows, 5, f"calibration: {variant}/{metric}")
            ax.bar(x + (j - 0.5) * w, [r["mean"] for r in rows], width=w,
                   yerr=[r["sd"] for r in rows], capsize=2, color=color,
                   alpha=0.88, label=label)
        ax.set_xticks(x)
        ax.set_xticklabels([a for a, _ in methods], rotation=22, ha="right")
        ax.set_ylim(*ylim)
        ax.set_title(f"{title} " + r"$\downarrow$")
        panel_label(ax, f"({chr(97 + idx)})")
    axes[0].legend(loc="upper left")
    fig.suptitle("Closed PTB-XL calibration (five seeds; post-hoc scaling)", y=1.01)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.86, bottom=0.25, wspace=0.28)
    finish(fig, out / "fig_calibration.pdf")


def fig_risk_coverage(sel: pd.DataFrame, out: Path) -> None:
    methods = [("TrustOOD-ECG", "trust_full", RED),
               ("Softmax", "softmax_modular", BLUE),
               ("Deep ensemble", "deep_ensemble", GREEN)]
    coverages = [0.50, 0.70, 0.80, 0.90, 0.95, 1.00]
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 4.65), sharex=True)
    for label, method, color in methods:
        q = sel[(sel.protocol == "closed") & (sel.method == method)]
        for ax, metric in [(axes[0], "risk"), (axes[1], "rare_rejection_rate")]:
            rows = [one(q, target_coverage=c, metric=metric) for c in coverages]
            require_n(rows, 5, f"selective summaries: {method}/{metric}")
            y = np.asarray([r["mean"] for r in rows])
            sd = np.asarray([r["sd"] for r in rows])
            axes_y = np.asarray(coverages)
            ax.plot(axes_y, y, marker="o", ms=3.2, lw=1.2, color=color, label=label)
            ax.fill_between(axes_y, np.clip(y - sd, 0, 1), np.clip(y + sd, 0, 1),
                            color=color, alpha=0.13, linewidth=0)
    axes[0].set_ylabel("Selective risk")
    axes[0].set_title("Risk-coverage summaries")
    nominal_rejection = 1.0 - np.asarray(coverages)
    axes[1].plot(coverages, nominal_rejection, color=BLACK, ls="--", lw=1.0,
                 label="Nominal overall rejection (1 - coverage)")
    axes[1].set_ylabel("Rare-class rejection rate")
    axes[1].set_title("Disproportionate rare-case rejection")
    axes[1].set_xlabel("Coverage")
    axes[0].legend(loc="upper left")
    axes[1].legend(loc="upper right", fontsize=6.3)
    axes[0].set_ylim(0.25, 0.56)
    axes[1].set_ylim(-0.03, 0.82)
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    fig.suptitle("Retrospective PTB-XL selection (five-seed mean ± SD)", y=1.005)
    fig.subplots_adjust(left=0.18, right=0.98, top=0.92, bottom=0.11, hspace=0.30)
    finish(fig, out / "fig_risk_coverage.pdf")


SNR_ORDER = ["clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB"]
SNR_LABELS = ["clean", "24", "18", "12", "6", "0", "-6"]


def fig_noise(noise: pd.DataFrame, cal_noise: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.75))
    x = np.arange(len(SNR_ORDER))
    for label, variant, color in [("TrustOOD-ECG", "trust_full", RED),
                                  ("Softmax", "softmax_modular", BLUE)]:
        q = noise[(noise.category == "model") & (noise.variant == variant) &
                  (noise.metric == "diagnosis.accuracy")]
        rows = [one(q, context=s) for s in SNR_ORDER]
        require_n(rows, 3, f"noise diagnosis: {variant}")
        axes[0].errorbar(x, [r["mean"] for r in rows], yerr=[r["sd"] for r in rows],
                         marker="o", ms=3.1, lw=1.1, capsize=1.8, color=color, label=label)
    axes[0].set_ylabel("Accuracy")
    axes[0].set_title("Diagnosis under paired noise")
    axes[0].legend(loc="lower left")

    q = cal_noise[(cal_noise.split == "test") & (cal_noise.stratum == "all")]
    require_seed_rows(q, {7, 13, 42}, "noise calibration")
    for variant, label, color in [("raw", "Raw ECE", BLUE),
                                  ("temperature_scaled", "Frozen-TS ECE", RED)]:
        values, errors = [], []
        for s in SNR_ORDER:
            z = q[(q.snr_label == s) & (q.calibration_variant == variant)]
            values.append(z.ece_equal_width.mean())
            errors.append(z.ece_equal_width.std(ddof=1))
        axes[1].errorbar(x, values, yerr=errors, marker="o", ms=3.1,
                         capsize=1.8, lw=1.1, color=color, label=label)
    axes[1].set_ylabel("TrustOOD-ECG ECE")
    axes[1].set_title("TrustOOD-ECG calibration transfer")
    axes[1].legend(loc="upper left")

    for variant, label, color in [("composite", "Composite", RED),
                                  ("sqi_only", "SQI only", GREEN),
                                  ("sqi_plus_composite", "SQI + composite", PURPLE)]:
        q = noise[(noise.category == "corruption_detector") &
                  (noise.variant == variant) & (noise.metric == "auroc")]
        rows = [one(q, context=s) for s in SNR_ORDER[1:]]
        require_n(rows, 3, f"corruption detection: {variant}")
        axes[2].errorbar(x[1:], [r["mean"] for r in rows], yerr=[r["sd"] for r in rows],
                         marker="o", ms=3.1, capsize=1.8, lw=1.1, color=color, label=label)
    axes[2].set_ylabel("Corruption AUROC")
    axes[2].set_ylim(0.45, 1.02)
    axes[2].set_title("Synthetic corruption detection")
    axes[2].legend(loc="lower left")
    for idx, ax in enumerate(axes):
        ax.set_xticks(x)
        ax.set_xticklabels(SNR_LABELS)
        ax.set_xlabel("SNR (dB)")
        panel_label(ax, f"({chr(97 + idx)})")
    fig.suptitle("Paired acquisition corruption (three seeds; error bars are sample SD)", y=1.01)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.84, bottom=0.20, wspace=0.30)
    finish(fig, out / "fig_noise.pdf")


def fig_source_weights(gate: pd.DataFrame, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(3.55, 2.85))
    x = np.arange(len(SNR_ORDER))
    for source, label, color, marker in [
        ("ecg", "ECG", RED, "o"), ("hrv", "HRV", BLUE, "s"),
        ("spec", "Spectrum", GREEN, "^"), ("sqi", "SQI", PURPLE, "D"),
    ]:
        q = gate[(gate.gate == "independent_sigmoid") &
                 (gate.metric == f"gate_{source}_mean")]
        rows = [one(q, snr_label=s) for s in SNR_ORDER]
        require_n(rows, 3, f"gate response: {source}", column="n_seed")
        y = np.asarray([r["mean"] for r in rows])
        sd = np.asarray([r["std"] for r in rows])
        ax.errorbar(x, y, yerr=sd, marker=marker, ms=3.0, capsize=1.6,
                    lw=1.0, color=color, label=label)
    ax.set_xticks(x)
    ax.set_xticklabels(SNR_LABELS)
    ax.set_xlabel("SNR (dB)")
    ax.set_ylabel("Mean gate coefficient")
    ax.set_ylim(0.08, 1.04)
    ax.set_title("Independent gate response under paired noise (three seeds)")
    ax.legend(ncol=2, loc="center right")
    finish(fig, out / "fig_source_weights.pdf")


def fig_multimodal(wear: pd.DataFrame, out: Path) -> None:
    specs = [
        ("mhealth", [("ECG", "ecg_only"), ("Motion", "motion_only"),
                     ("Concat.", "concat_matched"), ("Trust", "trust_full")]),
        ("wesad", [("ECG", "ecg_only"), ("Motion", "motion_only"),
                   ("PPG", "ppg_only"), ("Concat.", "concat_matched"),
                   ("Trust", "trust_full")]),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for idx, (ax, (dataset, methods)) in enumerate(zip(axes, specs)):
        x = np.arange(len(methods))
        w = 0.36
        for j, (metric, label, color) in enumerate([
            ("macro_f1", "Macro-F1", BLUE), ("macro_auprc", "Macro-AUPRC", RED)
        ]):
            rows = [one(wear, dataset=dataset, model=m, section="diagnosis_raw",
                        metric=metric) for _, m in methods]
            require_n(rows, 3, f"wearable LOSO: {dataset}/{metric}")
            ax.bar(x + (j - 0.5) * w, [r["mean"] for r in rows], width=w,
                   yerr=[r["sd"] for r in rows], capsize=2, color=color,
                   alpha=0.88, label=label)
        ax.set_xticks(x)
        ax.set_xticklabels([a for a, _ in methods], rotation=22, ha="right")
        ax.set_ylim(0.2, 0.9)
        ax.set_title("MHEALTH activity" if dataset == "mhealth" else "WESAD affect")
        panel_label(ax, f"({chr(97 + idx)})")
    axes[0].set_ylabel("Subject-wise LOSO score")
    axes[0].legend(loc="upper left")
    fig.suptitle("Wearable multimodal results (three seeds; subject-averaged mean ± SD)", y=1.01)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.84, bottom=0.25, wspace=0.22)
    finish(fig, out / "fig_multimodal.pdf")


def fig_generalization(ood: pd.DataFrame, alerts: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(3.55, 4.85))
    taus = [40, 80, 160]
    for category, label, color, marker in [
        ("aggregate", "All OOD", RED, "o"), ("pure", "Pure OOD", BLUE, "s"),
        ("mixed", "Mixed OOD", GREEN, "^")
    ]:
        vals, sds = [], []
        for tau in taus:
            scenario = "all" if category == "aggregate" else category
            r = one(ood, method="trust_full", protocol=f"strict:tau{tau}",
                    detector="composite", scenario=scenario,
                    ood_category=category, metric="auroc")
            vals.append(r["mean"]); sds.append(r["sd"])
            require_n([r], 5 if tau == 80 else 3,
                      f"strict threshold sensitivity: tau={tau}/{category}")
        axes[0].errorbar(np.arange(3), vals, yerr=sds, marker=marker, ms=3.2,
                         capsize=2, lw=1.1, color=color, label=label)
    axes[0].set_xticks(np.arange(3))
    axes[0].set_xticklabels(["40\n34 OOD; 3 seeds", "80\n93 OOD; 5 seeds",
                             "160\n240 OOD; 3 seeds"])
    axes[0].set_xlabel(r"Held-out-code support threshold $\tau$")
    axes[0].set_ylabel("Composite AUROC")
    axes[0].set_ylim(0.55, 0.82)
    axes[0].set_title("Strict-protocol sensitivity (descriptive; non-paired)")
    axes[0].legend(loc="upper right")

    q = alerts[(alerts.protocol == "closed") & (alerts.scenario == "chapman") &
               (alerts.method == "trust_full") & (alerts.detector == "composite")]
    prevalence = [0.01, 0.05, 0.10]
    ppv = [one(q, prevalence=p, metric="ppv") for p in prevalence]
    fp = [one(q, prevalence=p, metric="false_alerts_per_1000") for p in prevalence]
    require_n(ppv + fp, 5, "Chapman-Ningbo prevalence projection")
    ax = axes[1]
    x = np.arange(3)
    ax.errorbar(x, [100 * r["mean"] for r in ppv], yerr=[100 * r["sd"] for r in ppv],
                marker="o", color=BLUE, capsize=2, lw=1.1, label="PPV (%)")
    ax.set_ylabel("PPV (%)", color=BLUE)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.set_xticks(x)
    ax.set_xticklabels(["1%", "5%", "10%"])
    ax.set_xlabel("Assumed OOD prevalence")
    ax2 = ax.twinx()
    ax2.spines["top"].set_visible(False)
    ax2.errorbar(x, [r["mean"] for r in fp], yerr=[r["sd"] for r in fp],
                 marker="s", color=RED, capsize=2, lw=1.1,
                 label="False alerts / 1,000")
    ax2.set_ylabel("False alerts per 1,000", color=RED)
    ax2.tick_params(axis="y", labelcolor=RED)
    ax.set_title("Chapman-Ningbo 95%-sensitivity projection")
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    fig.suptitle("Scenario sensitivity and alarm burden", y=1.005)
    fig.subplots_adjust(left=0.18, right=0.83, top=0.92, bottom=0.10, hspace=0.42)
    finish(fig, out / "fig_generalization.pdf")


def main() -> None:
    args = parse_args()
    root = args.reference_root.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    agg = root / "aggregates"
    tables = root / "manuscript_tables"

    seed = read_csv(agg / "ptbxl" / "seed_summary.csv")
    ood = read_csv(agg / "ptbxl" / "ood_summary.csv")
    calibration = read_csv(agg / "ptbxl" / "calibration_summary.csv")
    classwise = read_csv(agg / "ptbxl" / "classwise_summary.csv")
    noise = read_csv(agg / "auxiliary" / "noise_summary.csv")
    wearable = read_csv(agg / "auxiliary" / "wearable_summary.csv")
    ext = read_csv(agg / "promised_extensions" / "summary.csv")
    paired = read_csv(agg / "promised_postprocess" / "ood_paired_seed.csv")
    selective = read_csv(agg / "promised_postprocess" / "selective_seed_summary.csv")
    alerts = read_csv(agg / "promised_postprocess" / "ood_alert_seed_summary.csv")
    gate = read_csv(agg / "noise_gate_extensions" / "summary_aggregate.csv")
    cal_noise = read_csv(agg / "noise_shift_calibration_audit" / "calibration_metrics.csv")
    distributions = read_csv(tables / "Supplementary_Class_Distributions.csv")

    fig_main_compare(seed, out)
    fig_rare_scatter(classwise, distributions, out)
    fig_ablation(seed, ext, out)
    fig_ood_openset(ood, out)
    fig_ood_effects(paired, out)
    fig_calibration(calibration, out)
    fig_risk_coverage(selective, out)
    fig_noise(noise, cal_noise, out)
    fig_source_weights(gate, out)
    fig_multimodal(wearable, out)
    fig_generalization(ood, alerts, out)

    quantitative_names = [
        "fig_main_compare.pdf",
        "fig_rare_scatter.pdf",
        "fig_ablation.pdf",
        "fig_ood_openset.pdf",
        "fig_ood_hist.pdf",
        "fig_calibration.pdf",
        "fig_risk_coverage.pdf",
        "fig_noise.pdf",
        "fig_source_weights.pdf",
        "fig_multimodal.pdf",
        "fig_generalization.pdf",
    ]
    files = [out / name for name in quantitative_names]
    if len(files) != 11:
        raise RuntimeError(f"Expected 11 quantitative PDFs, found {len(files)}")
    manifest = {
        "schema": "paper46-manuscript-quantitative-figures-v1",
        # Preserve the caller-provided path instead of leaking the machine-specific
        # absolute path produced by ``resolve()`` into the distributable manifest.
        "reference_root": str(args.reference_root),
        "figures": [
            {"name": p.name, "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in files
        ],
    }
    (out / "quantitative_figure_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"output_dir": str(out), "figure_count": len(files)}))


if __name__ == "__main__":
    main()
