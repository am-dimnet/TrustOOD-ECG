#!/usr/bin/env python3
"""Strict, inference-independent audit of noise-shift calibration artefacts.

The auditor is intentionally small and does not import any Paper46 training or
inference module.  It authenticates the three result pairs, checks the frozen
run definition and every declared input, validates the exact official-fold
array contract, independently reproduces temperature fitting on clean fold 9,
and recomputes every raw/temperature-scaled metric from the saved arrays.

Only compact audit JSON/CSV files are written.  No waveform is read into an
array by this program and the calibration NPZ contract rejects every unknown
key, including any accidental waveform key.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence

import numpy as np


SCRIPT_VERSION = "paper46-noise-shift-calibration-audit-v1"
RESULT_SCHEMA = "paper46-noise-shift-calibration-v1"
SEEDS = (7, 13, 42)
SNR_LABELS = ("clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB")
SNR_VALUES = (None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0)
N_CLASSES = 70
SPLIT_SIZES = {"validation": 2183, "test": 2198}
TRAIN_SIZE = 17418
CALIBRATION_BINS = 15
TEMPERATURE_BOUNDS = (0.05, 20.0)
TEMPERATURE_XATOL = 1e-8
EXPECTED_INPUT_ROLES = (
    "inference_script",
    "frozen_noise_runner",
    "revisionlib",
    "data_adapter",
    "adapter_manifest",
    "ptbxl_signal_mmap",
    "canonical_noise_json",
    "canonical_noise_curves",
    "checkpoint_json",
    "checkpoint_weights",
)
EXPECTED_ARRAY_KEYS = {
    "snr_db",
    "snr_label",
    "validation_y",
    "test_y",
    "validation_index",
    "test_index",
    "validation_record_id",
    "test_record_id",
    "validation_patient",
    "test_patient",
    "class_names",
    "train_class_support",
    "rare_ids",
    "temperature",
    "validation_logits_raw",
    "validation_prob_raw",
    "validation_logits_ts",
    "validation_prob_ts",
    "validation_achieved_snr",
    "test_logits_raw",
    "test_prob_raw",
    "test_logits_ts",
    "test_prob_ts",
    "test_achieved_snr",
}
METRIC_COLUMNS = (
    "seed",
    "snr_index",
    "snr_label",
    "snr_db",
    "split",
    "calibration_variant",
    "stratum",
    "support",
    "accuracy",
    "balanced_accuracy",
    "macro_f1",
    "nll",
    "brier",
    "ece_equal_width",
    "ece_adaptive",
    "classwise_ece",
    "classwise_ece_adaptive",
    "classwise_supported_ece",
    "classwise_supported_ece_adaptive",
    "classes",
    "true_supported_classes",
    "temperature",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def strict(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return strict(value.tolist())
    if isinstance(value, np.generic):
        return strict(value.item())
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): strict(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict(item) for item in value]
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        strict(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


_FILE_HASH_CACHE: dict[tuple[str, int, int], str] = {}


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    resolved = path.resolve()
    stat = resolved.stat()
    cache_key = (str(resolved), stat.st_size, stat.st_mtime_ns)
    cached = _FILE_HASH_CACHE.get(cache_key)
    if cached is not None:
        return cached
    digest = hashlib.sha256()
    with resolved.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    answer = digest.hexdigest()
    _FILE_HASH_CACHE[cache_key] = answer
    return answer


def sha256_array(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(array)
    return hashlib.sha256(memoryview(contiguous).cast("B")).hexdigest()


def is_sha256(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(character in "0123456789abcdef" for character in value)


def add_issue(
    issues: list[dict[str, Any]], code: str, location: str | Path, **details: Any,
) -> None:
    issue: dict[str, Any] = {"code": code, "location": str(location)}
    issue.update({str(key): strict(value) for key, value in details.items()})
    issues.append(issue)


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                strict(value), handle, indent=2, sort_keys=True,
                ensure_ascii=False, allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fieldnames), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: strict(row.get(key)) for key in fieldnames})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("top-level JSON value is not an object")
    return value


def compare_tree(
    actual: Any,
    expected: Any,
    location: str,
    issues: list[dict[str, Any]],
    *,
    rel_tol: float = 1e-7,
    abs_tol: float = 1e-9,
) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping):
            add_issue(issues, "type_mismatch", location, expected="object", actual=type(actual).__name__)
            return
        actual_keys = set(actual)
        expected_keys = set(expected)
        if actual_keys != expected_keys:
            add_issue(
                issues, "mapping_keys_mismatch", location,
                missing=sorted(expected_keys - actual_keys), extra=sorted(actual_keys - expected_keys),
            )
        for key in sorted(expected_keys & actual_keys):
            compare_tree(
                actual[key], expected[key], f"{location}.{key}", issues,
                rel_tol=rel_tol, abs_tol=abs_tol,
            )
        return
    if isinstance(expected, (list, tuple)):
        if not isinstance(actual, (list, tuple)):
            add_issue(issues, "type_mismatch", location, expected="sequence", actual=type(actual).__name__)
            return
        if len(actual) != len(expected):
            add_issue(issues, "sequence_length_mismatch", location, expected=len(expected), actual=len(actual))
            return
        for index, (actual_item, expected_item) in enumerate(zip(actual, expected)):
            compare_tree(
                actual_item, expected_item, f"{location}[{index}]", issues,
                rel_tol=rel_tol, abs_tol=abs_tol,
            )
        return
    if isinstance(expected, bool) or isinstance(actual, bool):
        if actual is not expected:
            add_issue(issues, "value_mismatch", location, expected=expected, actual=actual)
        return
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        if not math.isfinite(float(actual)) or not math.isclose(
            float(actual), float(expected), rel_tol=rel_tol, abs_tol=abs_tol,
        ):
            add_issue(issues, "numeric_mismatch", location, expected=expected, actual=actual)
        return
    if actual != expected:
        add_issue(issues, "value_mismatch", location, expected=expected, actual=actual)


def audit_artifact(
    declaration: Any,
    expected_path: Path | None,
    expected_role: str,
    issues: list[dict[str, Any]],
    location: str,
) -> str | None:
    if not isinstance(declaration, Mapping):
        add_issue(issues, "artifact_declaration_absent", location, role=expected_role)
        return None
    if declaration.get("role") != expected_role:
        add_issue(
            issues, "artifact_role_mismatch", location,
            expected=expected_role, actual=declaration.get("role"),
        )
    raw_path = declaration.get("path")
    if not isinstance(raw_path, str) or not raw_path:
        add_issue(issues, "artifact_path_absent", location, role=expected_role)
        return None
    declared_path = Path(raw_path)
    if not declared_path.is_file():
        add_issue(issues, "artifact_file_absent", location, path=declared_path)
        return None
    resolved = declared_path.resolve()
    if expected_path is not None and resolved != expected_path.resolve():
        add_issue(
            issues, "artifact_path_mismatch", location,
            expected=expected_path.resolve(), actual=resolved,
        )
    observed_bytes = resolved.stat().st_size
    if declaration.get("bytes") != observed_bytes:
        add_issue(
            issues, "artifact_bytes_mismatch", location,
            expected=declaration.get("bytes"), actual=observed_bytes,
        )
    declared_sha = declaration.get("sha256")
    if not is_sha256(declared_sha):
        add_issue(issues, "artifact_sha256_malformed", location, value=declared_sha)
        return None
    observed_sha = sha256_file(resolved)
    if declared_sha != observed_sha:
        add_issue(
            issues, "artifact_sha256_mismatch", location,
            expected=declared_sha, actual=observed_sha,
        )
    return observed_sha


def softmax(logits: np.ndarray) -> np.ndarray:
    values = np.asarray(logits, dtype=np.float64)
    values = values - values.max(axis=1, keepdims=True)
    exp_values = np.exp(values)
    exp_values /= np.maximum(exp_values.sum(axis=1, keepdims=True), 1e-300)
    return exp_values


def nll(probabilities: np.ndarray, labels: np.ndarray) -> float:
    selected = np.asarray(probabilities, dtype=np.float64)[np.arange(len(labels)), labels]
    return float(-np.mean(np.log(np.clip(selected, 1e-15, 1.0))))


def logits_nll(logits: np.ndarray, labels: np.ndarray, temperature: float) -> float:
    values = np.asarray(logits, dtype=np.float64) / float(temperature)
    maximum = values.max(axis=1, keepdims=True)
    log_normalizer = maximum[:, 0] + np.log(np.exp(values - maximum).sum(axis=1))
    return float(np.mean(log_normalizer - values[np.arange(len(labels)), labels]))


def independent_temperature(logits: np.ndarray, labels: np.ndarray) -> tuple[float, float]:
    """Golden-section reproduction of the clean-fold9 scalar TS optimum."""

    lower, upper = (math.log(value) for value in TEMPERATURE_BOUNDS)
    ratio = (math.sqrt(5.0) - 1.0) / 2.0
    left = upper - ratio * (upper - lower)
    right = lower + ratio * (upper - lower)
    left_value = logits_nll(logits, labels, math.exp(left))
    right_value = logits_nll(logits, labels, math.exp(right))
    for _ in range(160):
        if right_value < left_value:
            lower = left
            left = right
            left_value = right_value
            right = lower + ratio * (upper - lower)
            right_value = logits_nll(logits, labels, math.exp(right))
        else:
            upper = right
            right = left
            right_value = left_value
            left = upper - ratio * (upper - lower)
            left_value = logits_nll(logits, labels, math.exp(left))
    log_temperature = (lower + upper) / 2.0
    temperature = math.exp(log_temperature)
    return temperature, logits_nll(logits, labels, temperature)


def brier(probabilities: np.ndarray, labels: np.ndarray) -> float:
    one_hot = np.zeros_like(probabilities, dtype=np.float64)
    one_hot[np.arange(len(labels)), labels] = 1.0
    return float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1)))


def calibration_error(
    confidence: np.ndarray, correctness: np.ndarray, bins: int, *, adaptive: bool,
) -> tuple[float | None, int]:
    confidence = np.asarray(confidence, dtype=np.float64).reshape(-1)
    correctness = np.asarray(correctness, dtype=np.float64).reshape(-1)
    if len(confidence) == 0:
        return None, 0
    if adaptive:
        quantiles = np.quantile(confidence, np.linspace(0.0, 1.0, bins + 1))
        interior = np.unique(quantiles[1:-1])
        assignments = np.searchsorted(interior, confidence, side="right")
        n_bins = len(interior) + 1
    else:
        assignments = np.minimum(
            (np.clip(confidence, 0.0, 1.0) * bins).astype(int), bins - 1,
        )
        n_bins = bins
    total = float(len(confidence))
    error = 0.0
    nonempty = 0
    for index in range(n_bins):
        mask = assignments == index
        if not mask.any():
            continue
        nonempty += 1
        error += float(mask.sum()) / total * abs(
            float(correctness[mask].mean()) - float(confidence[mask].mean())
        )
    return error, nonempty


def balanced_accuracy(labels: np.ndarray, predictions: np.ndarray) -> float:
    recalls = [
        float(np.mean(predictions[labels == class_id] == class_id))
        for class_id in np.unique(labels)
    ]
    return float(np.mean(recalls))


def macro_f1(labels: np.ndarray, predictions: np.ndarray, n_classes: int) -> float:
    values = []
    for class_id in range(n_classes):
        truth = labels == class_id
        predicted = predictions == class_id
        true_positive = int(np.sum(truth & predicted))
        denominator = 2 * true_positive + int(np.sum(~truth & predicted)) + int(np.sum(truth & ~predicted))
        values.append(0.0 if denominator == 0 else 2.0 * true_positive / denominator)
    return float(np.mean(values))


def calibration_metrics(
    probabilities: np.ndarray, labels: np.ndarray, bins: int,
) -> dict[str, Any]:
    probabilities = np.asarray(probabilities, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    if len(labels) == 0:
        return {
            "support": 0,
            "accuracy": None,
            "balanced_accuracy": None,
            "macro_f1": None,
            "nll": None,
            "brier": None,
            "ece_equal_width": None,
            "ece_adaptive": None,
            "classwise_ece": None,
            "classwise_ece_adaptive": None,
            "classwise_supported_ece": None,
            "classwise_supported_ece_adaptive": None,
        }
    prediction = probabilities.argmax(axis=1)
    confidence = probabilities.max(axis=1)
    correctness = prediction == labels
    equal, equal_nonempty = calibration_error(confidence, correctness, bins, adaptive=False)
    adaptive, adaptive_nonempty = calibration_error(confidence, correctness, bins, adaptive=True)
    class_equal: list[float] = []
    class_adaptive: list[float] = []
    supported_equal: list[float] = []
    supported_adaptive: list[float] = []
    for class_id in range(probabilities.shape[1]):
        truth = labels == class_id
        current_equal, _ = calibration_error(
            probabilities[:, class_id], truth, bins, adaptive=False,
        )
        current_adaptive, _ = calibration_error(
            probabilities[:, class_id], truth, bins, adaptive=True,
        )
        if current_equal is None or current_adaptive is None:
            raise ValueError("nonempty metric stratum produced an empty classwise ECE")
        class_equal.append(current_equal)
        class_adaptive.append(current_adaptive)
        if truth.any():
            supported_equal.append(current_equal)
            supported_adaptive.append(current_adaptive)
    return {
        "support": len(labels),
        "accuracy": float(np.mean(prediction == labels)),
        "balanced_accuracy": balanced_accuracy(labels, prediction),
        "macro_f1": macro_f1(labels, prediction, probabilities.shape[1]),
        "nll": nll(probabilities, labels),
        "brier": brier(probabilities, labels),
        "ece_equal_width": equal,
        "ece_equal_width_nonempty_bins": equal_nonempty,
        "ece_adaptive": adaptive,
        "ece_adaptive_nonempty_bins": adaptive_nonempty,
        "classwise_ece": float(np.mean(class_equal)),
        "classwise_ece_adaptive": float(np.mean(class_adaptive)),
        "classwise_supported_ece": float(np.mean(supported_equal)) if supported_equal else None,
        "classwise_supported_ece_adaptive": (
            float(np.mean(supported_adaptive)) if supported_adaptive else None
        ),
        "classes": probabilities.shape[1],
        "true_supported_classes": len(supported_equal),
        "bins_requested": bins,
    }


def stratified_metrics(
    probabilities: np.ndarray, labels: np.ndarray, rare_ids: np.ndarray, bins: int,
) -> dict[str, Any]:
    rare = np.isin(labels, rare_ids)
    return {
        "all": calibration_metrics(probabilities, labels, bins),
        "rare_true_label": calibration_metrics(probabilities[rare], labels[rare], bins),
        "frequent_true_label": calibration_metrics(probabilities[~rare], labels[~rare], bins),
    }


def audit_source_manifest(
    results_root: Path,
    issues: list[dict[str, Any]],
) -> dict[str, Any] | None:
    manifest_path = results_root / "manifest.json"
    if not manifest_path.is_file():
        add_issue(issues, "source_manifest_absent", manifest_path)
        return None
    try:
        payload = load_json(manifest_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        add_issue(issues, "source_manifest_unreadable", manifest_path, error=str(exc))
        return None
    compare_tree(payload.get("schema"), RESULT_SCHEMA, "source_manifest.schema", issues)
    compare_tree(payload.get("complete"), True, "source_manifest.complete", issues)
    compare_tree(payload.get("expected_seeds"), list(SEEDS), "source_manifest.expected_seeds", issues)
    compare_tree(payload.get("observed_seeds"), list(SEEDS), "source_manifest.observed_seeds", issues)
    script_sha = audit_artifact(
        payload.get("script"), None, "inference_script", issues, "source_manifest.script",
    )
    entries = payload.get("results")
    if not isinstance(entries, list) or len(entries) != len(SEEDS):
        add_issue(
            issues, "source_manifest_result_count", manifest_path,
            expected=len(SEEDS), actual=len(entries) if isinstance(entries, list) else None,
        )
        return payload
    by_seed = {
        entry.get("seed"): entry for entry in entries
        if isinstance(entry, Mapping) and isinstance(entry.get("seed"), int)
    }
    if set(by_seed) != set(SEEDS):
        add_issue(
            issues, "source_manifest_seed_set", manifest_path,
            expected=list(SEEDS), actual=sorted(by_seed),
        )
    for seed in SEEDS:
        entry = by_seed.get(seed)
        if not isinstance(entry, Mapping):
            continue
        audit_artifact(
            entry.get("json"), results_root / f"seed_{seed}.json",
            "calibration_json", issues, f"source_manifest.results.seed_{seed}.json",
        )
        audit_artifact(
            entry.get("npz"), results_root / f"seed_{seed}_calibration.npz",
            "calibration_npz", issues, f"source_manifest.results.seed_{seed}.npz",
        )
    if script_sha is not None and not is_sha256(script_sha):
        add_issue(issues, "source_manifest_script_sha_invalid", manifest_path, value=script_sha)
    return payload


def audit_inputs_and_fingerprints(
    payload: Mapping[str, Any],
    seed: int,
    issues: list[dict[str, Any]],
    location: str,
) -> dict[str, str]:
    run_definition = payload.get("run_definition")
    if not isinstance(run_definition, Mapping):
        add_issue(issues, "run_definition_absent", location)
        return {}
    observed_fingerprint = fingerprint(run_definition)
    if payload.get("run_fingerprint") != observed_fingerprint:
        add_issue(
            issues, "run_fingerprint_mismatch", location,
            expected=observed_fingerprint, actual=payload.get("run_fingerprint"),
        )
    expected_definition = {
        "script_version": RESULT_SCHEMA,
        "seed": seed,
        "model": "trust_full",
        "snrs": list(SNR_LABELS),
        "splits": "official folds 9 and 10; no split limits",
        "eval_batch_size": 512,
        "feature_chunk_size": 256,
        "calibration_bins": CALIBRATION_BINS,
        "temperature": {
            "fit_split": "clean fold9 only",
            "bounds": list(TEMPERATURE_BOUNDS),
            "xatol": TEMPERATURE_XATOL,
        },
        "rare_threshold": 50,
    }
    for key, wanted in expected_definition.items():
        compare_tree(
            run_definition.get(key), wanted,
            f"{location}.run_definition.{key}", issues,
        )
    for key in (
        "script_sha256", "train_index_sha256", "validation_index_sha256",
        "test_index_sha256", "labels_sha256", "signals_sha256",
        "record_id_order_sha256", "checkpoint_fingerprint",
    ):
        if not is_sha256(run_definition.get(key)):
            add_issue(
                issues, "run_definition_sha_malformed",
                f"{location}.run_definition.{key}", value=run_definition.get(key),
            )

    inputs = payload.get("inputs")
    if not isinstance(inputs, list):
        add_issue(issues, "inputs_absent", location)
        return {}
    by_role: dict[str, Any] = {}
    for declaration in inputs:
        if not isinstance(declaration, Mapping) or not isinstance(declaration.get("role"), str):
            add_issue(issues, "input_declaration_invalid", location, declaration=declaration)
            continue
        role = str(declaration["role"])
        if role in by_role:
            add_issue(issues, "input_role_duplicate", location, role=role)
        by_role[role] = declaration
    if set(by_role) != set(EXPECTED_INPUT_ROLES):
        add_issue(
            issues, "input_role_set_mismatch", location,
            missing=sorted(set(EXPECTED_INPUT_ROLES) - set(by_role)),
            extra=sorted(set(by_role) - set(EXPECTED_INPUT_ROLES)),
        )
    observed_hashes: dict[str, str] = {}
    for role in EXPECTED_INPUT_ROLES:
        if role not in by_role:
            continue
        observed = audit_artifact(
            by_role[role], None, role, issues, f"{location}.inputs.{role}",
        )
        if observed is not None:
            observed_hashes[role] = observed
    compare_tree(
        run_definition.get("input_hashes"), observed_hashes,
        f"{location}.run_definition.input_hashes", issues,
    )
    if observed_hashes.get("inference_script") != run_definition.get("script_sha256"):
        add_issue(
            issues, "inference_script_hash_not_bound", location,
            input_sha=observed_hashes.get("inference_script"),
            run_sha=run_definition.get("script_sha256"),
        )

    checkpoint_declaration = by_role.get("checkpoint_json")
    if isinstance(checkpoint_declaration, Mapping):
        checkpoint_path = Path(str(checkpoint_declaration.get("path", "")))
        if checkpoint_path.is_file():
            try:
                checkpoint = load_json(checkpoint_path)
                compare_tree(
                    checkpoint.get("status"), "complete",
                    f"{location}.checkpoint.status", issues,
                )
                compare_tree(checkpoint.get("seed"), seed, f"{location}.checkpoint.seed", issues)
                compare_tree(
                    checkpoint.get("checkpoint_fingerprint"),
                    run_definition.get("checkpoint_fingerprint"),
                    f"{location}.checkpoint.fingerprint", issues,
                )
                provenance = checkpoint.get("checkpoint_provenance")
                if not isinstance(provenance, Mapping):
                    add_issue(issues, "checkpoint_provenance_absent", checkpoint_path)
                elif fingerprint(provenance) != checkpoint.get("checkpoint_fingerprint"):
                    add_issue(issues, "checkpoint_provenance_fingerprint_mismatch", checkpoint_path)
                compare_tree(
                    checkpoint.get("weights_sha256"), observed_hashes.get("checkpoint_weights"),
                    f"{location}.checkpoint.weights_sha256", issues,
                )
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                add_issue(issues, "checkpoint_json_unreadable", checkpoint_path, error=str(exc))

    canonical_declaration = by_role.get("canonical_noise_json")
    if isinstance(canonical_declaration, Mapping):
        canonical_path = Path(str(canonical_declaration.get("path", "")))
        if canonical_path.is_file():
            try:
                canonical = load_json(canonical_path)
                compare_tree(canonical.get("status"), "complete", f"{location}.canonical.status", issues)
                compare_tree(canonical.get("canonical"), True, f"{location}.canonical.flag", issues)
                compare_tree(canonical.get("full_fold_run"), True, f"{location}.canonical.full_fold", issues)
                compare_tree(canonical.get("seed"), seed, f"{location}.canonical.seed", issues)
                compare_tree(
                    canonical.get("raw_npz", {}).get("sha256"),
                    observed_hashes.get("canonical_noise_curves"),
                    f"{location}.canonical.raw_npz.sha256", issues,
                )
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                add_issue(issues, "canonical_noise_json_unreadable", canonical_path, error=str(exc))
    return observed_hashes


def load_npz_arrays(
    path: Path, issues: list[dict[str, Any]], location: str,
) -> dict[str, np.ndarray]:
    arrays: dict[str, np.ndarray] = {}
    try:
        with np.load(path, allow_pickle=False) as archive:
            keys = set(archive.files)
            if keys != EXPECTED_ARRAY_KEYS:
                add_issue(
                    issues, "npz_key_set_mismatch", location,
                    missing=sorted(EXPECTED_ARRAY_KEYS - keys),
                    extra=sorted(keys - EXPECTED_ARRAY_KEYS),
                )
            for key in sorted(EXPECTED_ARRAY_KEYS & keys):
                value = np.asarray(archive[key])
                if value.dtype.hasobject:
                    add_issue(issues, "npz_object_dtype", f"{location}.{key}", dtype=str(value.dtype))
                    continue
                arrays[key] = value
    except (OSError, ValueError, KeyError) as exc:
        add_issue(issues, "npz_unreadable", location, error=str(exc))
    return arrays


def require_shape(
    arrays: Mapping[str, np.ndarray], key: str, shape: tuple[int, ...],
    issues: list[dict[str, Any]], location: str,
) -> None:
    if key not in arrays:
        return
    if arrays[key].shape != shape:
        add_issue(
            issues, "array_shape_mismatch", f"{location}.{key}",
            expected=shape, actual=arrays[key].shape,
        )


def require_finite(
    arrays: Mapping[str, np.ndarray], key: str,
    issues: list[dict[str, Any]], location: str,
) -> None:
    if key in arrays and not np.isfinite(arrays[key]).all():
        add_issue(issues, "array_nonfinite", f"{location}.{key}")


def check_cross_seed_reference(
    references: MutableMapping[str, np.ndarray],
    key: str,
    value: np.ndarray,
    seed: int,
    issues: list[dict[str, Any]],
) -> None:
    if key not in references:
        references[key] = np.array(value, copy=True)
    elif not np.array_equal(references[key], value):
        add_issue(issues, "cross_seed_array_mismatch", f"seed_{seed}.{key}")


def audit_array_contract(
    arrays: Mapping[str, np.ndarray],
    payload: Mapping[str, Any],
    seed: int,
    references: MutableMapping[str, np.ndarray],
    issues: list[dict[str, Any]],
    location: str,
) -> None:
    require_shape(arrays, "snr_db", (len(SNR_LABELS),), issues, location)
    require_shape(arrays, "snr_label", (len(SNR_LABELS),), issues, location)
    require_shape(arrays, "class_names", (N_CLASSES,), issues, location)
    require_shape(arrays, "train_class_support", (N_CLASSES,), issues, location)
    require_shape(arrays, "temperature", (), issues, location)
    for split, n_records in SPLIT_SIZES.items():
        for suffix in ("y", "index", "record_id", "patient"):
            require_shape(arrays, f"{split}_{suffix}", (n_records,), issues, location)
        for suffix in ("logits_raw", "prob_raw", "logits_ts", "prob_ts"):
            require_shape(
                arrays, f"{split}_{suffix}",
                (len(SNR_LABELS), n_records, N_CLASSES), issues, location,
            )
        require_shape(
            arrays, f"{split}_achieved_snr",
            (len(SNR_LABELS), n_records), issues, location,
        )

    for key, array in arrays.items():
        if key in ("snr_label", "validation_record_id", "test_record_id", "validation_patient", "test_patient", "class_names"):
            if array.dtype.kind not in ("U", "S"):
                add_issue(issues, "text_array_dtype", f"{location}.{key}", dtype=str(array.dtype))
        elif key not in ("snr_db", "validation_achieved_snr", "test_achieved_snr"):
            require_finite(arrays, key, issues, location)

    if "snr_label" in arrays:
        compare_tree(arrays["snr_label"].astype(str).tolist(), list(SNR_LABELS), f"{location}.snr_label", issues)
    if "snr_db" in arrays:
        observed_snr = arrays["snr_db"].astype(np.float64)
        if not np.isnan(observed_snr[0]):
            add_issue(issues, "clean_snr_not_nan", f"{location}.snr_db[0]")
        expected_numeric = np.asarray(SNR_VALUES[1:], dtype=np.float64)
        if observed_snr.shape == (len(SNR_LABELS),) and not np.allclose(
            observed_snr[1:], expected_numeric, rtol=0.0, atol=0.0,
        ):
            add_issue(issues, "snr_values_mismatch", f"{location}.snr_db")

    class_names = arrays.get("class_names")
    support = arrays.get("train_class_support")
    rare_ids = arrays.get("rare_ids")
    if class_names is not None:
        class_text = class_names.astype(str)
        if len(set(class_text.tolist())) != N_CLASSES or np.any(class_text == ""):
            add_issue(issues, "class_names_invalid", f"{location}.class_names")
        compare_tree(payload.get("class_names"), class_text.tolist(), f"{location}.json.class_names", issues)
        check_cross_seed_reference(references, "class_names", class_text, seed, issues)
    if support is not None:
        if support.dtype.kind not in ("i", "u") or np.any(support < 0) or int(support.sum()) != TRAIN_SIZE:
            add_issue(
                issues, "train_support_invalid", f"{location}.train_class_support",
                dtype=str(support.dtype), total=int(support.sum()),
            )
        compare_tree(payload.get("train_class_support"), support.tolist(), f"{location}.json.train_class_support", issues)
        check_cross_seed_reference(references, "train_class_support", support, seed, issues)
    if rare_ids is not None and support is not None:
        expected_rare = np.flatnonzero(support < 50).astype(rare_ids.dtype, copy=False)
        if rare_ids.dtype.kind not in ("i", "u") or not np.array_equal(rare_ids, expected_rare):
            add_issue(
                issues, "rare_ids_invalid", f"{location}.rare_ids",
                expected=expected_rare, actual=rare_ids,
            )
        compare_tree(payload.get("rare_ids"), rare_ids.tolist(), f"{location}.json.rare_ids", issues)
        if class_names is not None:
            expected_names = class_names.astype(str)[rare_ids.astype(np.int64)].tolist()
            compare_tree(payload.get("rare_names"), expected_names, f"{location}.json.rare_names", issues)
        check_cross_seed_reference(references, "rare_ids", rare_ids, seed, issues)

    run_definition = payload.get("run_definition", {})
    for split, n_records in SPLIT_SIZES.items():
        y = arrays.get(f"{split}_y")
        index = arrays.get(f"{split}_index")
        record_id = arrays.get(f"{split}_record_id")
        patient = arrays.get(f"{split}_patient")
        if y is not None:
            if y.dtype.kind not in ("i", "u") or np.any((y < 0) | (y >= N_CLASSES)):
                add_issue(issues, "labels_invalid", f"{location}.{split}_y", dtype=str(y.dtype))
            check_cross_seed_reference(references, f"{split}_y", y, seed, issues)
        if index is not None:
            if index.dtype.kind not in ("i", "u") or np.any(index < 0) or np.any(np.diff(index) <= 0):
                add_issue(issues, "fold_index_invalid", f"{location}.{split}_index")
            declared_key = "validation_index_sha256" if split == "validation" else "test_index_sha256"
            compare_tree(
                run_definition.get(declared_key), sha256_array(index),
                f"{location}.run_definition.{declared_key}", issues,
            )
            check_cross_seed_reference(references, f"{split}_index", index, seed, issues)
        if record_id is not None:
            text = record_id.astype(str)
            if len(set(text.tolist())) != n_records or np.any(text == ""):
                add_issue(issues, "record_ids_invalid", f"{location}.{split}_record_id")
            check_cross_seed_reference(references, f"{split}_record_id", text, seed, issues)
        if patient is not None:
            text = patient.astype(str)
            if np.any(text == ""):
                add_issue(issues, "patient_ids_invalid", f"{location}.{split}_patient")
            check_cross_seed_reference(references, f"{split}_patient", text, seed, issues)

    if "validation_index" in arrays and "test_index" in arrays:
        if np.intersect1d(arrays["validation_index"], arrays["test_index"]).size:
            add_issue(issues, "fold_index_overlap", location)
    if "validation_record_id" in arrays and "test_record_id" in arrays:
        if np.intersect1d(arrays["validation_record_id"], arrays["test_record_id"]).size:
            add_issue(issues, "record_id_overlap", location)
    if "validation_patient" in arrays and "test_patient" in arrays:
        if np.intersect1d(arrays["validation_patient"], arrays["test_patient"]).size:
            add_issue(issues, "patient_overlap", location)

    for split in SPLIT_SIZES:
        achieved = arrays.get(f"{split}_achieved_snr")
        if achieved is None or achieved.shape[0] != len(SNR_LABELS):
            continue
        if not np.isnan(achieved[0]).all():
            add_issue(issues, "clean_achieved_snr_not_all_nan", f"{location}.{split}_achieved_snr[0]")
        if not np.isfinite(achieved[1:]).all():
            add_issue(issues, "noisy_achieved_snr_nonfinite", f"{location}.{split}_achieved_snr[1:]")
        else:
            targets = np.asarray(SNR_VALUES[1:], dtype=np.float64)[:, None]
            maximum_error = float(np.max(np.abs(achieved[1:] - targets)))
            if maximum_error > 5e-3:
                add_issue(
                    issues, "achieved_snr_target_error", f"{location}.{split}_achieved_snr",
                    maximum_absolute_error=maximum_error,
                )


def audit_metrics_and_temperature(
    arrays: Mapping[str, np.ndarray],
    payload: Mapping[str, Any],
    seed: int,
    issues: list[dict[str, Any]],
    metric_rows: list[dict[str, Any]],
    location: str,
) -> None:
    required = {
        "temperature", "rare_ids", "validation_y", "test_y",
        "validation_logits_raw", "validation_prob_raw", "validation_logits_ts",
        "validation_prob_ts", "test_logits_raw", "test_prob_raw",
        "test_logits_ts", "test_prob_ts",
    }
    if not required.issubset(arrays):
        add_issue(issues, "metric_arrays_incomplete", location, missing=sorted(required - set(arrays)))
        return
    temperature = float(arrays["temperature"].item())
    if not math.isfinite(temperature) or not TEMPERATURE_BOUNDS[0] <= temperature <= TEMPERATURE_BOUNDS[1]:
        add_issue(issues, "temperature_out_of_bounds", f"{location}.temperature", value=temperature)
        return
    temperature_payload = payload.get("temperature")
    if not isinstance(temperature_payload, Mapping):
        add_issue(issues, "temperature_metadata_absent", location)
        return
    compare_tree(temperature_payload.get("value"), temperature, f"{location}.temperature.value", issues)
    expected_temperature_metadata = {
        "fit_split": "clean official fold 9 only",
        "objective": "multiclass negative log-likelihood",
        "parameterization": "bounded scalar log-temperature",
        "bounds": list(TEMPERATURE_BOUNDS),
        "xatol": TEMPERATURE_XATOL,
        "optimizer_success": True,
        "same_temperature_frozen_for_all_snr_and_fold10": True,
    }
    for key, wanted in expected_temperature_metadata.items():
        compare_tree(
            temperature_payload.get(key), wanted,
            f"{location}.temperature.{key}", issues,
        )
    iterations = temperature_payload.get("iterations")
    if not isinstance(iterations, int) or isinstance(iterations, bool) or iterations < 1:
        add_issue(issues, "temperature_iterations_invalid", f"{location}.temperature.iterations", value=iterations)

    clean_logits = arrays["validation_logits_raw"][0]
    clean_labels = arrays["validation_y"].astype(np.int64)
    raw_fold9_nll = logits_nll(clean_logits, clean_labels, 1.0)
    scaled_fold9_nll = logits_nll(clean_logits, clean_labels, temperature)
    compare_tree(
        temperature_payload.get("raw_fold9_nll"), raw_fold9_nll,
        f"{location}.temperature.raw_fold9_nll", issues,
    )
    compare_tree(
        temperature_payload.get("scaled_fold9_nll"), scaled_fold9_nll,
        f"{location}.temperature.scaled_fold9_nll", issues,
    )
    independently_fitted, independent_nll = independent_temperature(clean_logits, clean_labels)
    if not math.isclose(temperature, independently_fitted, rel_tol=2e-5, abs_tol=2e-6):
        add_issue(
            issues, "temperature_not_clean_fold9_optimum", f"{location}.temperature",
            stored=temperature, independent=independently_fitted,
            stored_nll=scaled_fold9_nll, independent_nll=independent_nll,
        )
    if scaled_fold9_nll > raw_fold9_nll + 1e-10:
        add_issue(
            issues, "temperature_worsens_fit_fold", f"{location}.temperature",
            raw_nll=raw_fold9_nll, scaled_nll=scaled_fold9_nll,
        )

    conditions = payload.get("conditions")
    if not isinstance(conditions, Mapping):
        add_issue(issues, "conditions_absent", location)
        return
    if set(conditions) != set(SNR_LABELS):
        add_issue(
            issues, "condition_set_mismatch", location,
            expected=list(SNR_LABELS), actual=sorted(conditions),
        )
    rare_ids = arrays["rare_ids"].astype(np.int64)
    for split in SPLIT_SIZES:
        logits_raw = arrays[f"{split}_logits_raw"]
        prob_raw = arrays[f"{split}_prob_raw"]
        logits_ts = arrays[f"{split}_logits_ts"]
        prob_ts = arrays[f"{split}_prob_ts"]
        labels = arrays[f"{split}_y"].astype(np.int64)
        for key, values in (
            ("logits_raw", logits_raw), ("prob_raw", prob_raw),
            ("logits_ts", logits_ts), ("prob_ts", prob_ts),
        ):
            if not np.isfinite(values).all():
                add_issue(issues, "prediction_array_nonfinite", f"{location}.{split}_{key}")
        if np.any(prob_raw < -1e-7) or np.any(prob_raw > 1.0 + 1e-7):
            add_issue(issues, "raw_probability_bounds", f"{location}.{split}_prob_raw")
        if np.any(prob_ts < -1e-7) or np.any(prob_ts > 1.0 + 1e-7):
            add_issue(issues, "ts_probability_bounds", f"{location}.{split}_prob_ts")
        if not np.allclose(prob_raw.sum(axis=2), 1.0, rtol=0.0, atol=2e-5):
            add_issue(issues, "raw_probability_simplex", f"{location}.{split}_prob_raw")
        if not np.allclose(prob_ts.sum(axis=2), 1.0, rtol=0.0, atol=2e-5):
            add_issue(issues, "ts_probability_simplex", f"{location}.{split}_prob_ts")
        if not np.allclose(logits_ts, logits_raw / temperature, rtol=2e-6, atol=2e-6):
            add_issue(issues, "ts_logits_not_single_temperature", f"{location}.{split}_logits_ts")
        if not np.array_equal(prob_raw.argmax(axis=2), prob_ts.argmax(axis=2)):
            add_issue(issues, "temperature_changes_prediction", f"{location}.{split}")

        for condition_index, (snr_label, snr_value) in enumerate(zip(SNR_LABELS, SNR_VALUES)):
            reconstructed_raw = softmax(logits_raw[condition_index])
            reconstructed_ts = softmax(logits_raw[condition_index] / temperature)
            raw_difference = float(np.max(np.abs(reconstructed_raw - prob_raw[condition_index])))
            ts_difference = float(np.max(np.abs(reconstructed_ts - prob_ts[condition_index])))
            if raw_difference > 2e-6:
                add_issue(
                    issues, "raw_probability_logit_identity", f"{location}.{snr_label}.{split}",
                    maximum_absolute_difference=raw_difference,
                )
            if ts_difference > 2e-6:
                add_issue(
                    issues, "ts_probability_logit_identity", f"{location}.{snr_label}.{split}",
                    maximum_absolute_difference=ts_difference,
                )
            expected_variants = {
                "raw": stratified_metrics(prob_raw[condition_index], labels, rare_ids, CALIBRATION_BINS),
                "temperature_scaled": stratified_metrics(
                    prob_ts[condition_index], labels, rare_ids, CALIBRATION_BINS,
                ),
            }
            condition = conditions.get(snr_label, {})
            if isinstance(condition, Mapping):
                compare_tree(
                    condition.get("snr_db"), snr_value,
                    f"{location}.conditions.{snr_label}.snr_db", issues,
                )
                split_payload = condition.get("splits", {}).get(split, {})
            else:
                split_payload = {}
            for variant, strata in expected_variants.items():
                actual_strata = split_payload.get(variant) if isinstance(split_payload, Mapping) else None
                compare_tree(
                    actual_strata, strata,
                    f"{location}.conditions.{snr_label}.splits.{split}.{variant}", issues,
                )
                for stratum, metrics in strata.items():
                    row = {
                        "seed": seed,
                        "snr_index": condition_index,
                        "snr_label": snr_label,
                        "snr_db": snr_value,
                        "split": split,
                        "calibration_variant": variant,
                        "stratum": stratum,
                        "temperature": temperature,
                    }
                    row.update(metrics)
                    metric_rows.append(row)

    for condition_index, (snr_label, snr_value) in enumerate(zip(SNR_LABELS, SNR_VALUES)):
        condition = conditions.get(snr_label)
        if not isinstance(condition, Mapping):
            continue
        provenance = condition.get("provenance")
        if not isinstance(provenance, Mapping):
            add_issue(issues, "condition_provenance_absent", f"{location}.{snr_label}")
            continue
        for split, n_records in SPLIT_SIZES.items():
            split_provenance = provenance.get(split)
            if not isinstance(split_provenance, Mapping):
                add_issue(issues, "split_provenance_absent", f"{location}.{snr_label}.{split}")
                continue
            compare_tree(
                split_provenance.get("records"), n_records,
                f"{location}.{snr_label}.{split}.records", issues,
            )
            imputed = split_provenance.get("hrv_values_imputed")
            if not isinstance(imputed, int) or isinstance(imputed, bool) or imputed < 0:
                add_issue(
                    issues, "hrv_imputation_count_invalid",
                    f"{location}.{snr_label}.{split}.hrv_values_imputed", value=imputed,
                )
            achieved = arrays[f"{split}_achieved_snr"][condition_index]
            if snr_value is None:
                compare_tree(
                    split_provenance.get("base_noise_sha256"), None,
                    f"{location}.{snr_label}.{split}.base_noise_sha256", issues,
                )
                compare_tree(
                    split_provenance.get("achieved_snr_mean"), None,
                    f"{location}.{snr_label}.{split}.achieved_snr_mean", issues,
                )
                compare_tree(
                    split_provenance.get("achieved_snr_sd"), None,
                    f"{location}.{snr_label}.{split}.achieved_snr_sd", issues,
                )
            else:
                if not is_sha256(split_provenance.get("base_noise_sha256")):
                    add_issue(
                        issues, "base_noise_sha_malformed",
                        f"{location}.{snr_label}.{split}.base_noise_sha256",
                        value=split_provenance.get("base_noise_sha256"),
                    )
                compare_tree(
                    split_provenance.get("achieved_snr_mean"), float(np.mean(achieved)),
                    f"{location}.{snr_label}.{split}.achieved_snr_mean", issues,
                )
                compare_tree(
                    split_provenance.get("achieved_snr_sd"), float(np.std(achieved)),
                    f"{location}.{snr_label}.{split}.achieved_snr_sd", issues,
                )
            raw_difference = float(np.max(np.abs(
                softmax(arrays[f"{split}_logits_raw"][condition_index])
                - arrays[f"{split}_prob_raw"][condition_index]
            )))
            compare_tree(
                split_provenance.get("probability_equals_softmax_decision_logits_max_abs"),
                raw_difference,
                f"{location}.{snr_label}.{split}.probability_identity", issues,
            )

    for split in SPLIT_SIZES:
        hashes = []
        for snr_label in SNR_LABELS[1:]:
            condition = conditions.get(snr_label, {})
            value = condition.get("provenance", {}).get(split, {}).get("base_noise_sha256") \
                if isinstance(condition, Mapping) else None
            hashes.append(value)
        if len(set(hashes)) != 1 or not is_sha256(hashes[0]):
            add_issue(
                issues, "noise_not_paired_across_snr", f"{location}.{split}", hashes=hashes,
            )


def audit_payload_protocol(
    payload: Mapping[str, Any], seed: int, issues: list[dict[str, Any]], location: str,
) -> None:
    compare_tree(payload.get("status"), "complete", f"{location}.status", issues)
    compare_tree(payload.get("schema"), RESULT_SCHEMA, f"{location}.schema", issues)
    compare_tree(payload.get("seed"), seed, f"{location}.seed", issues)
    compare_tree(payload.get("model"), "trust_full", f"{location}.model", issues)
    protocol = payload.get("protocol")
    expected_protocol = {
        "train": TRAIN_SIZE,
        "validation": SPLIT_SIZES["validation"],
        "test": SPLIT_SIZES["test"],
        "rule": "official PTB-XL folds1-8 / fold9 / fold10",
        "all_noisy_ecg_sources_recomputed": ["ecg", "sqi6", "quality", "hrv8", "spec36"],
        "paired_noise_across_snr": True,
        "temperature_fit_uses_test": False,
    }
    compare_tree(protocol, expected_protocol, f"{location}.protocol", issues)
    compare_tree(
        payload.get("rare_definition"), "folds1-8 record support < 50",
        f"{location}.rare_definition", issues,
    )
    raw_npz = payload.get("raw_npz")
    if not isinstance(raw_npz, Mapping):
        add_issue(issues, "raw_npz_declaration_absent", location)
    elif "no waveform is stored" not in str(raw_npz.get("axis_convention", "")):
        add_issue(issues, "no_waveform_declaration_absent", f"{location}.raw_npz.axis_convention")


def audit_seed(
    results_root: Path,
    seed: int,
    references: MutableMapping[str, np.ndarray],
    issues: list[dict[str, Any]],
    metric_rows: list[dict[str, Any]],
) -> dict[str, Any] | None:
    json_path = results_root / f"seed_{seed}.json"
    npz_path = results_root / f"seed_{seed}_calibration.npz"
    location = f"seed_{seed}"
    if not json_path.is_file():
        add_issue(issues, "result_json_absent", json_path)
    if not npz_path.is_file():
        add_issue(issues, "result_npz_absent", npz_path)
    if not json_path.is_file() or not npz_path.is_file():
        return None
    try:
        payload = load_json(json_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        add_issue(issues, "result_json_unreadable", json_path, error=str(exc))
        return None

    audit_payload_protocol(payload, seed, issues, location)
    audit_inputs_and_fingerprints(payload, seed, issues, location)
    declared_raw = payload.get("raw_npz")
    audit_artifact(declared_raw, npz_path, "calibration_npz", issues, f"{location}.raw_npz")
    arrays = load_npz_arrays(npz_path, issues, location)
    audit_array_contract(arrays, payload, seed, references, issues, location)
    audit_metrics_and_temperature(arrays, payload, seed, issues, metric_rows, location)
    run_definition = payload.get("run_definition", {})
    return {
        "seed": seed,
        "json": {
            "path": str(json_path.resolve()),
            "bytes": json_path.stat().st_size,
            "sha256": sha256_file(json_path),
        },
        "npz": {
            "path": str(npz_path.resolve()),
            "bytes": npz_path.stat().st_size,
            "sha256": sha256_file(npz_path),
        },
        "run_fingerprint": payload.get("run_fingerprint"),
        "script_sha256": run_definition.get("script_sha256") if isinstance(run_definition, Mapping) else None,
        "temperature": float(arrays["temperature"].item()) if "temperature" in arrays and arrays["temperature"].shape == () else None,
    }


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--results-root", type=Path,
        default=Path("/dev/shm/Paper46_noise_shift_calibration/results"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path("/dev/shm/Paper46_noise_shift_calibration/audit"),
    )
    parser.add_argument("--fail-on-incomplete", action="store_true")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    results_root = args.results_root.resolve()
    output_dir = args.output_dir.resolve()
    if output_dir == results_root:
        raise SystemExit("--output-dir must differ from --results-root")
    output_dir.mkdir(parents=True, exist_ok=True)

    issues: list[dict[str, Any]] = []
    metric_rows: list[dict[str, Any]] = []
    references: dict[str, np.ndarray] = {}
    source_manifest = audit_source_manifest(results_root, issues)
    results: list[dict[str, Any]] = []
    valid_seeds: list[int] = []
    for seed in SEEDS:
        issue_start = len(issues)
        try:
            result = audit_seed(results_root, seed, references, issues, metric_rows)
        except Exception as exc:  # malformed artefacts must yield a manifest, not a partial audit
            add_issue(
                issues, "seed_audit_exception", f"seed_{seed}",
                exception_type=type(exc).__name__, error=str(exc),
            )
            result = None
        if result is not None:
            results.append(result)
        if result is not None and len(issues) == issue_start:
            valid_seeds.append(seed)

    script_hashes = {item.get("script_sha256") for item in results}
    if len(script_hashes) != 1 or not script_hashes or not is_sha256(next(iter(script_hashes))):
        add_issue(issues, "cross_seed_script_hash_mismatch", output_dir, hashes=sorted(str(item) for item in script_hashes))
    run_fingerprints = [item.get("run_fingerprint") for item in results]
    if len(run_fingerprints) != len(SEEDS) or any(not is_sha256(value) for value in run_fingerprints):
        add_issue(issues, "result_fingerprint_set_invalid", output_dir, values=run_fingerprints)
    elif len(set(run_fingerprints)) != len(SEEDS):
        add_issue(issues, "result_fingerprints_not_seed_specific", output_dir, values=run_fingerprints)

    issues_csv = output_dir / "issues.csv"
    issue_rows = [
        {
            "code": item.get("code"),
            "location": item.get("location"),
            "details_json": json.dumps(
                {key: value for key, value in item.items() if key not in ("code", "location")},
                sort_keys=True, ensure_ascii=False, allow_nan=False,
            ),
        }
        for item in issues
    ]
    atomic_csv(issues_csv, ("code", "location", "details_json"), issue_rows)
    metrics_csv = output_dir / "calibration_metrics.csv"
    atomic_csv(metrics_csv, METRIC_COLUMNS, metric_rows)

    complete = len(issues) == 0 and valid_seeds == list(SEEDS) and len(metric_rows) == 252
    manifest_path = output_dir / "manifest.json"
    manifest = {
        "schema": SCRIPT_VERSION,
        "created_at_utc": utc_now(),
        "complete": complete,
        "issue_count": len(issues),
        "issues": issues,
        "expected": {
            "seeds": list(SEEDS),
            "snr_labels": list(SNR_LABELS),
            "folds": {"validation": 9, "test": 10},
            "split_sizes": SPLIT_SIZES,
            "classes": N_CLASSES,
            "metric_rows": 252,
            "temperature_fit": "clean fold 9 only; one scalar per seed",
            "waveform_arrays": 0,
        },
        "observed": {
            "result_pairs": len(results),
            "valid_seeds": valid_seeds,
            "metric_rows": len(metric_rows),
        },
        "source_manifest": {
            "path": str((results_root / "manifest.json").resolve()),
            "sha256": sha256_file(results_root / "manifest.json")
            if source_manifest is not None and (results_root / "manifest.json").is_file()
            else None,
        },
        "auditor": {
            "path": str(Path(__file__).resolve()),
            "sha256": sha256_file(Path(__file__).resolve()),
            "python": sys.version,
            "numpy": np.__version__,
        },
        "results": results,
        "csv": {
            "metrics": {
                "path": str(metrics_csv.resolve()),
                "rows": len(metric_rows),
                "bytes": metrics_csv.stat().st_size,
                "sha256": sha256_file(metrics_csv),
            },
            "issues": {
                "path": str(issues_csv.resolve()),
                "rows": len(issue_rows),
                "bytes": issues_csv.stat().st_size,
                "sha256": sha256_file(issues_csv),
            },
        },
        "note": "manifest.json is intentionally not self-hashed",
    }
    atomic_json(manifest_path, manifest)
    print(json.dumps({
        "complete": complete,
        "issue_count": len(issues),
        "valid_seeds": valid_seeds,
        "metric_rows": len(metric_rows),
        "manifest": str(manifest_path),
    }, sort_keys=True), flush=True)
    if args.fail_on_incomplete and not complete:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
