#!/usr/bin/env python3
"""Leakage-free subject-level wearable fusion experiments for Paper46.

The runner consumes the existing Paper54 *per-subject* archives directly.  It
does not create a merged waveform cache: each ``S*.npz`` is opened, filtered,
and released in turn, and the selected windows exist only in process memory.

Two classification protocols are implemented:

* MHEALTH: 12 activities (raw labels 1--12), ECG (1 x 1120) and wrist-motion
  acceleration (3 x 256).
* WESAD: four affective states (raw labels 1--4), ECG resampled in memory from
  140 Hz / 1120 samples to 100 Hz / 800 samples, PPG (1 x 512), and wrist
  acceleration (3 x 256).

Every fold is leave-one-subject-out (LOSO).  The held-out subject is used only
for the final test.  The next subject in the canonical cyclic ordering is the
validation subject, independent of seed; all remaining subjects form the
training split.  Therefore validation/model selection never sees the test
subject.

Canonical repeated runs use seeds 7, 42 and 2026, one invocation per seed::

    for seed in 7 42 2026; do
      python run_wearables_revision.py --dataset wesad \
        --heldout-subject S2 --models all --seed "$seed"
    done

All result files are compact, atomic and resumable.  No model checkpoint or
combined dataset cache is written.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import socket
import sys
import time
from collections import OrderedDict
from pathlib import Path
from typing import Any, Mapping, Sequence

# Required by CUDA >=10.2 for deterministic cuBLAS GEMM.  Set it before
# importing torch so the reproducibility request is effective without relying
# on a particular launcher shell.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import numpy as np
import scipy
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.signal import resample_poly
from scipy.stats import rankdata
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
)

import revisionlib as R


SCRIPT_VERSION = "paper46-wearable-loso-v1"
CANONICAL_SEEDS = (7, 42, 2026)
DEFAULT_DATA_ROOT = Path("/root/autodl-tmp/Paper54/data_processed")
DEFAULT_RESULTS_DIR = Path("/root/Paper46_revision/results_final/wearables")

DATASET_CONFIG: dict[str, dict[str, Any]] = {
    "mhealth": {
        "label_key": "activity",
        "raw_labels": (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12),
        "class_names": (
            "standing_still",
            "sitting_relaxing",
            "lying_down",
            "walking",
            "climbing_stairs",
            "waist_bends_forward",
            "frontal_elevation_arms",
            "knees_bending",
            "cycling",
            "jogging",
            "running",
            "jumping_front_back",
        ),
        "expected_subjects": tuple(f"S{index}" for index in range(1, 11)),
        "sources": ("ecg", "motion"),
        "window_hop_seconds": 2.0,
    },
    "wesad": {
        "label_key": "affect",
        "raw_labels": (1, 2, 3, 4),
        "class_names": ("baseline", "stress", "amusement", "meditation"),
        "expected_subjects": tuple(
            f"S{index}" for index in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17)
        ),
        "sources": ("ecg", "ppg", "motion"),
        "window_hop_seconds": 2.0,
    },
}


def set_seed(seed: int) -> None:
    """Seed every stochastic component and request deterministic CUDA kernels."""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True, warn_only=True)


def natural_subject_key(subject: str) -> tuple[int, str]:
    digits = "".join(character for character in subject if character.isdigit())
    return (int(digits) if digits else 10**9, subject)


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    return value


def atomic_json(payload: Any, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(
                jsonable(payload), handle, indent=2, sort_keys=True,
                ensure_ascii=False, allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(target: Path, **arrays: np.ndarray) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def discover_subject_files(dataset_dir: Path, dataset: str) -> OrderedDict[str, Path]:
    if not dataset_dir.is_dir():
        raise FileNotFoundError(f"dataset directory not found: {dataset_dir}")
    discovered = {
        path.stem: path.resolve()
        for path in dataset_dir.glob("S*.npz")
        if path.is_file() and not path.name.startswith("._")
    }
    ordered = OrderedDict(
        (subject, discovered[subject])
        for subject in sorted(discovered, key=natural_subject_key)
    )
    expected = tuple(DATASET_CONFIG[dataset]["expected_subjects"])
    missing = sorted(set(expected) - set(ordered), key=natural_subject_key)
    extra = sorted(set(ordered) - set(expected), key=natural_subject_key)
    if missing or extra:
        raise ValueError(
            f"{dataset} subject files disagree with the prespecified cohort: "
            f"missing={missing}, extra={extra}"
        )
    return OrderedDict((subject, ordered[subject]) for subject in expected)


def data_manifest(
    files: Mapping[str, Path], dataset: str, manifest_path: Path,
) -> dict[str, Any]:
    """Return SHA-256 provenance, reusing an atomic manifest when stats match."""

    stat_rows = [
        {
            "subject": subject,
            "path": str(path),
            "bytes": int(path.stat().st_size),
            "mtime_ns": int(path.stat().st_mtime_ns),
        }
        for subject, path in files.items()
    ]
    if manifest_path.exists():
        try:
            with manifest_path.open("r", encoding="utf-8") as handle:
                cached = json.load(handle)
            if (
                cached.get("dataset") == dataset
                and cached.get("files_without_hash") == stat_rows
                and len(cached.get("files", [])) == len(stat_rows)
                and all("sha256" in row for row in cached.get("files", []))
            ):
                return cached
        except (OSError, ValueError, TypeError):
            pass

    rows = []
    for row in stat_rows:
        enriched = dict(row)
        enriched["sha256"] = sha256_file(Path(row["path"]))
        rows.append(enriched)
    payload = {
        "schema": "paper46-wearable-data-manifest-v1",
        "dataset": dataset,
        "files_without_hash": stat_rows,
        "files": rows,
        "combined_sha256": hashlib.sha256(
            "\n".join(f"{row['subject']}:{row['sha256']}" for row in rows).encode("utf-8")
        ).hexdigest(),
    }
    atomic_json(payload, manifest_path)
    return payload


def split_subjects(subjects: Sequence[str], heldout: str) -> dict[str, Any]:
    """Cyclic, seed-independent LOSO split with a distinct validation subject."""

    ordered = tuple(subjects)
    if heldout not in ordered:
        raise ValueError(f"held-out subject {heldout!r} is not in {ordered}")
    if len(ordered) < 3:
        raise ValueError("LOSO plus subject-level validation needs at least three subjects")
    heldout_index = ordered.index(heldout)
    validation = ordered[(heldout_index + 1) % len(ordered)]
    train = tuple(subject for subject in ordered if subject not in (heldout, validation))
    assert heldout not in train and heldout != validation and validation not in train
    return {
        "strategy": "cyclic-next-subject validation, independent of seed",
        "train": train,
        "validation": (validation,),
        "test": (heldout,),
    }


def _validate_wave(name: str, value: np.ndarray, expected_tail: tuple[int, ...]) -> np.ndarray:
    value = np.asarray(value)
    if value.ndim != len(expected_tail) + 1 or tuple(value.shape[1:]) != expected_tail:
        raise ValueError(f"{name}: expected shape (N,{expected_tail}), got {value.shape}")
    if not np.isfinite(value).all():
        raise ValueError(f"{name}: NaN or infinity found")
    return np.asarray(value, dtype=np.float32)


def load_one_subject(path: Path, dataset: str) -> dict[str, np.ndarray]:
    """Load, label-filter and transform one subject; close the NPZ immediately."""

    config = DATASET_CONFIG[dataset]
    label_key = str(config["label_key"])
    raw_labels = np.asarray(config["raw_labels"], dtype=np.int64)
    with np.load(path, allow_pickle=False) as archive:
        required = {label_key, "ecg", "acc", "ecg_sqi", "acc_motion"}
        if dataset == "wesad":
            required.update(("ppg", "ppg_sqi"))
        missing = sorted(required - set(archive.files))
        if missing:
            raise KeyError(f"{path}: missing required arrays {missing}")

        raw_y = np.asarray(archive[label_key], dtype=np.int64).reshape(-1)
        keep = np.isin(raw_y, raw_labels)
        if not keep.any():
            raise ValueError(f"{path}: no allowed {label_key} labels {raw_labels.tolist()}")
        # The raw labels are consecutive and begin at one in both protocols.
        y = raw_y[keep] - 1
        n_total = len(raw_y)
        for key in required - {label_key}:
            if len(archive[key]) != n_total:
                raise ValueError(
                    f"{path}: {key} has {len(archive[key])} rows but labels have {n_total}"
                )

        ecg_raw = np.asarray(archive["ecg"])[keep]
        acc_raw = np.asarray(archive["acc"])[keep]
        ecg_q = np.asarray(archive["ecg_sqi"], dtype=np.float32).reshape(-1)[keep]
        motion_raw = np.asarray(archive["acc_motion"], dtype=np.float32).reshape(-1)[keep]
        if dataset == "wesad":
            ppg_raw = np.asarray(archive["ppg"])[keep]
            ppg_q = np.asarray(archive["ppg_sqi"], dtype=np.float32).reshape(-1)[keep]

    if dataset == "mhealth":
        ecg = _validate_wave(f"{path}:ecg", ecg_raw, (1120,))[:, None, :]
    else:
        source_ecg = _validate_wave(f"{path}:ecg", ecg_raw, (1120,))
        # Exact 140 -> 100 Hz rational resampling; 1120 samples become 800.
        ecg = np.asarray(resample_poly(source_ecg, 5, 7, axis=-1), dtype=np.float32)
        if ecg.shape[1] != 800:
            raise ValueError(f"{path}: resampled ECG shape is {ecg.shape}, expected (N,800)")
        ecg = ecg[:, None, :]
    motion = _validate_wave(f"{path}:acc", acc_raw, (3, 256))

    result: dict[str, np.ndarray] = {
        "ecg": np.ascontiguousarray(ecg, dtype=np.float32),
        "motion": np.ascontiguousarray(motion, dtype=np.float32),
        "ecg_q": np.clip(ecg_q, 0.0, 1.0).astype(np.float32),
        "motion_raw": motion_raw.astype(np.float32),
        "y": y.astype(np.int64),
        "subject": np.full(len(y), path.stem, dtype=f"<U{max(2, len(path.stem))}"),
        "n_unfiltered": np.asarray(n_total, dtype=np.int64),
        "n_filtered_out": np.asarray(n_total - len(y), dtype=np.int64),
    }
    if dataset == "wesad":
        ppg = _validate_wave(f"{path}:ppg", ppg_raw, (512,))[:, None, :]
        result["ppg"] = np.ascontiguousarray(ppg, dtype=np.float32)
        result["ppg_q"] = np.clip(ppg_q, 0.0, 1.0).astype(np.float32)
    return result


def fit_motion_quality(subject_payloads: Sequence[Mapping[str, np.ndarray]]) -> dict[str, float]:
    values = np.concatenate(
        [np.asarray(payload["motion_raw"], dtype=np.float64) for payload in subject_payloads]
    )
    finite = values[np.isfinite(values)]
    if not len(finite):
        raise ValueError("training motion intensity contains no finite values")
    low, high = np.quantile(finite, (0.05, 0.95))
    if high <= low:
        high = low + 1.0
    return {
        "definition": "1 - clip((motion - training_q05)/(training_q95-training_q05),0,1)",
        "training_q05": float(low),
        "training_q95": float(high),
    }


def apply_motion_quality(payload: dict[str, np.ndarray], fit: Mapping[str, float]) -> None:
    low = float(fit["training_q05"])
    high = float(fit["training_q95"])
    scaled = (payload["motion_raw"] - low) / max(high - low, 1e-12)
    payload["motion_q"] = (1.0 - np.clip(scaled, 0.0, 1.0)).astype(np.float32)


def concatenate_subjects(
    payloads: Sequence[Mapping[str, np.ndarray]], sources: Sequence[str],
) -> dict[str, np.ndarray]:
    keys = list(sources) + [f"{source}_q" for source in sources]
    keys += ["motion_raw", "y", "subject"]
    result = {
        key: np.concatenate([np.asarray(payload[key]) for payload in payloads], axis=0)
        for key in keys
    }
    n = len(result["y"])
    if any(len(value) != n for value in result.values()):
        raise ValueError("concatenated split arrays are not row-aligned")
    return result


def load_fold(
    files: Mapping[str, Path], dataset: str, split: Mapping[str, Sequence[str]],
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, Any]]:
    """Sequentially read subjects and build in-memory split arrays only."""

    needed = tuple(split["train"]) + tuple(split["validation"]) + tuple(split["test"])
    payload_by_subject: dict[str, dict[str, np.ndarray]] = {}
    audit: dict[str, Any] = {}
    for subject in needed:
        payload = load_one_subject(files[subject], dataset)
        payload_by_subject[subject] = payload
        counts = np.bincount(
            payload["y"], minlength=len(DATASET_CONFIG[dataset]["class_names"])
        )
        audit[subject] = {
            "path": str(files[subject]),
            "n_unfiltered": int(payload["n_unfiltered"]),
            "n_filtered_out": int(payload["n_filtered_out"]),
            "n_kept": int(len(payload["y"])),
            "class_counts": counts,
        }
        print(
            f"[{dataset}] loaded {subject}: kept={len(payload['y'])} "
            f"filtered={int(payload['n_filtered_out'])}", flush=True,
        )

    train_payloads = [payload_by_subject[subject] for subject in split["train"]]
    quality_fit = fit_motion_quality(train_payloads)
    for payload in payload_by_subject.values():
        apply_motion_quality(payload, quality_fit)

    sources = tuple(DATASET_CONFIG[dataset]["sources"])
    arrays = {
        split_name: concatenate_subjects(
            [payload_by_subject[subject] for subject in split[split_name]], sources,
        )
        for split_name in ("train", "validation", "test")
    }
    n_classes = len(DATASET_CONFIG[dataset]["class_names"])
    train_counts = np.bincount(arrays["train"]["y"], minlength=n_classes)
    if np.any(train_counts == 0):
        absent = np.flatnonzero(train_counts == 0).tolist()
        raise ValueError(f"training subjects have no samples for class IDs {absent}")
    audit["motion_quality_fit_train_only"] = quality_fit
    audit["split_counts"] = {
        name: {
            "windows": int(len(value["y"])),
            "class_counts": np.bincount(value["y"], minlength=n_classes),
            "subjects": sorted(set(value["subject"].tolist()), key=natural_subject_key),
        }
        for name, value in arrays.items()
    }
    audit["cache_policy"] = (
        "per-subject NPZ files read sequentially; no merged waveform cache written; "
        "split arrays are process-memory only"
    )
    return arrays, audit


def full_source_specs(dataset: str) -> OrderedDict[str, dict[str, Any]]:
    if dataset == "mhealth":
        return OrderedDict(
            (
                ("ecg", {"type": "wave", "in": 1, "quality_key": "ecg_q"}),
                ("motion", {"type": "wave", "in": 3, "quality_key": "motion_q"}),
            )
        )
    return OrderedDict(
        (
            ("ecg", {"type": "wave", "in": 1, "quality_key": "ecg_q"}),
            ("ppg", {"type": "wave", "in": 1, "quality_key": "ppg_q"}),
            ("motion", {"type": "wave", "in": 3, "quality_key": "motion_q"}),
        )
    )


class MatchedConcatClassifier(R.SharedBackboneClassifier):
    """Concatenation control with an analytically parameter-matched MLP head."""

    def __init__(
        self, sources: Mapping[str, Mapping[str, Any]], n_classes: int,
        hidden: int, feat_dim: int = 128, drop: float = 0.2,
    ):
        super().__init__(sources, n_classes, feat_dim=feat_dim, drop=drop)
        self.hidden = int(hidden)
        self.head = nn.Sequential(
            nn.Linear(self.feature_dim, self.hidden),
            nn.ReLU(),
            nn.Dropout(drop),
            nn.Linear(self.hidden, n_classes),
        )


def parameter_count(model: nn.Module) -> dict[str, int]:
    return {
        "total": int(sum(parameter.numel() for parameter in model.parameters())),
        "trainable": int(
            sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        ),
    }


def matched_hidden_width(
    sources: Mapping[str, Mapping[str, Any]], n_classes: int,
) -> tuple[int, int]:
    reference = R.RevisionTrustModel(
        sources, n_classes, feat_dim=128, proj_dim=64, drop=0.2,
        pooling="cumulative", branch="both", gate_mode="both",
        sqi_source=True, missing_quality="error", fuse_hidden=256,
    )
    target = parameter_count(reference)["total"]
    # Shared encoders are structurally identical between the two models.
    encoder_parameters = sum(parameter.numel() for parameter in reference.enc.parameters())
    feature_dim = 128 * len(sources)
    denominator = feature_dim + 1 + n_classes
    hidden = max(1, int(round((target - encoder_parameters - n_classes) / denominator)))
    return hidden, target


def build_model(
    tag: str, dataset: str, n_classes: int,
) -> tuple[nn.Module, str, dict[str, Any]]:
    specs = full_source_specs(dataset)
    if tag == "trust_full":
        model = R.RevisionTrustModel(
            specs, n_classes, feat_dim=128, proj_dim=64, drop=0.2,
            pooling="cumulative", branch="both", gate_mode="both",
            sqi_source=True, missing_quality="error", fuse_hidden=256,
        )
        return model, "trust", {"sources": tuple(specs), "complementarity_weight": 0.1}
    if tag == "concat_matched":
        hidden, reference_parameters = matched_hidden_width(specs, n_classes)
        model = MatchedConcatClassifier(specs, n_classes, hidden=hidden)
        count = parameter_count(model)["total"]
        return model, "softmax", {
            "sources": tuple(specs),
            "matched_hidden": hidden,
            "reference_trust_parameters": reference_parameters,
            "parameter_ratio_to_trust": float(count / reference_parameters),
        }
    if tag.endswith("_only"):
        source = tag[: -len("_only")]
        if source not in specs:
            raise ValueError(f"model {tag!r} is invalid for {dataset}; sources={tuple(specs)}")
        selected = OrderedDict(((source, specs[source]),))
        return R.SharedBackboneClassifier(selected, n_classes), "softmax", {
            "sources": (source,), "single_modality": True,
        }
    raise ValueError(f"unknown wearable model {tag!r}")


def input_keys(model: nn.Module, arrays: Mapping[str, np.ndarray]) -> tuple[str, ...]:
    names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    specs = getattr(model, "source_specs", {})
    quality = []
    for name in names:
        key = str(specs.get(name, {}).get("quality_key", f"{name}_q"))
        if key in arrays:
            quality.append(key)
    return names + tuple(quality)


def tensor_batch(
    arrays: Mapping[str, np.ndarray], indices: np.ndarray, keys: Sequence[str],
    device: torch.device,
) -> dict[str, torch.Tensor]:
    batch: dict[str, torch.Tensor] = {}
    for key in keys:
        value = torch.as_tensor(np.ascontiguousarray(arrays[key][indices]), device=device)
        if value.is_floating_point():
            value = value.float()
        batch[key] = value
    return batch


def class_weights(labels: np.ndarray, n_classes: int) -> np.ndarray:
    counts = np.bincount(labels, minlength=n_classes).astype(np.float64)
    weights = 1.0 / np.sqrt(counts + 1.0)
    return np.asarray(weights / weights.mean(), dtype=np.float32)


def safe_macro_auc(probs: np.ndarray, labels: np.ndarray) -> float:
    values = []
    for class_id in range(probs.shape[1]):
        truth = labels == class_id
        if truth.any() and (~truth).any():
            values.append(roc_auc_score(truth, probs[:, class_id]))
    return float(np.mean(values)) if values else float("nan")


def safe_macro_auprc(probs: np.ndarray, labels: np.ndarray) -> float:
    values = []
    for class_id in range(probs.shape[1]):
        truth = labels == class_id
        if truth.any():
            values.append(average_precision_score(truth, probs[:, class_id]))
    return float(np.mean(values)) if values else float("nan")


@torch.no_grad()
def predict_model(
    model: nn.Module, family: str, arrays: Mapping[str, np.ndarray], batch_size: int,
    device: torch.device,
) -> dict[str, np.ndarray]:
    was_training = model.training
    model.eval()
    keys = input_keys(model, arrays)
    n = len(arrays["y"])
    collected: dict[str, list[np.ndarray]] = {
        "logits": [], "prob": [], "u": [], "source_w": [],
        "source_u": [], "source_q": [], "source_prob": [],
    }
    for start in range(0, n, batch_size):
        indices = np.arange(start, min(start + batch_size, n))
        output = model(tensor_batch(arrays, indices, keys, device))
        if family == "trust":
            collected["logits"].append(output["logits"].detach().cpu().numpy())
            collected["prob"].append(output["prob"].detach().cpu().numpy())
            collected["u"].append(output["u"].detach().cpu().numpy().reshape(-1))
            collected["source_w"].append(output["source_w"].detach().cpu().numpy())
            collected["source_u"].append(output["source_u"].detach().cpu().numpy())
            collected["source_q"].append(output["source_q"].detach().cpu().numpy())
            collected["source_prob"].append(
                torch.stack(
                    [output["per"][name]["prob"] for name in model.source_names], dim=1
                ).detach().cpu().numpy()
            )
        else:
            logits = output.detach().cpu().numpy()
            shifted = logits - logits.max(axis=1, keepdims=True)
            probability = np.exp(shifted)
            probability /= probability.sum(axis=1, keepdims=True)
            collected["logits"].append(logits)
            collected["prob"].append(probability)
    result = {
        key: np.concatenate(parts, axis=0)
        for key, parts in collected.items()
        if parts
    }
    result["pred"] = result["prob"].argmax(axis=1)
    result["conf"] = result["prob"].max(axis=1)
    if family == "trust":
        result["selection_confidence"] = 1.0 - result["u"]
    else:
        result["selection_confidence"] = result["conf"]
    result["source_names"] = np.asarray(tuple(model.source_names), dtype=str)
    if was_training:
        model.train()
    return result


def train_model(
    model: nn.Module, family: str, train: Mapping[str, np.ndarray],
    validation: Mapping[str, np.ndarray], n_classes: int, epochs: int,
    batch_size: int, learning_rate: float, seed: int, device: torch.device,
    tag: str,
) -> tuple[nn.Module, dict[str, Any]]:
    set_seed(seed)
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs, 1))
    weights = torch.as_tensor(class_weights(train["y"], n_classes), device=device)
    keys = input_keys(model, train)
    best_score = -float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    history = []
    started = time.time()
    for epoch in range(epochs):
        model.train()
        permutation = np.random.permutation(len(train["y"]))
        total_loss = 0.0
        batches = 0
        for start in range(0, len(permutation), batch_size):
            indices = permutation[start:start + batch_size]
            if len(indices) < 2:
                continue
            batch = tensor_batch(train, indices, keys, device)
            target = torch.as_tensor(train["y"][indices], dtype=torch.long, device=device)
            output = model(batch)
            if family == "trust":
                annealed_kl = 0.05 * min(1.0, (epoch + 1) / 10.0)
                loss = R.revision_training_loss(
                    output, target, kl_weight=annealed_kl, ce_weight=0.5,
                    deep_supervision_weight=0.3, complementarity_weight=0.1,
                    class_weights=weights,
                )
            else:
                loss = F.cross_entropy(output, target, weight=weights)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total_loss += float(loss.detach().cpu())
            batches += 1
        scheduler.step()
        validation_raw = predict_model(
            model, family, validation, max(batch_size, 512), device,
        )
        score = safe_macro_auc(validation_raw["prob"], validation["y"])
        if not math.isfinite(score):
            score = float(accuracy_score(validation["y"], validation_raw["pred"]))
        if score > best_score:
            best_score = score
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
        record = {
            "epoch": epoch + 1,
            "loss": total_loss / max(batches, 1),
            "validation_macro_auroc": score,
            "validation_accuracy": float(
                accuracy_score(validation["y"], validation_raw["pred"])
            ),
            "elapsed_seconds": time.time() - started,
        }
        history.append(record)
        print(
            f"[{tag} seed={seed}] epoch {epoch + 1:02d}/{epochs} "
            f"loss={record['loss']:.4f} val_auc={score:.4f} "
            f"val_acc={record['validation_accuracy']:.4f}", flush=True,
        )
    if best_state is None:
        raise RuntimeError("training produced no selectable model state")
    model.load_state_dict(best_state)
    return model, {
        "best_validation_macro_auroc": best_score,
        "selection": (
            "maximum macro-AUROC on the prespecified validation subject; "
            "held-out test subject never used"
        ),
        "history": history,
        "train_seconds": time.time() - started,
    }


def classification_metrics(
    probs: np.ndarray, labels: np.ndarray, class_names: Sequence[str],
) -> dict[str, Any]:
    predictions = probs.argmax(axis=1)
    precision, recall, f1, support = precision_recall_fscore_support(
        labels, predictions, labels=np.arange(len(class_names)), zero_division=0,
    )
    classwise = []
    for class_id, class_name in enumerate(class_names):
        truth = labels == class_id
        classwise.append(
            {
                "class_id": class_id,
                "class_name": class_name,
                "support": int(support[class_id]),
                "precision": float(precision[class_id]),
                "recall": float(recall[class_id]),
                "f1": float(f1[class_id]),
                "auroc": float(roc_auc_score(truth, probs[:, class_id]))
                if truth.any() and (~truth).any() else None,
                "auprc": float(average_precision_score(truth, probs[:, class_id]))
                if truth.any() else None,
            }
        )
    return {
        "n": int(len(labels)),
        "accuracy": float(accuracy_score(labels, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "macro_f1": float(
            f1_score(
                labels, predictions, average="macro",
                labels=np.arange(len(class_names)), zero_division=0,
            )
        ),
        "macro_auroc": safe_macro_auc(probs, labels),
        "macro_auprc": safe_macro_auprc(probs, labels),
        "classwise": classwise,
    }


def _selection_row(
    probs: np.ndarray, labels: np.ndarray, confidence: np.ndarray, accepted: np.ndarray,
    threshold: float,
) -> dict[str, Any]:
    predictions = probs.argmax(axis=1)
    count = int(accepted.sum())
    if count == 0:
        return {
            "threshold": threshold, "coverage": 0.0, "risk": None,
            "accuracy": None, "balanced_accuracy": None, "macro_f1": None,
            "n_accepted": 0,
        }
    return {
        "threshold": float(threshold),
        "coverage": float(accepted.mean()),
        "risk": float(np.mean(predictions[accepted] != labels[accepted])),
        "accuracy": float(accuracy_score(labels[accepted], predictions[accepted])),
        "balanced_accuracy": float(
            balanced_accuracy_score(labels[accepted], predictions[accepted])
        ),
        "macro_f1": float(
            f1_score(
                labels[accepted], predictions[accepted], average="macro",
                labels=np.arange(probs.shape[1]), zero_division=0,
            )
        ),
        "n_accepted": count,
    }


def threshold_for_validation_risk(
    confidence: np.ndarray, correct: np.ndarray, target_risk: float,
) -> float:
    order = np.argsort(-confidence, kind="mergesort")
    cumulative_risk = np.cumsum(~correct[order]) / np.arange(1, len(order) + 1)
    eligible = np.flatnonzero(cumulative_risk <= target_risk)
    return float(confidence[order[eligible[-1]]]) if len(eligible) else float("inf")


def selective_report(
    test_raw: Mapping[str, np.ndarray], labels: np.ndarray,
    validation_raw: Mapping[str, np.ndarray], validation_labels: np.ndarray,
) -> dict[str, Any]:
    probs = np.asarray(test_raw["prob"])
    confidence = np.asarray(test_raw["selection_confidence"])
    validation_confidence = np.asarray(validation_raw["selection_confidence"])
    validation_correct = validation_raw["pred"] == validation_labels
    intrinsic = R.selective_metrics(probs, labels, confidence=confidence)
    intrinsic.pop("coverage_curve", None)
    intrinsic.pop("risk_curve", None)

    fixed_coverage = {}
    for coverage in (0.95, 0.90, 0.80, 0.50):
        threshold = float(np.quantile(validation_confidence, 1.0 - coverage))
        fixed_coverage[f"{coverage:.6g}"] = _selection_row(
            probs, labels, confidence, confidence >= threshold, threshold,
        )
    fixed_risk = {}
    for target_risk in (0.01, 0.05, 0.10):
        threshold = threshold_for_validation_risk(
            validation_confidence, validation_correct, target_risk,
        )
        fixed_risk[f"{target_risk:.6g}"] = _selection_row(
            probs, labels, confidence, confidence >= threshold, threshold,
        )
    return {
        "confidence_definition": "1-vacuity" if "u" in test_raw else "maximum probability",
        "retrospective_test_curve_summary": intrinsic,
        "validation_threshold_fixed_coverage": fixed_coverage,
        "validation_threshold_fixed_risk": fixed_risk,
    }


def alarm_burden(
    test_raw: Mapping[str, np.ndarray], labels: np.ndarray,
    validation_raw: Mapping[str, np.ndarray], nominal_hop_seconds: float,
) -> dict[str, Any]:
    confidence = np.asarray(test_raw["selection_confidence"])
    val_confidence = np.asarray(validation_raw["selection_confidence"])
    correct = test_raw["pred"] == labels
    rows = {}
    windows_per_hour = 3600.0 / nominal_hop_seconds
    for target_coverage in (0.95, 0.90, 0.80):
        threshold = float(np.quantile(val_confidence, 1.0 - target_coverage))
        rejected = confidence < threshold
        rows[f"{target_coverage:.6g}"] = {
            "validation_target_coverage": target_coverage,
            "threshold": threshold,
            "test_rejection_rate": float(rejected.mean()),
            "rejected_windows_per_1000": float(rejected.mean() * 1000.0),
            "nominal_rejected_windows_per_hour": float(rejected.mean() * windows_per_hour),
            "unnecessary_rejection_rate_among_correct": float(rejected[correct].mean())
            if correct.any() else None,
            "error_capture_rate": float(rejected[~correct].mean())
            if (~correct).any() else None,
        }
    return {
        "note": (
            "Window-level referral/alarm burden; per-hour value uses the source "
            "cache's nominal 2-second hop and is not a prospective clinical alarm rate."
        ),
        "operating_points": rows,
    }


def safe_correlation(left: np.ndarray, right: np.ndarray, rank: bool = False) -> float | None:
    left = np.asarray(left, dtype=np.float64).reshape(-1)
    right = np.asarray(right, dtype=np.float64).reshape(-1)
    finite = np.isfinite(left) & np.isfinite(right)
    left, right = left[finite], right[finite]
    if len(left) < 3 or np.std(left) <= 1e-12 or np.std(right) <= 1e-12:
        return None
    if rank:
        left, right = rankdata(left), rankdata(right)
    return float(np.corrcoef(left, right)[0, 1])


def source_weight_report(raw: Mapping[str, np.ndarray], labels: np.ndarray) -> dict[str, Any]:
    if "source_w" not in raw:
        return {}
    names = [str(name) for name in raw["source_names"]]
    fused_correct = np.asarray(raw["pred"] == labels, dtype=float)
    result = {}
    for source_index, name in enumerate(names):
        weight = raw["source_w"][:, source_index]
        quality = raw["source_q"][:, source_index]
        uncertainty = raw["source_u"][:, source_index]
        source_correct = (
            raw["source_prob"][:, source_index, :].argmax(axis=1) == labels
        ).astype(float)
        result[name] = {
            "weight_mean": float(weight.mean()),
            "weight_std": float(weight.std()),
            "quality_mean": float(quality.mean()),
            "source_accuracy": float(source_correct.mean()),
            "pearson_weight_quality": safe_correlation(weight, quality),
            "spearman_weight_quality": safe_correlation(weight, quality, rank=True),
            "pearson_weight_source_correctness": safe_correlation(weight, source_correct),
            "spearman_weight_source_correctness": safe_correlation(
                weight, source_correct, rank=True,
            ),
            "pearson_weight_fused_correctness": safe_correlation(weight, fused_correct),
            "spearman_weight_fused_correctness": safe_correlation(
                weight, fused_correct, rank=True,
            ),
            "pearson_weight_source_uncertainty": safe_correlation(weight, uncertainty),
            "mean_weight_when_source_correct": float(weight[source_correct.astype(bool)].mean())
            if source_correct.any() else None,
            "mean_weight_when_source_incorrect": float(weight[~source_correct.astype(bool)].mean())
            if (~source_correct.astype(bool)).any() else None,
        }
    return result


def corrupt_source(
    clean: Mapping[str, np.ndarray], source: str, kind: str, snr_db: float | None,
    seed: int,
) -> dict[str, np.ndarray]:
    """Return a shallow split copy with exactly one waveform source replaced."""

    result = dict(clean)
    signal = np.asarray(clean[source], dtype=np.float32)
    quality_key = f"{source}_q"
    if kind == "missing":
        result[source] = np.zeros_like(signal)
        if quality_key in result:
            result[quality_key] = np.zeros_like(result[quality_key], dtype=np.float32)
        return result
    if kind != "gaussian" or snr_db is None:
        raise ValueError(f"unsupported stress kind={kind!r}, snr_db={snr_db!r}")
    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(signal.shape, dtype=np.float32)
    axes = tuple(range(1, signal.ndim))
    signal_rms = np.sqrt(np.mean(np.square(signal), axis=axes, keepdims=True) + 1e-12)
    noise_rms = np.sqrt(np.mean(np.square(noise), axis=axes, keepdims=True) + 1e-12)
    scale = signal_rms / noise_rms / np.float32(10.0 ** (snr_db / 20.0))
    result[source] = np.asarray(signal + scale * noise, dtype=np.float32)
    # The main corruption condition deliberately retains the measured clean SQI:
    # this tests whether learned uncertainty reacts when the gate is not told.
    return result


def stress_report(
    model: nn.Module, family: str, clean_test: Mapping[str, np.ndarray],
    clean_raw: Mapping[str, np.ndarray], validation_raw: Mapping[str, np.ndarray],
    class_names: Sequence[str], batch_size: int, device: torch.device,
    seed: int, snrs: Sequence[float], nominal_hop_seconds: float,
) -> dict[str, Any]:
    baseline = classification_metrics(clean_raw["prob"], clean_test["y"], class_names)
    active_sources = tuple(model.source_names)
    result: dict[str, Any] = {
        "protocol": {
            "missing": "zero waveform and set that source's quality to zero",
            "gaussian": (
                "deterministic per-window white Gaussian noise at stated SNR; "
                "retain pre-corruption SQI to test uncertainty response"
            ),
            "thresholds": "all alarm thresholds fixed on the clean validation subject",
        },
        "conditions": {},
    }
    condition_index = 0
    for source in active_sources:
        conditions: list[tuple[str, float | None]] = [("missing", None)]
        conditions.extend(("gaussian", float(snr)) for snr in snrs)
        for kind, snr in conditions:
            label = f"{source}_{kind}" if snr is None else f"{source}_gaussian_{snr:g}dB"
            stressed = corrupt_source(
                clean_test, source, kind, snr,
                seed=seed * 1009 + condition_index * 9173 + 41,
            )
            raw = predict_model(model, family, stressed, batch_size, device)
            diagnosis = classification_metrics(raw["prob"], clean_test["y"], class_names)
            result["conditions"][label] = {
                "source": source,
                "kind": kind,
                "snr_db": snr,
                "diagnosis": diagnosis,
                "delta_from_clean": {
                    metric: float(diagnosis[metric] - baseline[metric])
                    for metric in (
                        "accuracy", "balanced_accuracy", "macro_f1",
                        "macro_auroc", "macro_auprc",
                    )
                    if math.isfinite(diagnosis[metric]) and math.isfinite(baseline[metric])
                },
                "alarm_burden": alarm_burden(
                    raw, clean_test["y"], validation_raw, nominal_hop_seconds,
                ),
                "source_weights": source_weight_report(raw, clean_test["y"]),
            }
            condition_index += 1
    return result


def environment_manifest(args: argparse.Namespace, device: torch.device) -> dict[str, Any]:
    gpu = None
    if device.type == "cuda":
        gpu = {
            "name": torch.cuda.get_device_name(device),
            "capability": list(torch.cuda.get_device_capability(device)),
            "total_memory_bytes": int(torch.cuda.get_device_properties(device).total_memory),
        }
    return {
        "argv": sys.argv,
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "scikit_learn": sklearn.__version__,
        "torch": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version(),
        "device": str(device),
        "gpu": gpu,
        "canonical_seeds": CANONICAL_SEEDS,
        "determinism": {
            "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
            "cudnn_benchmark": torch.backends.cudnn.benchmark,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "tf32_disabled": True,
            "deterministic_algorithms_warn_only": True,
        },
        "arguments": vars(args),
    }


def expand_models(value: str, dataset: str) -> list[str]:
    valid = ["trust_full", "concat_matched"] + [
        f"{source}_only" for source in DATASET_CONFIG[dataset]["sources"]
    ]
    requested = [item.strip() for item in value.split(",") if item.strip()]
    if requested == ["all"]:
        return valid
    unknown = sorted(set(requested) - set(valid))
    if unknown:
        raise ValueError(f"unknown models for {dataset}: {unknown}; valid={valid}")
    if not requested:
        raise ValueError("--models cannot be empty")
    return list(dict.fromkeys(requested))


def result_paths(
    results_dir: Path, dataset: str, heldout: str, tag: str, seed: int,
) -> tuple[Path, Path]:
    directory = results_dir / dataset / f"loso_{heldout}" / tag
    return directory / f"seed_{seed}.json", directory / f"seed_{seed}_predictions.npz"


def run_key(
    args: argparse.Namespace, dataset: str, heldout: str, tag: str,
    code_hashes: Mapping[str, str], data_hash: str,
) -> str:
    relevant = {
        "script_version": SCRIPT_VERSION,
        "dataset": dataset,
        "heldout_subject": heldout,
        "model": tag,
        "seed": args.seed,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "learning_rate": args.learning_rate,
        "device": args.device,
        "torch_threads": args.torch_threads,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "stress_snrs": args.stress_snrs,
        "stress": not args.no_stress,
        "code_hashes": code_hashes,
        "data_combined_sha256": data_hash,
    }
    encoded = json.dumps(relevant, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def completed_same_run(target: Path, predictions: Path, key: str) -> bool:
    if not target.exists() or not predictions.exists():
        return False
    try:
        with target.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload.get("status") == "complete" and payload.get("run_key") == key
    except (OSError, ValueError, TypeError):
        return False


def run_one_model(
    args: argparse.Namespace, dataset: str, heldout: str, tag: str,
    arrays: Mapping[str, Mapping[str, np.ndarray]], split: Mapping[str, Any],
    audit: Mapping[str, Any], manifest: Mapping[str, Any],
    code_hashes: Mapping[str, str], device: torch.device,
) -> None:
    json_path, prediction_path = result_paths(
        args.results_dir, dataset, heldout, tag, args.seed,
    )
    key = run_key(
        args, dataset, heldout, tag, code_hashes, manifest["combined_sha256"],
    )
    if not args.force and completed_same_run(json_path, prediction_path, key):
        print(f"[skip] complete identical run: {json_path}", flush=True)
        return

    set_seed(args.seed)
    n_classes = len(DATASET_CONFIG[dataset]["class_names"])
    model, family, model_definition = build_model(tag, dataset, n_classes)
    model, training = train_model(
        model, family, arrays["train"], arrays["validation"], n_classes,
        args.epochs, args.batch_size, args.learning_rate, args.seed, device, tag,
    )
    validation_raw = predict_model(
        model, family, arrays["validation"], max(args.batch_size, 512), device,
    )
    test_raw = predict_model(
        model, family, arrays["test"], max(args.batch_size, 512), device,
    )
    scaler = R.TemperatureScaler.fit(validation_raw["logits"], arrays["validation"]["y"])
    scaled_prob = scaler.predict_proba(test_raw["logits"])
    class_names = tuple(DATASET_CONFIG[dataset]["class_names"])
    diagnosis_raw = classification_metrics(test_raw["prob"], arrays["test"]["y"], class_names)
    diagnosis_scaled = classification_metrics(scaled_prob, arrays["test"]["y"], class_names)
    calibration = R.calibration_report(
        test_raw["logits"], arrays["test"]["y"],
        validation_logits=validation_raw["logits"],
        validation_labels=arrays["validation"]["y"],
    )
    selective = selective_report(
        test_raw, arrays["test"]["y"], validation_raw, arrays["validation"]["y"],
    )
    burden = alarm_burden(
        test_raw, arrays["test"]["y"], validation_raw,
        float(DATASET_CONFIG[dataset]["window_hop_seconds"]),
    )
    weights = source_weight_report(test_raw, arrays["test"]["y"])
    stress = {}
    if not args.no_stress:
        stress = stress_report(
            model, family, arrays["test"], test_raw, validation_raw, class_names,
            max(args.batch_size, 512), device, args.seed,
            args.stress_snrs,
            float(DATASET_CONFIG[dataset]["window_hop_seconds"]),
        )

    prediction_arrays: dict[str, np.ndarray] = {
        "y": np.asarray(arrays["test"]["y"], dtype=np.int16),
        "subject": np.asarray(arrays["test"]["subject"], dtype=str),
        "prob_raw": np.asarray(test_raw["prob"], dtype=np.float32),
        "prob_temperature_scaled": np.asarray(scaled_prob, dtype=np.float32),
        "logits_raw": np.asarray(test_raw["logits"], dtype=np.float32),
        "pred": np.asarray(test_raw["pred"], dtype=np.int16),
        "selection_confidence": np.asarray(
            test_raw["selection_confidence"], dtype=np.float32,
        ),
        "source_names": np.asarray(test_raw["source_names"], dtype=str),
    }
    for name in ("u", "source_w", "source_u", "source_q", "source_prob"):
        if name in test_raw:
            prediction_arrays[name] = np.asarray(test_raw[name], dtype=np.float32)
    atomic_npz(prediction_path, **prediction_arrays)

    payload = {
        "status": "complete",
        "schema": SCRIPT_VERSION,
        "run_key": key,
        "dataset": dataset,
        "heldout_subject": heldout,
        "validation_subject": split["validation"][0],
        "model": tag,
        "family": family,
        "seed": args.seed,
        "model_definition": model_definition,
        "parameters": parameter_count(model),
        "split": split,
        "data_audit": audit,
        "label_protocol": {
            "source_key": DATASET_CONFIG[dataset]["label_key"],
            "included_raw_labels": DATASET_CONFIG[dataset]["raw_labels"],
            "mapping": {
                str(raw): raw - 1 for raw in DATASET_CONFIG[dataset]["raw_labels"]
            },
            "excluded_labels": "all labels outside the included set, including raw label 0",
            "class_names": class_names,
        },
        "training": training,
        "diagnosis_raw": diagnosis_raw,
        "diagnosis_temperature_scaled": diagnosis_scaled,
        "calibration": calibration,
        "selective_prediction": selective,
        "source_weight_analysis": weights,
        "alarm_rejection_burden": burden,
        "stress_tests": stress,
        "prediction_file": {
            "path": str(prediction_path),
            "sha256": sha256_file(prediction_path),
        },
        "provenance": {
            "code_sha256": code_hashes,
            "data_manifest_path": str(
                args.results_dir / dataset / "data_manifest.json"
            ),
            "data_combined_sha256": manifest["combined_sha256"],
            "environment": environment_manifest(args, device),
        },
    }
    atomic_json(payload, json_path)
    print(f"[complete] {json_path}", flush=True)
    del model
    if device.type == "cuda":
        torch.cuda.empty_cache()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Paper46 leakage-free MHEALTH/WESAD subject-level LOSO experiments",
    )
    parser.add_argument("--dataset", required=True, choices=tuple(DATASET_CONFIG))
    parser.add_argument(
        "--heldout-subject", default="all",
        help="one subject ID (for parallel execution) or 'all' for every LOSO fold",
    )
    parser.add_argument(
        "--models", default="all",
        help=(
            "comma list or all: trust_full,concat_matched and every valid *_only modality"
        ),
    )
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS_DIR)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--torch-threads", type=int, default=1)
    parser.add_argument(
        "--stress-snrs", type=float, nargs="+", default=(10.0, 0.0, -5.0),
        help="Gaussian corruption SNRs in dB; clean-SQI values remain unchanged",
    )
    parser.add_argument("--no-stress", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser


def validate_arguments(args: argparse.Namespace) -> None:
    if args.epochs < 1:
        raise ValueError("--epochs must be positive")
    if args.batch_size < 2:
        raise ValueError("--batch-size must be at least two for BatchNorm")
    if args.learning_rate <= 0:
        raise ValueError("--learning-rate must be positive")
    if args.torch_threads < 1:
        raise ValueError("--torch-threads must be positive")
    if any(not math.isfinite(value) for value in args.stress_snrs):
        raise ValueError("--stress-snrs must be finite")


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    validate_arguments(args)
    args.data_root = args.data_root.resolve()
    args.results_dir = args.results_dir.resolve()
    torch.set_num_threads(args.torch_threads)
    if hasattr(torch, "set_num_interop_threads"):
        try:
            torch.set_num_interop_threads(1)
        except RuntimeError:
            pass
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")

    dataset = args.dataset
    dataset_dir = args.data_root / dataset
    files = discover_subject_files(dataset_dir, dataset)
    heldouts = list(files) if args.heldout_subject == "all" else [args.heldout_subject]
    unknown = sorted(set(heldouts) - set(files), key=natural_subject_key)
    if unknown:
        raise ValueError(f"unknown held-out subjects for {dataset}: {unknown}")
    models = expand_models(args.models, dataset)

    script_path = Path(__file__).resolve()
    revisionlib_path = Path(R.__file__).resolve()
    code_hashes = {
        str(script_path): sha256_file(script_path),
        str(revisionlib_path): sha256_file(revisionlib_path),
    }
    manifest_path = args.results_dir / dataset / "data_manifest.json"
    manifest = data_manifest(files, dataset, manifest_path)

    for heldout in heldouts:
        pending_models = []
        for tag in models:
            json_path, prediction_path = result_paths(
                args.results_dir, dataset, heldout, tag, args.seed,
            )
            key = run_key(
                args, dataset, heldout, tag, code_hashes,
                manifest["combined_sha256"],
            )
            if args.force or not completed_same_run(json_path, prediction_path, key):
                pending_models.append(tag)
            else:
                print(f"[skip] complete identical run: {json_path}", flush=True)
        if not pending_models:
            continue
        split = split_subjects(tuple(files), heldout)
        arrays, audit = load_fold(files, dataset, split)
        for tag in pending_models:
            run_one_model(
                args, dataset, heldout, tag, arrays, split, audit, manifest,
                code_hashes, device,
            )
        del arrays
        if device.type == "cuda":
            torch.cuda.empty_cache()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
