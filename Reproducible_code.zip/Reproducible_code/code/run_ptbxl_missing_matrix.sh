#!/usr/bin/env bash
# Complete only reviewer-promised PTB-XL fits absent from the frozen 212 results.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
RUNNER="${EXPERIMENT_DIR}/run_ptbxl_missing_extensions.py"
RESULTS_DIR="${RESULTS_DIR:-/dev/shm/Paper46_revision_results_missing/ptbxl}"
LOG_DIR="${LOG_DIR:-${REVISION_ROOT}/logs_final/ptbxl_missing}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
MAX_PARALLEL="${MAX_PARALLEL:-20}"
EPOCHS="${EPOCHS:-40}"
BATCH_SIZE="${BATCH_SIZE:-256}"
EVAL_BATCH_SIZE="${EVAL_BATCH_SIZE:-512}"

FIVE_SEEDS=(7 13 42 99 2026)
THREE_SEEDS=(7 42 2026)

if [[ ! -f "${TRUSTFED_CACHE}/ptbxl_signals.npy" ]]; then
  echo "Refusing to run: AutoDL PTB-XL cache is absent at ${TRUSTFED_CACHE}" >&2
  exit 2
fi
if [[ ! -f "${RUNNER}" ]]; then
  echo "Runner is absent: ${RUNNER}" >&2
  exit 2
fi
if [[ "${RESULTS_DIR}" == "${REVISION_ROOT}/results_final/ptbxl" ]]; then
  echo "Refusing to mix extensions into the frozen 212-result root" >&2
  exit 2
fi
if [[ ! "${MAX_PARALLEL}" =~ ^[1-9][0-9]*$ ]]; then
  echo "MAX_PARALLEL must be a positive integer" >&2
  exit 2
fi

mkdir -p "${RESULTS_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile "${RUNNER}"

{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'host='; hostname
  printf 'results_dir=%s\n' "${RESULTS_DIR}"
  printf 'max_parallel=%s\n' "${MAX_PARALLEL}"
  printf 'epochs=%s\n' "${EPOCHS}"
  printf 'batch_size=%s\n' "${BATCH_SIZE}"
  printf 'expected_task_processes=66\n'
  printf 'expected_new_results_and_fits=221\n'
  sha256sum \
    "${EXPERIMENT_DIR}/data_adapter.py" \
    "${EXPERIMENT_DIR}/revisionlib.py" \
    "${EXPERIMENT_DIR}/run_ptbxl_revision.py" \
    "${RUNNER}"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/missing_matrix_manifest.txt"

COMMON=(
  --epochs "${EPOCHS}"
  --batch-size "${BATCH_SIZE}"
  --eval-batch-size "${EVAL_BATCH_SIZE}"
  --learning-rate 0.001
  --rare-threshold 50
  --ensemble-members 5
  --bootstrap 0
  --device cuda
  --cache-dir "${CACHE_DIR}"
  --trustfed-cache "${TRUSTFED_CACHE}"
  --results-dir "${RESULTS_DIR}"
)

run_task() {
  local name="$1"
  shift
  local exit_file="${LOG_DIR}/${name}.exit"
  local log_file="${LOG_DIR}/${name}.log"
  local command_file="${LOG_DIR}/${name}.command.txt"
  printf '%q ' "${PYTHON}" "${RUNNER}" "$@" > "${command_file}"
  printf '\n' >> "${command_file}"
  set +e
  CUBLAS_WORKSPACE_CONFIG=:4096:8 \
    OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${PYTHON}" "${RUNNER}" "$@" > "${log_file}" 2>&1
  local status=$?
  printf '%s\n' "${status}" > "${exit_file}"
  return "${status}"
}

launch_task() {
  while (( $(jobs -rp | wc -l) >= MAX_PARALLEL )); do
    wait -n || true
  done
  run_task "$@" &
}

# Closed PTB-XL: the complete 6 eta x 3 auxiliary-weight x 5 seed Cartesian
# product.  Every result tag explicitly records both coefficients, avoiding
# alias-dependent joins with the frozen one-dimensional ablations.
for eta in 0 0.01 0.03 0.1 0.3 1; do
  for seed in "${FIVE_SEEDS[@]}"; do
    launch_task "closed_pareto_eta${eta}_seed${seed}" \
      --protocol closed --models \
      "pareto_eta_${eta}_aux_0,pareto_eta_${eta}_aux_0.3,pareto_eta_${eta}_aux_1" \
      --seed "${seed}" --cross-dataset "${COMMON[@]}"
  done
done

# Strict tau80: five-seed one-factor eta and auxiliary-weight scans.  The
# closed protocol above supplies the two-dimensional Pareto surface; strict
# runs test whether either axis transfers to held-out semantic OOD.
for seed in "${FIVE_SEEDS[@]}"; do
  launch_task "strict_eta_full_seed${seed}" \
    --protocol strict --tau 80 --models eta_full --seed "${seed}" \
    "${COMMON[@]}"
  launch_task "strict_aux_primary_seed${seed}" \
    --protocol strict --tau 80 --models aux_0,aux_0.3,aux_1 \
    --seed "${seed}" "${COMMON[@]}"
done

# Five-seed objective alternatives: batch cross-correlation and normalized
# linear HSIC (linear CKA), for both covariate- and semantic-OOD settings.
for protocol in closed strict; do
  for seed in "${FIVE_SEEDS[@]}"; do
    extra=()
    [[ "${protocol}" == "closed" ]] && extra+=(--cross-dataset)
    launch_task "${protocol}_objective_alternatives_seed${seed}" \
      --protocol "${protocol}" --tau 80 --models alt_crosscorr,alt_linear_cka \
      --seed "${seed}" "${extra[@]}" "${COMMON[@]}"
  done
done

# Five-seed gate architecture controls, plus the explicit detach audit needed
# because the draft response claims a stop-gradient absent from the frozen code.
for protocol in closed strict; do
  for seed in "${FIVE_SEEDS[@]}"; do
    extra=()
    [[ "${protocol}" == "closed" ]] && extra+=(--cross-dataset)
    launch_task "${protocol}_gate_architecture_seed${seed}" \
      --protocol "${protocol}" --tau 80 \
      --models gate_global,gate_sample_normalized,gate_detached \
      --seed "${seed}" "${extra[@]}" "${COMMON[@]}"
  done
done

# Source-count controls use all four pooling-count source definitions already
# present in the frozen matrix; this additional control holds total trainable
# parameters approximately fixed by changing an active Fuse hidden width.
for seed in "${THREE_SEEDS[@]}"; do
  launch_task "closed_capacity_matched_source_count_seed${seed}" \
    --protocol closed --models capacity --seed "${seed}" --cross-dataset \
    "${COMMON[@]}"
done

# The response letter explicitly promises TMC/TMDF source-count sensitivity.
# Three seeds are the prespecified focused-ablation budget.
for seed in "${THREE_SEEDS[@]}"; do
  launch_task "closed_tmc_tmdf_source_count_seed${seed}" \
    --protocol closed --models tmc_tmdf_source_count --seed "${seed}" \
    --cross-dataset "${COMMON[@]}"
done

wait || true

failed=0
observed=0
for exit_file in "${LOG_DIR}"/*.exit; do
  [[ -e "${exit_file}" ]] || continue
  observed=$((observed + 1))
  status="$(tr -d '[:space:]' < "${exit_file}")"
  if [[ "${status}" != "0" ]]; then
    echo "FAILED: ${exit_file} (exit ${status})" >&2
    failed=$((failed + 1))
  fi
done
if (( observed != 66 )); then
  echo "FAILED: expected 66 task exit files, found ${observed}" >&2
  exit 3
fi
if (( failed != 0 )); then
  echo "FAILED: ${failed} missing-extension task(s) failed" >&2
  exit 1
fi

json_count="$(find "${RESULTS_DIR}" -type f -name 'seed_*.json' | wc -l | tr -d '[:space:]')"
raw_count="$(find "${RESULTS_DIR}" -type f -name 'seed_*_raw.npz' | wc -l | tr -d '[:space:]')"
ood_count="$(find "${RESULTS_DIR}" -type f -name 'seed_*_ood_scores.npz' | wc -l | tr -d '[:space:]')"
if [[ "${json_count}" != "221" || "${raw_count}" != "221" || "${ood_count}" != "221" ]]; then
  echo "FAILED: expected 221 JSON/raw/OOD triplets, found ${json_count}/${raw_count}/${ood_count}" >&2
  exit 4
fi

date --iso-8601=seconds > "${LOG_DIR}/missing_matrix.complete"
echo "All 66 task processes completed: 221 new result/fitting triplets."
