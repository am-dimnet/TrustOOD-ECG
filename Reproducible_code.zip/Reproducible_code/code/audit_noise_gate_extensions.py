#!/usr/bin/env python3
"""Strict, independent audit and aggregation of the noise-gate extension.

The expected design is three gate architectures by three paired seeds.  This
auditor intentionally does not import either training runner.  It reconstructs
the result and checkpoint fingerprints from the frozen output schema, verifies
all file checksums and experiment-time code hashes, inspects every NumPy member
with ``allow_pickle=False``, recomputes the diagnostics that are recoverable
from the archived curves, and emits paired gate comparisons.

The frozen runner originally wrote ``test_record_id`` as an object-dtype NPY
member.  The required serialization migration converts it to fixed Unicode.
This auditor rejects every object array, loads all members with
``allow_pickle=False``, and checks exact record-ID equality across all nine
cells together with test indices, labels, and patient IDs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
import platform
import re
import shlex
import sys
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import scipy
from scipy import stats as scipy_stats
import sklearn
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score


SCRIPT_VERSION = "paper46-noise-gate-audit-v1"
GATES = ("independent_sigmoid", "global_sigmoid", "sample_softmax")
SEEDS = (7, 13, 42)
SNRS: tuple[float | None, ...] = (None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0)
SNR_LABELS = ("clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB")
SOURCES = ("ecg", "hrv", "spec", "sqi")
SQI_NAMES = ("kSQI", "abs_skew_SQI", "pSQI_5_15Hz", "basSQI", "flat", "sat")
EXPECTED_SPLIT = {
    "train": 17418,
    "validation": 2183,
    "test": 2198,
    "rule": "official PTB-XL folds 1-8 / 9 / 10",
}
EXPECTED_CLASS_NAMES = (
    "1AVB", "2AVB", "3AVB", "ABQRS", "AFIB", "AFLT", "ALMI", "AMI",
    "ANEUR", "ASMI", "BIGU", "CLBBB", "CRBBB", "DIG", "EL", "HVOLT",
    "ILBBB", "ILMI", "IMI", "INJAL", "INJAS", "INJIL", "INJIN",
    "INJLA", "INVT", "IPLMI", "IPMI", "IRBBB", "ISCAL", "ISCAN",
    "ISCAS", "ISCIL", "ISCIN", "ISCLA", "ISC_", "IVCD", "LAFB",
    "LAO/LAE", "LMI", "LNGQT", "LOWT", "LPFB", "LPR", "LVH",
    "LVOLT", "NDT", "NORM", "NST_", "NT_", "PAC", "PACE", "PMI",
    "PRC(S)", "PSVT", "PVC", "QWAVE", "RAO/RAE", "RVH", "SARRH",
    "SBRAD", "SEHYP", "STACH", "STD_", "STE_", "SVARR", "SVTAC",
    "TAB_", "TRIGU", "VCLVH", "WPW",
)
EXPECTED_RARE_IDS = (1, 2, 15, 21, 22, 23, 25, 26, 29, 51, 52, 53, 60, 63, 65, 66, 67)
EXPECTED_RESULT_ARRAYS = {
    "snr_db", "snr_label", "test_y", "test_index", "test_record_id",
    "test_patient", "rare_ids", "class_names", "trust_pred", "sqi6",
    "quality", "vacuity", "density", "composite", "sqi_plus_composite",
    "source_w", "source_u",
}
EXPECTED_SELECTION_METHODS = {
    "vacuity_only", "sqi_only", "density_only", "composite", "sqi_plus_composite",
}
EXPECTED_CODE_FILES = (
    "data_adapter.py",
    "revisionlib.py",
    "run_noise_sqi.py",
    "run_ptbxl_missing_extensions.py",
    "run_noise_gate_extensions.py",
)
HEX64 = re.compile(r"^[0-9a-f]{64}$")
FATAL_LOG_PATTERN = re.compile(
    r"Traceback \(most recent call last\)|CUDA out of memory|OutOfMemoryError|"
    r"\bKilled\b|\bFAILED:",
    flags=re.IGNORECASE,
)


def jsonable(value: Any) -> Any:
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [jsonable(item) for item in value]
    return value


def canonical_json_bytes(payload: Any) -> bytes:
    return json.dumps(
        jsonable(payload), sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False,
    ).encode("utf-8")


def fingerprint(payload: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(array)
    return hashlib.sha256(memoryview(contiguous).cast("B")).hexdigest()


def strict_json(path: Path) -> Any:
    def reject_constant(token: str) -> None:
        raise ValueError(f"non-finite JSON token {token!r}")

    return json.loads(path.read_text(encoding="utf-8"), parse_constant=reject_constant)


def atomic_json(payload: Any, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                jsonable(payload), handle, indent=2, sort_keys=True,
                ensure_ascii=False, allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_csv(rows: Sequence[Mapping[str, Any]], fields: Sequence[str], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({field: jsonable(row.get(field)) for field in fields})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def add_issue(issues: list[dict[str, Any]], code: str, path: Path | str, **detail: Any) -> None:
    issues.append({"code": code, "path": str(path), **jsonable(detail)})


def require(
    condition: bool,
    issues: list[dict[str, Any]],
    code: str,
    path: Path | str,
    **detail: Any,
) -> bool:
    if not condition:
        add_issue(issues, code, path, **detail)
        return False
    return True


def finite_number(value: Any) -> bool:
    return isinstance(value, (int, float, np.integer, np.floating)) and math.isfinite(float(value))


def close_scalar(actual: Any, expected: Any, *, atol: float = 1e-7, rtol: float = 1e-6) -> bool:
    if actual is None or expected is None:
        return actual is None and expected is None
    if not finite_number(actual) or not finite_number(expected):
        return False
    return bool(math.isclose(float(actual), float(expected), abs_tol=atol, rel_tol=rtol))


def read_npy_member_header(payload: bytes) -> tuple[tuple[int, ...], bool, np.dtype[Any], tuple[int, int]]:
    stream = io.BytesIO(payload)
    version = np.lib.format.read_magic(stream)
    if version == (1, 0):
        shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(stream)
    elif version in ((2, 0), (3, 0)):
        shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(stream)
    else:
        raise ValueError(f"unsupported NPY version {version}")
    return tuple(int(value) for value in shape), bool(fortran_order), np.dtype(dtype), version


def inspect_npz(
    path: Path,
    expected_keys: set[str] | None,
    issues: list[dict[str, Any]],
    *,
    opaque_object_keys: set[str] | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, dict[str, Any]]]:
    arrays: dict[str, np.ndarray] = {}
    headers: dict[str, dict[str, Any]] = {}
    opaque = opaque_object_keys or set()
    try:
        with zipfile.ZipFile(path, "r") as archive:
            members = archive.namelist()
            require(len(members) == len(set(members)), issues, "duplicate_npz_member", path)
            require(
                all(name.endswith(".npy") and "/" not in name for name in members),
                issues, "unexpected_npz_member_path", path, members=members,
            )
            member_keys = {name[:-4] for name in members if name.endswith(".npy")}
            if expected_keys is not None:
                require(
                    member_keys == expected_keys, issues, "npz_key_set_mismatch", path,
                    expected=sorted(expected_keys), observed=sorted(member_keys),
                )
            for member in members:
                if not member.endswith(".npy"):
                    continue
                key = member[:-4]
                raw = archive.read(member)
                try:
                    shape, fortran_order, dtype, version = read_npy_member_header(raw)
                except Exception as exc:
                    add_issue(issues, "invalid_npy_header", path, member=member, error=repr(exc))
                    continue
                headers[key] = {
                    "shape": list(shape),
                    "fortran_order": fortran_order,
                    "dtype": str(dtype),
                    "has_object": bool(dtype.hasobject),
                    "npy_version": list(version),
                    "member_sha256": hashlib.sha256(raw).hexdigest(),
                    "member_bytes": len(raw),
                }
                if dtype.hasobject and key not in opaque:
                    add_issue(issues, "unexpected_object_array", path, key=key, dtype=str(dtype))
                if not dtype.hasobject and key in opaque:
                    add_issue(issues, "opaque_key_no_longer_object", path, key=key, dtype=str(dtype))
        with np.load(path, allow_pickle=False) as archive:
            for key in archive.files:
                header = headers.get(key)
                if header is None or header["has_object"]:
                    continue
                try:
                    arrays[key] = np.array(archive[key], copy=True)
                except Exception as exc:
                    add_issue(issues, "npz_array_load_failed", path, key=key, error=repr(exc))
    except Exception as exc:
        add_issue(issues, "npz_open_failed", path, error=repr(exc))
    return arrays, headers


def array_equal(left: np.ndarray, right: np.ndarray) -> bool:
    if left.dtype != right.dtype or left.shape != right.shape:
        return False
    if left.dtype.kind in "fc":
        return bool(np.array_equal(left, right, equal_nan=True))
    return bool(np.array_equal(left, right))


def validate_array_shapes(
    arrays: Mapping[str, np.ndarray],
    headers: Mapping[str, Mapping[str, Any]],
    path: Path,
    issues: list[dict[str, Any]],
) -> None:
    n = EXPECTED_SPLIT["test"]
    expected_shapes = {
        "snr_db": (7,), "snr_label": (7,), "test_y": (n,), "test_index": (n,),
        "test_record_id": (n,), "test_patient": (n,),
        "rare_ids": (len(EXPECTED_RARE_IDS),), "class_names": (70,),
        "trust_pred": (7, n), "sqi6": (7, n, 6), "quality": (7, n),
        "vacuity": (7, n), "density": (7, n), "composite": (7, n),
        "sqi_plus_composite": (7, n), "source_w": (7, n, 4),
        "source_u": (7, n, 4),
    }
    for key, shape in expected_shapes.items():
        observed = tuple(headers.get(key, {}).get("shape", ()))
        require(observed == shape, issues, "array_shape_mismatch", path, key=key, expected=shape, observed=observed)
    record_header = headers.get("test_record_id", {})
    require(
        record_header.get("has_object") is False
        and str(record_header.get("dtype", ""))[0:2] in ("<U", "|S", "<S"),
        issues, "record_id_not_safe_fixed_string", path,
        header=record_header,
    )
    for key, value in arrays.items():
        if value.dtype.kind in "iufcb":
            if key == "snr_db":
                valid = value.shape == (7,) and np.isnan(value[0]) and np.all(np.isfinite(value[1:]))
            else:
                valid = bool(np.all(np.isfinite(value)))
            require(valid, issues, "nonfinite_array", path, key=key)
        elif value.dtype.kind in "US":
            require(bool(np.all(np.char.str_len(value.astype(str)) > 0)), issues, "empty_string_array", path, key=key)
    if "snr_db" in arrays:
        expected = np.asarray([np.nan, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0])
        require(np.array_equal(arrays["snr_db"], expected, equal_nan=True), issues, "snr_axis_mismatch", path)
    if "snr_label" in arrays:
        require(tuple(arrays["snr_label"].astype(str)) == SNR_LABELS, issues, "snr_label_axis_mismatch", path)
    if "class_names" in arrays:
        require(tuple(arrays["class_names"].astype(str)) == EXPECTED_CLASS_NAMES, issues, "class_name_axis_mismatch", path)
    if "rare_ids" in arrays:
        require(tuple(int(value) for value in arrays["rare_ids"]) == EXPECTED_RARE_IDS, issues, "rare_id_axis_mismatch", path)
    for key in ("test_y", "trust_pred"):
        if key in arrays:
            require(
                bool(np.all((arrays[key] >= 0) & (arrays[key] < 70))),
                issues, "class_id_out_of_range", path, key=key,
            )
    for key in ("quality", "vacuity", "source_u", "source_w"):
        if key in arrays:
            require(
                bool(np.all((arrays[key] >= -1e-7) & (arrays[key] <= 1.0 + 1e-7))),
                issues, "unit_interval_violation", path, key=key,
            )


def classification_metrics(prediction: np.ndarray, labels: np.ndarray, rare_ids: np.ndarray) -> dict[str, Any]:
    return {
        "accuracy": float(accuracy_score(labels, prediction)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, prediction)),
        "macro_f1": float(
            f1_score(labels, prediction, labels=np.arange(70), average="macro", zero_division=0)
        ),
        "rare_macro_f1": float(
            f1_score(labels, prediction, labels=rare_ids, average="macro", zero_division=0)
        ) if len(rare_ids) else None,
    }


def safe_spearman(left: np.ndarray, right: np.ndarray) -> dict[str, Any]:
    left = np.asarray(left).reshape(-1)
    right = np.asarray(right).reshape(-1)
    n = int(min(len(left), len(right)))
    if len(left) != len(right) or len(left) < 3 or np.ptp(left) == 0 or np.ptp(right) == 0:
        return {"rho": None, "pvalue": None, "n": n}
    result = scipy_stats.spearmanr(left, right)
    rho = float(result.statistic)
    pvalue = float(result.pvalue)
    if not math.isfinite(rho) or not math.isfinite(pvalue):
        return {"rho": None, "pvalue": None, "n": n}
    return {"rho": rho, "pvalue": pvalue, "n": n}


def compare_reported_correlation(
    reported: Mapping[str, Any],
    computed: Mapping[str, Any],
    issues: list[dict[str, Any]],
    path: Path,
    context: str,
) -> None:
    require(reported.get("n") == computed.get("n"), issues, "gate_correlation_n_mismatch", path, context=context, expected=computed.get("n"), observed=reported.get("n"))
    for key in ("rho", "pvalue"):
        require(
            close_scalar(reported.get(key), computed.get(key), atol=1e-8, rtol=1e-5),
            issues, "gate_correlation_value_mismatch", path, context=context,
            field=key, expected=computed.get(key), observed=reported.get(key),
        )


def recompute_gate_diagnostics(
    condition: Mapping[str, Any],
    arrays: Mapping[str, np.ndarray],
    snr_index: int,
    issues: list[dict[str, Any]],
    path: Path,
) -> list[dict[str, Any]]:
    reported = condition.get("gate_correlations")
    if not isinstance(reported, Mapping):
        add_issue(issues, "missing_gate_correlations", path, snr=SNR_LABELS[snr_index])
        return []
    source_w = arrays["source_w"][snr_index]
    labels = arrays["test_y"]
    prediction = arrays["trust_pred"][snr_index]
    sqi = arrays["sqi6"][snr_index]
    quality = arrays["quality"][snr_index]
    correct = (prediction == labels).astype(np.float32)
    compare_reported_correlation(
        reported.get("mean_gate_vs_correctness", {}),
        safe_spearman(source_w.mean(axis=1), correct), issues, path,
        f"{SNR_LABELS[snr_index]}:mean_gate_vs_correctness",
    )
    compare_reported_correlation(
        reported.get("mean_gate_vs_quality", {}),
        safe_spearman(source_w.mean(axis=1), quality), issues, path,
        f"{SNR_LABELS[snr_index]}:mean_gate_vs_quality",
    )
    per_source = reported.get("per_source", {})
    require(set(per_source) == set(SOURCES), issues, "gate_diagnostic_source_set_mismatch", path, snr=SNR_LABELS[snr_index], observed=sorted(per_source))
    rows: list[dict[str, Any]] = []
    for source_index, source in enumerate(SOURCES):
        values = source_w[:, source_index]
        entry = per_source.get(source, {})
        mean = float(np.mean(values))
        std = float(np.std(values))
        require(close_scalar(entry.get("weight_mean"), mean), issues, "gate_weight_mean_mismatch", path, snr=SNR_LABELS[snr_index], source=source)
        require(close_scalar(entry.get("weight_std"), std), issues, "gate_weight_std_mismatch", path, snr=SNR_LABELS[snr_index], source=source)
        compare_reported_correlation(entry.get("weight_vs_correctness", {}), safe_spearman(values, correct), issues, path, f"{SNR_LABELS[snr_index]}:{source}:correct")
        compare_reported_correlation(entry.get("weight_vs_quality", {}), safe_spearman(values, quality), issues, path, f"{SNR_LABELS[snr_index]}:{source}:quality")
        weight_vs_sqi = entry.get("weight_vs_sqi", {})
        require(set(weight_vs_sqi) == set(SQI_NAMES), issues, "gate_sqi_diagnostic_set_mismatch", path, snr=SNR_LABELS[snr_index], source=source)
        for sqi_index, sqi_name in enumerate(SQI_NAMES):
            compare_reported_correlation(
                weight_vs_sqi.get(sqi_name, {}), safe_spearman(values, sqi[:, sqi_index]),
                issues, path, f"{SNR_LABELS[snr_index]}:{source}:{sqi_name}",
            )
        rows.append({
            "snr_label": SNR_LABELS[snr_index], "source": source,
            "weight_mean": mean, "weight_std": std,
            "weight_min": float(np.min(values)), "weight_max": float(np.max(values)),
        })
    return rows


def paired_weight_change(clean: np.ndarray, changed: np.ndarray) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for source_index, source in enumerate(SOURCES):
        delta = changed[:, source_index] - clean[:, source_index]
        scale = float(np.std(delta, ddof=1)) if len(delta) > 1 else 0.0
        result[source] = {
            "clean_mean": float(np.mean(clean[:, source_index])),
            "changed_mean": float(np.mean(changed[:, source_index])),
            "paired_mean_delta": float(np.mean(delta)),
            "paired_median_delta": float(np.median(delta)),
            "paired_cohen_dz": float(np.mean(delta) / scale) if scale > 0 else None,
            "fraction_decreased": float(np.mean(delta < 0)),
        }
    return result


def compare_numeric_mapping(
    reported: Mapping[str, Any],
    computed: Mapping[str, Any],
    issues: list[dict[str, Any]],
    path: Path,
    code: str,
    context: str,
) -> None:
    require(set(reported) == set(computed), issues, f"{code}_field_set_mismatch", path, context=context, expected=sorted(computed), observed=sorted(reported))
    for key, expected in computed.items():
        require(
            close_scalar(reported.get(key), expected, atol=1e-7, rtol=1e-5),
            issues, code, path, context=context, field=key,
            expected=expected, observed=reported.get(key),
        )


def validate_source_corruption(
    payload: Mapping[str, Any],
    arrays: Mapping[str, np.ndarray],
    issues: list[dict[str, Any]],
    path: Path,
) -> list[dict[str, Any]]:
    report = payload.get("source_corruption")
    if not isinstance(report, Mapping):
        add_issue(issues, "missing_source_corruption", path)
        return []
    require(close_scalar(report.get("snr_db"), 0.0), issues, "source_corruption_snr_mismatch", path)
    definition = str(report.get("definition", ""))
    require("holding the other sources" in definition and "shared quality" in definition, issues, "source_corruption_definition_mismatch", path, definition=definition)
    variants = report.get("variants", {})
    expected_variants = {f"source_only:{source}" for source in SOURCES} | {"quality_only", "full_acquisition"}
    require(set(variants) == expected_variants, issues, "source_corruption_variant_set_mismatch", path, expected=sorted(expected_variants), observed=sorted(variants))
    rows: list[dict[str, Any]] = []
    for variant in sorted(expected_variants):
        entry = variants.get(variant, {})
        diagnosis = entry.get("diagnosis", {})
        require(set(diagnosis) == {"accuracy", "balanced_accuracy", "macro_f1", "rare_macro_f1"}, issues, "source_corruption_diagnosis_fields", path, variant=variant)
        for metric, value in diagnosis.items():
            if metric == "rare_macro_f1":
                require(value is None, issues, "source_corruption_rare_metric_should_be_null", path, variant=variant, value=value)
            else:
                require(finite_number(value), issues, "source_corruption_nonfinite_diagnosis", path, variant=variant, metric=metric, value=value)
        changes = entry.get("weight_change", {})
        require(set(changes) == set(SOURCES), issues, "source_corruption_weight_source_set", path, variant=variant, observed=sorted(changes))
        for source in SOURCES:
            source_change = changes.get(source, {})
            expected_fields = {
                "clean_mean", "changed_mean", "paired_mean_delta", "paired_median_delta",
                "paired_cohen_dz", "fraction_decreased",
            }
            require(set(source_change) == expected_fields, issues, "source_corruption_weight_fields", path, variant=variant, source=source, observed=sorted(source_change))
            for field, value in source_change.items():
                require(value is None or finite_number(value), issues, "source_corruption_nonfinite_weight", path, variant=variant, source=source, field=field, value=value)
            rows.append({
                "variant": variant, "source": source,
                "accuracy": diagnosis.get("accuracy"),
                "balanced_accuracy": diagnosis.get("balanced_accuracy"),
                "macro_f1": diagnosis.get("macro_f1"),
                **{field: source_change.get(field) for field in expected_fields},
            })
    if all(key in arrays for key in ("source_w", "trust_pred", "test_y", "rare_ids")):
        zero_index = SNR_LABELS.index("0dB")
        computed_weights = paired_weight_change(arrays["source_w"][0], arrays["source_w"][zero_index])
        full = variants.get("full_acquisition", {})
        for source in SOURCES:
            compare_numeric_mapping(
                full.get("weight_change", {}).get(source, {}), computed_weights[source],
                issues, path, "source_corruption_full_weight_mismatch", source,
            )
        computed_diagnosis = classification_metrics(
            arrays["trust_pred"][zero_index], arrays["test_y"], np.asarray([], dtype=int)
        )
        compare_numeric_mapping(
            full.get("diagnosis", {}), computed_diagnosis, issues, path,
            "source_corruption_full_diagnosis_mismatch", "full_acquisition",
        )
    return rows


def parse_matrix_hashes(path: Path, issues: list[dict[str, Any]]) -> dict[str, str]:
    try:
        text = path.read_text(encoding="utf-8", errors="strict")
    except Exception as exc:
        add_issue(issues, "matrix_manifest_read_failed", path, error=repr(exc))
        return {}
    require("expected_tasks_results_fits=9" in text, issues, "matrix_manifest_expected_count_missing", path)
    hashes: dict[str, str] = {}
    for line in text.splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  (/.+)", line.strip())
        if match:
            digest, recorded_path = match.groups()
            hashes[Path(recorded_path).name] = digest
    require(set(hashes) == set(EXPECTED_CODE_FILES), issues, "matrix_manifest_code_set_mismatch", path, expected=sorted(EXPECTED_CODE_FILES), observed=sorted(hashes))
    return hashes


def validate_logs(log_root: Path, results_root: Path, checkpoint_root: Path, issues: list[dict[str, Any]]) -> dict[str, Any]:
    marker = log_root / "noise_gate_matrix.complete"
    manifest = log_root / "noise_gate_matrix_manifest.txt"
    require(marker.is_file() and bool(marker.read_text(encoding="utf-8", errors="replace").strip()) if marker.is_file() else False, issues, "completion_marker_missing_or_empty", marker)
    require(manifest.is_file(), issues, "matrix_manifest_missing", manifest)
    expected_exit_names = {f"{gate}_seed{seed}.exit" for gate in GATES for seed in SEEDS}
    observed_exit_names = {path.name for path in log_root.glob("*.exit")}
    require(observed_exit_names == expected_exit_names, issues, "exit_file_set_mismatch", log_root, expected=sorted(expected_exit_names), observed=sorted(observed_exit_names))
    for gate in GATES:
        for seed in SEEDS:
            stem = f"{gate}_seed{seed}"
            exit_path = log_root / f"{stem}.exit"
            log_path = log_root / f"{stem}.log"
            command_path = log_root / f"{stem}.command.txt"
            if exit_path.is_file():
                require(exit_path.read_text(encoding="utf-8", errors="replace").strip() == "0", issues, "nonzero_task_exit", exit_path)
            else:
                add_issue(issues, "missing_task_exit", exit_path)
            if log_path.is_file():
                log_text = log_path.read_text(encoding="utf-8", errors="replace")
                require(FATAL_LOG_PATTERN.search(log_text) is None, issues, "fatal_log_signature", log_path)
                expected_saved = str(results_root / gate / "canonical" / f"seed_{seed}.json")
                require(expected_saved in log_text or f"[resume] seed={seed} complete" in log_text, issues, "task_log_has_no_completion_evidence", log_path)
            else:
                add_issue(issues, "missing_task_log", log_path)
            if command_path.is_file():
                try:
                    tokens = shlex.split(command_path.read_text(encoding="utf-8", errors="strict"))
                except Exception as exc:
                    add_issue(issues, "command_parse_failed", command_path, error=repr(exc))
                    tokens = []
                required_pairs = {
                    "--gate-architecture": gate,
                    "--worker-seed": str(seed),
                    "--results-dir": str(results_root),
                    "--checkpoint-dir": str(checkpoint_root),
                    "--snrs": "clean,24,18,12,6,0,-6",
                    "--epochs": "40",
                    "--batch-size": "256",
                    "--eval-batch-size": "512",
                    "--device": "cuda",
                }
                for flag, expected in required_pairs.items():
                    try:
                        observed = tokens[tokens.index(flag) + 1]
                    except (ValueError, IndexError):
                        observed = None
                    require(observed == expected, issues, "command_argument_mismatch", command_path, flag=flag, expected=expected, observed=observed)
                require("--no-run-2x2" in tokens, issues, "command_missing_no_run_2x2", command_path)
            else:
                add_issue(issues, "missing_task_command", command_path)
    return {
        "marker": str(marker),
        "marker_sha256": sha256_file(marker) if marker.is_file() else None,
        "manifest": str(manifest),
        "manifest_sha256": sha256_file(manifest) if manifest.is_file() else None,
        "exit_files": len(observed_exit_names),
    }


def validate_code_hashes(
    experiment_dir: Path,
    manifest_hashes: Mapping[str, str],
    issues: list[dict[str, Any]],
) -> dict[str, str]:
    actual: dict[str, str] = {}
    for name in EXPECTED_CODE_FILES:
        path = experiment_dir / name
        if not path.is_file():
            add_issue(issues, "experiment_code_missing", path)
            continue
        actual[name] = sha256_file(path)
        require(manifest_hashes.get(name) == actual[name], issues, "experiment_code_changed_since_matrix_launch", path, launch_sha256=manifest_hashes.get(name), current_sha256=actual[name])
    return actual


def expected_arguments(gate: str, seed: int, results_root: Path, checkpoint_root: Path) -> dict[str, Any]:
    return {
        "alarm_quantile": 0.95,
        "batch_size": 256,
        "device": "cuda",
        "epochs": 40,
        "eval_batch_size": 512,
        "feature_chunk_size": 256,
        "fixed_coverages": [0.95, 0.9, 0.8, 0.7, 0.5],
        "force": False,
        "gate_architecture": gate,
        "learning_rate": 0.001,
        "limit_test": None,
        "limit_train": None,
        "limit_val": None,
        "q_min_percent": [5.0, 10.0, 20.0, 30.0],
        "rare_threshold": 50,
        "results_dir": str(results_root / gate),
        "retrain_sqi_configs": ["joint_minus20", "joint_plus20", "uniform", "psqi_only"],
        "risk_targets": [0.01, 0.05, 0.1],
        "run_2x2": False,
        "seeds": [7, 13, 42],
        "smoke": False,
        "snrs": [None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0],
        "source_corruption_snr": 0.0,
        "sqi_sensitivity": "none",
        "worker_seed": seed,
        "checkpoint_dir": str(checkpoint_root / gate),
    }


def validate_arguments(
    arguments: Mapping[str, Any],
    gate: str,
    seed: int,
    results_root: Path,
    checkpoint_root: Path,
    issues: list[dict[str, Any]],
    path: Path,
) -> None:
    expected = expected_arguments(gate, seed, results_root, checkpoint_root)
    for key, value in expected.items():
        require(arguments.get(key) == value, issues, "canonical_argument_mismatch", path, argument=key, expected=value, observed=arguments.get(key))
    require(isinstance(arguments.get("cache_dir"), str) and bool(arguments.get("cache_dir")), issues, "cache_dir_missing", path)
    require(isinstance(arguments.get("trustfed_cache"), str) and bool(arguments.get("trustfed_cache")), issues, "trustfed_cache_missing", path)


def validate_checkpoint(
    gate: str,
    seed: int,
    checkpoint_json: Path,
    checkpoint_npz: Path,
    code_hashes: Mapping[str, str],
    issues: list[dict[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, np.ndarray]]:
    if not checkpoint_json.is_file():
        add_issue(issues, "checkpoint_json_missing", checkpoint_json)
        return None, {}
    if not checkpoint_npz.is_file():
        add_issue(issues, "checkpoint_npz_missing", checkpoint_npz)
        return None, {}
    try:
        metadata = strict_json(checkpoint_json)
    except Exception as exc:
        add_issue(issues, "checkpoint_json_invalid", checkpoint_json, error=repr(exc))
        return None, {}
    require(metadata.get("status") == "complete", issues, "checkpoint_not_complete", checkpoint_json)
    require(metadata.get("seed") == seed, issues, "checkpoint_seed_mismatch", checkpoint_json, expected=seed, observed=metadata.get("seed"))
    checkpoint_fingerprint = metadata.get("checkpoint_fingerprint")
    require(isinstance(checkpoint_fingerprint, str) and HEX64.fullmatch(checkpoint_fingerprint) is not None, issues, "checkpoint_fingerprint_invalid", checkpoint_json)
    provenance = metadata.get("checkpoint_provenance")
    if not isinstance(provenance, Mapping):
        add_issue(issues, "checkpoint_provenance_missing", checkpoint_json)
        provenance = {}
    require(fingerprint(provenance) == checkpoint_fingerprint, issues, "checkpoint_fingerprint_reconstruction_failed", checkpoint_json, expected=fingerprint(provenance), observed=checkpoint_fingerprint)
    model = metadata.get("model", {})
    expected_model = {
        "name": "trust_full", "family": "trust", "sqi_source": True,
        "quality_gate": True, "quality_config": "canonical",
        "analysis_role": "primary_gate_architecture", "gate_architecture": gate,
        "detach_gate_uncertainty": False,
    }
    require(model == expected_model, issues, "checkpoint_model_schema_mismatch", checkpoint_json, expected=expected_model, observed=model)
    require(provenance.get("model") == expected_model, issues, "checkpoint_provenance_model_mismatch", checkpoint_json)
    require(provenance.get("training_protocol_version") == "paper46-noise-gate-extensions-v1", issues, "checkpoint_protocol_version_mismatch", checkpoint_json)
    for field, name in (("script_sha256", "run_noise_gate_extensions.py"), ("revisionlib_sha256", "revisionlib.py"), ("data_adapter_sha256", "data_adapter.py")):
        require(provenance.get(field) == code_hashes.get(name), issues, "checkpoint_code_hash_mismatch", checkpoint_json, field=field, expected=code_hashes.get(name), observed=provenance.get(field))
    for key in ("signals_sha256", "record_id_order_sha256", "train_index_sha256", "val_index_sha256", "labels_sha256", "ptbxl_adapter_manifest_sha256"):
        require(isinstance(provenance.get(key), str) and HEX64.fullmatch(provenance.get(key, "")) is not None, issues, "checkpoint_data_hash_invalid", checkpoint_json, field=key, value=provenance.get(key))
    for key, expected in (("seed", seed), ("epochs", 40), ("batch_size", 256), ("learning_rate", 0.001), ("n_classes", 70)):
        require(provenance.get(key) == expected, issues, "checkpoint_training_protocol_mismatch", checkpoint_json, field=key, expected=expected, observed=provenance.get(key))
    require(tuple(provenance.get("class_names", ())) == EXPECTED_CLASS_NAMES, issues, "checkpoint_class_names_mismatch", checkpoint_json)
    weights_sha = sha256_file(checkpoint_npz)
    require(metadata.get("weights_sha256") == weights_sha, issues, "checkpoint_weights_sha_mismatch", checkpoint_json, expected=weights_sha, observed=metadata.get("weights_sha256"))
    require(metadata.get("format") == "allow_pickle=False compressed NumPy state_dict", issues, "checkpoint_format_mismatch", checkpoint_json)
    state, headers = inspect_npz(checkpoint_npz, None, issues)
    require("checkpoint_fingerprint" in state, issues, "checkpoint_npz_fingerprint_missing", checkpoint_npz)
    if "checkpoint_fingerprint" in state:
        require(str(state["checkpoint_fingerprint"].item()) == checkpoint_fingerprint, issues, "checkpoint_npz_fingerprint_mismatch", checkpoint_npz)
    state_keys = {key for key in state if key.startswith("state::")}
    require(bool(state_keys), issues, "checkpoint_state_empty", checkpoint_npz)
    require(set(headers) == set(state), issues, "checkpoint_header_load_key_mismatch", checkpoint_npz, header_keys=sorted(headers), loaded_keys=sorted(state))
    for key in state_keys:
        require(bool(np.all(np.isfinite(state[key]))), issues, "checkpoint_nonfinite_parameter", checkpoint_npz, key=key)
    global_keys = {key for key in state_keys if key.startswith("state::global_gate_logits.")}
    gate_network_keys = {key for key in state_keys if key.startswith("state::gate.")}
    if gate == "global_sigmoid":
        require(global_keys == {f"state::global_gate_logits.{source}" for source in SOURCES}, issues, "global_gate_parameter_set_mismatch", checkpoint_npz, observed=sorted(global_keys))
        require(not gate_network_keys, issues, "global_gate_has_sample_gate_network", checkpoint_npz, observed=sorted(gate_network_keys))
    else:
        require(not global_keys, issues, "sample_gate_has_global_parameters", checkpoint_npz, observed=sorted(global_keys))
        require(bool(gate_network_keys), issues, "sample_gate_network_parameters_missing", checkpoint_npz)
    training = metadata.get("training", {})
    history = training.get("history", []) if isinstance(training, Mapping) else []
    require(len(history) == 40, issues, "checkpoint_history_length_mismatch", checkpoint_json, observed=len(history))
    require([entry.get("epoch") for entry in history if isinstance(entry, Mapping)] == list(range(1, 41)), issues, "checkpoint_epoch_sequence_mismatch", checkpoint_json)
    require(training.get("selection") == "maximum fold-9 macro-AUROC; fold 10 never inspected", issues, "checkpoint_selection_rule_mismatch", checkpoint_json)
    for entry in history:
        if isinstance(entry, Mapping):
            for field in ("loss", "val_macro_auroc", "val_accuracy", "elapsed_seconds"):
                require(finite_number(entry.get(field)), issues, "checkpoint_nonfinite_history", checkpoint_json, epoch=entry.get("epoch"), field=field, value=entry.get(field))
    return metadata, state


def reconstruct_run_fingerprint(
    payload: Mapping[str, Any],
    checkpoint: Mapping[str, Any],
    test_index: np.ndarray,
) -> str:
    arguments = payload["environment"]["arguments"]
    provenance = checkpoint["checkpoint_provenance"]
    run_payload = {
        "script_version": provenance["training_protocol_version"],
        "script_sha256": provenance["script_sha256"],
        "revisionlib_sha256": provenance["revisionlib_sha256"],
        "data_adapter_sha256": provenance["data_adapter_sha256"],
        "adapter_manifest_sha256": provenance["ptbxl_adapter_manifest_sha256"],
        "signals_sha256": provenance["signals_sha256"],
        "record_id_order_sha256": provenance["record_id_order_sha256"],
        "seed": payload["seed"],
        "train_index_sha256": provenance["train_index_sha256"],
        "val_index_sha256": provenance["val_index_sha256"],
        "test_index_sha256": sha256_array(test_index),
        "labels_sha256": provenance["labels_sha256"],
        "class_names": payload["class_names"],
        "models": [checkpoint["model"]],
        "training": {
            "epochs": arguments["epochs"],
            "batch_size": arguments["batch_size"],
            "learning_rate": arguments["learning_rate"],
        },
        "snrs": ["clean" if value is None else f"{value:g}dB" for value in arguments["snrs"]],
        "noise_chunk_size": arguments["feature_chunk_size"],
        "q_min_percent": arguments["q_min_percent"],
        "fixed_coverages": arguments["fixed_coverages"],
        "risk_targets": arguments["risk_targets"],
        "alarm_quantile": arguments["alarm_quantile"],
        "rare_threshold": arguments["rare_threshold"],
        "sqi_sensitivity": arguments["sqi_sensitivity"],
        "retrain_sqi_configs": arguments["retrain_sqi_configs"],
        "run_2x2": arguments["run_2x2"],
        "source_corruption_snr": arguments["source_corruption_snr"],
        "smoke": arguments["smoke"],
        "extension_script_version": "paper46-noise-gate-extensions-v1",
        "extension_script_sha256": payload["environment"]["extension_script_sha256"],
        "base_noise_runner_sha256": payload["environment"]["base_noise_runner_sha256"],
        "gate_architecture": arguments["gate_architecture"],
        "gate_comparison": list(GATES),
    }
    return fingerprint(run_payload)


def validate_condition(
    payload: Mapping[str, Any],
    arrays: Mapping[str, np.ndarray],
    gate: str,
    seed: int,
    snr_index: int,
    issues: list[dict[str, Any]],
    path: Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    label = SNR_LABELS[snr_index]
    condition = payload.get("conditions", {}).get(label, {})
    expected_snr = SNRS[snr_index]
    require(close_scalar(condition.get("snr_db"), expected_snr), issues, "condition_snr_mismatch", path, snr=label, expected=expected_snr, observed=condition.get("snr_db"))
    achieved = condition.get("achieved_snr")
    if expected_snr is None:
        require(achieved is None, issues, "clean_achieved_snr_not_null", path)
    else:
        require(isinstance(achieved, Mapping), issues, "achieved_snr_missing", path, snr=label)
        if isinstance(achieved, Mapping):
            for split in ("validation", "test"):
                mean = achieved.get(f"{split}_mean")
                std = achieved.get(f"{split}_std")
                digest = achieved.get(f"{split}_base_noise_sha256")
                require(close_scalar(mean, expected_snr, atol=1e-4, rtol=0.0), issues, "achieved_snr_mean_mismatch", path, snr=label, split=split, expected=expected_snr, observed=mean)
                require(finite_number(std) and 0.0 <= float(std) <= 1e-4, issues, "achieved_snr_std_too_large", path, snr=label, split=split, observed=std)
                require(isinstance(digest, str) and HEX64.fullmatch(digest) is not None, issues, "base_noise_hash_invalid", path, snr=label, split=split, value=digest)
    diagnosis = condition.get("diagnosis", {})
    computed_diagnosis = classification_metrics(arrays["trust_pred"][snr_index], arrays["test_y"], arrays["rare_ids"])
    compare_numeric_mapping(diagnosis, computed_diagnosis, issues, path, "condition_diagnosis_mismatch", label)
    require(close_scalar(condition.get("mean_quality"), float(np.mean(arrays["quality"][snr_index]))), issues, "condition_mean_quality_mismatch", path, snr=label)
    require(close_scalar(condition.get("mean_vacuity"), float(np.mean(arrays["vacuity"][snr_index]))), issues, "condition_mean_vacuity_mismatch", path, snr=label)
    selection = condition.get("selection", {})
    require(set(selection) == EXPECTED_SELECTION_METHODS, issues, "selection_method_set_mismatch", path, snr=label, expected=sorted(EXPECTED_SELECTION_METHODS), observed=sorted(selection))
    aurc_values: dict[str, Any] = {}
    for method in sorted(EXPECTED_SELECTION_METHODS):
        method_report = selection.get(method, {})
        require(method_report.get("risk_direction") == "higher_is_reject", issues, "selection_risk_direction_mismatch", path, snr=label, method=method)
        for selector in ("condition_matched_fold9", "frozen_clean_fold9"):
            selected = method_report.get(selector, {})
            require(finite_number(selected.get("aurc_ranking_only")), issues, "selection_aurc_invalid", path, snr=label, method=method, selector=selector)
            require(set(selected.get("fixed_coverage", {})) == {"0.95", "0.9", "0.8", "0.7", "0.5"}, issues, "selection_fixed_coverage_set_mismatch", path, snr=label, method=method, selector=selector)
            require(set(selected.get("coverage_at_fixed_risk", {})) == {"0.01", "0.05", "0.1"}, issues, "selection_fixed_risk_set_mismatch", path, snr=label, method=method, selector=selector)
        aurc_values[f"aurc_{method}"] = method_report.get("condition_matched_fold9", {}).get("aurc_ranking_only")
    diagnostic_rows = recompute_gate_diagnostics(condition, arrays, snr_index, issues, path)
    source_w = arrays["source_w"][snr_index]
    row = {
        "gate": gate, "seed": seed, "snr_label": label,
        "snr_db": expected_snr,
        **{f"diagnosis_{key}": value for key, value in computed_diagnosis.items()},
        "mean_quality": float(np.mean(arrays["quality"][snr_index])),
        "mean_vacuity": float(np.mean(arrays["vacuity"][snr_index])),
        "gate_sum_mean": float(np.mean(source_w.sum(axis=1))),
        "gate_sum_std": float(np.std(source_w.sum(axis=1))),
        "sample_softmax_max_row_sum_error": float(np.max(np.abs(source_w.sum(axis=1) - 1.0))) if gate == "sample_softmax" else None,
        **aurc_values,
    }
    for source_index, source in enumerate(SOURCES):
        row[f"gate_{source}_mean"] = float(np.mean(source_w[:, source_index]))
        row[f"gate_{source}_std"] = float(np.std(source_w[:, source_index]))
    return row, diagnostic_rows


def validate_result_cell(
    gate: str,
    seed: int,
    results_root: Path,
    checkpoint_root: Path,
    code_hashes: Mapping[str, str],
    issues: list[dict[str, Any]],
) -> dict[str, Any] | None:
    result_json = results_root / gate / "canonical" / f"seed_{seed}.json"
    result_npz = results_root / gate / "canonical" / f"seed_{seed}_curves.npz"
    checkpoint_json = checkpoint_root / gate / "canonical" / "trust_full" / f"seed_{seed}.json"
    checkpoint_npz = checkpoint_root / gate / "canonical" / "trust_full" / f"seed_{seed}.npz"
    if not result_json.is_file():
        add_issue(issues, "result_json_missing", result_json)
        return None
    if not result_npz.is_file():
        add_issue(issues, "result_npz_missing", result_npz)
        return None
    try:
        payload = strict_json(result_json)
    except Exception as exc:
        add_issue(issues, "result_json_invalid", result_json, error=repr(exc))
        return None
    checkpoint, checkpoint_state = validate_checkpoint(
        gate, seed, checkpoint_json, checkpoint_npz, code_hashes, issues
    )
    arrays, headers = inspect_npz(result_npz, EXPECTED_RESULT_ARRAYS, issues)
    validate_array_shapes(arrays, headers, result_npz, issues)
    required_loaded = EXPECTED_RESULT_ARRAYS
    if not required_loaded.issubset(arrays):
        add_issue(issues, "required_result_arrays_not_loaded", result_npz, missing=sorted(required_loaded - set(arrays)))
        return None
    require(payload.get("status") == "complete", issues, "result_not_complete", result_json)
    require(payload.get("canonical") is True, issues, "result_not_canonical", result_json)
    require(payload.get("full_fold_run") is True, issues, "result_not_full_fold", result_json)
    require(payload.get("seed") == seed, issues, "result_seed_mismatch", result_json, expected=seed, observed=payload.get("seed"))
    require(payload.get("split") == EXPECTED_SPLIT, issues, "result_split_mismatch", result_json, expected=EXPECTED_SPLIT, observed=payload.get("split"))
    require(payload.get("n_classes") == 70, issues, "result_class_count_mismatch", result_json)
    require(tuple(payload.get("class_names", ())) == EXPECTED_CLASS_NAMES, issues, "result_class_names_mismatch", result_json)
    require(tuple(payload.get("rare_ids", ())) == EXPECTED_RARE_IDS, issues, "result_rare_ids_mismatch", result_json)
    require(payload.get("rare_definition") == "folds1-8 record count < 50", issues, "result_rare_definition_mismatch", result_json)
    expected_rare_names = [EXPECTED_CLASS_NAMES[index] for index in EXPECTED_RARE_IDS]
    require(payload.get("rare_names") == expected_rare_names, issues, "result_rare_names_mismatch", result_json)
    require(set(payload.get("conditions", {})) == set(SNR_LABELS), issues, "condition_set_mismatch", result_json, expected=sorted(SNR_LABELS), observed=sorted(payload.get("conditions", {})))
    guards = payload.get("protocol_guards", {})
    expected_guards = {
        "thresholds_fold9_only": True,
        "density_fit_folds1_8_only": True,
        "density_reference_clean_fold9_only": True,
        "hrv_imputation_folds1_8_only": True,
        "test_tuning": False,
        "all_noisy_ecg_sources_recomputed": ["sqi6", "quality", "hrv8", "spec36"],
        "noise_realisation_paired_across_snr": True,
        "score_direction": "higher means reject / more OOD",
    }
    require(guards == expected_guards, issues, "protocol_guard_mismatch", result_json, expected=expected_guards, observed=guards)
    require(payload.get("source_sqi_input_x_quality_gate_2x2") is None, issues, "unexpected_2x2_payload", result_json)
    require(payload.get("sqi_coefficient_sensitivity_inference_only") == {}, issues, "unexpected_sqi_sensitivity_payload", result_json)
    require(payload.get("trained_model_robustness") == {}, issues, "unexpected_trained_robustness_payload", result_json)
    require(payload.get("retrained_sqi_model_names") == [], issues, "unexpected_retrained_sqi_names", result_json)
    canonical_quality = payload.get("quality_configs", {}).get("canonical", {})
    expected_quality = {
        "name": "canonical", "family": "canonical",
        "coefficients": [0.2, 0.0, 0.5, 0.3, -0.5, -0.5],
        "description": "Paper46 sigmoid quality: sigmoid(6*(c dot SQI - 0.3))",
        "degenerate_with": None,
    }
    require(canonical_quality == expected_quality, issues, "canonical_quality_config_mismatch", result_json, expected=expected_quality, observed=canonical_quality)
    recomputed_quality_input = arrays["sqi6"].astype(np.float64, copy=True)
    recomputed_quality_input[..., 0] = np.clip(recomputed_quality_input[..., 0], 0.0, 1.0)
    linear = recomputed_quality_input @ np.asarray(expected_quality["coefficients"], dtype=np.float64) - 0.3
    recomputed_quality = (1.0 / (1.0 + np.exp(-6.0 * linear))).astype(np.float32)
    require(np.allclose(arrays["quality"], recomputed_quality, atol=2e-6, rtol=2e-6), issues, "quality_not_recomputed_from_sqi", result_npz, max_abs_error=float(np.max(np.abs(arrays["quality"] - recomputed_quality))))
    for snr_index in range(1, len(SNR_LABELS)):
        for key in ("sqi6", "quality"):
            require(not np.array_equal(arrays[key][0], arrays[key][snr_index]), issues, "derived_source_unchanged_from_clean", result_npz, snr=SNR_LABELS[snr_index], source=key)
        for source_index, source in enumerate(SOURCES):
            require(not np.array_equal(arrays["source_u"][0, :, source_index], arrays["source_u"][snr_index, :, source_index]), issues, "source_evidence_unchanged_from_clean", result_npz, snr=SNR_LABELS[snr_index], source=source)
    density = payload.get("density", {})
    require(density.get("source_names") == list(SOURCES), issues, "density_source_order_mismatch", result_json)
    require(density.get("feature_dim") == {source: 128 for source in SOURCES}, issues, "density_feature_dim_mismatch", result_json)
    require(density.get("class_counts_used") == {source: 70 for source in SOURCES}, issues, "density_class_count_mismatch", result_json)
    require(density.get("covariance") == "LedoitWolf pooled within-class residuals" and density.get("ridge") == 0.001 and density.get("standardize") is True, issues, "density_configuration_mismatch", result_json)
    environment = payload.get("environment", {})
    require(environment.get("script_version") == "paper46-noise-gate-extensions-v1", issues, "result_script_version_mismatch", result_json)
    require(environment.get("gate_architecture") == gate, issues, "environment_gate_mismatch", result_json)
    require(environment.get("extension_script_sha256") == code_hashes.get("run_noise_gate_extensions.py"), issues, "extension_script_hash_mismatch", result_json)
    require(environment.get("base_noise_runner_sha256") == code_hashes.get("run_noise_sqi.py"), issues, "base_runner_hash_mismatch", result_json)
    require(environment.get("cuda_available") is True and environment.get("device") == "cuda" and bool(environment.get("gpu")), issues, "result_not_cuda", result_json, cuda_available=environment.get("cuda_available"), device=environment.get("device"), gpu=environment.get("gpu"))
    arguments = environment.get("arguments", {})
    validate_arguments(arguments, gate, seed, results_root, checkpoint_root, issues, result_json)
    raw_info = payload.get("raw_npz", {})
    raw_sha = sha256_file(result_npz)
    require(raw_info.get("path") == str(result_npz), issues, "raw_npz_path_mismatch", result_json, expected=str(result_npz), observed=raw_info.get("path"))
    require(raw_info.get("sha256") == raw_sha, issues, "raw_npz_sha_mismatch", result_json, expected=raw_sha, observed=raw_info.get("sha256"))
    run_fingerprint = payload.get("run_fingerprint")
    require(isinstance(run_fingerprint, str) and HEX64.fullmatch(run_fingerprint) is not None, issues, "run_fingerprint_invalid", result_json)
    if checkpoint is not None:
        training = payload.get("training", {}).get("trust_full", {})
        require(training.get("checkpoint_fingerprint") == checkpoint.get("checkpoint_fingerprint"), issues, "result_checkpoint_fingerprint_mismatch", result_json)
        require(training.get("training") == checkpoint.get("training"), issues, "result_checkpoint_training_mismatch", result_json)
        reconstructed = reconstruct_run_fingerprint(payload, checkpoint, arrays["test_index"])
        require(reconstructed == run_fingerprint, issues, "run_fingerprint_reconstruction_failed", result_json, expected=reconstructed, observed=run_fingerprint)
    condition_rows: list[dict[str, Any]] = []
    diagnostic_rows: list[dict[str, Any]] = []
    for snr_index in range(len(SNR_LABELS)):
        row, diagnostics = validate_condition(payload, arrays, gate, seed, snr_index, issues, result_json)
        condition_rows.append(row)
        for diagnostic in diagnostics:
            diagnostic_rows.append({"gate": gate, "seed": seed, **diagnostic})
    noisy_achieved = [payload["conditions"][label]["achieved_snr"] for label in SNR_LABELS[1:]]
    for split in ("validation", "test"):
        hashes = {entry[f"{split}_base_noise_sha256"] for entry in noisy_achieved}
        require(len(hashes) == 1, issues, "unpaired_base_noise_across_snr", result_json, split=split, observed=sorted(hashes))
    source_corruption_rows = validate_source_corruption(payload, arrays, issues, result_json)
    for row in source_corruption_rows:
        row.update({"gate": gate, "seed": seed})
    if gate == "sample_softmax":
        row_sum_error = float(np.max(np.abs(arrays["source_w"].sum(axis=2) - 1.0)))
        require(row_sum_error <= 2e-6, issues, "sample_softmax_rows_not_normalized", result_npz, max_abs_error=row_sum_error)
    if gate == "global_sigmoid":
        for source_index, source in enumerate(SOURCES):
            values = arrays["source_w"][..., source_index]
            require(float(np.max(values) - np.min(values)) <= 2e-6, issues, "global_gate_is_sample_dependent", result_npz, source=source, value_range=float(np.max(values) - np.min(values)))
            key = f"state::global_gate_logits.{source}"
            if key in checkpoint_state:
                logit = float(checkpoint_state[key].reshape(-1)[0])
                expected_weight = 1.0 / (1.0 + math.exp(-logit))
                require(np.allclose(values, expected_weight, atol=2e-6, rtol=2e-6), issues, "global_gate_weight_checkpoint_mismatch", result_npz, source=source, expected=expected_weight, observed_mean=float(np.mean(values)))
    return {
        "gate": gate,
        "seed": seed,
        "payload": payload,
        "arrays": arrays,
        "headers": headers,
        "result_json": result_json,
        "result_npz": result_npz,
        "checkpoint_json": checkpoint_json,
        "checkpoint_npz": checkpoint_npz,
        "condition_rows": condition_rows,
        "diagnostic_rows": diagnostic_rows,
        "source_corruption_rows": source_corruption_rows,
        "record_id_member_sha256": headers.get("test_record_id", {}).get("member_sha256"),
    }


def validate_exact_file_sets(results_root: Path, checkpoint_root: Path, issues: list[dict[str, Any]]) -> None:
    expected_result_json = {results_root / gate / "canonical" / f"seed_{seed}.json" for gate in GATES for seed in SEEDS}
    expected_result_npz = {results_root / gate / "canonical" / f"seed_{seed}_curves.npz" for gate in GATES for seed in SEEDS}
    observed_result_json = set(results_root.rglob("seed_*.json")) if results_root.is_dir() else set()
    observed_result_npz = set(results_root.rglob("seed_*_curves.npz")) if results_root.is_dir() else set()
    require(observed_result_json == expected_result_json, issues, "result_json_file_set_mismatch", results_root, expected=sorted(map(str, expected_result_json)), observed=sorted(map(str, observed_result_json)))
    require(observed_result_npz == expected_result_npz, issues, "result_npz_file_set_mismatch", results_root, expected=sorted(map(str, expected_result_npz)), observed=sorted(map(str, observed_result_npz)))
    expected_checkpoint_json = {checkpoint_root / gate / "canonical" / "trust_full" / f"seed_{seed}.json" for gate in GATES for seed in SEEDS}
    expected_checkpoint_npz = {checkpoint_root / gate / "canonical" / "trust_full" / f"seed_{seed}.npz" for gate in GATES for seed in SEEDS}
    observed_checkpoint_json = set(checkpoint_root.rglob("seed_*.json")) if checkpoint_root.is_dir() else set()
    observed_checkpoint_npz = set(checkpoint_root.rglob("seed_*.npz")) if checkpoint_root.is_dir() else set()
    require(observed_checkpoint_json == expected_checkpoint_json, issues, "checkpoint_json_file_set_mismatch", checkpoint_root, expected=sorted(map(str, expected_checkpoint_json)), observed=sorted(map(str, observed_checkpoint_json)))
    require(observed_checkpoint_npz == expected_checkpoint_npz, issues, "checkpoint_npz_file_set_mismatch", checkpoint_root, expected=sorted(map(str, expected_checkpoint_npz)), observed=sorted(map(str, observed_checkpoint_npz)))


def validate_pairing(cells: Sequence[Mapping[str, Any]], issues: list[dict[str, Any]]) -> dict[str, Any]:
    if not cells:
        add_issue(issues, "no_valid_cells_for_pairing", "pairing")
        return {}
    reference = cells[0]
    reference_arrays = reference["arrays"]
    identity_keys = (
        "test_index", "test_y", "test_record_id", "test_patient", "rare_ids",
        "class_names", "snr_db", "snr_label",
    )
    for cell in cells[1:]:
        for key in identity_keys:
            require(array_equal(cell["arrays"][key], reference_arrays[key]), issues, "paired_identity_array_mismatch", cell["result_npz"], key=key, reference=str(reference["result_npz"]))
        require(cell["record_id_member_sha256"] == reference["record_id_member_sha256"], issues, "paired_record_id_member_mismatch", cell["result_npz"], expected=reference["record_id_member_sha256"], observed=cell["record_id_member_sha256"])
    by_seed: dict[int, list[Mapping[str, Any]]] = defaultdict(list)
    for cell in cells:
        by_seed[int(cell["seed"])].append(cell)
    for seed in SEEDS:
        seed_cells = by_seed.get(seed, [])
        require(len(seed_cells) == 3, issues, "paired_gate_cell_count_mismatch", "pairing", seed=seed, observed=len(seed_cells))
        if len(seed_cells) != 3:
            continue
        base = seed_cells[0]
        for cell in seed_cells[1:]:
            for key in ("sqi6", "quality"):
                require(array_equal(cell["arrays"][key], base["arrays"][key]), issues, "derived_inputs_not_paired_across_gates", cell["result_npz"], seed=seed, key=key, reference=str(base["result_npz"]))
            for label in SNR_LABELS[1:]:
                left = base["payload"]["conditions"][label]["achieved_snr"]
                right = cell["payload"]["conditions"][label]["achieved_snr"]
                require(left == right, issues, "achieved_noise_not_paired_across_gates", cell["result_json"], seed=seed, snr=label, reference=str(base["result_json"]))
    run_fingerprints = [cell["payload"].get("run_fingerprint") for cell in cells]
    checkpoint_fingerprints = [cell["payload"].get("training", {}).get("trust_full", {}).get("checkpoint_fingerprint") for cell in cells]
    require(len(set(run_fingerprints)) == 9, issues, "run_fingerprints_not_unique", "pairing", observed=run_fingerprints)
    require(len(set(checkpoint_fingerprints)) == 9, issues, "checkpoint_fingerprints_not_unique", "pairing", observed=checkpoint_fingerprints)
    common_provenance_keys = (
        "signals_sha256", "record_id_order_sha256", "train_index_sha256",
        "val_index_sha256", "labels_sha256", "ptbxl_adapter_manifest_sha256",
    )
    first_checkpoint = strict_json(reference["checkpoint_json"])
    for cell in cells[1:]:
        checkpoint = strict_json(cell["checkpoint_json"])
        for key in common_provenance_keys:
            require(checkpoint["checkpoint_provenance"].get(key) == first_checkpoint["checkpoint_provenance"].get(key), issues, "common_data_fingerprint_mismatch", cell["checkpoint_json"], field=key, expected=first_checkpoint["checkpoint_provenance"].get(key), observed=checkpoint["checkpoint_provenance"].get(key))
    return {
        "paired_cells": len(cells),
        "test_records": int(reference_arrays["test_index"].shape[0]),
        "record_id_member_sha256": reference["record_id_member_sha256"],
        "record_id_validation": (
            "fixed-string array loaded with allow_pickle=False; exact values and "
            "NPY member SHA-256 equal across all cells"
        ),
        "identity_arrays": list(identity_keys),
        "gate_paired_derived_arrays": ["sqi6", "quality", "achieved_snr/base-noise hashes"],
    }


SUMMARY_METRICS = (
    "diagnosis_accuracy", "diagnosis_balanced_accuracy", "diagnosis_macro_f1",
    "diagnosis_rare_macro_f1", "mean_quality", "mean_vacuity",
    "gate_sum_mean", "gate_sum_std", "gate_ecg_mean", "gate_hrv_mean",
    "gate_spec_mean", "gate_sqi_mean", "aurc_vacuity_only",
    "aurc_sqi_only", "aurc_density_only", "aurc_composite",
    "aurc_sqi_plus_composite",
)


def aggregate_rows(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["gate"]), str(row["snr_label"]))].append(row)
    output: list[dict[str, Any]] = []
    for (gate, snr_label), group in sorted(grouped.items(), key=lambda item: (GATES.index(item[0][0]), SNR_LABELS.index(item[0][1]))):
        for metric in SUMMARY_METRICS:
            values = np.asarray([row.get(metric) for row in group if finite_number(row.get(metric))], dtype=float)
            if not len(values):
                continue
            output.append({
                "gate": gate, "snr_label": snr_label, "metric": metric,
                "n_seed": int(len(values)), "mean": float(np.mean(values)),
                "std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
                "min": float(np.min(values)), "max": float(np.max(values)),
            })
    return output


def paired_statistics(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    indexed = {(str(row["gate"]), int(row["seed"]), str(row["snr_label"])): row for row in rows}
    comparisons = (
        ("independent_sigmoid", "global_sigmoid"),
        ("independent_sigmoid", "sample_softmax"),
        ("global_sigmoid", "sample_softmax"),
    )
    output: list[dict[str, Any]] = []
    for snr_label in SNR_LABELS:
        for metric in SUMMARY_METRICS:
            for gate_a, gate_b in comparisons:
                pairs: list[tuple[float, float, int]] = []
                for seed in SEEDS:
                    left = indexed.get((gate_a, seed, snr_label), {}).get(metric)
                    right = indexed.get((gate_b, seed, snr_label), {}).get(metric)
                    if finite_number(left) and finite_number(right):
                        pairs.append((float(left), float(right), seed))
                if len(pairs) != 3:
                    continue
                left = np.asarray([item[0] for item in pairs], dtype=float)
                right = np.asarray([item[1] for item in pairs], dtype=float)
                delta = left - right
                mean = float(np.mean(delta))
                std = float(np.std(delta, ddof=1))
                sem = std / math.sqrt(len(delta))
                critical = float(scipy_stats.t.ppf(0.975, len(delta) - 1))
                if np.all(delta == 0):
                    t_statistic, t_pvalue = 0.0, 1.0
                    wilcoxon_statistic, wilcoxon_pvalue = 0.0, 1.0
                else:
                    t_result = scipy_stats.ttest_rel(left, right)
                    t_statistic = float(t_result.statistic)
                    t_pvalue = float(t_result.pvalue)
                    try:
                        w_result = scipy_stats.wilcoxon(left, right, zero_method="wilcox", alternative="two-sided", method="auto")
                        wilcoxon_statistic = float(w_result.statistic)
                        wilcoxon_pvalue = float(w_result.pvalue)
                    except ValueError:
                        wilcoxon_statistic, wilcoxon_pvalue = None, None
                output.append({
                    "scope": "snr_condition", "context": snr_label,
                    "metric": metric, "gate_a": gate_a, "gate_b": gate_b,
                    "difference": "gate_a - gate_b", "n_pairs": len(delta),
                    "seeds": ",".join(str(item[2]) for item in pairs),
                    "gate_a_mean": float(np.mean(left)),
                    "gate_b_mean": float(np.mean(right)),
                    "mean_difference": mean, "std_difference": std,
                    "ci95_low": mean - critical * sem,
                    "ci95_high": mean + critical * sem,
                    "paired_cohen_dz": mean / std if std > 0 else None,
                    "paired_t_statistic": t_statistic,
                    "paired_t_pvalue": t_pvalue,
                    "paired_t_pvalue_holm": None,
                    "wilcoxon_statistic": wilcoxon_statistic,
                    "wilcoxon_pvalue": wilcoxon_pvalue,
                })
    finite_indices = [index for index, row in enumerate(output) if finite_number(row.get("paired_t_pvalue"))]
    ordered = sorted(finite_indices, key=lambda index: float(output[index]["paired_t_pvalue"]))
    running = 0.0
    total = len(ordered)
    for rank, index in enumerate(ordered):
        adjusted = min(1.0, (total - rank) * float(output[index]["paired_t_pvalue"]))
        running = max(running, adjusted)
        output[index]["paired_t_pvalue_holm"] = running
    return output


def build_inventory(paths: Iterable[Path]) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(set(paths)):
        if path.is_file():
            rows.append({"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    return rows


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-root", type=Path, default=Path("/dev/shm/Paper46_revision_results_missing/noise_gate"))
    parser.add_argument("--checkpoint-root", type=Path, default=Path("/dev/shm/Paper46_revision_checkpoints_missing/noise_gate"))
    parser.add_argument("--log-root", type=Path, default=Path("/dev/shm/Paper46_logs_missing/noise_gate"))
    parser.add_argument("--experiment-dir", type=Path, default=Path("/root/Paper46_revision/experiments"))
    parser.add_argument("--output-dir", type=Path, default=Path("/dev/shm/Paper46_aggregate_final/noise_gate_extensions"))
    parser.add_argument("--fail-on-incomplete", action=argparse.BooleanOptionalAction, default=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    results_root = args.results_root.resolve()
    checkpoint_root = args.checkpoint_root.resolve()
    log_root = args.log_root.resolve()
    experiment_dir = args.experiment_dir.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    issues: list[dict[str, Any]] = []
    for root, label in ((results_root, "results"), (checkpoint_root, "checkpoints"), (log_root, "logs"), (experiment_dir, "experiment_code")):
        require(root.is_dir(), issues, f"{label}_root_missing", root)
    validate_exact_file_sets(results_root, checkpoint_root, issues)
    log_summary = validate_logs(log_root, results_root, checkpoint_root, issues)
    matrix_manifest = log_root / "noise_gate_matrix_manifest.txt"
    manifest_hashes = parse_matrix_hashes(matrix_manifest, issues) if matrix_manifest.is_file() else {}
    code_hashes = validate_code_hashes(experiment_dir, manifest_hashes, issues)
    cells: list[dict[str, Any]] = []
    for gate in GATES:
        for seed in SEEDS:
            try:
                cell = validate_result_cell(
                    gate, seed, results_root, checkpoint_root, code_hashes, issues
                )
            except Exception as exc:
                result_path = results_root / gate / "canonical" / f"seed_{seed}.json"
                add_issue(issues, "unexpected_cell_audit_exception", result_path, gate=gate, seed=seed, error=repr(exc))
                cell = None
            if cell is not None:
                cells.append(cell)
    pairing_summary = validate_pairing(cells, issues)
    condition_rows = [row for cell in cells for row in cell["condition_rows"]]
    diagnostic_rows = [row for cell in cells for row in cell["diagnostic_rows"]]
    corruption_rows = [row for cell in cells for row in cell["source_corruption_rows"]]
    aggregate = aggregate_rows(condition_rows)
    paired = paired_statistics(condition_rows)
    condition_fields = (
        "gate", "seed", "snr_label", "snr_db", "diagnosis_accuracy",
        "diagnosis_balanced_accuracy", "diagnosis_macro_f1",
        "diagnosis_rare_macro_f1", "mean_quality", "mean_vacuity",
        "gate_sum_mean", "gate_sum_std", "sample_softmax_max_row_sum_error",
        "gate_ecg_mean", "gate_ecg_std", "gate_hrv_mean", "gate_hrv_std",
        "gate_spec_mean", "gate_spec_std", "gate_sqi_mean", "gate_sqi_std",
        "aurc_vacuity_only", "aurc_sqi_only", "aurc_density_only",
        "aurc_composite", "aurc_sqi_plus_composite",
    )
    aggregate_fields = ("gate", "snr_label", "metric", "n_seed", "mean", "std", "min", "max")
    paired_fields = (
        "scope", "context", "metric", "gate_a", "gate_b", "difference",
        "n_pairs", "seeds", "gate_a_mean", "gate_b_mean", "mean_difference",
        "std_difference", "ci95_low", "ci95_high", "paired_cohen_dz",
        "paired_t_statistic", "paired_t_pvalue", "paired_t_pvalue_holm",
        "wilcoxon_statistic", "wilcoxon_pvalue",
    )
    diagnostic_fields = (
        "gate", "seed", "snr_label", "source", "weight_mean", "weight_std",
        "weight_min", "weight_max",
    )
    corruption_fields = (
        "gate", "seed", "variant", "source", "accuracy", "balanced_accuracy",
        "macro_f1", "clean_mean", "changed_mean", "paired_mean_delta",
        "paired_median_delta", "paired_cohen_dz", "fraction_decreased",
    )
    output_paths = {
        "summary_json": output_dir / "summary.json",
        "summary_runs_csv": output_dir / "summary_runs.csv",
        "summary_aggregate_csv": output_dir / "summary_aggregate.csv",
        "paired_statistics_csv": output_dir / "paired_statistics.csv",
        "gate_diagnostics_csv": output_dir / "gate_diagnostics.csv",
        "source_corruption_csv": output_dir / "source_corruption.csv",
        "artifact_inventory_csv": output_dir / "artifact_inventory.csv",
    }
    atomic_csv(condition_rows, condition_fields, output_paths["summary_runs_csv"])
    atomic_csv(aggregate, aggregate_fields, output_paths["summary_aggregate_csv"])
    atomic_csv(paired, paired_fields, output_paths["paired_statistics_csv"])
    atomic_csv(diagnostic_rows, diagnostic_fields, output_paths["gate_diagnostics_csv"])
    atomic_csv(corruption_rows, corruption_fields, output_paths["source_corruption_csv"])
    source_artifacts = [
        path for cell in cells for path in (
            cell["result_json"], cell["result_npz"],
            cell["checkpoint_json"], cell["checkpoint_npz"],
        )
    ]
    source_artifacts.extend(log_root.glob("*"))
    source_artifacts.extend(experiment_dir / name for name in EXPECTED_CODE_FILES)
    inventory = build_inventory(source_artifacts)
    atomic_csv(inventory, ("path", "bytes", "sha256"), output_paths["artifact_inventory_csv"])
    complete = (
        not issues
        and len(cells) == 9
        and len(condition_rows) == 63
        and len(diagnostic_rows) == 252
        and len(corruption_rows) == 216
    )
    summary_payload = {
        "script_version": SCRIPT_VERSION,
        "complete": complete,
        "issue_count": len(issues),
        "expected": {
            "gates": list(GATES), "seeds": list(SEEDS), "cells": 9,
            "conditions_per_cell": 7, "source_corruption_variants": 6,
            "sources": list(SOURCES),
        },
        "observed": {
            "valid_cells": len(cells), "condition_rows": len(condition_rows),
            "gate_diagnostic_rows": len(diagnostic_rows),
            "source_corruption_rows": len(corruption_rows),
            "aggregate_rows": len(aggregate), "paired_statistics_rows": len(paired),
        },
        "pairing": pairing_summary,
        "log_audit": log_summary,
        "code_hashes": code_hashes,
        "matrix_launch_code_hashes": manifest_hashes,
        "issues": issues,
        "condition_rows": condition_rows,
        "aggregate": aggregate,
        "paired_statistics": paired,
    }
    atomic_json(summary_payload, output_paths["summary_json"])
    output_inventory = build_inventory(output_paths.values())
    manifest_payload = {
        "script_version": SCRIPT_VERSION,
        "complete": complete,
        "issue_count": len(issues),
        "issues": issues,
        "roots": {
            "results": str(results_root), "checkpoints": str(checkpoint_root),
            "logs": str(log_root), "experiment_code": str(experiment_dir),
            "output": str(output_dir),
        },
        "expected_cells": 9,
        "observed_valid_cells": len(cells),
        "expected_condition_rows": 63,
        "observed_condition_rows": len(condition_rows),
        "paired_record_audit": pairing_summary,
        "code_hashes": code_hashes,
        "outputs": output_inventory,
        "runtime": {
            "python": platform.python_version(), "numpy": np.__version__,
            "scipy": scipy.__version__, "sklearn": sklearn.__version__,
            "platform": platform.platform(),
        },
        "auditor_sha256": sha256_file(Path(__file__).resolve()),
    }
    atomic_json(manifest_payload, output_dir / "result_manifest.json")
    atomic_json(manifest_payload, output_dir / "audit_manifest.json")
    print(json.dumps({"complete": complete, "issue_count": len(issues), "valid_cells": len(cells), "output_dir": str(output_dir)}, sort_keys=True), flush=True)
    if args.fail_on_incomplete and not complete:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
