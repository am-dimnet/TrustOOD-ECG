#!/usr/bin/env python3
"""
Preprocess MHEALTH (Banos et al., 2014) as a CROSS-DEVICE, PPG-ABSENT test set
for CALM: 2-lead chest ECG + body ACC at 50 Hz, no PPG.  Used to evaluate
graceful degradation when the whole PPG modality is unavailable and the sensor
suite / sampling rate differ from the wrist-Empatica training device.

Columns (24, 50 Hz): 1-3 chest ACC (m/s^2), 4-5 ECG lead1/2, 15-17 right-lower-
arm ACC (wrist proxy), 24 activity label (0 null, 1-12 activities).
Windows are resampled to the DaLiA layout: ECG@140Hz(1120), ACC@32Hz(256).
"""
from __future__ import annotations
import argparse, glob, os, sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from utils.signal_utils import (butter_bandpass, butter_highpass, zscore, resample_to,
                                 ecg_sqi, acc_motion_intensity,
                                 detect_rpeaks, windowed_hr_from_rpeaks)

FS_IN = 50
FS_ACC, FS_ECG_OUT = 32, 140
WIN_S, HOP_S = 8, 2
L_ACC, L_ECG = WIN_S * FS_ACC, WIN_S * FS_ECG_OUT
G = 9.81


def process_file(path):
    raw = np.loadtxt(path)
    ecg = raw[:, 3].astype(np.float64)             # lead 1
    acc = raw[:, 14:17].astype(np.float64) / G     # right-lower-arm, m/s^2 -> g
    lab = raw[:, 23].astype(np.int64)
    dur = len(ecg) / FS_IN
    n_win = int((dur - WIN_S) // HOP_S) + 1

    ecg_140 = resample_to(ecg, FS_IN, FS_ECG_OUT)
    ecg_f = butter_bandpass(ecg_140, FS_ECG_OUT, 0.5, 40.0)
    acc_32 = np.stack([resample_to(acc[:, k], FS_IN, FS_ACC) for k in range(3)], 0)  # (3,T)
    acc_f = np.stack([butter_highpass(acc_32[k], FS_ACC, 0.3) for k in range(3)], 0)

    rpk = detect_rpeaks(ecg_140, FS_ECG_OUT)
    hr_all, valid = windowed_hr_from_rpeaks(rpk, FS_ECG_OUT, n_win, WIN_S, HOP_S)

    keys = ("acc", "ecg", "hr", "activity", "valid_hr",
            "ecg_sqi", "acc_motion", "ecg_stats", "acc_stats")
    out = {k: [] for k in keys}
    for i in range(n_win):
        e0, a0, l0 = i*HOP_S*FS_ECG_OUT, i*HOP_S*FS_ACC, i*HOP_S*FS_IN
        ew, aw = ecg_f[e0:e0+L_ECG], acc_f[:, a0:a0+L_ACC]
        acc_raw_w = acc_32[:, a0:a0+L_ACC]
        if len(ew) < L_ECG or aw.shape[1] < L_ACC:
            break
        lseg = lab[l0:l0+WIN_S*FS_IN]
        out["ecg_stats"].append([ew.mean(), ew.std(), np.ptp(ew)])
        mag = np.sqrt((acc_raw_w**2).sum(0))
        out["acc_stats"].append([mag.mean(), mag.std()])
        out["ecg"].append(zscore(ew)); out["acc"].append(zscore(aw, axis=1))
        out["hr"].append(hr_all[i]); out["valid_hr"].append(bool(valid[i]))
        out["activity"].append(int(np.bincount(lseg[lseg >= 0]).argmax()) if len(lseg) else 0)
        out["ecg_sqi"].append(ecg_sqi(ew, FS_ECG_OUT))
        out["acc_motion"].append(acc_motion_intensity(acc_raw_w, FS_ACC))

    N = len(out["hr"])
    return {
        "ppg": np.zeros((N, WIN_S*64), np.float32),        # PPG absent -> zeros (masked)
        "acc": np.asarray(out["acc"], np.float32),
        "ecg": np.asarray(out["ecg"], np.float32),
        "hr": np.asarray(out["hr"], np.float32),
        "activity": np.asarray(out["activity"], np.int8),
        "valid_hr": np.asarray(out["valid_hr"], bool),
        "ppg_present": np.zeros(N, bool),
        "ecg_sqi": np.asarray(out["ecg_sqi"], np.float32),
        "ppg_sqi": np.zeros(N, np.float32),
        "acc_motion": np.asarray(out["acc_motion"], np.float32),
        "ecg_stats": np.asarray(out["ecg_stats"], np.float32),
        "ppg_stats": np.zeros((N, 3), np.float32),
        "acc_stats": np.asarray(out["acc_stats"], np.float32),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="MHEALTH dir with mHealth_subject*.log")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    files = sorted(glob.glob(os.path.join(args.dir, "mHealth_subject*.log")),
                   key=lambda p: int("".join(filter(str.isdigit, os.path.basename(p)))))
    tot = 0
    for path in files:
        sid = "S" + "".join(filter(str.isdigit, os.path.basename(path)))
        res = process_file(path)
        np.savez_compressed(os.path.join(args.out, f"{sid}.npz"), subject=sid, **res)
        nv = int(res["valid_hr"].sum()); n = len(res["hr"]); tot += n
        print(f"[{sid}] N={n:5d} validHR={nv:5d} HR={np.nanmean(res['hr']):5.1f} "
              f"motion={res['acc_motion'].mean():.3f}g")
    print(f"\nMHEALTH done -> {tot} windows, {args.out}")


if __name__ == "__main__":
    main()
