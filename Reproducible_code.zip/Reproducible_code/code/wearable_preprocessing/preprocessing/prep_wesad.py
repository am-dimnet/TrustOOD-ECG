#!/usr/bin/env python3
"""
Preprocess WESAD (Schmidt et al., ICMI 2018) into the SAME compact window format
as PPG-DaLiA, enabling cross-dataset transfer (identical RespiBAN+Empatica-E4
hardware).  Two label streams are produced per 8 s / 2 s window:

  hr        reference heart rate [bpm] from chest-ECG R-peaks (same protocol as
            PPG-DaLiA) -> used for cross-dataset HR-estimation evaluation
  affect    majority WESAD condition label (1=baseline,2=stress,3=amusement,
            4=meditation; 0/5/6/7 = ignore) -> used for stress-detection task

Raw archive : WESAD.zip -> WESAD/S{n}/S{n}.pkl (15 subjects S2..S17, no S1/S12)
"""
from __future__ import annotations
import argparse, os, pickle, sys, zipfile
import numpy as np
from scipy import signal as sps

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from utils.signal_utils import (butter_bandpass, butter_highpass, zscore,
                                 ppg_spectral_sqi, ecg_sqi, acc_motion_intensity,
                                 detect_rpeaks, windowed_hr_from_rpeaks)

FS_PPG, FS_ACC, FS_ECG = 64, 32, 700
FS_ECG_OUT = 140
WIN_S, HOP_S = 8, 2
L_PPG, L_ACC, L_ECG = WIN_S * FS_PPG, WIN_S * FS_ACC, WIN_S * FS_ECG_OUT


def process_subject(d):
    ppg_raw = np.asarray(d["signal"]["wrist"]["BVP"]).astype(np.float64).ravel()
    acc_raw = np.asarray(d["signal"]["wrist"]["ACC"]).astype(np.float64)
    # Empatica E4 stores wrist ACC in 1/64 g counts (gravity ~64); convert to g
    # so motion/statistics match PPG-DaLiA units for cross-dataset consistency.
    if np.median(np.sqrt((acc_raw ** 2).sum(1))) > 10:
        acc_raw = acc_raw / 64.0
    ecg_raw = np.asarray(d["signal"]["chest"]["ECG"]).astype(np.float64).ravel()
    lab = np.asarray(d["label"]).astype(np.int64).ravel()      # @700 Hz

    dur = min(len(ecg_raw) / FS_ECG, len(ppg_raw) / FS_PPG, len(acc_raw) / FS_ACC)
    n_win = int((dur - WIN_S) // HOP_S) + 1

    ppg_f = butter_bandpass(ppg_raw, FS_PPG, 0.5, 8.0)
    ecg_d = sps.decimate(ecg_raw, FS_ECG // FS_ECG_OUT, ftype="fir", zero_phase=True)
    ecg_f = butter_bandpass(ecg_d, FS_ECG_OUT, 0.5, 40.0)
    acc_f = np.stack([butter_highpass(acc_raw[:, k], FS_ACC, 0.3) for k in range(3)], 0)

    rpk = detect_rpeaks(ecg_raw, FS_ECG)
    hr_all, valid = windowed_hr_from_rpeaks(rpk, FS_ECG, n_win, WIN_S, HOP_S)

    keys = ("ppg", "acc", "ecg", "hr", "affect", "valid_hr",
            "ppg_sqi", "ecg_sqi", "acc_motion", "ppg_stats", "ecg_stats", "acc_stats")
    out = {k: [] for k in keys}
    for i in range(n_win):
        p0, a0, e0, l0 = i*HOP_S*FS_PPG, i*HOP_S*FS_ACC, i*HOP_S*FS_ECG_OUT, i*HOP_S*FS_ECG
        pw, aw, ew = ppg_f[p0:p0+L_PPG], acc_f[:, a0:a0+L_ACC], ecg_f[e0:e0+L_ECG]
        if len(pw) < L_PPG or aw.shape[1] < L_ACC or len(ew) < L_ECG:
            break
        acc_raw_w = acc_raw[a0:a0+L_ACC].T
        lseg = lab[l0:l0+WIN_S*FS_ECG]
        out["ppg_stats"].append([pw.mean(), pw.std(), np.ptp(pw)])
        out["ecg_stats"].append([ew.mean(), ew.std(), np.ptp(ew)])
        mag = np.sqrt((acc_raw_w**2).sum(0))
        out["acc_stats"].append([mag.mean(), mag.std()])
        out["ppg"].append(zscore(pw)); out["acc"].append(zscore(aw, axis=1)); out["ecg"].append(zscore(ew))
        out["hr"].append(hr_all[i]); out["valid_hr"].append(bool(valid[i]))
        out["affect"].append(int(np.bincount(lseg[lseg >= 0]).argmax()) if len(lseg) else 0)
        out["ppg_sqi"].append(ppg_spectral_sqi(pw, FS_PPG))
        out["ecg_sqi"].append(ecg_sqi(ew, FS_ECG_OUT))
        out["acc_motion"].append(acc_motion_intensity(acc_raw_w, FS_ACC))

    return {
        "ppg": np.asarray(out["ppg"], np.float32), "acc": np.asarray(out["acc"], np.float32),
        "ecg": np.asarray(out["ecg"], np.float32), "hr": np.asarray(out["hr"], np.float32),
        "affect": np.asarray(out["affect"], np.int8),
        "valid_hr": np.asarray(out["valid_hr"], bool),
        "ppg_sqi": np.asarray(out["ppg_sqi"], np.float32),
        "ecg_sqi": np.asarray(out["ecg_sqi"], np.float32),
        "acc_motion": np.asarray(out["acc_motion"], np.float32),
        "ppg_stats": np.asarray(out["ppg_stats"], np.float32),
        "ecg_stats": np.asarray(out["ecg_stats"], np.float32),
        "acc_stats": np.asarray(out["acc_stats"], np.float32),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--subjects",
                    default=",".join(f"S{i}" for i in [2,3,4,5,6,7,8,9,10,11,13,14,15,16,17]))
    ap.add_argument("--tmp", default="/tmp/wesad_tmp")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True); os.makedirs(args.tmp, exist_ok=True)
    zf = zipfile.ZipFile(args.zip); names = zf.namelist()
    tot = 0
    for s in args.subjects.split(","):
        member = next((n for n in names if n.endswith(f"/{s}/{s}.pkl")), None)
        if member is None:
            print(f"[{s}] not found"); continue
        tmp = os.path.join(args.tmp, f"{s}.pkl")
        with zf.open(member) as src, open(tmp, "wb") as dst:
            dst.write(src.read())
        with open(tmp, "rb") as f:
            d = pickle.load(f, encoding="latin1")
        res = process_subject(d)
        np.savez_compressed(os.path.join(args.out, f"{s}.npz"), subject=s, **res)
        os.remove(tmp)
        nv = int(res["valid_hr"].sum()); n = len(res["hr"])
        aff = {int(k): int(v) for k, v in zip(*np.unique(res["affect"], return_counts=True))}
        tot += n
        print(f"[{s}] N={n:5d} validHR={nv:5d} HR={np.nanmean(res['hr']):5.1f} "
              f"motion={res['acc_motion'].mean():.3f} affect={aff}")
    print(f"\nWESAD done -> {tot} windows total, {args.out}")


if __name__ == "__main__":
    main()
