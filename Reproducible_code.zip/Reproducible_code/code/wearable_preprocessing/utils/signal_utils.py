"""
Shared signal-processing utilities for the CALM wearable cardiovascular pipeline.

All functions are deterministic and dependency-light (numpy + scipy only) so that
the full preprocessing pipeline is reproducible from the public raw archives.

References for design choices are given inline; see README.md for provenance.
"""
from __future__ import annotations
import numpy as np
from scipy import signal as sps


# ----------------------------------------------------------------------------
# Filtering / resampling
# ----------------------------------------------------------------------------
def butter_bandpass(x, fs, lo, hi, order=4):
    """Zero-phase Butterworth band-pass on a 1-D array."""
    ny = 0.5 * fs
    lo_n = max(lo / ny, 1e-4)
    hi_n = min(hi / ny, 0.999)
    b, a = sps.butter(order, [lo_n, hi_n], btype="band")
    return sps.filtfilt(b, a, x, method="gust")


def butter_highpass(x, fs, lo, order=4):
    ny = 0.5 * fs
    b, a = sps.butter(order, max(lo / ny, 1e-4), btype="high")
    return sps.filtfilt(b, a, x, method="gust")


def resample_to(x, fs_in, fs_out):
    """Polyphase resample a 1-D signal from fs_in to fs_out."""
    if fs_in == fs_out:
        return x.astype(np.float64)
    g = np.gcd(int(round(fs_in)), int(round(fs_out)))
    up = int(round(fs_out)) // g
    down = int(round(fs_in)) // g
    return sps.resample_poly(x, up, down).astype(np.float64)


def zscore(x, axis=-1, eps=1e-6):
    m = x.mean(axis=axis, keepdims=True)
    s = x.std(axis=axis, keepdims=True)
    return (x - m) / (s + eps)


# ----------------------------------------------------------------------------
# Signal-quality indices (reference values for analysis / auxiliary supervision)
# ----------------------------------------------------------------------------
def ppg_spectral_sqi(win, fs, band=(0.6, 3.3)):
    """
    Spectral-purity SQI for a PPG window in [0,1]: fraction of band-limited
    spectral energy concentrated in the dominant peak's neighbourhood.
    High => clean pulsatile PPG; low => motion-corrupted / flat.
    """
    win = win - win.mean()
    n = len(win)
    if np.allclose(win, 0):
        return 0.0
    f, pxx = sps.periodogram(win, fs, window="hann")
    m = (f >= band[0]) & (f <= band[1])
    if not m.any() or pxx[m].sum() <= 0:
        return 0.0
    pk = np.argmax(pxx[m])
    fpk = f[m][pk]
    # energy within +-0.2 Hz of the dominant peak vs total band energy
    near = (f >= fpk - 0.2) & (f <= fpk + 0.2)
    return float(pxx[near].sum() / (pxx[m].sum() + 1e-12))


def ecg_sqi(win, fs):
    """
    Simple ECG quality proxy in [0,1] combining (i) non-saturation fraction and
    (ii) relative power in the QRS band (5-25 Hz) vs baseline-wander band.
    """
    win = np.asarray(win, dtype=np.float64)
    if np.allclose(win, win[0]):
        return 0.0
    sat = np.mean(np.abs(win) < 0.995 * np.max(np.abs(win)) + 1e-9)
    f, pxx = sps.periodogram(win - win.mean(), fs, window="hann")
    qrs = pxx[(f >= 5) & (f <= 25)].sum()
    base = pxx[(f >= 0) & (f < 1)].sum()
    snr = qrs / (qrs + base + 1e-12)
    return float(np.clip(0.5 * sat + 0.5 * snr, 0, 1))


def acc_motion_intensity(acc_win, fs):
    """
    Motion intensity: RMS of the gravity-removed acceleration magnitude (in g).
    acc_win: (3, T). Returns scalar >= 0 (0 = still).
    """
    mag = np.sqrt((acc_win ** 2).sum(axis=0))
    mag_hp = butter_highpass(mag, fs, 0.3) if len(mag) > 12 else mag - mag.mean()
    return float(np.sqrt(np.mean(mag_hp ** 2)))


# ----------------------------------------------------------------------------
# ECG R-peak detection (Pan-Tompkins style) and HR derivation
# ----------------------------------------------------------------------------
def detect_rpeaks(ecg, fs):
    """
    Pan-Tompkins-style R-peak detector. Returns peak sample indices.
    Robust enough to derive a reference HR series on clean-ish chest ECG.
    """
    x = ecg.astype(np.float64)
    x = butter_bandpass(x, fs, 5.0, 15.0)
    d = np.ediff1d(x, to_begin=0)          # derivative
    sq = d * d                             # squaring
    w = max(1, int(0.150 * fs))            # 150 ms moving integration
    integ = np.convolve(sq, np.ones(w) / w, mode="same")
    thr = 0.3 * np.mean(integ) + 0.2 * np.std(integ)
    dist = int(0.30 * fs)                  # refractory (>=0.3s -> <=200 bpm)
    peaks, _ = sps.find_peaks(integ, height=thr, distance=dist)
    # refine each peak to local ECG maximum within +-50 ms
    r = int(0.05 * fs)
    refined = []
    for p in peaks:
        a, b = max(0, p - r), min(len(x), p + r)
        refined.append(a + int(np.argmax(np.abs(x[a:b]))))
    return np.array(sorted(set(refined)), dtype=int)


def windowed_hr_from_rpeaks(rpeaks, fs, n_win, win_s=8, hop_s=2,
                            hr_min=30, hr_max=220):
    """
    Derive a per-window HR [bpm] series from R-peak indices, mirroring the
    PPG-DaLiA ground-truth protocol (8 s window, 2 s hop, RR-median HR).
    Returns (hr[n_win], valid_mask[n_win]).
    """
    rt = rpeaks / fs
    hr = np.full(n_win, np.nan)
    for i in range(n_win):
        t0 = i * hop_s
        idx = rpeaks[(rt >= t0) & (rt < t0 + win_s)]
        if len(idx) >= 3:
            rr = np.diff(idx) / fs
            rr = rr[(rr > 60.0 / hr_max) & (rr < 60.0 / hr_min)]
            if len(rr) >= 2:
                hr[i] = 60.0 / np.median(rr)
    return hr, ~np.isnan(hr)


# ----------------------------------------------------------------------------
# Noise templates (MIT-BIH Noise Stress Test DB) for artifact injection
# ----------------------------------------------------------------------------
def load_nstdb_noise(nstdb_dir):
    """Load bw/ma/em noise records (2-channel, 360 Hz) as 1-D arrays."""
    import wfdb
    out = {}
    for rec in ("bw", "ma", "em"):
        try:
            sig, _ = wfdb.rdsamp(f"{nstdb_dir}/{rec}")
            out[rec] = sig[:, 0].astype(np.float64)
        except Exception as e:  # pragma: no cover
            print(f"  [nstdb] could not load {rec}: {e}")
    return out
