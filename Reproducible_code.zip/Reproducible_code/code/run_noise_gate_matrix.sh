#!/usr/bin/env bash
# Three gate architectures x three seeds under the full remote noise protocol.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
RUNNER="${EXPERIMENT_DIR}/run_noise_gate_extensions.py"
RESULTS_DIR="${RESULTS_DIR:-/dev/shm/Paper46_revision_results_missing/noise_gate}"
CHECKPOINT_DIR="${CHECKPOINT_DIR:-/dev/shm/Paper46_revision_checkpoints_missing/noise_gate}"
LOG_DIR="${LOG_DIR:-${REVISION_ROOT}/logs_final/noise_gate_missing}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
MAX_PARALLEL="${MAX_PARALLEL:-9}"

GATES=(independent_sigmoid global_sigmoid sample_softmax)
SEEDS=(7 13 42)

if [[ ! -f "${TRUSTFED_CACHE}/ptbxl_signals.npy" ]]; then
  echo "Refusing to run: AutoDL PTB-XL cache is absent" >&2
  exit 2
fi
if [[ ! -f "${RUNNER}" ]]; then
  echo "Runner is absent: ${RUNNER}" >&2
  exit 2
fi
if [[ ! "${MAX_PARALLEL}" =~ ^[1-9][0-9]*$ ]]; then
  echo "MAX_PARALLEL must be a positive integer" >&2
  exit 2
fi

mkdir -p "${RESULTS_DIR}" "${CHECKPOINT_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile "${RUNNER}"
{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'expected_tasks_results_fits=9\n'
  printf 'max_parallel=%s\n' "${MAX_PARALLEL}"
  sha256sum \
    "${EXPERIMENT_DIR}/data_adapter.py" \
    "${EXPERIMENT_DIR}/revisionlib.py" \
    "${EXPERIMENT_DIR}/run_noise_sqi.py" \
    "${EXPERIMENT_DIR}/run_ptbxl_missing_extensions.py" \
    "${RUNNER}"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/noise_gate_matrix_manifest.txt"

run_task() {
  local gate="$1"
  local seed="$2"
  local name="${gate}_seed${seed}"
  local log_file="${LOG_DIR}/${name}.log"
  local exit_file="${LOG_DIR}/${name}.exit"
  local command_file="${LOG_DIR}/${name}.command.txt"
  local command=(
    "${PYTHON}" "${RUNNER}"
    --gate-architecture "${gate}"
    --seeds 7,13,42 --worker-seed "${seed}"
    --snrs clean,24,18,12,6,0,-6
    --epochs 40 --batch-size 256 --eval-batch-size 512
    --feature-chunk-size 256 --learning-rate 0.001
    --rare-threshold 50 --q-min-percent 5,10,20,30
    --fixed-coverages 95,90,80,70,50 --risk-targets 1,5,10
    --alarm-quantile 0.95 --source-corruption-snr 0
    --sqi-sensitivity none --no-run-2x2
    --device cuda --trustfed-cache "${TRUSTFED_CACHE}" --cache-dir "${CACHE_DIR}"
    --checkpoint-dir "${CHECKPOINT_DIR}" --results-dir "${RESULTS_DIR}"
  )
  printf '%q ' "${command[@]}" > "${command_file}"
  printf '\n' >> "${command_file}"
  set +e
  CUBLAS_WORKSPACE_CONFIG=:4096:8 \
    OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${command[@]}" > "${log_file}" 2>&1
  local status=$?
  printf '%s\n' "${status}" > "${exit_file}"
  return "${status}"
}

launch_task() {
  while (( $(jobs -rp | wc -l) >= MAX_PARALLEL )); do
    wait -n || true
  done
  run_task "$@" &
}

for gate in "${GATES[@]}"; do
  for seed in "${SEEDS[@]}"; do
    launch_task "${gate}" "${seed}"
  done
done
wait || true

failed=0
observed=0
for exit_file in "${LOG_DIR}"/*.exit; do
  [[ -e "${exit_file}" ]] || continue
  observed=$((observed + 1))
  status="$(tr -d '[:space:]' < "${exit_file}")"
  if [[ "${status}" != "0" ]]; then
    failed=$((failed + 1))
    echo "FAILED: ${exit_file} (exit ${status})" >&2
  fi
done
if (( observed != 9 || failed != 0 )); then
  echo "FAILED: observed=${observed}/9 failed=${failed}" >&2
  exit 1
fi

json_count="$(find "${RESULTS_DIR}" -type f -name 'seed_*.json' | wc -l | tr -d '[:space:]')"
curve_count="$(find "${RESULTS_DIR}" -type f -name 'seed_*_curves.npz' | wc -l | tr -d '[:space:]')"
checkpoint_json_count="$(find "${CHECKPOINT_DIR}" -type f -name 'seed_*.json' | wc -l | tr -d '[:space:]')"
checkpoint_npz_count="$(find "${CHECKPOINT_DIR}" -type f -name 'seed_*.npz' | wc -l | tr -d '[:space:]')"
if [[ "${json_count}" != "9" || "${curve_count}" != "9" || \
      "${checkpoint_json_count}" != "9" || "${checkpoint_npz_count}" != "9" ]]; then
  echo "FAILED: result/checkpoint counts ${json_count}/${curve_count}/${checkpoint_json_count}/${checkpoint_npz_count}" >&2
  exit 4
fi

date --iso-8601=seconds > "${LOG_DIR}/noise_gate_matrix.complete"
echo "All 9 gate x seed noise/corruption runs completed."
