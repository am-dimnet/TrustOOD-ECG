#!/usr/bin/env python3
"""Write the exact expected-result matrix for the Paper46 PTB-XL revision.

The generated JSON is consumed by ``aggregate_results.py``.  Groups that are
part of the canonical comparison use five seeds; focused mechanism and
sensitivity studies use the three preregistered ablation seeds.
"""

from __future__ import annotations

import argparse
import json
import os
import tempfile
from pathlib import Path


FIVE_SEEDS = [7, 13, 42, 99, 2026]
THREE_SEEDS = [7, 42, 2026]
MAIN = [
    "trust_full",
    "softmax_modular",
    "concat_matched",
    "deep_ensemble",
    "tmc",
    "tmdf",
    "pool_only",
    "fuse_only",
]
ABLATIONS = [
    "trust_normalized",
    "trust_mean",
    "gate_uncertainty",
    "gate_sqi",
    "no_gate",
    "no_sqi_source",
    "no_sqi_source_gate_uncertainty",
    "comp_0",
    "comp_0.01",
    "comp_0.05",
    "comp_0.2",
    "comp_squared",
    "comp_crosscov",
]
SOURCE_COUNT = [
    f"{pooling}_s{count}"
    for pooling in ("cumulative", "normalized", "mean")
    for count in (1, 2, 3, 4)
]
SENSITIVITY = ["trust_full", "softmax_modular", "concat_matched"]

COMMON_CONFIG_REQUIREMENTS = {
    "environment.script_version": "paper46-ptbxl-revision-v1",
    "environment.score_direction": "higher means more OOD for every OOD score",
    "environment.arguments.epochs": 40,
    "environment.arguments.batch_size": 256,
    "environment.arguments.eval_batch_size": 512,
    "environment.arguments.learning_rate": 1e-3,
    "environment.arguments.rare_threshold": 50,
    "environment.arguments.ensemble_members": 5,
    "environment.arguments.bootstrap": 0,
    "environment.arguments.limit_train": None,
    "environment.arguments.limit_val": None,
    "environment.arguments.limit_test": None,
    "environment.arguments.limit_ood": None,
    "environment.arguments.limit_chapman": None,
    "environment.arguments.device": "cuda",
    "fingerprint_schema": "paper46-ptbxl-run-fingerprint-v1",
}

PROTOCOL_CONFIG_REQUIREMENTS = {
    "closed": {
        "protocol": "closed",
        "tau": None,
        "n_classes": 70,
        "environment.arguments.protocol": "closed",
        "environment.arguments.tau": 80,
        "environment.arguments.cross_dataset": True,
        "split.protocol": "closed",
        "split.train": 17418,
        "split.validation": 2183,
        "split.test": 2198,
        "ood.chapman_n": 45150,
    },
    "strict:tau40": {
        "protocol": "strict",
        "tau": 40,
        "n_classes": 55,
        "environment.arguments.protocol": "strict",
        "environment.arguments.tau": 40,
        "environment.arguments.cross_dataset": False,
        "split.threshold": 40,
        "split.n_heldout_codes": 15,
        "split.counts.train_id": 17159,
        "split.counts.val_id": 2147,
        "split.counts.test_id": 2164,
        "split.counts.test_ood": 34,
        "split.counts.test_ood_pure": 6,
        "split.counts.test_ood_mixed": 28,
    },
    "strict:tau80": {
        "protocol": "strict",
        "tau": 80,
        "n_classes": 47,
        "environment.arguments.protocol": "strict",
        "environment.arguments.tau": 80,
        "environment.arguments.cross_dataset": False,
        "split.threshold": 80,
        "split.n_heldout_codes": 23,
        "split.counts.train_id": 16677,
        "split.counts.val_id": 2086,
        "split.counts.test_id": 2105,
        "split.counts.test_ood": 93,
        "split.counts.test_ood_pure": 22,
        "split.counts.test_ood_mixed": 71,
    },
    "strict:tau160": {
        "protocol": "strict",
        "tau": 160,
        "n_classes": 36,
        "environment.arguments.protocol": "strict",
        "environment.arguments.tau": 160,
        "environment.arguments.cross_dataset": False,
        "split.threshold": 160,
        "split.n_heldout_codes": 34,
        "split.counts.train_id": 15527,
        "split.counts.val_id": 1940,
        "split.counts.test_id": 1958,
        "split.counts.test_ood": 240,
        "split.counts.test_ood_pure": 44,
        "split.counts.test_ood_mixed": 196,
    },
}

STRICT_ASSERTIONS = {
    "split.assertions.heldout_absent_from_train_id_raw_code_sets": True,
    "split.assertions.heldout_absent_from_val_id_raw_code_sets": True,
    "split.assertions.patient_disjoint_official_folds": True,
    "split.assertions.test_id_has_no_heldout_raw_code": True,
    "split.assertions.test_ood_has_at_least_one_heldout_raw_code": True,
    "split.assertions.train_val_records_with_any_heldout_code_are_purged": True,
}

EVIDENCE_OOD_DETECTORS = [
    "vacuity",
    "density",
    "composite",
    "composite_robust",
]
SOFTMAX_OOD_DETECTORS = [
    "MSP",
    "Energy",
    "GEN",
    "ViM",
    "DICE",
    "deep-kNN",
    "ODIN",
    "Mahalanobis:empirical_r1e-5",
    "Mahalanobis:empirical_r1e-3",
    "Mahalanobis:empirical_r1e-1",
    "Mahalanobis:empirical_shrink0.1",
    "Mahalanobis:ledoit_wolf",
    "Mahalanobis:oas",
]
MATCHED_CONCAT_OOD_DETECTORS = ["MSP", "Energy", "GEN", "ODIN"]
ENSEMBLE_OOD_DETECTORS = [
    "Ensemble-MSP",
    "Ensemble-predictive-entropy",
    "Ensemble-mutual-information",
]

CORE_PRIMARY_METRICS = [
    "diagnosis.accuracy",
    "diagnosis.balanced_accuracy",
    "diagnosis.macro_f1",
    "diagnosis.macro_auroc",
    "diagnosis.macro_auprc",
    "diagnosis.calibration.raw.ece_fixed",
    "diagnosis.calibration.raw.ece_adaptive",
    "diagnosis.calibration.raw.nll",
    "diagnosis.calibration.raw.brier",
    "diagnosis.calibration.temperature_scaled.ece_fixed",
    "diagnosis.calibration.temperature_scaled.nll",
    "diagnosis.selective_primary.aurc",
]
RARE_PRIMARY_METRICS = [
    "diagnosis.rare_macro_f1",
    "diagnosis.rare_macro_auroc",
    "diagnosis.rare_macro_auprc",
]


def group(method: str, protocol: str, seeds: list[int]) -> dict[str, object]:
    return {
        "method": method,
        "protocol": protocol,
        "dataset": "ptbxl",
        "split": "test",
        "seeds": seeds,
    }


def build() -> dict[str, object]:
    expected_runs: list[dict[str, object]] = []
    for protocol in ("closed", "strict:tau80"):
        expected_runs.extend(group(method, protocol, FIVE_SEEDS) for method in MAIN)
        expected_runs.extend(group(method, protocol, THREE_SEEDS) for method in ABLATIONS)
    expected_runs.extend(group(method, "closed", THREE_SEEDS) for method in SOURCE_COUNT)
    for protocol in ("strict:tau40", "strict:tau160"):
        expected_runs.extend(group(method, protocol, THREE_SEEDS) for method in SENSITIVITY)

    expected_group_count = len(expected_runs)
    expected_record_count = sum(len(item["seeds"]) for item in expected_runs)
    if (expected_group_count, expected_record_count) != (60, 212):
        raise RuntimeError(
            "internal expected-matrix drift: "
            f"groups={expected_group_count}, records={expected_record_count}"
        )

    protocol_requirements = {
        protocol: {
            **requirements,
            **(STRICT_ASSERTIONS if protocol.startswith("strict:") else {}),
        }
        for protocol, requirements in PROTOCOL_CONFIG_REQUIREMENTS.items()
    }
    comparisons = []
    for baseline in MAIN:
        if baseline == "trust_full":
            continue
        comparisons.append(
            {
                "a": "trust_full",
                "b": baseline,
                "metrics": [
                    "diagnosis.accuracy",
                    "diagnosis.balanced_accuracy",
                    "diagnosis.macro_f1",
                    "diagnosis.macro_auroc",
                    "diagnosis.calibration.raw.ece_fixed",
                    "diagnosis.selective_primary.aurc",
                ],
            }
        )
        comparisons.append(
            {
                "a": "trust_full",
                "b": baseline,
                "protocols": ["closed"],
                "metrics": [
                    "diagnosis.rare_macro_f1",
                    "diagnosis.rare_macro_auroc",
                ],
            }
        )

    return {
        "schema_version": 1,
        "expected_group_count": expected_group_count,
        "expected_record_count": expected_record_count,
        "expected_seeds": FIVE_SEEDS,
        "expected_runs": expected_runs,
        "reference_method": "trust_full",
        "required_artifacts": ["json", "raw_npz", "ood_npz"],
        "require_artifact_checksums": True,
        "require_run_fingerprint": True,
        "require_uniform_code_hashes": True,
        "config_requirements": COMMON_CONFIG_REQUIREMENTS,
        "config_requirements_by_protocol": protocol_requirements,
        "ood_npz_contract": {
            "scenarios_by_protocol": {
                "closed": ["validation", "id", "chapman"],
                "strict": ["validation", "id", "all", "pure", "mixed"],
            },
            "scenario_lengths_by_protocol": {
                "closed": {"validation": 2183, "id": 2198, "chapman": 45150},
                "strict:tau40": {
                    "validation": 2147, "id": 2164, "all": 34, "pure": 6, "mixed": 28,
                },
                "strict:tau80": {
                    "validation": 2086, "id": 2105, "all": 93, "pure": 22, "mixed": 71,
                },
                "strict:tau160": {
                    "validation": 1940, "id": 1958, "all": 240, "pure": 44, "mixed": 196,
                },
            },
            "detectors_default": EVIDENCE_OOD_DETECTORS,
            "detectors_by_method": {
                "softmax_modular": SOFTMAX_OOD_DETECTORS,
                "concat_matched": MATCHED_CONCAT_OOD_DETECTORS,
                "deep_ensemble": ENSEMBLE_OOD_DETECTORS,
            },
            "require_json_primary": True,
            "require_json_strata": True,
            "require_json_operating_point": True,
            "require_nonempty_1d_arrays": True,
            "require_floating_arrays": True,
            "required_ood_metrics": ["auroc", "aupr_out", "aupr_in", "fpr95"],
            "required_operating_point_metrics": [
                "validation_quantile",
                "threshold",
                "id_test_false_positive_rate",
                "ood_test_true_positive_rate",
            ],
            "require_finite_json_metrics": True,
            "require_evidence_coefficient_sensitivity": True,
            "evidence_coefficient_values": ["0.0", "0.5", "1.0", "2.0"],
        },
        "primary_metrics": CORE_PRIMARY_METRICS,
        "primary_metrics_by_protocol": {
            "closed": CORE_PRIMARY_METRICS + RARE_PRIMARY_METRICS,
            "strict": CORE_PRIMARY_METRICS,
        },
        "metric_directions": {
            "re:(nll|brier|ece|fpr|risk|aurc|eaurc|error|latency|loss)": "lower"
        },
        "comparisons": comparisons,
        "patient_bootstrap": {
            "metrics": ["accuracy", "balanced_accuracy", "macro_f1", "rare_macro_f1"],
            "n_bootstrap": 2000,
        },
    }


def atomic_json(payload: dict[str, object], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    atomic_json(build(), args.output.expanduser().resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
