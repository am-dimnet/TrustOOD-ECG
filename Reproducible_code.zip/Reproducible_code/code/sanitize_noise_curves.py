#!/usr/bin/env python3
"""Remove pickle-requiring string arrays from completed noise/SQI NPZ files.

This is a serialization-only migration for trusted three-seed artifacts written
by ``run_noise_sqi.py`` or its gate-architecture extension.  The historical
``--results-dir ROOT`` invocation still selects ``ROOT/canonical``.  A caller
may instead provide a validated relative ``--result-subdir`` below ROOT, or an
``--exact-results-dir`` together with an explicit safe ``--backup-subdir``.

The migration refuses unknown object arrays, verifies that every object value
is a string, leaves every non-object array unchanged, writes an atomic
replacement, updates the declared SHA-256, and records full provenance in the
result JSON.  It never trains a model or changes a reported metric.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

import numpy as np


EXPECTED_SEEDS = (7, 13, 42)
ALLOWED_OBJECT_KEYS = frozenset({"test_record_id", "test_patient"})


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_headers(path: Path) -> dict[str, dict[str, Any]]:
    """Read NPY headers inside an NPZ without unpickling array payloads."""

    result: dict[str, dict[str, Any]] = {}
    with zipfile.ZipFile(path, "r") as archive:
        for info in archive.infolist():
            if not info.filename.endswith(".npy"):
                continue
            with archive.open(info, "r") as handle:
                version = np.lib.format.read_magic(handle)
                if version == (1, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_1_0(handle)
                elif version in ((2, 0), (3, 0)):
                    shape, fortran, dtype = np.lib.format.read_array_header_2_0(handle)
                else:
                    raise RuntimeError(
                        f"unsupported NPY header version {version}: {info.filename}"
                    )
            result[info.filename[:-4]] = {
                "shape": tuple(int(value) for value in shape),
                "fortran_order": bool(fortran),
                "dtype": np.dtype(dtype),
            }
    return result


def atomic_json(payload: Mapping[str, Any], target: Path) -> None:
    fd, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(arrays: Mapping[str, np.ndarray], target: Path) -> Path:
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".npz", dir=target.parent
    )
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        return temporary
    except Exception:
        if temporary.exists():
            temporary.unlink()
        raise


def arrays_equal(left: np.ndarray, right: np.ndarray) -> bool:
    if left.shape != right.shape or left.dtype != right.dtype:
        return False
    if np.issubdtype(left.dtype, np.inexact):
        return bool(np.array_equal(left, right, equal_nan=True))
    return bool(np.array_equal(left, right))


def backup_once(source: Path, backup: Path) -> None:
    backup.parent.mkdir(parents=True, exist_ok=True)
    if backup.exists():
        if sha256_file(source) != sha256_file(backup):
            raise RuntimeError(f"existing backup differs from source: {backup}")
        return
    shutil.copy2(source, backup)
    if sha256_file(source) != sha256_file(backup):
        raise RuntimeError(f"backup verification failed: {backup}")


def safe_relative_subdir(value: str, option: str) -> Path:
    """Return a normalized non-empty relative POSIX path without traversal."""

    if not isinstance(value, str) or not value.strip():
        raise RuntimeError(f"{option} must be a non-empty relative path")
    if "\\" in value:
        raise RuntimeError(f"{option} must use POSIX separators: {value!r}")
    parsed = PurePosixPath(value)
    if parsed.is_absolute() or not parsed.parts:
        raise RuntimeError(f"{option} must be relative: {value!r}")
    if any(part in ("", ".", "..") for part in parsed.parts):
        raise RuntimeError(f"unsafe {option}: {value!r}")
    normalized = parsed.as_posix()
    if normalized != value.strip().rstrip("/"):
        raise RuntimeError(
            f"{option} must already be normalized: {value!r} -> {normalized!r}"
        )
    return Path(*parsed.parts)


def migrate_one(
    json_path: Path,
    backup_result_dir: Path,
    result_scope: str,
    dry_run: bool,
) -> None:
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    seed = int(payload.get("seed", -1))
    if seed not in EXPECTED_SEEDS:
        raise RuntimeError(f"unexpected seed in {json_path}: {seed}")
    if payload.get("status") != "complete" or payload.get("canonical") is not True:
        raise RuntimeError(f"not a complete canonical result: {json_path}")
    raw_info = payload.get("raw_npz")
    if not isinstance(raw_info, dict):
        raise RuntimeError(f"raw_npz manifest missing: {json_path}")
    raw_path = Path(str(raw_info.get("path", ""))).expanduser().resolve()
    expected_path = json_path.with_name(f"seed_{seed}_curves.npz").resolve()
    if raw_path != expected_path or not raw_path.is_file():
        raise RuntimeError(f"non-canonical or missing curves path: {raw_path}")
    old_sha = sha256_file(raw_path)
    if raw_info.get("sha256") != old_sha:
        raise RuntimeError(f"declared curves SHA-256 mismatch: {raw_path}")

    headers = read_headers(raw_path)
    object_keys = {key for key, row in headers.items() if row["dtype"].kind == "O"}
    unknown = object_keys - ALLOWED_OBJECT_KEYS
    if unknown:
        raise RuntimeError(f"refusing unknown object arrays in {raw_path}: {sorted(unknown)}")
    if not object_keys:
        print(f"[already safe] seed={seed} sha256={old_sha}", flush=True)
        return
    if dry_run:
        print(f"[would migrate] seed={seed} object_keys={sorted(object_keys)}", flush=True)
        return

    backup_npz = backup_result_dir / raw_path.name
    backup_json = backup_result_dir / json_path.name
    backup_once(raw_path, backup_npz)
    backup_once(json_path, backup_json)

    original: dict[str, np.ndarray] = {}
    migrated: dict[str, np.ndarray] = {}
    with np.load(raw_path, allow_pickle=True) as archive:
        if set(archive.files) != set(headers):
            raise RuntimeError(f"NPZ key/header mismatch: {raw_path}")
        for key in archive.files:
            value = np.asarray(archive[key])
            original[key] = value.copy()
            if value.dtype.kind != "O":
                migrated[key] = value
                continue
            if key not in ALLOWED_OBJECT_KEYS or value.ndim != 1:
                raise RuntimeError(f"refusing object array {key} with shape {value.shape}")
            flattened = value.tolist()
            if not all(isinstance(item, (str, np.str_)) for item in flattened):
                raise RuntimeError(f"non-string object found in {key}")
            migrated[key] = np.asarray([str(item) for item in flattened], dtype=str)

    temporary = atomic_npz(migrated, raw_path)
    try:
        with np.load(temporary, allow_pickle=False) as fixed:
            if set(fixed.files) != set(migrated):
                raise RuntimeError("sanitized NPZ key set changed")
            for key, expected in migrated.items():
                observed = np.asarray(fixed[key])
                if not arrays_equal(observed, expected):
                    raise RuntimeError(f"sanitized array differs: {key}")
                if key not in object_keys and not arrays_equal(observed, original[key]):
                    raise RuntimeError(f"numeric/non-object array changed: {key}")
        os.replace(temporary, raw_path)
    finally:
        if temporary.exists():
            temporary.unlink()

    new_sha = sha256_file(raw_path)
    raw_info["sha256"] = new_sha
    migrations = payload.setdefault("artifact_migrations", [])
    if not isinstance(migrations, list):
        raise RuntimeError(f"artifact_migrations is not a list: {json_path}")
    migrations.append(
        {
            "type": "object_string_to_fixed_unicode",
            "reason": "remove pickle requirement without changing values or metrics",
            "keys": sorted(object_keys),
            "source_sha256": old_sha,
            "target_sha256": new_sha,
            "tool": Path(__file__).name,
            "tool_sha256": sha256_file(Path(__file__).resolve()),
            "result_scope": result_scope,
            "backup_npz": str(backup_npz),
            "backup_json": str(backup_json),
            "verification": {
                "object_key_whitelist_enforced": True,
                "all_object_values_verified_strings": True,
                "non_object_shape_dtype_and_values_unchanged": True,
                "sanitized_npz_loaded_with_allow_pickle_false": True,
            },
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    )
    atomic_json(payload, json_path)
    print(f"[migrated] seed={seed} keys={sorted(object_keys)} sha256={new_sha}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    location = parser.add_mutually_exclusive_group(required=True)
    location.add_argument(
        "--results-dir",
        type=Path,
        help=(
            "root containing --result-subdir; with no explicit subdir this "
            "preserves the historical ROOT/canonical behavior"
        ),
    )
    location.add_argument(
        "--exact-results-dir",
        type=Path,
        help="exact directory containing seed JSON/curves pairs",
    )
    parser.add_argument(
        "--result-subdir",
        default="canonical",
        help="validated relative directory below --results-dir (default: canonical)",
    )
    parser.add_argument("--backup-dir", type=Path, required=True)
    parser.add_argument(
        "--backup-subdir",
        help=(
            "validated relative directory below --backup-dir; required with "
            "--exact-results-dir and otherwise defaults to --result-subdir"
        ),
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    backup_root = args.backup_dir.expanduser().resolve()
    if args.exact_results_dir is not None:
        if args.result_subdir != "canonical":
            raise RuntimeError(
                "--result-subdir cannot be combined with --exact-results-dir"
            )
        if args.backup_subdir is None:
            raise RuntimeError(
                "--exact-results-dir requires an explicit --backup-subdir"
            )
        result_dir = args.exact_results_dir.expanduser().resolve()
        backup_subdir = safe_relative_subdir(
            args.backup_subdir, "--backup-subdir"
        )
        result_scope = f"exact:{result_dir}"
    else:
        result_subdir = safe_relative_subdir(
            args.result_subdir, "--result-subdir"
        )
        results_root = args.results_dir.expanduser().resolve()
        result_dir = (results_root / result_subdir).resolve()
        try:
            result_dir.relative_to(results_root)
        except ValueError as exc:
            raise RuntimeError(
                f"resolved result directory escapes --results-dir: {result_dir}"
            ) from exc
        if args.backup_subdir is None:
            backup_subdir = result_subdir
        else:
            backup_subdir = safe_relative_subdir(
                args.backup_subdir, "--backup-subdir"
            )
        result_scope = f"relative:{result_subdir.as_posix()}"

    backup_result_dir = (backup_root / backup_subdir).resolve()
    try:
        backup_result_dir.relative_to(backup_root)
    except ValueError as exc:
        raise RuntimeError(
            f"resolved backup directory escapes --backup-dir: {backup_result_dir}"
        ) from exc
    if result_dir == backup_result_dir:
        raise RuntimeError("result and backup directories must differ")
    if not result_dir.is_dir():
        raise RuntimeError(f"result directory is absent: {result_dir}")

    paths = [result_dir / f"seed_{seed}.json" for seed in EXPECTED_SEEDS]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise RuntimeError(f"missing canonical JSON files: {missing}")
    expected_json = set(paths)
    observed_json = set(result_dir.glob("seed_*.json"))
    if observed_json != expected_json:
        raise RuntimeError(
            "unexpected result JSON set: "
            f"expected={sorted(map(str, expected_json))} "
            f"observed={sorted(map(str, observed_json))}"
        )
    expected_npz = {
        result_dir / f"seed_{seed}_curves.npz" for seed in EXPECTED_SEEDS
    }
    observed_npz = set(result_dir.glob("seed_*_curves.npz"))
    if observed_npz != expected_npz:
        raise RuntimeError(
            "unexpected curves NPZ set: "
            f"expected={sorted(map(str, expected_npz))} "
            f"observed={sorted(map(str, observed_npz))}"
        )
    for path in paths:
        migrate_one(path, backup_result_dir, result_scope, args.dry_run)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
