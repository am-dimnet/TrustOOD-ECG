#!/usr/bin/env bash
# Run the canonical three-seed PTB-XL noise, SQI and selective-risk study.

set -euo pipefail

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
RUNNER="${EXPERIMENT_DIR}/run_noise_sqi.py"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
CHECKPOINT_DIR="${CHECKPOINT_DIR:-${REVISION_ROOT}/checkpoints_final/noise_sqi}"
RESULTS_DIR="${RESULTS_DIR:-${REVISION_ROOT}/results_final/noise_sqi}"
LOG_DIR="${LOG_DIR:-${REVISION_ROOT}/logs_final/noise_sqi}"

if [[ ! -f "${TRUSTFED_CACHE}/ptbxl_signals.npy" ]]; then
  echo "Refusing to run: AutoDL PTB-XL cache is absent" >&2
  exit 2
fi
mkdir -p "${CHECKPOINT_DIR}" "${RESULTS_DIR}" "${LOG_DIR}"
"${PYTHON}" -m py_compile \
  "${EXPERIMENT_DIR}/data_adapter.py" \
  "${EXPERIMENT_DIR}/revisionlib.py" \
  "${RUNNER}"

{
  date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version
  printf 'host='; hostname
  sha256sum \
    "${EXPERIMENT_DIR}/data_adapter.py" \
    "${EXPERIMENT_DIR}/revisionlib.py" \
    "${RUNNER}"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
} > "${LOG_DIR}/noise_sqi_manifest.txt"

COMMON=(
  --seeds 7,13,42
  --snrs clean,24,18,12,6,0,-6
  --epochs 40
  --batch-size 256
  --eval-batch-size 512
  --feature-chunk-size 256
  --sqi-sensitivity both
  --retrain-sqi-configs core
  --run-2x2
  --trustfed-cache "${TRUSTFED_CACHE}"
  --cache-dir "${CACHE_DIR}"
  --checkpoint-dir "${CHECKPOINT_DIR}"
  --results-dir "${RESULTS_DIR}"
  --device cuda
)

run_worker() {
  local seed="$1"
  local command=("${PYTHON}" "${RUNNER}" "${COMMON[@]}" --worker-seed "${seed}")
  printf '%q ' "${command[@]}" > "${LOG_DIR}/noise_sqi_seed${seed}.command.txt"
  printf '\n' >> "${LOG_DIR}/noise_sqi_seed${seed}.command.txt"
  set +e
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "${command[@]}" > "${LOG_DIR}/noise_sqi_seed${seed}.log" 2>&1
  local status=$?
  printf '%s\n' "${status}" > "${LOG_DIR}/noise_sqi_seed${seed}.exit"
  return "${status}"
}

pids=()
for seed in 7 13 42; do
  run_worker "${seed}" &
  pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=$((failed + 1))
  fi
done
if (( failed != 0 )); then
  echo "Noise/SQI matrix failed in ${failed} seed worker(s)" >&2
  exit 1
fi

for seed in 7 13 42; do
  json="${RESULTS_DIR}/canonical/seed_${seed}.json"
  curves="${RESULTS_DIR}/canonical/seed_${seed}_curves.npz"
  if [[ ! -s "${json}" || ! -s "${curves}" ]]; then
    echo "Missing canonical seed artefacts for seed ${seed}" >&2
    exit 3
  fi
done

date --iso-8601=seconds > "${LOG_DIR}/noise_sqi.complete"
echo "Canonical three-seed noise/SQI experiment completed successfully."
