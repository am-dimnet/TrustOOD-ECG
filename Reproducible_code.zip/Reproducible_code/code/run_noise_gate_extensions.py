#!/usr/bin/env python3
"""Independent SNR/corruption evaluation of three gate architectures.

The audited noise protocol remains in :mod:`run_noise_sqi`: folds 1--8 train,
fold 9 selection/thresholds, fold 10 test; paired clean-to--6 dB corruptions;
recomputed SQI/quality/HRV/spectrum; isolated-source corruption; gate-weight
diagnostics; and atomic, fingerprinted artefacts.  This extension changes only
the gate architecture and writes to a separate result/checkpoint root.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

import run_noise_sqi as N
import run_ptbxl_missing_extensions as E


SCRIPT_VERSION = "paper46-noise-gate-extensions-v1"
GATE_ARCHITECTURES = (
    "independent_sigmoid",
    "global_sigmoid",
    "sample_softmax",
)
BASE_NOISE_RUNNER = Path(N.__file__).resolve()
_BASE_RUN_FINGERPRINT_PAYLOAD = N.run_fingerprint_payload
_BASE_ENVIRONMENT_MANIFEST = N.environment_manifest
_BASE_BUILD_PARSER = N.build_parser


@dataclass(frozen=True)
class NoiseGateConfig:
    name: str
    family: str
    sqi_source: bool
    quality_gate: bool
    quality_config: str
    analysis_role: str
    gate_architecture: str
    detach_gate_uncertainty: bool = False

    @property
    def gate_mode(self) -> str:
        return "both"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def model_configs(
    args: argparse.Namespace,
    qconfigs: Mapping[str, N.QualityConfig],
) -> list[NoiseGateConfig]:
    del qconfigs
    return [
        NoiseGateConfig(
            name="trust_full",
            family="trust",
            sqi_source=True,
            quality_gate=True,
            quality_config="canonical",
            analysis_role="primary_gate_architecture",
            gate_architecture=args.gate_architecture,
        )
    ]


def build_model(config: NoiseGateConfig, n_classes: int) -> torch.nn.Module:
    if config.family != "trust":
        raise ValueError("noise gate extension supports only the evidential Trust model")
    return E.AlternativeGateTrustModel(
        N.source_specs(),
        n_classes,
        config.gate_architecture,
        config.detach_gate_uncertainty,
    )


def run_fingerprint_payload(
    args: argparse.Namespace,
    seed: int,
    protocol: Mapping[str, Any],
    models: Sequence[NoiseGateConfig],
) -> dict[str, Any]:
    payload = _BASE_RUN_FINGERPRINT_PAYLOAD(args, seed, protocol, models)
    payload.update(
        {
            "extension_script_version": SCRIPT_VERSION,
            "extension_script_sha256": sha256_file(Path(__file__).resolve()),
            "base_noise_runner_sha256": sha256_file(BASE_NOISE_RUNNER),
            "gate_architecture": args.gate_architecture,
            "gate_comparison": list(GATE_ARCHITECTURES),
        }
    )
    return payload


def environment_manifest(args: argparse.Namespace, device: torch.device) -> dict[str, Any]:
    payload = _BASE_ENVIRONMENT_MANIFEST(args, device)
    payload.update(
        {
            "script_version": SCRIPT_VERSION,
            "extension_script_sha256": sha256_file(Path(__file__).resolve()),
            "base_noise_runner_sha256": sha256_file(BASE_NOISE_RUNNER),
            "gate_architecture": args.gate_architecture,
            "python": platform.python_version(),
        }
    )
    return payload


def is_canonical_run(args: argparse.Namespace) -> bool:
    return bool(
        not args.smoke
        and args.epochs == 40
        and args.batch_size == 256
        and args.eval_batch_size == 512
        and args.learning_rate == 1e-3
        and tuple(args.snrs) == N.DEFAULT_SNRS
        and tuple(args.seeds) == N.DEFAULT_SEEDS
        and args.sqi_sensitivity == "none"
        and not args.run_2x2
        and args.gate_architecture in GATE_ARCHITECTURES
        and all(
            value is None
            for value in (args.limit_train, args.limit_val, args.limit_test)
        )
    )


def install_independent_hooks() -> None:
    """Patch imported module globals only inside this extension process."""

    N.SCRIPT_VERSION = SCRIPT_VERSION
    # ``run_noise_sqi`` hashes its module-global __file__ in checkpoint
    # fingerprints. Point it at the actual executable and separately archive
    # the base runner hash above.
    N.__file__ = str(Path(__file__).resolve())
    N.model_configs = model_configs
    N.build_model = build_model
    N.run_fingerprint_payload = run_fingerprint_payload
    N.environment_manifest = environment_manifest
    N.is_canonical_run = is_canonical_run


def build_parser() -> argparse.ArgumentParser:
    parser = _BASE_BUILD_PARSER()
    parser.description = __doc__
    parser.add_argument(
        "--gate-architecture",
        choices=GATE_ARCHITECTURES,
        required=True,
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    install_independent_hooks()
    args = build_parser().parse_args(argv)
    N.apply_smoke_overrides(args)
    N.validate_args(args)
    if not args.smoke:
        if args.sqi_sensitivity != "none" or args.run_2x2:
            raise SystemExit(
                "gate-extension canonical runs require --sqi-sensitivity none "
                "and --no-run-2x2"
            )
        if tuple(args.seeds) != N.DEFAULT_SEEDS:
            raise SystemExit("canonical gate comparison declares seeds 7,13,42")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    gate_name = args.gate_architecture
    args.results_dir = str(Path(args.results_dir) / gate_name)
    args.checkpoint_dir = str(Path(args.checkpoint_dir) / gate_name)
    print(
        json.dumps(
            N.jsonable(
                {
                    "script_version": SCRIPT_VERSION,
                    "canonical": is_canonical_run(args),
                    "gate_architecture": gate_name,
                    "seeds": args.seeds,
                    "worker_seed": args.worker_seed,
                    "snrs": [N.snr_label(value) for value in args.snrs],
                    "epochs": args.epochs,
                    "batch_size": args.batch_size,
                    "device": str(device),
                    "results_dir": args.results_dir,
                    "checkpoint_dir": args.checkpoint_dir,
                }
            ),
            indent=2,
        ),
        flush=True,
    )
    run_seeds = (args.worker_seed,) if args.worker_seed is not None else args.seeds
    for seed in run_seeds:
        N.run_seed(args, int(seed), device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
