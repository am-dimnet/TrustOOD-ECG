#!/usr/bin/env python3
"""Independent PTB-XL experiments promised after the 212-result freeze.

This file deliberately does not modify ``run_ptbxl_revision.py`` or
``revisionlib.py``.  It imports their audited data/protocol/evaluation code and
adds only the missing reviewer-facing training factors:

* the unrun eta values in {0, .01, .03, .1, .3, 1};
* batch cross-correlation and linear-CKA redundancy penalties;
* globally learned, sample-independent and per-sample normalized gates;
* an explicit stop-gradient gate control (the frozen implementation does not
  detach source vacuity, despite wording in the draft response letter);
* auxiliary source-classification-loss weights; and
* functional source-count controls matched to the four-source parameter count
  by changing only the learned Fuse hidden width.

All fitting and checkpoint selection remain folds 1--8 / fold 9.  The base
runner writes atomically replaced JSON/NPZ artefacts with a run fingerprint and
SHA256 checksums.  Use a result root separate from the frozen 212-result root.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import math
from collections import OrderedDict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import data_adapter as D
import revisionlib as R
import run_ptbxl_revision as B


SCRIPT_VERSION = "paper46-ptbxl-missing-extensions-v1"
RUN_FINGERPRINT_SCHEMA = "paper46-ptbxl-missing-extensions-fingerprint-v1"
FIVE_SEEDS = (7, 13, 42, 99, 2026)
THREE_SEEDS = (7, 42, 2026)
ETA_GRID = (0.0, 0.01, 0.03, 0.1, 0.3, 1.0)
AUX_GRID = (0.0, 0.1, 0.3, 1.0)


@dataclass(frozen=True)
class ExtensionPlan:
    tag: str
    family: str = "trust"
    pooling: str = "cumulative"
    branch: str = "both"
    gate_mode: str = "both"
    sqi_source: bool = True
    source_count: int = 4
    complementarity_weight: float = 0.1
    complementarity_mode: str = "absolute_cosine"
    auxiliary_classification_weight: float = 0.3
    gate_architecture: str = "independent_sigmoid"
    detach_gate_uncertainty: bool = False
    capacity_match: bool = False
    representation_diagnostics: bool = False


def _parse_float_suffix(tag: str, prefix: str) -> float:
    try:
        value = float(tag[len(prefix):])
    except ValueError as exc:
        raise ValueError(f"invalid numeric model tag {tag!r}") from exc
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"model coefficient must be finite and non-negative: {tag!r}")
    return value


def parse_model_plan(tag: str) -> ExtensionPlan:
    if tag.startswith("pareto_eta_") and "_aux_" in tag:
        eta_text, aux_text = tag[len("pareto_eta_"):].split("_aux_", 1)
        eta_value = _parse_float_suffix(f"eta_{eta_text}", "eta_")
        aux_value = _parse_float_suffix(f"aux_{aux_text}", "aux_")
        if eta_value not in ETA_GRID:
            raise ValueError(f"eta must be one of {ETA_GRID}, got {eta_value}")
        if aux_value not in (0.0, 0.3, 1.0):
            raise ValueError("Pareto auxiliary weight must be 0, 0.3, or 1")
        return ExtensionPlan(
            tag=tag,
            complementarity_weight=eta_value,
            auxiliary_classification_weight=aux_value,
            representation_diagnostics=True,
        )
    if tag.startswith("eta_"):
        value = _parse_float_suffix(tag, "eta_")
        if value not in ETA_GRID:
            raise ValueError(f"eta must be one of {ETA_GRID}, got {value}")
        return ExtensionPlan(
            tag=tag,
            complementarity_weight=value,
            representation_diagnostics=True,
        )
    if tag == "alt_crosscorr":
        return ExtensionPlan(
            tag=tag,
            complementarity_mode="cross_correlation",
            representation_diagnostics=True,
        )
    if tag == "alt_linear_cka":
        return ExtensionPlan(
            tag=tag,
            complementarity_mode="linear_cka",
            representation_diagnostics=True,
        )
    if tag == "gate_global":
        return ExtensionPlan(tag=tag, gate_architecture="global_sigmoid")
    if tag == "gate_sample_normalized":
        return ExtensionPlan(tag=tag, gate_architecture="sample_softmax")
    if tag == "gate_detached":
        return ExtensionPlan(tag=tag, detach_gate_uncertainty=True)
    if tag.startswith("aux_"):
        value = _parse_float_suffix(tag, "aux_")
        if value not in AUX_GRID:
            raise ValueError(f"auxiliary weight must be one of {AUX_GRID}, got {value}")
        return ExtensionPlan(tag=tag, auxiliary_classification_weight=value)
    if tag.startswith("capmatch_s"):
        try:
            count = int(tag[len("capmatch_s"):])
        except ValueError as exc:
            raise ValueError(f"invalid source-count tag {tag!r}") from exc
        if count not in (1, 2, 3, 4):
            raise ValueError("capacity-matched source count must be 1, 2, 3, or 4")
        return ExtensionPlan(tag=tag, source_count=count, capacity_match=True)
    for family in ("tmc", "tmdf"):
        prefix = f"{family}_s"
        if tag.startswith(prefix):
            try:
                count = int(tag[len(prefix):])
            except ValueError as exc:
                raise ValueError(f"invalid {family} source-count tag {tag!r}") from exc
            if count not in (1, 2, 3, 4):
                raise ValueError(f"{family} source count must be 1, 2, 3, or 4")
            return ExtensionPlan(
                tag=tag,
                family=family,
                source_count=count,
                complementarity_weight=0.0,
                auxiliary_classification_weight=0.0,
            )
    raise ValueError(f"unknown missing-extension model tag {tag!r}")


class AlternativeGateTrustModel(R.RevisionTrustModel):
    """Trust model with only the gate architecture changed.

    ``global_sigmoid`` learns one scalar per source and is sample-independent.
    ``sample_softmax`` normalizes learned sample logits across available sources.
    ``independent_sigmoid`` is the frozen architecture and can optionally detach
    source vacuity to audit the draft response letter's stop-gradient wording.
    """

    def __init__(
        self,
        sources: Mapping[str, Mapping[str, Any]],
        n_classes: int,
        gate_architecture: str,
        detach_gate_uncertainty: bool,
    ) -> None:
        if gate_architecture not in (
            "independent_sigmoid", "global_sigmoid", "sample_softmax"
        ):
            raise ValueError(f"unsupported gate architecture {gate_architecture!r}")
        super().__init__(
            sources,
            n_classes,
            pooling="cumulative",
            branch="both",
            gate_mode="both",
            sqi_source=True,
            missing_quality="error",
        )
        self.gate_architecture = gate_architecture
        self.detach_gate_uncertainty = bool(detach_gate_uncertainty)
        if gate_architecture == "global_sigmoid":
            self.gate = nn.ModuleDict()
            self.global_gate_logits = nn.ParameterDict(
                {name: nn.Parameter(torch.zeros(1)) for name in self.src_names}
            )
        else:
            self.global_gate_logits = nn.ParameterDict()

    def forward(self, batch: Mapping[str, torch.Tensor]) -> dict[str, Any]:
        source_rows: list[dict[str, torch.Tensor]] = []
        raw_gate_logits: list[torch.Tensor] = []
        projections: list[torch.Tensor] = []

        for name in self.src_names:
            if name not in batch:
                raise KeyError(f"missing model source {name!r}")
            h = self.enc[name](batch[name])
            logits = self.head[name](h)
            evidence = R.nonnegative_evidence(logits)
            alpha = evidence + 1.0
            strength = alpha.sum(dim=-1, keepdim=True)
            uncertainty = self.n_classes / strength
            quality, observed = self._quality(name, batch, uncertainty)
            gate_u = uncertainty.detach() if self.detach_gate_uncertainty else uncertainty
            if self.gate_architecture == "global_sigmoid":
                gate_logit = self.global_gate_logits[name].reshape(1, 1).expand_as(uncertainty)
            else:
                gate_logit = self.gate[name](torch.cat((gate_u, quality), dim=-1))
            projection = F.normalize(self.proj[name](h), dim=-1)
            source_rows.append(
                {
                    "name": name,
                    "h": h,
                    "logits": logits,
                    "evidence": evidence,
                    "alpha": alpha,
                    "strength": strength,
                    "u": uncertainty,
                    "q": quality,
                    "q_observed": observed,
                    "prob": alpha / strength,
                }
            )
            raw_gate_logits.append(gate_logit)
            projections.append(projection)

        stacked_gate_logits = torch.stack(raw_gate_logits, dim=1)
        if self.gate_architecture == "sample_softmax":
            weights = torch.softmax(stacked_gate_logits, dim=1)
        else:
            weights = torch.sigmoid(stacked_gate_logits)

        per: dict[str, dict[str, torch.Tensor]] = {}
        evidence_parts: list[torch.Tensor] = []
        uncertainty_parts: list[torch.Tensor] = []
        quality_parts: list[torch.Tensor] = []
        observed_parts: list[torch.Tensor] = []
        gated_features: list[torch.Tensor] = []
        for index, row in enumerate(source_rows):
            weight = weights[:, index]
            name = str(row["name"])
            per[name] = {
                "h": row["h"],
                "logits": row["logits"],
                "evidence": row["evidence"],
                "e": row["evidence"],
                "alpha": row["alpha"],
                "prob": row["prob"],
                "u": row["u"],
                "q": row["q"],
                "q_observed": row["q_observed"],
                "w": weight,
            }
            evidence_parts.append(row["evidence"])
            uncertainty_parts.append(row["u"])
            quality_parts.append(row["q"])
            observed_parts.append(row["q_observed"])
            gated_features.append(weight * row["h"])

        source_evidence = torch.stack(evidence_parts, dim=1)
        source_u = torch.stack(uncertainty_parts, dim=1).squeeze(-1)
        source_q = torch.stack(quality_parts, dim=1).squeeze(-1)
        q_observed = torch.stack(observed_parts, dim=1).squeeze(-1)
        pool_evidence = (weights * source_evidence).sum(dim=1)
        pool_alpha = pool_evidence + 1.0
        u_pool = self.n_classes / pool_alpha.sum(dim=-1, keepdim=True)
        assert self.fuse is not None
        fuse_evidence = R.nonnegative_evidence(self.fuse(torch.cat(gated_features, dim=-1)))
        evidence = pool_evidence + fuse_evidence
        alpha = evidence + 1.0
        strength = alpha.sum(dim=-1, keepdim=True)
        decision_logits = torch.log(alpha.clamp_min(self.eps))
        return {
            "alpha": alpha,
            "evidence": evidence,
            "logits": decision_logits,
            "prob": alpha / strength,
            "u": self.n_classes / strength,
            "u_pool": u_pool,
            "pool_evidence": pool_evidence,
            "fuse_evidence": fuse_evidence,
            "source_evidence": source_evidence,
            "source_u": source_u,
            "source_q": source_q,
            "source_w": weights.squeeze(-1),
            "q_observed": q_observed,
            "W": weights.squeeze(-1),
            "per": per,
            "projs": projections,
            "gate_logits": stacked_gate_logits.squeeze(-1),
        }


def _parameter_count(model: nn.Module) -> int:
    return int(sum(parameter.numel() for parameter in model.parameters()))


def build_capacity_matched_model(plan: ExtensionPlan, n_classes: int) -> nn.Module:
    """Match four-source total parameters through a functional Fuse width.

    Total parameters are affine in ``fuse_hidden``.  The nearest positive
    integer width therefore gives a deterministic match without unused padding
    parameters.  The chosen branch is active in every forward pass.
    """

    cpu_rng = torch.random.get_rng_state()
    target_model = R.RevisionTrustModel(B.source_specs(4), n_classes, fuse_hidden=256)
    one_model = R.RevisionTrustModel(B.source_specs(plan.source_count), n_classes, fuse_hidden=1)
    two_model = R.RevisionTrustModel(B.source_specs(plan.source_count), n_classes, fuse_hidden=2)
    target_count = _parameter_count(target_model)
    one_count = _parameter_count(one_model)
    slope = _parameter_count(two_model) - one_count
    if slope <= 0:
        raise RuntimeError("Fuse parameter slope must be positive")
    hidden = max(1, int(round(1.0 + (target_count - one_count) / slope)))
    del target_model, one_model, two_model
    torch.random.set_rng_state(cpu_rng)
    model = R.RevisionTrustModel(
        B.source_specs(plan.source_count), n_classes, fuse_hidden=hidden
    )
    actual_count = _parameter_count(model)
    model.capacity_match_manifest = {
        "reference": "four-source RevisionTrustModel with fuse_hidden=256",
        "matched_component": "active learned Fuse hidden width",
        "source_count": plan.source_count,
        "fuse_hidden": hidden,
        "target_total_parameters": target_count,
        "actual_total_parameters": actual_count,
        "absolute_gap": actual_count - target_count,
        "relative_gap": (actual_count - target_count) / max(target_count, 1),
    }
    return model


def build_model(plan: ExtensionPlan, n_classes: int) -> nn.Module:
    if plan.family == "tmc":
        return R.TMCAdapter(B.source_specs(plan.source_count), n_classes)
    if plan.family == "tmdf":
        return R.TMDFAdapter(B.source_specs(plan.source_count), n_classes)
    if plan.capacity_match:
        return build_capacity_matched_model(plan, n_classes)
    if plan.gate_architecture != "independent_sigmoid" or plan.detach_gate_uncertainty:
        return AlternativeGateTrustModel(
            B.source_specs(plan.source_count),
            n_classes,
            plan.gate_architecture,
            plan.detach_gate_uncertainty,
        )
    return R.RevisionTrustModel(
        B.source_specs(plan.source_count),
        n_classes,
        pooling=plan.pooling,
        branch=plan.branch,
        gate_mode=plan.gate_mode,
        sqi_source=plan.sqi_source,
        missing_quality="error",
    )


def cross_correlation_penalty(projections: Sequence[torch.Tensor], eps: float = 1e-6) -> torch.Tensor:
    """Mean squared batch cross-correlation between every source pair."""

    if len(projections) < 2:
        return projections[0].new_zeros(()) if projections else torch.tensor(0.0)
    terms = []
    for left_index in range(len(projections)):
        for right_index in range(left_index + 1, len(projections)):
            left = projections[left_index]
            right = projections[right_index]
            left = (left - left.mean(0, keepdim=True)) / left.std(0, unbiased=False, keepdim=True).clamp_min(eps)
            right = (right - right.mean(0, keepdim=True)) / right.std(0, unbiased=False, keepdim=True).clamp_min(eps)
            cross_correlation = left.T @ right / max(left.shape[0], 1)
            terms.append(cross_correlation.square().mean())
    return torch.stack(terms).mean()


def linear_cka_penalty(projections: Sequence[torch.Tensor], eps: float = 1e-12) -> torch.Tensor:
    """Normalized linear HSIC (linear CKA) between every source pair."""

    if len(projections) < 2:
        return projections[0].new_zeros(()) if projections else torch.tensor(0.0)
    terms = []
    for left_index in range(len(projections)):
        for right_index in range(left_index + 1, len(projections)):
            left = projections[left_index] - projections[left_index].mean(0, keepdim=True)
            right = projections[right_index] - projections[right_index].mean(0, keepdim=True)
            cross = left.T @ right
            numerator = cross.square().sum()
            left_norm = (left.T @ left).square().sum()
            right_norm = (right.T @ right).square().sum()
            denominator = torch.sqrt(left_norm * right_norm).clamp_min(eps)
            terms.append(numerator / denominator)
    return torch.stack(terms).mean()


def training_loss(
    model: nn.Module,
    plan: ExtensionPlan,
    output: Any,
    targets: torch.Tensor,
    epoch: int,
    class_weight: torch.Tensor,
) -> torch.Tensor:
    del model
    kl_weight = 0.05 * min(1.0, (epoch + 1) / 10.0)
    if plan.family in ("tmc", "tmdf"):
        return R.tmc_training_loss(
            output, targets, kl_weight=kl_weight, class_weights=class_weight
        )
    built_in_weight = (
        plan.complementarity_weight
        if plan.complementarity_mode == "absolute_cosine"
        else 0.0
    )
    loss = R.revision_training_loss(
        output,
        targets,
        kl_weight=kl_weight,
        ce_weight=0.5,
        deep_supervision_weight=plan.auxiliary_classification_weight,
        complementarity_weight=built_in_weight,
        class_weights=class_weight,
    )
    if plan.complementarity_weight > 0:
        if plan.complementarity_mode == "cross_correlation":
            loss = loss + plan.complementarity_weight * cross_correlation_penalty(output["projs"])
        elif plan.complementarity_mode == "linear_cka":
            loss = loss + plan.complementarity_weight * linear_cka_penalty(output["projs"])
    return loss


@torch.no_grad()
def extract_projections(
    model: nn.Module,
    arrays: Mapping[str, np.ndarray],
    batch_size: int,
    device: torch.device,
) -> list[np.ndarray]:
    model.eval()
    keys = B.input_keys(model, arrays)
    collected: list[list[np.ndarray]] | None = None
    for start in range(0, len(arrays["y"]), batch_size):
        indices = np.arange(start, min(start + batch_size, len(arrays["y"])))
        output = model(B.tensor_batch(arrays, indices, keys, device))
        projections = output.get("projs", [])
        if collected is None:
            collected = [[] for _ in projections]
        for source_index, projection in enumerate(projections):
            collected[source_index].append(projection.detach().cpu().numpy())
    return [np.concatenate(parts, axis=0) for parts in (collected or [])]


def _linear_cka_numpy(left: np.ndarray, right: np.ndarray, eps: float = 1e-12) -> float:
    left = np.asarray(left, dtype=np.float64)
    right = np.asarray(right, dtype=np.float64)
    left -= left.mean(axis=0, keepdims=True)
    right -= right.mean(axis=0, keepdims=True)
    numerator = float(np.square(left.T @ right).sum())
    denominator = math.sqrt(
        float(np.square(left.T @ left).sum()) * float(np.square(right.T @ right).sum())
    )
    return numerator / max(denominator, eps)


def representation_diagnostics(
    model: nn.Module,
    train: Mapping[str, np.ndarray],
    validation: Mapping[str, np.ndarray],
    n_classes: int,
    batch_size: int,
    device: torch.device,
) -> dict[str, Any]:
    """Fold-9 representation diagnostics with train-only linear ridge probes."""

    train_projection = extract_projections(model, train, batch_size, device)
    val_projection = extract_projections(model, validation, batch_size, device)
    source_names = list(getattr(model, "source_names", ()))
    pairwise = []
    for left_index in range(len(val_projection)):
        for right_index in range(left_index + 1, len(val_projection)):
            left = val_projection[left_index]
            right = val_projection[right_index]
            pairwise.append(
                {
                    "left": source_names[left_index],
                    "right": source_names[right_index],
                    "mean_absolute_cosine": float(np.abs((left * right).sum(axis=1)).mean()),
                    "linear_cka_normalized_hsic": _linear_cka_numpy(left, right),
                }
            )

    labels = np.asarray(train["y"], dtype=np.int64)
    val_labels = np.asarray(validation["y"], dtype=np.int64)
    target = np.eye(n_classes, dtype=np.float64)[labels]
    ridge = 1e-3
    probes = []
    for source_index, train_features in enumerate(train_projection):
        x_train = np.c_[np.asarray(train_features, dtype=np.float64), np.ones(len(train_features))]
        x_val = np.c_[np.asarray(val_projection[source_index], dtype=np.float64), np.ones(len(val_projection[source_index]))]
        gram = x_train.T @ x_train
        regularizer = ridge * np.eye(gram.shape[0], dtype=np.float64)
        regularizer[-1, -1] = 0.0
        coefficients = np.linalg.solve(gram + regularizer, x_train.T @ target)
        logits = x_val @ coefficients
        probability = B.softmax_numpy(logits)
        probes.append(
            {
                "source": source_names[source_index],
                "probe": "train-only linear ridge classifier with intercept",
                "ridge": ridge,
                "fold9_macro_auroc": B.macro_auc(probability, val_labels),
                "fold9_accuracy": float((probability.argmax(axis=1) == val_labels).mean()),
            }
        )
    return {
        "fit_split": "folds 1-8 only",
        "evaluation_split": "fold 9 only",
        "n_train": int(len(labels)),
        "n_validation": int(len(val_labels)),
        "pairwise": pairwise,
        "source_linear_probes": probes,
    }


_BASE_TRAIN_MODEL = B.train_model


def train_model(
    model: nn.Module,
    plan: ExtensionPlan,
    train: Mapping[str, np.ndarray],
    validation: Mapping[str, np.ndarray],
    n_classes: int,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    seed: int,
    device: torch.device,
) -> tuple[nn.Module, dict[str, Any]]:
    model, report = _BASE_TRAIN_MODEL(
        model, plan, train, validation, n_classes, epochs,
        batch_size, learning_rate, seed, device,
    )
    capacity = getattr(model, "capacity_match_manifest", None)
    if capacity is not None:
        report["capacity_matching"] = capacity
    if plan.representation_diagnostics:
        report["representation_diagnostics"] = representation_diagnostics(
            model, train, validation, n_classes, max(batch_size, 512), device
        )
    return model, report


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def current_code_hashes() -> dict[str, str]:
    return {
        "run_ptbxl_revision.py": sha256_file(Path(__file__).resolve()),
        "base_run_ptbxl_revision.py": sha256_file(Path(B.__file__).resolve()),
        "revisionlib.py": sha256_file(Path(R.__file__).resolve()),
        "data_adapter.py": sha256_file(Path(D.__file__).resolve()),
    }


def install_independent_hooks() -> None:
    """Redirect only this process; imported source files remain untouched."""

    B.SCRIPT_VERSION = SCRIPT_VERSION
    B.RUN_FINGERPRINT_SCHEMA = RUN_FINGERPRINT_SCHEMA
    B.parse_model_plan = parse_model_plan
    B.build_model = build_model
    B.training_loss = training_loss
    B.train_model = train_model
    B.current_code_hashes = current_code_hashes


def expand_models(value: str) -> list[str]:
    groups = {
        "eta_full": tuple(f"eta_{value:g}" for value in ETA_GRID),
        "alternatives": ("alt_crosscorr", "alt_linear_cka"),
        "gates": ("gate_global", "gate_sample_normalized", "gate_detached"),
        "aux_full": tuple(f"aux_{value:g}" for value in AUX_GRID),
        "capacity": tuple(f"capmatch_s{count}" for count in (1, 2, 3, 4)),
        "tmc_tmdf_source_count": tuple(
            f"{family}_s{count}"
            for family in ("tmc", "tmdf")
            for count in (1, 2, 3, 4)
        ),
    }
    expanded: list[str] = []
    for token in (item.strip() for item in value.split(",")):
        if not token:
            continue
        candidates = groups.get(token, (token,))
        for candidate in candidates:
            parse_model_plan(candidate)
            if candidate not in expanded:
                expanded.append(candidate)
    if not expanded:
        raise argparse.ArgumentTypeError("at least one extension model is required")
    return expanded


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", choices=("closed", "strict"), required=True)
    parser.add_argument("--models", required=True,
                        help="comma tags or eta_full/alternatives/gates/aux_full/capacity")
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--tau", type=int, default=80)
    parser.add_argument("--rare-threshold", type=int, default=50)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--eval-batch-size", type=int, default=512)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--ensemble-members", type=int, default=5)
    parser.add_argument("--bootstrap", type=int, default=0)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--cross-dataset", action="store_true")
    parser.add_argument("--limit-train", type=int)
    parser.add_argument("--limit-val", type=int)
    parser.add_argument("--limit-test", type=int)
    parser.add_argument("--limit-ood", type=int)
    parser.add_argument("--limit-chapman", type=int)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--trustfed-cache", default=str(D.DEFAULT_TRUSTFED_CACHE))
    parser.add_argument("--cache-dir", default="/root/Paper46_revision/cache")
    parser.add_argument(
        "--results-dir",
        default="/dev/shm/Paper46_revision_results_missing/ptbxl",
        help="must remain separate from the frozen 212-result root",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    install_independent_hooks()
    args = build_parser().parse_args(argv)
    if args.epochs < 1 or args.batch_size < 1 or args.eval_batch_size < 1:
        raise SystemExit("epochs and batch sizes must be positive")
    if args.protocol == "strict" and args.cross_dataset:
        raise SystemExit("--cross-dataset is only valid for the closed protocol")
    if args.protocol == "closed" and not args.cross_dataset:
        raise SystemExit("formal extension runs require --cross-dataset for closed PTB-XL")
    args.models = expand_models(args.models)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    B.set_seed(args.seed)
    protocol = B.load_protocol(args)
    print(
        B.json.dumps(
            B.jsonable(
                {
                    "script_version": SCRIPT_VERSION,
                    "protocol": args.protocol,
                    "models": args.models,
                    "seed": args.seed,
                    "train": len(protocol["train_index"]),
                    "validation": len(protocol["val_index"]),
                    "test": len(protocol["test_index"]),
                    "ood": {name: len(index) for name, index in protocol["ood_indices"].items()},
                    "device": str(device),
                }
            ),
            indent=2,
        ),
        flush=True,
    )
    for tag in args.models:
        B.run_one(args, tag, protocol, device)
    del protocol
    gc.collect()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
