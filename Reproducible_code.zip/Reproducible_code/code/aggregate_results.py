#!/usr/bin/env python3
"""Audit and aggregate Paper46 revision result artefacts.

The script is deliberately read-only with respect to experiment artefacts.  It
recursively discovers JSON/NPZ files produced by ``run_ptbxl_revision.py``,
hashes every input, checks the expected method/protocol/seed matrix, and writes
publication-facing summaries into a separate output directory.  Missing runs,
non-five-seed groups, duplicate identities, non-finite values, unpaired seeds,
and unavailable patient identifiers are reported explicitly; no value is ever
imputed.

Canonical invocation::

    python aggregate_results.py /root/Paper46_revision/results \
        --output-dir /root/Paper46_revision/aggregate \
        --expected-config expected_results.json

Audit without numerical aggregation::

    python aggregate_results.py /root/Paper46_revision/results \
        --output-dir /root/Paper46_revision/audit --audit-only

``--expected-config`` accepts JSON, or YAML when PyYAML is installed.  A useful
minimal schema is::

    {
      "expected_seeds": [7, 13, 42, 99, 2026],
      "methods": ["trust_full", "softmax_modular", "tmc", "tmdf"],
      "protocols": ["closed", "strict:tau80"],
      "datasets": ["ptbxl"],
      "splits": ["test"],
      "reference_method": "trust_full",
      "comparisons": [
        {"a": "trust_full", "b": "softmax_modular",
         "metrics": ["diagnosis.macro_f1", "diagnosis.balanced_accuracy"]}
      ],
      "metric_directions": {"diagnosis.nll": "lower"},
      "patient_bootstrap": {
        "metrics": ["accuracy", "balanced_accuracy", "macro_f1",
                    "rare_macro_f1"],
        "n_bootstrap": 2000
      },
      "rare_class_ids": [3, 7],
      "required_artifacts": ["json", "raw_npz"],
      "required_artifacts_by_protocol": {
        "strict:tau80": ["json", "raw_npz", "ood_npz"]
      },
      "config_requirements": {"environment.arguments.epochs": 50}
    }

All confidence intervals are two-sided.  Seed summaries report both a
Student-t interval for the mean and the empirical percentile interval across
seed estimates.  Patient intervals use a patient-cluster percentile bootstrap.
Paired contrasts are always ``method_a - method_b``; ``benefit_difference``
also applies the configured metric direction so that positive means method A
is better.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
import tempfile
import zipfile
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from itertools import product
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Mapping, MutableMapping, Optional, Sequence

import numpy as np
from scipy import stats
from scipy.special import logsumexp
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
    roc_curve,
)


SCRIPT_VERSION = "paper46-result-aggregate-v1"
DEFAULT_EXPECTED_SEEDS = (7, 13, 42, 99, 2026)
DEFAULT_PATIENT_METRICS = (
    "accuracy",
    "balanced_accuracy",
    "macro_f1",
    "rare_macro_f1",
)

PATIENT_KEYS = ("test_patient", "patient_ids", "patient_id", "patients", "subject_ids", "subj")
LABEL_KEYS = ("test_y", "y_true", "labels", "y", "target", "targets")
PROB_KEYS = ("test_prob", "test_probs", "probs", "probabilities", "prob")
LOGIT_KEYS = ("test_logits", "logits")
PREDICTION_KEYS = ("test_pred", "y_pred", "predictions", "pred")
CONFIDENCE_KEYS = ("test_conf", "confidence", "confidences")
SAMPLE_ID_KEYS = ("test_sample_id", "test_sample_ids", "sample_id", "sample_ids", "record_id")
RARE_ID_KEYS = ("rare_ids", "rare_class_ids")
OOD_LABEL_KEYS = ("is_ood", "ood_label", "ood_labels", "y_ood")
OOD_SCORE_KEYS = ("ood_score", "ood_scores", "score", "scores")


def jsonable(value: Any) -> Any:
    """Convert NumPy/path values to strict JSON without emitting NaN/Inf."""

    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        if value.ndim == 0:
            return jsonable(value.item())
        return [jsonable(item) for item in value.tolist()]
    if isinstance(value, np.generic):
        return jsonable(value.item())
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if hasattr(value, "__dataclass_fields__"):
        return jsonable(asdict(value))
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(jsonable(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle_fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(handle_fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_json(path: Path, payload: Any) -> None:
    text = json.dumps(
        jsonable(payload), indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False
    ) + "\n"
    atomic_text(path, text)


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(str(key))
    path.parent.mkdir(parents=True, exist_ok=True)
    handle_fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(handle_fd, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
            if columns:
                writer.writeheader()
                for row in rows:
                    writer.writerow({key: jsonable(row.get(key)) for key in columns})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_object(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def load_expected_config(path: Optional[Path]) -> dict[str, Any]:
    if path is None:
        return {}
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise RuntimeError("YAML expected config requires PyYAML; use JSON instead") from exc
        payload = yaml.safe_load(text)
    if not isinstance(payload, Mapping):
        raise ValueError("expected config must contain a mapping at its root")
    return dict(payload)


def nested_get(mapping: Mapping[str, Any], dotted_key: str, default: Any = None) -> Any:
    current: Any = mapping
    for part in dotted_key.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return default
        current = current[part]
    return current


def finite_number(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float, np.integer, np.floating)):
        result = float(value)
        return result if math.isfinite(result) else None
    return None


def flatten_numeric(value: Any, prefix: str = "") -> dict[str, float]:
    """Flatten numeric mapping leaves, deliberately excluding lists/tables."""

    result: dict[str, float] = {}
    number = finite_number(value)
    if number is not None and prefix:
        result[prefix] = number
    elif isinstance(value, Mapping):
        for key, item in value.items():
            child = f"{prefix}.{key}" if prefix else str(key)
            result.update(flatten_numeric(item, child))
    return result


def first_present(mapping: Mapping[str, Any], keys: Sequence[str]) -> Optional[str]:
    for key in keys:
        if key in mapping:
            return key
    return None


def scalar_from_npz(archive: Mapping[str, Any], keys: Sequence[str]) -> Any:
    key = first_present(archive, keys)
    if key is None:
        return None
    value = np.asarray(archive[key])
    if value.size != 1:
        return None
    return value.reshape(()).item()


def protocol_name(payload: Mapping[str, Any]) -> tuple[str, str]:
    base = str(payload.get("protocol", "unknown"))
    tau = payload.get("tau")
    if base == "strict" and tau is not None:
        return base, f"strict:tau{tau}"
    variant = payload.get("protocol_variant")
    return base, str(variant) if variant is not None else base


def model_name(payload: Mapping[str, Any]) -> tuple[str, str]:
    model = payload.get("model", {})
    if isinstance(model, Mapping):
        method = model.get("tag", model.get("name", payload.get("method", "unknown")))
        family = model.get("family", payload.get("family", method))
    else:
        method = payload.get("method", model)
        family = payload.get("family", method)
    return str(method), str(family)


def companion_path(json_path: Path, suffix: str) -> Path:
    stem = json_path.stem
    return json_path.with_name(f"{stem}{suffix}")


def resolve_payload_path(value: Any, json_path: Path) -> Optional[Path]:
    if not isinstance(value, str) or not value:
        return None
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = json_path.parent / path
    return path.resolve()


@dataclass
class RunRecord:
    record_id: str
    json_path: Path
    method: str
    family: str
    protocol_base: str
    protocol: str
    dataset: str
    split: str
    seed: Optional[int]
    status: str
    payload: dict[str, Any]
    config: dict[str, Any]
    metrics: dict[str, float]
    raw_npz: Optional[Path]
    ood_npz: Optional[Path]
    warnings: list[str] = field(default_factory=list)

    @property
    def group_key(self) -> tuple[str, str, str, str]:
        return self.method, self.protocol, self.dataset, self.split

    @property
    def pair_key(self) -> tuple[str, str, str, int]:
        return self.protocol, self.dataset, self.split, int(self.seed)  # type: ignore[arg-type]


def extract_metrics(payload: Mapping[str, Any]) -> dict[str, float]:
    metrics: dict[str, float] = {}
    if isinstance(payload.get("metrics"), Mapping):
        metrics.update(flatten_numeric(payload["metrics"], "metrics"))
    if isinstance(payload.get("diagnosis"), Mapping):
        diagnosis = dict(payload["diagnosis"])
        diagnosis.pop("classwise", None)
        metrics.update(flatten_numeric(diagnosis, "diagnosis"))
    if isinstance(payload.get("ood"), Mapping):
        metrics.update(flatten_numeric(payload["ood"], "ood"))
    if isinstance(payload.get("profiling"), Mapping):
        metrics.update(flatten_numeric(payload["profiling"], "profiling"))
    return metrics


def records_from_json(path: Path, payload: Any) -> list[RunRecord]:
    candidates: list[Mapping[str, Any]] = []
    if isinstance(payload, list):
        candidates = [item for item in payload if isinstance(item, Mapping)]
    elif isinstance(payload, Mapping) and isinstance(payload.get("runs"), list):
        candidates = [item for item in payload["runs"] if isinstance(item, Mapping)]
    elif isinstance(payload, Mapping):
        candidates = [payload]
    records: list[RunRecord] = []
    for index, item in enumerate(candidates):
        item = dict(item)
        looks_like_run = (
            "seed" in item
            and ("model" in item or "method" in item)
            and any(key in item for key in ("diagnosis", "metrics", "ood", "status"))
        )
        if not looks_like_run:
            continue
        method, family = model_name(item)
        base_protocol, protocol = protocol_name(item)
        seed_value = item.get("seed")
        try:
            seed = int(seed_value) if seed_value is not None else None
        except (TypeError, ValueError):
            seed = None
        dataset = str(item.get("dataset", nested_get(item, "split.dataset", "ptbxl")))
        split = str(item.get("evaluation_split", item.get("split_name", "test")))
        explicit_raw = resolve_payload_path(
            item.get("raw_npz", item.get("predictions_npz")), path
        )
        explicit_ood = resolve_payload_path(item.get("ood_npz"), path)
        raw_npz = explicit_raw or companion_path(path, "_raw.npz").resolve()
        ood_npz = explicit_ood or companion_path(path, "_ood_scores.npz").resolve()
        warnings: list[str] = []
        if seed is None:
            warnings.append("missing_or_invalid_seed")
        if method == "unknown":
            warnings.append("missing_method")
        if not raw_npz.is_file():
            warnings.append("missing_raw_npz")
        if not ood_npz.is_file():
            ood_npz = None
        config = {
            "model": item.get("model", {}),
            "protocol": base_protocol,
            "protocol_variant": protocol,
            "tau": item.get("tau"),
            "split": item.get("split", {}),
            "environment": item.get("environment", {}),
        }
        records.append(
            RunRecord(
                record_id=f"{path.resolve()}#{index}",
                json_path=path.resolve(),
                method=method,
                family=family,
                protocol_base=base_protocol,
                protocol=protocol,
                dataset=dataset,
                split=split,
                seed=seed,
                status=str(item.get("status", "unknown")),
                payload=item,
                config=config,
                metrics=extract_metrics(item),
                raw_npz=raw_npz if raw_npz.is_file() else None,
                ood_npz=ood_npz,
                warnings=warnings,
            )
        )
    return records


def inspect_npz_headers(path: Path) -> dict[str, Any]:
    """Read ZIP/NPY headers only; do not materialise potentially large arrays."""

    arrays: list[dict[str, Any]] = []
    with zipfile.ZipFile(path, "r") as archive:
        for info in archive.infolist():
            if not info.filename.endswith(".npy"):
                continue
            with archive.open(info, "r") as handle:
                version = np.lib.format.read_magic(handle)
                if version == (1, 0):
                    shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(
                        handle
                    )
                elif version in ((2, 0), (3, 0)):
                    # NumPy uses the 2.0 reader for both v2 and UTF-8 v3 headers.
                    shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(
                        handle
                    )
                else:
                    raise ValueError(
                        f"unsupported NPY header version {version} in {info.filename}"
                    )
            arrays.append(
                {
                    "key": info.filename[:-4],
                    "shape": list(shape),
                    "dtype": str(dtype),
                    "fortran_order": bool(fortran_order),
                    "compressed_bytes": int(info.compress_size),
                    "uncompressed_bytes": int(info.file_size),
                }
            )
    return {"arrays": arrays, "n_arrays": len(arrays)}


def discover_inputs(root: Path, output_dir: Path) -> tuple[list[RunRecord], list[dict[str, Any]]]:
    records: list[RunRecord] = []
    files: list[dict[str, Any]] = []
    output_resolved = output_dir.resolve()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in (".json", ".npz"):
            continue
        resolved = path.resolve()
        if resolved == output_resolved or output_resolved in resolved.parents:
            continue
        entry: dict[str, Any] = {
            "path": str(resolved),
            "relative_path": str(path.relative_to(root)),
            "kind": path.suffix.lower().lstrip("."),
            "role": (
                "result_json"
                if path.suffix.lower() == ".json"
                else "raw_predictions"
                if path.name.endswith("_raw.npz")
                else "ood_scores"
                if path.name.endswith("_ood_scores.npz")
                else "npz_other"
            ),
            "bytes": int(path.stat().st_size),
            "sha256": sha256_file(path),
            "parse_status": "ok",
        }
        try:
            if path.suffix.lower() == ".json":
                payload = json.loads(path.read_text(encoding="utf-8"))
                parsed = records_from_json(path, payload)
                records.extend(parsed)
                entry["record_ids"] = [record.record_id for record in parsed]
                entry["record_count"] = len(parsed)
                if not parsed:
                    entry["parse_status"] = "no_run_records"
            else:
                entry.update(inspect_npz_headers(path))
        except Exception as exc:  # audit must retain corrupt files in the manifest
            entry["parse_status"] = "error"
            entry["error"] = f"{type(exc).__name__}: {exc}"
        files.append(entry)
    return records, files


def expected_seeds(config: Mapping[str, Any]) -> tuple[int, ...]:
    values = config.get("expected_seeds", DEFAULT_EXPECTED_SEEDS)
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise ValueError("expected_seeds must be a sequence")
    seeds = tuple(int(value) for value in values)
    if len(set(seeds)) != len(seeds):
        raise ValueError("expected_seeds contains duplicates")
    return seeds


def expected_groups(
    config: Mapping[str, Any], records: Sequence[RunRecord]
) -> list[tuple[str, str, str, str, tuple[int, ...]]]:
    """Expand explicit expected runs, a Cartesian matrix, or observed groups."""

    default_seeds = expected_seeds(config)
    explicit = config.get("expected_runs")
    groups: list[tuple[str, str, str, str, tuple[int, ...]]] = []
    if isinstance(explicit, Sequence) and not isinstance(explicit, (str, bytes)):
        seen: set[tuple[str, str, str, str]] = set()
        for row in explicit:
            if not isinstance(row, Mapping):
                raise ValueError("each expected_runs item must be a mapping")
            group_seeds = tuple(int(value) for value in row.get("seeds", default_seeds))
            if not group_seeds or len(set(group_seeds)) != len(group_seeds):
                raise ValueError("each expected_runs seed list must be non-empty and unique")
            identity = (
                str(row["method"]),
                str(row["protocol"]),
                str(row.get("dataset", "ptbxl")),
                str(row.get("split", "test")),
            )
            if identity in seen:
                raise ValueError(f"duplicate expected run group: {identity}")
            seen.add(identity)
            groups.append((*identity, group_seeds))
        declared_groups = config.get("expected_group_count")
        declared_records = config.get("expected_record_count")
        actual_records = sum(len(item[-1]) for item in groups)
        if declared_groups is not None and int(declared_groups) != len(groups):
            raise ValueError(
                f"expected_group_count={declared_groups} but expected_runs has {len(groups)} groups"
            )
        if declared_records is not None and int(declared_records) != actual_records:
            raise ValueError(
                f"expected_record_count={declared_records} but expected_runs has "
                f"{actual_records} records"
            )
        return groups

    matrix_fields = ("methods", "protocols", "datasets", "splits")
    if any(field in config for field in matrix_fields):
        methods = [str(value) for value in config.get("methods", sorted({r.method for r in records}))]
        protocols = [str(value) for value in config.get("protocols", sorted({r.protocol for r in records}))]
        datasets = [str(value) for value in config.get("datasets", sorted({r.dataset for r in records}) or ["ptbxl"])]
        splits = [str(value) for value in config.get("splits", sorted({r.split for r in records}) or ["test"])]
        return [(*key, default_seeds) for key in product(methods, protocols, datasets, splits)]

    observed = sorted({record.group_key for record in records})
    return [(*key, default_seeds) for key in observed]


def required_artifacts(config: Mapping[str, Any], protocol: str) -> tuple[str, ...]:
    default = config.get("required_artifacts", ("json", "raw_npz"))
    by_protocol = config.get("required_artifacts_by_protocol", {})
    if isinstance(by_protocol, Mapping):
        selected = by_protocol.get(protocol, by_protocol.get(protocol.split(":", 1)[0], default))
    else:
        selected = default
    if not isinstance(selected, Sequence) or isinstance(selected, (str, bytes)):
        raise ValueError("required_artifacts entries must be sequences")
    allowed = {"json", "raw_npz", "ood_npz"}
    result = tuple(str(value) for value in selected)
    unknown = set(result) - allowed
    if unknown:
        raise ValueError(f"unknown required artefacts: {sorted(unknown)}")
    return result


def _protocol_value(mapping: Any, protocol: str, default: Any = None) -> Any:
    if not isinstance(mapping, Mapping):
        return default
    return mapping.get(protocol, mapping.get(protocol.split(":", 1)[0], default))


def _ood_contract_parts(
    record: RunRecord, config: Mapping[str, Any]
) -> tuple[tuple[str, ...], tuple[str, ...], Mapping[str, Any]]:
    contract = config.get("ood_npz_contract", {})
    if not isinstance(contract, Mapping):
        raise ValueError("ood_npz_contract must be a mapping")
    scenarios_value = _protocol_value(
        contract.get("scenarios_by_protocol", {}), record.protocol, (),
    )
    detectors_by_method = contract.get("detectors_by_method", {})
    if detectors_by_method is not None and not isinstance(detectors_by_method, Mapping):
        raise ValueError("ood_npz_contract.detectors_by_method must be a mapping")
    detectors_value = (
        detectors_by_method.get(record.method)
        if isinstance(detectors_by_method, Mapping) and record.method in detectors_by_method
        else contract.get("detectors_default", ())
    )
    for name, value in (("scenarios", scenarios_value), ("detectors", detectors_value)):
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            raise ValueError(f"ood_npz_contract {name} must be a sequence")
    return (
        tuple(str(value) for value in detectors_value),
        tuple(str(value) for value in scenarios_value),
        contract,
    )


def ood_contract_problems(record: RunRecord, config: Mapping[str, Any]) -> list[str]:
    detectors, scenarios, contract = _ood_contract_parts(record, config)
    if not detectors or not scenarios:
        return []
    if record.ood_npz is None or not record.ood_npz.is_file():
        return ["ood_npz"]
    try:
        header = inspect_npz_headers(record.ood_npz)
    except Exception as exc:
        return [f"ood_npz_unreadable:{type(exc).__name__}"]
    arrays = {
        str(item.get("key")): item
        for item in header.get("arrays", [])
        if isinstance(item, Mapping)
    }
    required_keys = {
        f"{detector}__{scenario}"
        for detector in detectors
        for scenario in scenarios
    }
    problems = [f"ood_npz_key:{key}" for key in sorted(required_keys - set(arrays))]
    if contract.get("require_nonempty_1d_arrays", False):
        for key in sorted(required_keys & set(arrays)):
            shape = arrays[key].get("shape")
            if not isinstance(shape, list) or len(shape) != 1 or not shape or int(shape[0]) <= 0:
                problems.append(f"ood_npz_shape:{key}={shape}")
    if contract.get("require_floating_arrays", False):
        for key in sorted(required_keys & set(arrays)):
            try:
                dtype_kind = np.dtype(arrays[key].get("dtype")).kind
            except (TypeError, ValueError):
                dtype_kind = None
            if dtype_kind != "f":
                problems.append(
                    f"ood_npz_dtype:{key}={arrays[key].get('dtype')};expected=floating"
                )
    expected_lengths = _protocol_value(
        contract.get("scenario_lengths_by_protocol", {}), record.protocol, {},
    )
    if not isinstance(expected_lengths, Mapping):
        raise ValueError("ood_npz_contract scenario lengths must be mappings")
    for detector in detectors:
        for scenario in scenarios:
            key = f"{detector}__{scenario}"
            if key not in arrays or scenario not in expected_lengths:
                continue
            shape = arrays[key].get("shape")
            if (
                not isinstance(shape, list) or len(shape) != 1
                or int(shape[0]) != int(expected_lengths[scenario])
            ):
                problems.append(
                    f"ood_npz_length:{key}={shape};expected={expected_lengths[scenario]}"
                )

    report = record.payload.get("ood", {})
    if not isinstance(report, Mapping):
        problems.append("ood_json")
        return problems
    out_scenarios = tuple(
        scenario for scenario in scenarios if scenario not in ("validation", "id")
    )
    required_ood_metrics = contract.get("required_ood_metrics", ())
    required_operating_metrics = contract.get("required_operating_point_metrics", ())
    for name, value in (
        ("required_ood_metrics", required_ood_metrics),
        ("required_operating_point_metrics", required_operating_metrics),
    ):
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            raise ValueError(f"ood_npz_contract.{name} must be a sequence")
    required_ood_metrics = tuple(str(value) for value in required_ood_metrics)
    required_operating_metrics = tuple(str(value) for value in required_operating_metrics)

    def check_metric_mapping(
        value: Any, label: str, required_metrics: Sequence[str]
    ) -> None:
        if not isinstance(value, Mapping):
            problems.append(label)
            return
        for metric in required_metrics:
            if metric not in value:
                problems.append(f"{label}_metric:{metric}")
            elif contract.get("require_finite_json_metrics", False) and finite_number(
                value.get(metric)
            ) is None:
                problems.append(f"{label}_nonfinite:{metric}")

    for detector in detectors:
        detector_report = report.get(detector)
        if not isinstance(detector_report, Mapping):
            problems.append(f"ood_json_detector:{detector}")
            continue
        if contract.get("require_json_primary", False):
            check_metric_mapping(
                detector_report.get("primary"),
                f"ood_json_primary:{detector}",
                required_ood_metrics,
            )
        if contract.get("require_json_operating_point", False):
            check_metric_mapping(
                detector_report.get("operating_point"),
                f"ood_json_operating_point:{detector}",
                required_operating_metrics,
            )
        if contract.get("require_json_strata", False):
            strata = detector_report.get("strata")
            if not isinstance(strata, Mapping):
                problems.append(f"ood_json_strata:{detector}")
            else:
                for scenario in out_scenarios:
                    check_metric_mapping(
                        strata.get(scenario),
                        f"ood_json_stratum:{detector}:{scenario}",
                        required_ood_metrics,
                    )

    explicit_detectors = contract.get("detectors_by_method", {})
    is_evidence_method = not (
        isinstance(explicit_detectors, Mapping) and record.method in explicit_detectors
    )
    if contract.get("require_evidence_coefficient_sensitivity", False) and is_evidence_method:
        values = contract.get("evidence_coefficient_values", ())
        if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
            raise ValueError(
                "ood_npz_contract.evidence_coefficient_values must be a sequence"
            )
        sensitivity = report.get("coefficient_sensitivity")
        if not isinstance(sensitivity, Mapping):
            problems.append("ood_json_coefficient_sensitivity")
        else:
            for coefficient in (str(value) for value in values):
                entry = sensitivity.get(coefficient)
                if not isinstance(entry, Mapping):
                    problems.append(
                        f"ood_json_coefficient_sensitivity_value:{coefficient}"
                    )
                    continue
                check_metric_mapping(
                    entry.get("metrics"),
                    f"ood_json_coefficient_metrics:{coefficient}",
                    required_ood_metrics,
                )
                check_metric_mapping(
                    entry.get("operating_point"),
                    f"ood_json_coefficient_operating_point:{coefficient}",
                    required_operating_metrics,
                )
    return problems


def artifact_missing(
    record: RunRecord, required: Sequence[str], config: Mapping[str, Any]
) -> list[str]:
    missing: list[str] = []
    if "json" in required and not record.json_path.is_file():
        missing.append("json")
    if "raw_npz" in required and (record.raw_npz is None or not record.raw_npz.is_file()):
        missing.append("raw_npz")
    if "ood_npz" in required and (record.ood_npz is None or not record.ood_npz.is_file()):
        missing.append("ood_npz")
    if config.get("require_artifact_checksums", False):
        artifacts = record.payload.get("artifacts", {})
        if not isinstance(artifacts, Mapping):
            missing.append("artifact_manifest")
        else:
            for role, path in (("raw_npz", record.raw_npz), ("ood_npz", record.ood_npz)):
                if role not in required:
                    continue
                declared = artifacts.get(role)
                if not isinstance(declared, Mapping):
                    missing.append(f"{role}_manifest")
                    continue
                if path is None or not path.is_file():
                    continue
                if declared.get("filename") != path.name:
                    missing.append(f"{role}_filename")
                if declared.get("bytes") != int(path.stat().st_size):
                    missing.append(f"{role}_bytes")
                if declared.get("sha256") != sha256_file(path):
                    missing.append(f"{role}_sha256")
    if "ood_npz" in required and record.ood_npz is not None and record.ood_npz.is_file():
        missing.extend(ood_contract_problems(record, config))
    return missing


def values_equivalent(actual: Any, expected: Any) -> bool:
    if isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        return bool(np.isclose(float(actual), float(expected), rtol=1e-12, atol=1e-12))
    return jsonable(actual) == jsonable(expected)


def config_violations(record: RunRecord, config: Mapping[str, Any]) -> list[dict[str, Any]]:
    global_requirements = config.get("config_requirements", {})
    if not isinstance(global_requirements, Mapping):
        raise ValueError("config_requirements must be a dotted-key mapping")
    protocol_requirements = _protocol_value(
        config.get("config_requirements_by_protocol", {}), record.protocol, {},
    )
    if not isinstance(protocol_requirements, Mapping):
        raise ValueError("config_requirements_by_protocol entries must be mappings")
    requirements = {**global_requirements, **protocol_requirements}
    violations: list[dict[str, Any]] = []
    sentinel = object()
    for dotted_key, expected in requirements.items():
        actual = nested_get(record.payload, str(dotted_key), sentinel)
        if actual is sentinel:
            violations.append(
                {"key": str(dotted_key), "expected": expected, "actual": None, "reason": "missing"}
            )
        elif not values_equivalent(actual, expected):
            violations.append(
                {"key": str(dotted_key), "expected": expected, "actual": actual, "reason": "mismatch"}
            )

    if config.get("require_run_fingerprint", False):
        schema = record.payload.get("fingerprint_schema")
        definition = record.payload.get("run_definition")
        stored = record.payload.get("run_fingerprint")
        expected_schema = requirements.get("fingerprint_schema")
        if schema != expected_schema:
            violations.append(
                {
                    "key": "fingerprint_schema", "expected": expected_schema,
                    "actual": schema, "reason": "mismatch",
                }
            )
        if not isinstance(definition, Mapping):
            violations.append(
                {"key": "run_definition", "expected": "mapping", "actual": None,
                 "reason": "missing"}
            )
        elif not isinstance(stored, str) or stored != sha256_object(definition):
            violations.append(
                {"key": "run_fingerprint", "expected": sha256_object(definition),
                 "actual": stored, "reason": "mismatch"}
            )
        else:
            linked = {
                "script_version": nested_get(record.payload, "environment.script_version"),
                "arguments": nested_get(record.payload, "environment.arguments"),
                "model": record.payload.get("model"),
                "seed": record.payload.get("seed"),
                "protocol": record.payload.get("protocol"),
                "tau": record.payload.get("tau"),
                "split": record.payload.get("split"),
                "n_classes": record.payload.get("n_classes"),
                "class_names": record.payload.get("class_names"),
            }
            for key, actual in linked.items():
                if not values_equivalent(definition.get(key), actual):
                    violations.append(
                        {"key": f"run_definition.{key}", "expected": actual,
                         "actual": definition.get(key), "reason": "payload_mismatch"}
                    )
            code_expected = {
                "run_ptbxl_revision.py": nested_get(record.payload, "environment.script_sha256"),
                "revisionlib.py": nested_get(record.payload, "environment.revisionlib_sha256"),
                "data_adapter.py": nested_get(record.payload, "environment.data_adapter_sha256"),
            }
            if not values_equivalent(definition.get("code_sha256"), code_expected):
                violations.append(
                    {"key": "run_definition.code_sha256", "expected": code_expected,
                     "actual": definition.get("code_sha256"), "reason": "payload_mismatch"}
                )
    return violations


def build_completion_matrix(
    records: Sequence[RunRecord], config: Mapping[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    by_identity: dict[tuple[str, str, str, str, int], list[RunRecord]] = defaultdict(list)
    for record in records:
        if record.seed is not None:
            by_identity[(*record.group_key, record.seed)].append(record)

    duplicate_rows = []
    for identity, values in sorted(by_identity.items()):
        if len(values) > 1:
            duplicate_rows.append(
                {
                    "method": identity[0],
                    "protocol": identity[1],
                    "dataset": identity[2],
                    "split": identity[3],
                    "seed": identity[4],
                    "record_ids": [value.record_id for value in values],
                    "count": len(values),
                }
            )

    matrix: list[dict[str, Any]] = []
    seed_rows: list[dict[str, Any]] = []
    for method, protocol, dataset, split, seeds in expected_groups(config, records):
        required = required_artifacts(config, protocol)
        missing_seeds: list[int] = []
        incomplete_seeds: list[int] = []
        complete_seeds: list[int] = []
        extra_duplicate_seeds: list[int] = []
        for seed in seeds:
            identity = (method, protocol, dataset, split, seed)
            candidates = by_identity.get(identity, [])
            row: dict[str, Any] = {
                "method": method,
                "protocol": protocol,
                "dataset": dataset,
                "split": split,
                "seed": seed,
                "expected": True,
                "record_count": len(candidates),
                "required_artifacts": list(required),
            }
            if not candidates:
                row.update({"complete": False, "missing": ["run"]})
                missing_seeds.append(seed)
            elif len(candidates) > 1:
                row.update(
                    {
                        "complete": False,
                        "missing": [],
                        "problems": ["duplicate_identity"],
                        "record_ids": [candidate.record_id for candidate in candidates],
                    }
                )
                incomplete_seeds.append(seed)
                extra_duplicate_seeds.append(seed)
            else:
                record = candidates[0]
                missing = artifact_missing(record, required, config)
                violations = config_violations(record, config)
                status_complete = record.status == "complete"
                complete = status_complete and not missing and not violations
                row.update(
                    {
                        "complete": complete,
                        "missing": missing,
                        "status": record.status,
                        "record_id": record.record_id,
                        "config_violations": violations,
                    }
                )
                if complete:
                    complete_seeds.append(seed)
                else:
                    incomplete_seeds.append(seed)
            seed_rows.append(row)
        observed_for_group = sorted(
            identity[-1]
            for identity in by_identity
            if identity[:4] == (method, protocol, dataset, split)
        )
        unexpected_seeds = sorted(set(observed_for_group) - set(seeds))
        unique_observed = sorted(set(observed_for_group))
        matrix.append(
            {
                "method": method,
                "protocol": protocol,
                "dataset": dataset,
                "split": split,
                "expected_seeds": list(seeds),
                "observed_seeds": unique_observed,
                "complete_seeds": complete_seeds,
                "missing_seeds": missing_seeds,
                "incomplete_seeds": incomplete_seeds,
                "unexpected_seeds": unexpected_seeds,
                "duplicate_seeds": extra_duplicate_seeds,
                "n_expected": len(seeds),
                "n_observed": len(unique_observed),
                "n_complete": len(complete_seeds),
                "is_five_seed": len(unique_observed) == 5,
                "is_exact_expected_seed_set": set(unique_observed) == set(seeds),
                "complete": len(complete_seeds) == len(seeds),
                "non_five_seed": len(unique_observed) != 5,
            }
        )

    expected_keys = {
        (method, protocol, dataset, split)
        for method, protocol, dataset, split, _ in expected_groups(config, records)
    }
    for record in records:
        if record.group_key not in expected_keys:
            seed_rows.append(
                {
                    "method": record.method,
                    "protocol": record.protocol,
                    "dataset": record.dataset,
                    "split": record.split,
                    "seed": record.seed,
                    "expected": False,
                    "complete": False,
                    "problems": ["unexpected_group"],
                    "record_id": record.record_id,
                }
            )
    return matrix, seed_rows, duplicate_rows


def build_manifest(
    root: Path,
    output_dir: Path,
    records: Sequence[RunRecord],
    files: Sequence[Mapping[str, Any]],
    expected: Mapping[str, Any],
    expected_path: Optional[Path],
    audit_only: bool,
) -> dict[str, Any]:
    matrix, seed_rows, duplicates = build_completion_matrix(records, expected)
    referenced = {
        str(path.resolve())
        for record in records
        for path in (record.json_path, record.raw_npz, record.ood_npz)
        if path is not None
    }
    orphan_npz = [
        entry["path"]
        for entry in files
        if entry.get("kind") == "npz" and entry.get("path") not in referenced
    ]
    parse_errors = [entry for entry in files if entry.get("parse_status") == "error"]
    incomplete = [row for row in matrix if not row["complete"]]
    unexpected_seed_groups = [row for row in matrix if row["unexpected_seeds"]]
    non_five = [row for row in matrix if row["non_five_seed"]]
    allowed_identities = {
        (method, protocol, dataset, split, seed)
        for method, protocol, dataset, split, seeds in expected_groups(expected, records)
        for seed in seeds
    }
    unexpected_records = [
        record.record_id
        for record in records
        if record.seed is None or (*record.group_key, record.seed) not in allowed_identities
    ]
    declared_record_count = expected.get("expected_record_count")
    exact_record_count = (
        len(records) == int(declared_record_count)
        if declared_record_count is not None else True
    )
    code_hash_groups: dict[str, list[str]] = defaultdict(list)
    records_without_code_hashes: list[str] = []
    for record in records:
        code_hashes = nested_get(record.payload, "run_definition.code_sha256")
        if isinstance(code_hashes, Mapping):
            code_hash_groups[sha256_object(code_hashes)].append(record.record_id)
        else:
            records_without_code_hashes.append(record.record_id)
    require_uniform_code = bool(expected.get("require_uniform_code_hashes", False))
    uniform_code_hashes = (
        len(code_hash_groups) == 1 and not records_without_code_hashes
        if require_uniform_code else True
    )
    record_rows = []
    for record in records:
        record_rows.append(
            {
                "record_id": record.record_id,
                "json_path": str(record.json_path),
                "raw_npz": str(record.raw_npz) if record.raw_npz else None,
                "ood_npz": str(record.ood_npz) if record.ood_npz else None,
                "method": record.method,
                "family": record.family,
                "protocol_base": record.protocol_base,
                "protocol": record.protocol,
                "dataset": record.dataset,
                "split": record.split,
                "seed": record.seed,
                "status": record.status,
                "metric_count": len(record.metrics),
                "config": record.config,
                "config_sha256": sha256_object(record.config),
                "warnings": record.warnings,
            }
        )
    return {
        "schema_version": 1,
        "script_version": SCRIPT_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_root": str(root.resolve()),
        "output_dir": str(output_dir.resolve()),
        "audit_only": audit_only,
        "expected_config": {
            "path": str(expected_path.resolve()) if expected_path else None,
            "sha256": sha256_file(expected_path) if expected_path else None,
            "content": expected,
        },
        "summary": {
            "n_files": len(files),
            "n_records": len(records),
            "n_groups": len(matrix),
            "n_incomplete_groups": len(incomplete),
            "n_non_five_seed_groups": len(non_five),
            "n_duplicate_identities": len(duplicates),
            "n_unexpected_records": len(unexpected_records),
            "n_unexpected_seed_groups": len(unexpected_seed_groups),
            "n_parse_errors": len(parse_errors),
            "n_orphan_npz": len(orphan_npz),
            "exact_expected_record_count": exact_record_count,
            "uniform_code_hashes": uniform_code_hashes,
            "complete": bool(records) and not incomplete and not duplicates
            and not unexpected_records and not unexpected_seed_groups
            and exact_record_count and not parse_errors and uniform_code_hashes,
        },
        "files": list(files),
        "records": record_rows,
        "complete_missing_matrix": matrix,
        "seed_audit": seed_rows,
        "duplicate_identities": duplicates,
        "unexpected_records": unexpected_records,
        "orphan_npz": orphan_npz,
        "parse_errors": parse_errors,
        "code_hash_audit": {
            "required_uniform": require_uniform_code,
            "uniform": uniform_code_hashes,
            "groups": [
                {"code_hash_sha256": key, "record_ids": value, "count": len(value)}
                for key, value in sorted(code_hash_groups.items())
            ],
            "records_without_code_hashes": records_without_code_hashes,
        },
        "notes": [
            "non_five_seed=true is always retained even when a custom expected seed set is used",
            "complete requires status=complete, all configured artefacts, no config violation, and no duplicate identity",
            "complete also requires exactly the declared records and no unexpected group or seed",
            "NPZ inventory reads array headers only during discovery",
        ],
    }


def confidence_intervals(
    values: Sequence[float], confidence_level: float
) -> dict[str, Optional[float]]:
    array = np.asarray(values, dtype=np.float64)
    array = array[np.isfinite(array)]
    if not 0.0 < confidence_level < 1.0:
        raise ValueError("confidence_level must lie in (0,1)")
    if len(array) == 0:
        return {
            "mean": None,
            "sd": None,
            "t_ci_lower": None,
            "t_ci_upper": None,
            "percentile_ci_lower": None,
            "percentile_ci_upper": None,
        }
    mean = float(array.mean())
    alpha = 1.0 - confidence_level
    percentile = np.quantile(array, (alpha / 2.0, 1.0 - alpha / 2.0))
    if len(array) >= 2:
        sd = float(array.std(ddof=1))
        half_width = float(stats.t.ppf(1.0 - alpha / 2.0, len(array) - 1) * sd / np.sqrt(len(array)))
        t_lower, t_upper = mean - half_width, mean + half_width
    else:
        sd = t_lower = t_upper = None
    return {
        "mean": mean,
        "sd": sd,
        "t_ci_lower": t_lower,
        "t_ci_upper": t_upper,
        "percentile_ci_lower": float(percentile[0]),
        "percentile_ci_upper": float(percentile[1]),
    }


def expected_seed_map(
    config: Mapping[str, Any], records: Sequence[RunRecord]
) -> dict[tuple[str, str, str, str], tuple[int, ...]]:
    return {
        (method, protocol, dataset, split): seeds
        for method, protocol, dataset, split, seeds in expected_groups(config, records)
    }


def metric_seed_rows(records: Sequence[RunRecord]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        if record.seed is None:
            continue
        for metric, value in sorted(record.metrics.items()):
            rows.append(
                {
                    "method": record.method,
                    "family": record.family,
                    "protocol": record.protocol,
                    "dataset": record.dataset,
                    "split": record.split,
                    "seed": record.seed,
                    "metric": metric,
                    "value": value,
                    "record_id": record.record_id,
                }
            )
    return rows


def metric_completeness_rows(
    records: Sequence[RunRecord], config: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """Audit every configured primary metric even when no finite row exists."""

    indexed: dict[tuple[str, str, str, str, int], list[RunRecord]] = defaultdict(list)
    for record in records:
        if record.seed is not None:
            indexed[(*record.group_key, record.seed)].append(record)
    rows: list[dict[str, Any]] = []
    for method, protocol, dataset, split, seeds in expected_groups(config, records):
        for metric in primary_metrics_for_protocol(config, protocol):
            finite_seeds: list[int] = []
            missing_seeds: list[int] = []
            duplicate_seeds: list[int] = []
            for seed in seeds:
                candidates = indexed.get((method, protocol, dataset, split, seed), [])
                if len(candidates) != 1:
                    missing_seeds.append(seed)
                    if len(candidates) > 1:
                        duplicate_seeds.append(seed)
                    continue
                if finite_number(candidates[0].metrics.get(metric)) is None:
                    missing_seeds.append(seed)
                else:
                    finite_seeds.append(seed)
            rows.append(
                {
                    "method": method,
                    "protocol": protocol,
                    "dataset": dataset,
                    "split": split,
                    "metric": metric,
                    "expected_seeds": list(seeds),
                    "finite_seeds": finite_seeds,
                    "missing_or_nonfinite_seeds": missing_seeds,
                    "duplicate_seeds": duplicate_seeds,
                    "n_finite": len(finite_seeds),
                    "complete": len(finite_seeds) == len(seeds),
                    "is_five_seed": len(finite_seeds) == 5,
                    "non_five_seed": len(finite_seeds) != 5,
                }
            )
    return rows


def aggregate_seed_rows(
    rows: Sequence[Mapping[str, Any]],
    key_fields: Sequence[str],
    expected_by_group: Mapping[tuple[str, str, str, str], Sequence[int]],
    confidence_level: float,
) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row.get(field) for field in key_fields)].append(row)
    output: list[dict[str, Any]] = []
    for key, group_rows in sorted(grouped.items(), key=lambda item: tuple(str(v) for v in item[0])):
        seed_values: dict[int, list[float]] = defaultdict(list)
        for row in group_rows:
            value = finite_number(row.get("value"))
            seed = row.get("seed")
            if value is not None and seed is not None:
                seed_values[int(seed)].append(value)
        accepted: dict[int, float] = {}
        conflicting_seeds: list[int] = []
        duplicate_equal_seeds: list[int] = []
        for seed, values in sorted(seed_values.items()):
            if len(values) == 1:
                accepted[seed] = values[0]
            elif np.allclose(values, values[0], rtol=1e-12, atol=1e-12):
                accepted[seed] = values[0]
                duplicate_equal_seeds.append(seed)
            else:
                conflicting_seeds.append(seed)
        base = {field: value for field, value in zip(key_fields, key)}
        group_key = (
            str(base.get("method")),
            str(base.get("protocol")),
            str(base.get("dataset")),
            str(base.get("split")),
        )
        expected = tuple(int(value) for value in expected_by_group.get(group_key, DEFAULT_EXPECTED_SEEDS))
        observed = sorted(accepted)
        missing = sorted(set(expected) - set(observed))
        statistics = confidence_intervals(list(accepted.values()), confidence_level)
        base.update(
            {
                **statistics,
                "n": len(accepted),
                "seeds": observed,
                "expected_seeds": list(expected),
                "missing_seeds": missing,
                "unexpected_seeds": sorted(set(observed) - set(expected)),
                "conflicting_duplicate_seeds": conflicting_seeds,
                "identical_duplicate_seeds": duplicate_equal_seeds,
                "complete_expected_seeds": set(observed) == set(expected) and not conflicting_seeds,
                "is_five_seed": len(observed) == 5,
                "non_five_seed": len(observed) != 5,
            }
        )
        output.append(base)
    return output


def metric_direction(metric: str, config: Mapping[str, Any]) -> str:
    directions = config.get("metric_directions", {})
    if isinstance(directions, Mapping):
        if metric in directions:
            direction = str(directions[metric]).lower()
            if direction not in ("higher", "lower"):
                raise ValueError(f"invalid direction for {metric}: {direction}")
            return direction
        for pattern, value in directions.items():
            if str(pattern).startswith("re:") and re.search(str(pattern)[3:], metric):
                direction = str(value).lower()
                if direction not in ("higher", "lower"):
                    raise ValueError(f"invalid direction for {metric}: {direction}")
                return direction
    lower_tokens = (
        "nll",
        "brier",
        "ece",
        "fpr",
        "risk",
        "aurc",
        "eaurc",
        "error",
        "latency",
        "loss",
    )
    return "lower" if any(token in metric.lower() for token in lower_tokens) else "higher"


def primary_metrics(config: Mapping[str, Any]) -> tuple[str, ...]:
    default = (
        "diagnosis.accuracy",
        "diagnosis.balanced_accuracy",
        "diagnosis.macro_f1",
        "diagnosis.macro_auroc",
        "diagnosis.rare_macro_f1",
        "diagnosis.rare_macro_auroc",
        "diagnosis.calibration.raw.ece_fixed",
        "diagnosis.calibration.raw.nll",
        "diagnosis.selective_primary.aurc",
    )
    values = config.get("primary_metrics", default)
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise ValueError("primary_metrics must be a sequence")
    return tuple(str(value) for value in values)


def primary_metrics_for_protocol(
    config: Mapping[str, Any], protocol: str
) -> tuple[str, ...]:
    selected = _protocol_value(
        config.get("primary_metrics_by_protocol", {}), protocol, None,
    )
    if selected is None:
        return primary_metrics(config)
    if not isinstance(selected, Sequence) or isinstance(selected, (str, bytes)):
        raise ValueError("primary_metrics_by_protocol entries must be sequences")
    return tuple(str(value) for value in selected)


def comparison_specs(
    records: Sequence[RunRecord], config: Mapping[str, Any], reference_method: Optional[str]
) -> list[dict[str, Any]]:
    explicit = config.get("comparisons")
    if isinstance(explicit, Sequence) and not isinstance(explicit, (str, bytes)):
        result = []
        for item in explicit:
            if not isinstance(item, Mapping) or "a" not in item or "b" not in item:
                raise ValueError("each comparison needs method keys 'a' and 'b'")
            copied = dict(item)
            copied["metrics"] = [str(value) for value in item.get("metrics", primary_metrics(config))]
            result.append(copied)
        return result
    methods = sorted({record.method for record in records})
    reference = reference_method or config.get("reference_method")
    if reference is None and "trust_full" in methods:
        reference = "trust_full"
    if reference is None or str(reference) not in methods:
        return []
    return [
        {"a": str(reference), "b": method, "metrics": list(primary_metrics(config)), "automatic": True}
        for method in methods
        if method != str(reference)
    ]


def paired_statistics(differences: np.ndarray, confidence_level: float) -> dict[str, Any]:
    differences = np.asarray(differences, dtype=np.float64)
    differences = differences[np.isfinite(differences)]
    base = confidence_intervals(differences, confidence_level)
    n = len(differences)
    if n < 2:
        return {
            **base,
            "cohen_dz": None,
            "hedges_gz": None,
            "t_statistic": None,
            "p_value": None,
        }
    sd = float(differences.std(ddof=1))
    mean = float(differences.mean())
    if sd == 0.0:
        cohen = 0.0 if mean == 0.0 else math.copysign(math.inf, mean)
        t_statistic = 0.0 if mean == 0.0 else math.copysign(math.inf, mean)
        p_value = 1.0 if mean == 0.0 else 0.0
    else:
        cohen = mean / sd
        test = stats.ttest_1samp(differences, popmean=0.0, nan_policy="omit")
        t_statistic = float(test.statistic)
        p_value = float(test.pvalue)
    correction = 1.0 - 3.0 / (4.0 * n - 5.0) if n > 1 else 1.0
    return {
        **base,
        "cohen_dz": cohen,
        "hedges_gz": cohen * correction,
        "t_statistic": t_statistic,
        "p_value": p_value,
    }


def holm_adjust(rows: list[dict[str, Any]], p_key: str = "p_value", alpha: float = 0.05) -> None:
    valid = [
        (index, float(row[p_key]))
        for index, row in enumerate(rows)
        if finite_number(row.get(p_key)) is not None
    ]
    valid.sort(key=lambda item: item[1])
    running = 0.0
    total = len(valid)
    for rank, (index, p_value) in enumerate(valid):
        adjusted = min(1.0, (total - rank) * p_value)
        running = max(running, adjusted)
        rows[index]["p_holm"] = running
        rows[index]["reject_holm"] = bool(running <= alpha)
        rows[index]["holm_family_size"] = total
    for row in rows:
        row.setdefault("p_holm", None)
        row.setdefault("reject_holm", None)
        row.setdefault("holm_family_size", total)


def paired_seed_comparisons(
    records: Sequence[RunRecord],
    config: Mapping[str, Any],
    reference_method: Optional[str],
    confidence_level: float,
) -> list[dict[str, Any]]:
    by_method_pair: dict[tuple[str, str, str, int, str], list[RunRecord]] = defaultdict(list)
    for record in records:
        if record.seed is not None:
            key = (record.protocol, record.dataset, record.split, record.seed, record.method)
            by_method_pair[key].append(record)
    groups = sorted({(r.protocol, r.dataset, r.split) for r in records})
    output: list[dict[str, Any]] = []
    for spec in comparison_specs(records, config, reference_method):
        method_a, method_b = str(spec["a"]), str(spec["b"])
        allowed_protocols = {str(value) for value in spec.get("protocols", [])}
        allowed_datasets = {str(value) for value in spec.get("datasets", [])}
        allowed_splits = {str(value) for value in spec.get("splits", [])}
        for protocol, dataset, split in groups:
            if allowed_protocols and protocol not in allowed_protocols:
                continue
            if allowed_datasets and dataset not in allowed_datasets:
                continue
            if allowed_splits and split not in allowed_splits:
                continue
            candidate_seeds = sorted(
                {
                    r.seed
                    for r in records
                    if r.seed is not None
                    and r.protocol == protocol
                    and r.dataset == dataset
                    and r.split == split
                    and r.method in (method_a, method_b)
                }
            )
            for metric in spec["metrics"]:
                values_a: list[float] = []
                values_b: list[float] = []
                paired_seeds: list[int] = []
                unavailable: dict[str, str] = {}
                for seed in candidate_seeds:
                    a_records = by_method_pair.get((protocol, dataset, split, seed, method_a), [])
                    b_records = by_method_pair.get((protocol, dataset, split, seed, method_b), [])
                    if len(a_records) != 1 or len(b_records) != 1:
                        unavailable[str(seed)] = "missing_or_duplicate_run"
                        continue
                    value_a = finite_number(a_records[0].metrics.get(metric))
                    value_b = finite_number(b_records[0].metrics.get(metric))
                    if value_a is None or value_b is None:
                        unavailable[str(seed)] = "metric_missing_or_nonfinite"
                        continue
                    values_a.append(value_a)
                    values_b.append(value_b)
                    paired_seeds.append(seed)
                differences = np.asarray(values_a) - np.asarray(values_b)
                direction = metric_direction(str(metric), config)
                row = {
                    "method_a": method_a,
                    "method_b": method_b,
                    "contrast": "method_a_minus_method_b",
                    "protocol": protocol,
                    "dataset": dataset,
                    "split": split,
                    "metric": str(metric),
                    "direction": direction,
                    "n_pairs": len(paired_seeds),
                    "paired_seeds": paired_seeds,
                    "unavailable_seeds": unavailable,
                    "mean_a": float(np.mean(values_a)) if values_a else None,
                    "mean_b": float(np.mean(values_b)) if values_b else None,
                    **paired_statistics(differences, confidence_level),
                }
                row["benefit_difference"] = (
                    row["mean"] if direction == "higher" else -row["mean"]
                ) if row["mean"] is not None else None
                row["complete_five_pairs"] = len(paired_seeds) == 5
                row["non_five_pair"] = len(paired_seeds) != 5
                output.append(row)
    holm_adjust(output)
    return output


def softmax(logits: np.ndarray) -> np.ndarray:
    values = np.asarray(logits, dtype=np.float64)
    values = values - values.max(axis=1, keepdims=True)
    exponent = np.exp(values)
    return exponent / np.maximum(exponent.sum(axis=1, keepdims=True), 1e-300)


@dataclass
class RawPrediction:
    path: Path
    y: np.ndarray
    patient_ids: np.ndarray
    probs: Optional[np.ndarray]
    predictions: np.ndarray
    confidence: np.ndarray
    sample_ids: Optional[np.ndarray]
    rare_ids: np.ndarray
    class_names: Optional[np.ndarray]
    is_ood: Optional[np.ndarray]
    ood_score: Optional[np.ndarray]

    @property
    def n(self) -> int:
        return len(self.y)


def load_raw_prediction(path: Path) -> RawPrediction:
    """Load the minimum raw arrays needed for cluster statistics, without pickle."""

    with np.load(path, allow_pickle=False) as archive:
        label_key = first_present(archive, LABEL_KEYS)
        patient_key = first_present(archive, PATIENT_KEYS)
        if label_key is None or patient_key is None:
            raise KeyError("raw NPZ must contain test labels and patient/subject IDs")
        y = np.asarray(archive[label_key], dtype=np.int64).reshape(-1)
        patient_ids = np.asarray(archive[patient_key]).astype(str).reshape(-1)
        probability_key = first_present(archive, PROB_KEYS)
        logit_key = first_present(archive, LOGIT_KEYS)
        prediction_key = first_present(archive, PREDICTION_KEYS)
        if probability_key is not None:
            probs = np.asarray(archive[probability_key], dtype=np.float64)
            if probs.ndim != 2:
                raise ValueError(f"{probability_key} must be a two-dimensional matrix")
            row_sum = probs.sum(axis=1, keepdims=True)
            if np.any(~np.isfinite(probs)) or np.any(probs < 0) or np.any(row_sum <= 0):
                raise ValueError("probabilities are non-finite, negative, or have zero row sum")
            probs = probs / row_sum
        elif logit_key is not None:
            probs = softmax(np.asarray(archive[logit_key], dtype=np.float64))
        else:
            probs = None
        if prediction_key is not None:
            predictions = np.asarray(archive[prediction_key], dtype=np.int64).reshape(-1)
        elif probs is not None:
            predictions = probs.argmax(axis=1)
        else:
            raise KeyError("raw NPZ needs predictions, probabilities, or logits")
        confidence_key = first_present(archive, CONFIDENCE_KEYS)
        if confidence_key is not None:
            confidence = np.asarray(archive[confidence_key], dtype=np.float64).reshape(-1)
        elif "test_u" in archive:
            confidence = -np.asarray(archive["test_u"], dtype=np.float64).reshape(-1)
        elif probs is not None:
            confidence = probs.max(axis=1)
        else:
            confidence = np.full(len(y), np.nan, dtype=np.float64)
        sample_key = first_present(archive, SAMPLE_ID_KEYS)
        sample_ids = np.asarray(archive[sample_key]).astype(str).reshape(-1) if sample_key else None
        rare_key = first_present(archive, RARE_ID_KEYS)
        rare_ids = (
            np.asarray(archive[rare_key], dtype=np.int64).reshape(-1)
            if rare_key
            else np.asarray([], dtype=np.int64)
        )
        class_names = (
            np.asarray(archive["class_names"]).astype(str).reshape(-1)
            if "class_names" in archive
            else None
        )
        ood_label_key = first_present(archive, OOD_LABEL_KEYS)
        ood_score_key = first_present(archive, OOD_SCORE_KEYS)
        is_ood = (
            np.asarray(archive[ood_label_key], dtype=np.int64).reshape(-1)
            if ood_label_key
            else None
        )
        ood_score = (
            np.asarray(archive[ood_score_key], dtype=np.float64).reshape(-1)
            if ood_score_key
            else None
        )

    aligned = {
        "patient_ids": len(patient_ids),
        "predictions": len(predictions),
        "confidence": len(confidence),
    }
    if probs is not None:
        aligned["probs"] = len(probs)
    if sample_ids is not None:
        aligned["sample_ids"] = len(sample_ids)
    if is_ood is not None:
        aligned["is_ood"] = len(is_ood)
    if ood_score is not None:
        aligned["ood_score"] = len(ood_score)
    invalid = {key: length for key, length in aligned.items() if length != len(y)}
    if invalid:
        raise ValueError(f"raw arrays are not label-aligned: {invalid}; labels={len(y)}")
    return RawPrediction(
        path=path,
        y=y,
        patient_ids=patient_ids,
        probs=probs,
        predictions=predictions,
        confidence=confidence,
        sample_ids=sample_ids,
        rare_ids=rare_ids,
        class_names=class_names,
        is_ood=is_ood,
        ood_score=ood_score,
    )


def fixed_class_ids(raw: RawPrediction) -> np.ndarray:
    if raw.probs is not None:
        return np.arange(raw.probs.shape[1], dtype=np.int64)
    return np.unique(np.r_[raw.y, raw.predictions]).astype(np.int64)


def macro_ranking_metric(
    y: np.ndarray, probs: np.ndarray, class_ids: Sequence[int], kind: str
) -> float:
    values = []
    for class_id in class_ids:
        truth = y == int(class_id)
        if kind == "auroc":
            if truth.any() and (~truth).any():
                values.append(float(roc_auc_score(truth, probs[:, int(class_id)])))
        elif kind == "auprc":
            if truth.any():
                values.append(float(average_precision_score(truth, probs[:, int(class_id)])))
        else:
            raise ValueError(kind)
    return float(np.mean(values)) if values else float("nan")


def expected_calibration_error(
    confidence: np.ndarray, correct: np.ndarray, n_bins: int = 15, adaptive: bool = False
) -> float:
    confidence = np.asarray(confidence, dtype=np.float64)
    correct = np.asarray(correct, dtype=np.float64)
    if len(confidence) == 0:
        return float("nan")
    if adaptive:
        order = np.argsort(confidence, kind="mergesort")
        bins = [part for part in np.array_split(order, min(n_bins, len(order))) if len(part)]
    else:
        edges = np.linspace(0.0, 1.0, n_bins + 1)
        assignment = np.clip(np.digitize(confidence, edges[1:-1], right=True), 0, n_bins - 1)
        bins = [np.flatnonzero(assignment == index) for index in range(n_bins)]
    result = 0.0
    for indices in bins:
        if len(indices):
            result += len(indices) / len(confidence) * abs(
                float(correct[indices].mean() - confidence[indices].mean())
            )
    return float(result)


def aurc_value(correct: np.ndarray, confidence: np.ndarray) -> float:
    order = np.argsort(-np.asarray(confidence), kind="mergesort")
    errors = 1.0 - np.asarray(correct, dtype=np.float64)[order]
    return float(np.mean(np.cumsum(errors) / np.arange(1, len(errors) + 1)))


def raw_metric(raw: RawPrediction, metric: str, indices: np.ndarray) -> float:
    y = raw.y[indices]
    prediction = raw.predictions[indices]
    classes = fixed_class_ids(raw)
    rare = raw.rare_ids
    metric = metric.lower()
    if metric == "accuracy":
        return float(accuracy_score(y, prediction))
    if metric == "balanced_accuracy":
        return float(balanced_accuracy_score(y, prediction))
    if metric == "macro_f1":
        return float(f1_score(y, prediction, labels=classes, average="macro", zero_division=0))
    if metric == "weighted_f1":
        return float(f1_score(y, prediction, labels=classes, average="weighted", zero_division=0))
    if metric == "rare_macro_f1":
        if len(rare) == 0:
            return float("nan")
        return float(f1_score(y, prediction, labels=rare, average="macro", zero_division=0))
    if metric in ("macro_auroc", "macro_auprc", "rare_macro_auroc", "rare_macro_auprc"):
        if raw.probs is None:
            return float("nan")
        selected = rare if metric.startswith("rare_") else classes
        kind = "auroc" if metric.endswith("auroc") else "auprc"
        return macro_ranking_metric(y, raw.probs[indices], selected, kind)
    if raw.probs is not None and metric == "nll":
        probability = np.clip(raw.probs[indices, y], 1e-12, 1.0)
        return float(-np.log(probability).mean())
    if raw.probs is not None and metric == "brier":
        one_hot = np.eye(raw.probs.shape[1], dtype=np.float64)[y]
        return float(np.square(raw.probs[indices] - one_hot).sum(axis=1).mean())
    correct = (prediction == y).astype(np.float64)
    if metric == "ece_fixed":
        return expected_calibration_error(raw.confidence[indices], correct, adaptive=False)
    if metric == "ece_adaptive":
        return expected_calibration_error(raw.confidence[indices], correct, adaptive=True)
    if metric == "aurc":
        return aurc_value(correct, raw.confidence[indices])
    if metric in ("ood_auroc", "ood_auprc", "ood_fpr95"):
        if raw.is_ood is None or raw.ood_score is None:
            return float("nan")
        labels = raw.is_ood[indices]
        scores = raw.ood_score[indices]
        if len(np.unique(labels)) < 2:
            return float("nan")
        if metric == "ood_auroc":
            return float(roc_auc_score(labels, scores))
        if metric == "ood_auprc":
            return float(average_precision_score(labels, scores))
        fpr, tpr, _ = roc_curve(labels, scores)
        eligible = np.flatnonzero(tpr >= 0.95)
        return float(fpr[eligible[0]]) if len(eligible) else 1.0
    raise KeyError(f"unsupported raw metric {metric!r}")


def bootstrap_settings(
    config: Mapping[str, Any], cli_bootstrap: Optional[int]
) -> tuple[tuple[str, ...], int]:
    section = config.get("patient_bootstrap", {})
    if not isinstance(section, Mapping):
        raise ValueError("patient_bootstrap config must be a mapping")
    metrics = section.get("metrics", DEFAULT_PATIENT_METRICS)
    if not isinstance(metrics, Sequence) or isinstance(metrics, (str, bytes)):
        raise ValueError("patient_bootstrap.metrics must be a sequence")
    count = cli_bootstrap if cli_bootstrap is not None else int(section.get("n_bootstrap", 2000))
    if count < 1:
        raise ValueError("patient bootstrap replicate count must be positive")
    return tuple(str(value) for value in metrics), count


def stable_seed(base_seed: int, *parts: Any) -> int:
    digest = hashlib.sha256("|".join(str(part) for part in parts).encode("utf-8")).digest()
    return int((base_seed + int.from_bytes(digest[:4], "little")) % (2**32 - 1))


def cluster_bootstrap_indices(
    patient_ids: np.ndarray, n_bootstrap: int, random_seed: int
) -> Iterator[np.ndarray]:
    patients, inverse = np.unique(patient_ids.astype(str), return_inverse=True)
    groups = [np.flatnonzero(inverse == index) for index in range(len(patients))]
    rng = np.random.default_rng(random_seed)
    for _ in range(n_bootstrap):
        sampled = rng.integers(0, len(groups), size=len(groups))
        yield np.concatenate([groups[index] for index in sampled])


def patient_cluster_bootstraps(
    records: Sequence[RunRecord],
    config: Mapping[str, Any],
    cli_bootstrap: Optional[int],
    confidence_level: float,
    base_seed: int,
    raw_cache: MutableMapping[Path, RawPrediction | Exception],
) -> list[dict[str, Any]]:
    metrics, n_bootstrap = bootstrap_settings(config, cli_bootstrap)
    output: list[dict[str, Any]] = []
    alpha = 1.0 - confidence_level
    for record in records:
        common = {
            "method": record.method,
            "protocol": record.protocol,
            "dataset": record.dataset,
            "split": record.split,
            "seed": record.seed,
            "raw_npz": str(record.raw_npz) if record.raw_npz else None,
        }
        if record.raw_npz is None:
            for metric in metrics:
                output.append({**common, "metric": metric, "available": False, "reason": "missing_raw_npz"})
            continue
        raw = cached_raw(record.raw_npz, raw_cache)
        if isinstance(raw, Exception):
            for metric in metrics:
                output.append(
                    {
                        **common,
                        "metric": metric,
                        "available": False,
                        "reason": f"{type(raw).__name__}: {raw}",
                    }
                )
            continue
        patient_count = len(np.unique(raw.patient_ids))
        all_indices = np.arange(raw.n)
        for metric in metrics:
            try:
                observed = raw_metric(raw, metric, all_indices)
                samples = np.asarray(
                    [
                        raw_metric(raw, metric, indices)
                        for indices in cluster_bootstrap_indices(
                            raw.patient_ids,
                            n_bootstrap,
                            stable_seed(base_seed, record.record_id, metric),
                        )
                    ],
                    dtype=np.float64,
                )
                finite = samples[np.isfinite(samples)]
                if not math.isfinite(observed) or len(finite) == 0:
                    raise ValueError("metric is not estimable from this run")
                lower, upper = np.quantile(finite, (alpha / 2.0, 1.0 - alpha / 2.0))
                output.append(
                    {
                        **common,
                        "metric": metric,
                        "available": True,
                        "observed": observed,
                        "ci_lower": float(lower),
                        "ci_upper": float(upper),
                        "n_bootstrap_requested": n_bootstrap,
                        "n_bootstrap_finite": len(finite),
                        "n_patients": patient_count,
                        "n_records": raw.n,
                    }
                )
            except Exception as exc:
                output.append(
                    {
                        **common,
                        "metric": metric,
                        "available": False,
                        "reason": f"{type(exc).__name__}: {exc}",
                    }
                )
    return output


def cached_raw(
    path: Path, cache: MutableMapping[Path, RawPrediction | Exception]
) -> RawPrediction | Exception:
    path = path.resolve()
    if path not in cache:
        try:
            cache[path] = load_raw_prediction(path)
        except Exception as exc:
            cache[path] = exc
    return cache[path]


def align_raw_predictions(
    raw_a: RawPrediction, raw_b: RawPrediction
) -> tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[str]]:
    if raw_a.sample_ids is not None and raw_b.sample_ids is not None:
        if len(np.unique(raw_a.sample_ids)) != raw_a.n or len(np.unique(raw_b.sample_ids)) != raw_b.n:
            return None, None, "non_unique_sample_ids"
        lookup_b = {value: index for index, value in enumerate(raw_b.sample_ids.tolist())}
        if set(raw_a.sample_ids.tolist()) != set(raw_b.sample_ids.tolist()):
            return None, None, "sample_id_sets_differ"
        indices_a = np.arange(raw_a.n)
        indices_b = np.asarray([lookup_b[value] for value in raw_a.sample_ids.tolist()], dtype=np.int64)
    else:
        if raw_a.n != raw_b.n:
            return None, None, "record_counts_differ_and_sample_ids_unavailable"
        indices_a = np.arange(raw_a.n)
        indices_b = np.arange(raw_b.n)
    if not np.array_equal(raw_a.y[indices_a], raw_b.y[indices_b]):
        return None, None, "paired_labels_differ"
    if not np.array_equal(raw_a.patient_ids[indices_a], raw_b.patient_ids[indices_b]):
        return None, None, "paired_patient_ids_differ"
    if not np.array_equal(np.sort(raw_a.rare_ids), np.sort(raw_b.rare_ids)):
        return None, None, "rare_class_definitions_differ"
    return indices_a, indices_b, None


def paired_patient_bootstraps(
    records: Sequence[RunRecord],
    config: Mapping[str, Any],
    reference_method: Optional[str],
    cli_bootstrap: Optional[int],
    confidence_level: float,
    base_seed: int,
    raw_cache: MutableMapping[Path, RawPrediction | Exception],
) -> list[dict[str, Any]]:
    default_metrics, n_bootstrap = bootstrap_settings(config, cli_bootstrap)
    indexed: dict[tuple[str, str, str, int, str], list[RunRecord]] = defaultdict(list)
    for record in records:
        if record.seed is not None:
            indexed[(record.protocol, record.dataset, record.split, record.seed, record.method)].append(record)
    output: list[dict[str, Any]] = []
    alpha = 1.0 - confidence_level
    for spec in comparison_specs(records, config, reference_method):
        method_a, method_b = str(spec["a"]), str(spec["b"])
        requested_metrics = spec.get("patient_metrics", default_metrics)
        patient_metrics = [str(value) for value in requested_metrics]
        identities = sorted(
            {
                (record.protocol, record.dataset, record.split, int(record.seed))
                for record in records
                if record.seed is not None and record.method in (method_a, method_b)
            }
        )
        for protocol, dataset, split, seed in identities:
            common = {
                "method_a": method_a,
                "method_b": method_b,
                "contrast": "method_a_minus_method_b",
                "protocol": protocol,
                "dataset": dataset,
                "split": split,
                "seed": seed,
            }
            rows_a = indexed.get((protocol, dataset, split, seed, method_a), [])
            rows_b = indexed.get((protocol, dataset, split, seed, method_b), [])
            if len(rows_a) != 1 or len(rows_b) != 1:
                for metric in patient_metrics:
                    output.append(
                        {**common, "metric": metric, "available": False, "reason": "missing_or_duplicate_run"}
                    )
                continue
            if rows_a[0].raw_npz is None or rows_b[0].raw_npz is None:
                for metric in patient_metrics:
                    output.append(
                        {**common, "metric": metric, "available": False, "reason": "missing_raw_npz"}
                    )
                continue
            raw_a = cached_raw(rows_a[0].raw_npz, raw_cache)
            raw_b = cached_raw(rows_b[0].raw_npz, raw_cache)
            if isinstance(raw_a, Exception) or isinstance(raw_b, Exception):
                reason = f"raw_load_error: A={raw_a!s}; B={raw_b!s}"
                for metric in patient_metrics:
                    output.append({**common, "metric": metric, "available": False, "reason": reason})
                continue
            indices_a, indices_b, reason = align_raw_predictions(raw_a, raw_b)
            if reason is not None or indices_a is None or indices_b is None:
                for metric in patient_metrics:
                    output.append({**common, "metric": metric, "available": False, "reason": reason})
                continue
            aligned_patients = raw_a.patient_ids[indices_a]
            patient_count = len(np.unique(aligned_patients))
            positions = np.arange(len(indices_a))
            for metric in patient_metrics:
                try:
                    observed_a = raw_metric(raw_a, metric, indices_a)
                    observed_b = raw_metric(raw_b, metric, indices_b)
                    differences = []
                    for sampled_positions in cluster_bootstrap_indices(
                        aligned_patients,
                        n_bootstrap,
                        stable_seed(base_seed, protocol, dataset, split, seed, method_a, method_b, metric),
                    ):
                        differences.append(
                            raw_metric(raw_a, metric, indices_a[sampled_positions])
                            - raw_metric(raw_b, metric, indices_b[sampled_positions])
                        )
                    samples = np.asarray(differences, dtype=np.float64)
                    finite = samples[np.isfinite(samples)]
                    if len(finite) == 0:
                        raise ValueError("paired metric is not estimable")
                    lower, upper = np.quantile(finite, (alpha / 2.0, 1.0 - alpha / 2.0))
                    p_value = float(
                        min(1.0, 2.0 * min(np.mean(finite <= 0.0), np.mean(finite >= 0.0)))
                    )
                    direction = metric_direction(metric, config)
                    difference = observed_a - observed_b
                    output.append(
                        {
                            **common,
                            "metric": metric,
                            "direction": direction,
                            "available": True,
                            "observed_a": observed_a,
                            "observed_b": observed_b,
                            "observed_difference": difference,
                            "benefit_difference": difference if direction == "higher" else -difference,
                            "ci_lower": float(lower),
                            "ci_upper": float(upper),
                            "p_value": p_value,
                            "n_bootstrap_requested": n_bootstrap,
                            "n_bootstrap_finite": len(finite),
                            "n_patients": patient_count,
                            "n_records": len(positions),
                        }
                    )
                except Exception as exc:
                    output.append(
                        {
                            **common,
                            "metric": metric,
                            "available": False,
                            "reason": f"{type(exc).__name__}: {exc}",
                        }
                    )
    holm_adjust(output)
    return output


def classwise_rows_from_raw(record: RunRecord, raw: RawPrediction) -> list[dict[str, Any]]:
    classes = fixed_class_ids(raw)
    rows: list[dict[str, Any]] = []
    for class_id in classes:
        truth = raw.y == class_id
        predicted = raw.predictions == class_id
        true_positive = int(np.sum(truth & predicted))
        false_positive = int(np.sum(~truth & predicted))
        false_negative = int(np.sum(truth & ~predicted))
        precision = true_positive / (true_positive + false_positive) if true_positive + false_positive else 0.0
        recall = true_positive / (true_positive + false_negative) if true_positive + false_negative else 0.0
        f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
        name = (
            str(raw.class_names[class_id])
            if raw.class_names is not None and class_id < len(raw.class_names)
            else str(class_id)
        )
        row: dict[str, Any] = {
            "class_id": int(class_id),
            "class_name": name,
            "test_records": int(truth.sum()),
            "test_patients": int(len(np.unique(raw.patient_ids[truth]))),
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "is_rare": bool(class_id in set(raw.rare_ids.tolist())),
            "estimable_ranking": bool(truth.any() and (~truth).any()),
            "source": "raw_npz_recomputed",
        }
        if raw.probs is not None and truth.any() and (~truth).any():
            row["auroc"] = float(roc_auc_score(truth, raw.probs[:, class_id]))
        else:
            row["auroc"] = None
        if raw.probs is not None and truth.any():
            row["auprc"] = float(average_precision_score(truth, raw.probs[:, class_id]))
        else:
            row["auprc"] = None
        rows.append(row)
    return rows


def classwise_seed_rows(
    records: Sequence[RunRecord], raw_cache: MutableMapping[Path, RawPrediction | Exception]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    values: list[dict[str, Any]] = []
    availability: list[dict[str, Any]] = []
    identifier_fields = {
        "class_id",
        "class_name",
        "is_rare",
        "estimable_ranking",
        "source",
    }
    for record in records:
        diagnosis = record.payload.get("diagnosis", {})
        table = diagnosis.get("classwise") if isinstance(diagnosis, Mapping) else None
        rows: list[dict[str, Any]] = []
        source = "json"
        if isinstance(table, list) and table and all(isinstance(item, Mapping) for item in table):
            rare_ids = {int(value) for value in record.payload.get("rare_ids", [])}
            rare_names = {str(value) for value in record.payload.get("rare_names", [])}
            for item in table:
                copied = dict(item)
                class_id = copied.get("class_id")
                class_name = str(copied.get("class_name", class_id))
                copied["is_rare"] = (
                    int(class_id) in rare_ids if class_id is not None else class_name in rare_names
                )
                copied["source"] = "json"
                rows.append(copied)
        elif record.raw_npz is not None:
            raw = cached_raw(record.raw_npz, raw_cache)
            if not isinstance(raw, Exception):
                rows = classwise_rows_from_raw(record, raw)
                source = "raw_npz_recomputed"
        common = {
            "method": record.method,
            "protocol": record.protocol,
            "dataset": record.dataset,
            "split": record.split,
            "seed": record.seed,
        }
        if not rows:
            availability.append({**common, "available": False, "reason": "classwise_data_missing"})
            continue
        availability.append({**common, "available": True, "source": source, "n_classes": len(rows)})
        for row in rows:
            class_id = row.get("class_id")
            class_name = str(row.get("class_name", class_id))
            is_rare = bool(row.get("is_rare", False))
            for metric, value in row.items():
                if metric in identifier_fields:
                    continue
                number = finite_number(value)
                if number is not None:
                    values.append(
                        {
                            **common,
                            "class_id": class_id,
                            "class_name": class_name,
                            "is_rare": is_rare,
                            "metric": metric,
                            "value": number,
                            "source": str(row.get("source", source)),
                        }
                    )
    return values, availability


def ood_category(
    protocol: str, scenario: str, config: Mapping[str, Any]
) -> str:
    mappings = config.get("ood_categories", {})
    if isinstance(mappings, Mapping):
        composite = f"{protocol}:{scenario}"
        if composite in mappings:
            return str(mappings[composite])
        if scenario in mappings:
            return str(mappings[scenario])
    name = scenario.lower()
    if "pure" in name:
        return "pure"
    if "mixed" in name:
        return "mixed"
    if any(token in name for token in ("chapman", "ningbo", "mhealth", "wesad", "cross")):
        return "cross"
    if protocol.startswith("closed") and scenario not in ("primary", "id", "validation"):
        return "cross"
    if scenario in ("all", "primary"):
        return "aggregate"
    return "unclassified"


def ood_seed_rows(records: Sequence[RunRecord], config: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        report = record.payload.get("ood", {})
        if not isinstance(report, Mapping):
            continue
        for detector, detector_report in report.items():
            if not isinstance(detector_report, Mapping):
                continue
            if detector == "coefficient_sensitivity":
                for coefficient, sensitivity in detector_report.items():
                    if not isinstance(sensitivity, Mapping):
                        continue
                    metrics = sensitivity.get("metrics", {})
                    if isinstance(metrics, Mapping):
                        for metric, value in metrics.items():
                            number = finite_number(value)
                            if number is not None:
                                rows.append(
                                    {
                                        "method": record.method,
                                        "protocol": record.protocol,
                                        "dataset": record.dataset,
                                        "split": record.split,
                                        "seed": record.seed,
                                        "detector": "composite_sensitivity",
                                        "detector_parameter": str(coefficient),
                                        "scenario": "primary",
                                        "ood_category": "aggregate",
                                        "metric": str(metric),
                                        "value": number,
                                    }
                                )
                continue
            scenario_maps: list[tuple[str, Mapping[str, Any]]] = []
            primary = detector_report.get("primary")
            if isinstance(primary, Mapping):
                scenario_maps.append(("primary", primary))
            strata = detector_report.get("strata")
            if isinstance(strata, Mapping):
                for scenario, metric_map in strata.items():
                    if isinstance(metric_map, Mapping):
                        scenario_maps.append((str(scenario), metric_map))
            operating = detector_report.get("operating_point")
            if isinstance(operating, Mapping):
                scenario_maps.append(("operating_point", operating))
            for scenario, metric_map in scenario_maps:
                for metric, value in flatten_numeric(metric_map).items():
                    number = finite_number(value)
                    if number is None:
                        continue
                    rows.append(
                        {
                            "method": record.method,
                            "protocol": record.protocol,
                            "dataset": record.dataset,
                            "split": record.split,
                            "seed": record.seed,
                            "detector": str(detector),
                            "detector_parameter": None,
                            "scenario": scenario,
                            "ood_category": ood_category(record.protocol, scenario, config),
                            "metric": metric,
                            "value": number,
                        }
                    )
    return rows


def calibration_seed_rows(records: Sequence[RunRecord]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        calibration = nested_get(record.payload, "diagnosis.calibration", {})
        if not isinstance(calibration, Mapping):
            continue
        for variant_key, variant in calibration.items():
            if not isinstance(variant, Mapping):
                continue
            if str(variant_key).lower() == "raw":
                variant_name = "raw"
            elif str(variant_key).lower() in ("temperature_scaled", "ts", "scaled"):
                variant_name = "TS"
            else:
                variant_name = str(variant_key)
            for metric, value in flatten_numeric(variant).items():
                rows.append(
                    {
                        "method": record.method,
                        "protocol": record.protocol,
                        "dataset": record.dataset,
                        "split": record.split,
                        "seed": record.seed,
                        "calibration_variant": variant_name,
                        "metric": metric,
                        "value": value,
                    }
                )
        temperature = finite_number(calibration.get("temperature"))
        if temperature is not None:
            rows.append(
                {
                    "method": record.method,
                    "protocol": record.protocol,
                    "dataset": record.dataset,
                    "split": record.split,
                    "seed": record.seed,
                    "calibration_variant": "TS",
                    "metric": "temperature",
                    "value": temperature,
                }
            )
    return rows


def selective_seed_rows(records: Sequence[RunRecord]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        diagnosis = record.payload.get("diagnosis", {})
        if not isinstance(diagnosis, Mapping):
            continue
        for selector_key in ("selective_primary", "selective_max_probability"):
            report = diagnosis.get(selector_key)
            if not isinstance(report, Mapping):
                continue
            common = {
                "method": record.method,
                "protocol": record.protocol,
                "dataset": record.dataset,
                "split": record.split,
                "seed": record.seed,
                "selector": selector_key.removeprefix("selective_"),
            }
            for metric in ("aurc", "eaurc"):
                value = finite_number(report.get(metric))
                if value is not None:
                    rows.append(
                        {
                            **common,
                            "operating_kind": "curve_summary",
                            "target": None,
                            "metric": metric,
                            "value": value,
                        }
                    )
            fixed_coverage = report.get("fixed_coverage", {})
            if isinstance(fixed_coverage, Mapping):
                for target, metrics in fixed_coverage.items():
                    if not isinstance(metrics, Mapping):
                        continue
                    for metric, value in flatten_numeric(metrics).items():
                        rows.append(
                            {
                                **common,
                                "operating_kind": "fixed_coverage",
                                "target": str(target),
                                "metric": metric,
                                "value": value,
                            }
                        )
            fixed_risk = report.get("coverage_at_fixed_risk", report.get("fixed_risk", {}))
            if isinstance(fixed_risk, Mapping):
                for target, metrics in fixed_risk.items():
                    if not isinstance(metrics, Mapping):
                        continue
                    for metric, value in flatten_numeric(metrics).items():
                        rows.append(
                            {
                                **common,
                                "operating_kind": "fixed_risk",
                                "target": str(target),
                                "metric": metric,
                                "value": value,
                            }
                        )
    return rows


def section_audit(
    records: Sequence[RunRecord],
    config: Mapping[str, Any],
    files: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    configured = config.get("required_sections")
    default_sections = (
        "diagnosis",
        "classwise",
        "rare_definition",
        "calibration_raw",
        "calibration_ts",
        "selective_fixed_coverage",
        "selective_fixed_risk",
        "raw_patient_predictions",
    )
    if configured is not None and (
        not isinstance(configured, Sequence) or isinstance(configured, (str, bytes))
    ):
        raise ValueError("required_sections must be a sequence")
    npz_headers = {
        str(entry.get("path")): {
            str(array.get("key")): dict(array)
            for array in entry.get("arrays", [])
            if isinstance(array, Mapping) and array.get("key") is not None
        }
        for entry in files
        if entry.get("kind") == "npz"
    }
    required_metrics_value = config.get("required_metrics", ())
    if not isinstance(required_metrics_value, Sequence) or isinstance(
        required_metrics_value, (str, bytes)
    ):
        raise ValueError("required_metrics must be a sequence")
    required_metrics = [str(value) for value in required_metrics_value]
    rows: list[dict[str, Any]] = []
    for record in records:
        required = list(configured or default_sections)
        cross_dataset = bool(nested_get(record.payload, "environment.arguments.cross_dataset", False))
        if record.protocol_base == "strict" or cross_dataset:
            required.append("ood")
        diagnosis = record.payload.get("diagnosis", {})
        calibration = diagnosis.get("calibration", {}) if isinstance(diagnosis, Mapping) else {}
        primary_selective = (
            diagnosis.get("selective_primary", {}) if isinstance(diagnosis, Mapping) else {}
        )
        raw_header = npz_headers.get(str(record.raw_npz.resolve()), {}) if record.raw_npz else {}
        raw_keys = set(raw_header)
        patient_key = first_present(raw_header, PATIENT_KEYS)
        label_key = first_present(raw_header, LABEL_KEYS)
        probability_key = first_present(raw_header, PROB_KEYS)
        logit_key = first_present(raw_header, LOGIT_KEYS)
        prediction_key = first_present(raw_header, PREDICTION_KEYS)
        raw_contract_errors: list[str] = []
        if patient_key is None:
            raw_contract_errors.append("patient_ids")
        if label_key is None:
            raw_contract_errors.append("labels")
        if probability_key is None and logit_key is None and prediction_key is None:
            raw_contract_errors.append("probabilities_or_logits_or_predictions")
        n_records: Optional[int] = None
        if label_key is not None:
            label_shape = raw_header[label_key].get("shape")
            if not isinstance(label_shape, list) or len(label_shape) != 1 or int(label_shape[0]) <= 0:
                raw_contract_errors.append(f"label_shape={label_shape}")
            else:
                n_records = int(label_shape[0])
        if patient_key is not None and n_records is not None:
            patient_shape = raw_header[patient_key].get("shape")
            if patient_shape != [n_records]:
                raw_contract_errors.append(f"patient_shape={patient_shape}")
        for role, key in (("probability", probability_key), ("logit", logit_key)):
            if key is None or n_records is None:
                continue
            shape = raw_header[key].get("shape")
            if (
                not isinstance(shape, list) or len(shape) != 2
                or int(shape[0]) != n_records or int(shape[1]) <= 1
            ):
                raw_contract_errors.append(f"{role}_shape={shape}")
        if prediction_key is not None and n_records is not None:
            prediction_shape = raw_header[prediction_key].get("shape")
            if prediction_shape != [n_records]:
                raw_contract_errors.append(f"prediction_shape={prediction_shape}")
        raw_has_required_keys = not raw_contract_errors
        available = {
            "diagnosis": isinstance(diagnosis, Mapping) and bool(diagnosis),
            "classwise": isinstance(diagnosis, Mapping)
            and isinstance(diagnosis.get("classwise"), list)
            and bool(diagnosis.get("classwise")),
            "rare_definition": "rare_definition" in record.payload
            and "rare_ids" in record.payload,
            "calibration_raw": isinstance(calibration, Mapping)
            and isinstance(calibration.get("raw"), Mapping),
            "calibration_ts": isinstance(calibration, Mapping)
            and isinstance(calibration.get("temperature_scaled", calibration.get("TS")), Mapping),
            "selective_fixed_coverage": isinstance(primary_selective, Mapping)
            and isinstance(primary_selective.get("fixed_coverage"), Mapping)
            and bool(primary_selective.get("fixed_coverage")),
            "selective_fixed_risk": isinstance(primary_selective, Mapping)
            and isinstance(
                primary_selective.get("coverage_at_fixed_risk", primary_selective.get("fixed_risk")),
                Mapping,
            )
            and bool(primary_selective.get("coverage_at_fixed_risk", primary_selective.get("fixed_risk"))),
            "raw_patient_predictions": record.raw_npz is not None and raw_has_required_keys,
            "ood": isinstance(record.payload.get("ood"), Mapping) and bool(record.payload.get("ood")),
        }
        missing = [str(section) for section in required if not available.get(str(section), False)]
        missing_metrics = [metric for metric in required_metrics if metric not in record.metrics]
        rows.append(
            {
                "record_id": record.record_id,
                "method": record.method,
                "protocol": record.protocol,
                "dataset": record.dataset,
                "split": record.split,
                "seed": record.seed,
                "required_sections": required,
                "available_sections": sorted(key for key, value in available.items() if value),
                "missing_sections": missing,
                "required_metrics": required_metrics,
                "missing_metrics": missing_metrics,
                "raw_npz_contract_errors": raw_contract_errors,
                "complete": not missing and not missing_metrics,
            }
        )
    return rows


def latex_escape(value: Any) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(character, character) for character in text)


def format_number(value: Any, digits: int = 4) -> str:
    number = finite_number(value)
    return "--" if number is None else f"{number:.{digits}f}"


def latex_summary(
    metric_summary: Sequence[Mapping[str, Any]],
    paired_summary: Sequence[Mapping[str, Any]],
    matrix: Sequence[Mapping[str, Any]],
    config: Mapping[str, Any],
) -> str:
    selected = set(str(value) for value in config.get("latex_metrics", primary_metrics(config)))
    metric_rows = [row for row in metric_summary if str(row.get("metric")) in selected]
    lines = [
        "% Auto-generated by aggregate_results.py; do not edit numerical values by hand.",
        r"\begin{table*}[t]",
        r"\centering",
        r"\small",
        r"\caption{Seed-level performance. Values are mean $\pm$ sample SD; incomplete groups are flagged.}",
        r"\label{tab:revision_seed_summary}",
        r"\begin{tabular}{llllll}",
        r"\hline",
        r"Method & Protocol & Dataset & Metric & Mean $\pm$ SD & Seeds \\",
        r"\hline",
    ]
    for row in metric_rows:
        mean_sd = f"{format_number(row.get('mean'))} $\\pm$ {format_number(row.get('sd'))}"
        seed_text = (
            f"{row.get('n', 0)}/{len(row.get('expected_seeds', DEFAULT_EXPECTED_SEEDS))}"
            + ("*" if row.get("non_five_seed") else "")
        )
        cells = [
            latex_escape(row.get("method")),
            latex_escape(row.get("protocol")),
            latex_escape(row.get("dataset")),
            latex_escape(row.get("metric")),
            mean_sd,
            latex_escape(seed_text),
        ]
        lines.append(
            " & ".join(cells) + r" \\"
        )
    if not metric_rows:
        lines.append(r"\multicolumn{6}{c}{No complete numeric rows available.} \\")
    lines.extend(
        [
            r"\hline",
            r"\end{tabular}",
            r"\begin{flushleft}\footnotesize * Non-five-seed group; consult result\_manifest.json.\end{flushleft}",
            r"\end{table*}",
            "",
            r"\begin{table*}[t]",
            r"\centering",
            r"\small",
            r"\caption{Paired seed contrasts (method A minus method B), with Holm-adjusted $p$ values.}",
            r"\label{tab:revision_paired_summary}",
            r"\begin{tabular}{llllrrr}",
            r"\hline",
            r"A & B & Protocol & Metric & Difference & Effect ($d_z$) & $p_{Holm}$ \\",
            r"\hline",
        ]
    )
    for row in paired_summary:
        lines.append(
            " & ".join(
                latex_escape(value)
                for value in (
                    row.get("method_a"),
                    row.get("method_b"),
                    row.get("protocol"),
                    row.get("metric"),
                    format_number(row.get("mean")),
                    format_number(row.get("cohen_dz")),
                    format_number(row.get("p_holm")),
                )
            )
            + r" \\" 
        )
    if not paired_summary:
        lines.append(r"\multicolumn{7}{c}{No estimable paired contrasts available.} \\")
    lines.extend(
        [
            r"\hline",
            r"\end{tabular}",
            r"\end{table*}",
            "",
            "% Completeness audit",
        ]
    )
    for row in matrix:
        lines.append(
            "% "
            + " | ".join(
                str(value)
                for value in (
                    row.get("method"),
                    row.get("protocol"),
                    f"complete={row.get('complete')}",
                    f"observed={row.get('observed_seeds')}",
                    f"missing={row.get('missing_seeds')}",
                )
            )
        )
    return "\n".join(lines) + "\n"


def generated_file_entry(path: Path, output_dir: Path) -> dict[str, Any]:
    return {
        "path": str(path.resolve()),
        "relative_path": str(path.resolve().relative_to(output_dir.resolve())),
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit and aggregate Paper46 JSON/NPZ results without imputing missing runs."
    )
    parser.add_argument("results_root", type=Path, help="root recursively containing result JSON/NPZ")
    parser.add_argument("--output-dir", type=Path, required=True, help="separate aggregate output directory")
    parser.add_argument(
        "--expected-config",
        type=Path,
        default=None,
        help="JSON/YAML expected run matrix, comparisons, metric directions, and required sections",
    )
    parser.add_argument(
        "--audit-only",
        action="store_true",
        help="write manifest/completeness CSV only; do not load raw arrays or compute statistics",
    )
    parser.add_argument(
        "--bootstrap",
        type=int,
        default=None,
        help="override patient-cluster bootstrap replicates from expected config (default 2000)",
    )
    parser.add_argument("--confidence-level", type=float, default=0.95)
    parser.add_argument("--random-seed", type=int, default=2026)
    parser.add_argument(
        "--reference-method",
        default=None,
        help="automatic comparison reference when expected config has no explicit comparisons",
    )
    parser.add_argument(
        "--fail-on-incomplete",
        action="store_true",
        help="return exit code 2 after writing outputs if any expected group/section is incomplete",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    root = args.results_root.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    expected_path = args.expected_config.expanduser().resolve() if args.expected_config else None
    if not root.is_dir():
        raise FileNotFoundError(f"results root does not exist or is not a directory: {root}")
    if output_dir == root or output_dir in root.parents:
        raise ValueError("--output-dir must not equal or contain results_root")
    if not 0.0 < args.confidence_level < 1.0:
        raise ValueError("--confidence-level must lie in (0,1)")
    expected = load_expected_config(expected_path)
    records, files = discover_inputs(root, output_dir)
    manifest = build_manifest(
        root, output_dir, records, files, expected, expected_path, args.audit_only
    )
    sections = section_audit(records, expected, files)
    metric_audit = metric_completeness_rows(records, expected)
    manifest["section_audit"] = sections
    manifest["metric_completeness"] = metric_audit
    manifest["summary"]["n_incomplete_section_records"] = sum(
        not row["complete"] for row in sections
    )
    manifest["summary"]["n_incomplete_metric_groups"] = sum(
        not row["complete"] for row in metric_audit
    )
    manifest["summary"]["complete"] = bool(
        manifest["summary"]["complete"]
        and all(row["complete"] for row in sections)
        and all(row["complete"] for row in metric_audit)
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    completion_path = output_dir / "completion_matrix.csv"
    seed_audit_path = output_dir / "seed_audit.csv"
    section_audit_path = output_dir / "section_audit.csv"
    metric_audit_path = output_dir / "metric_completeness.csv"
    write_csv(completion_path, manifest["complete_missing_matrix"])
    write_csv(seed_audit_path, manifest["seed_audit"])
    write_csv(section_audit_path, sections)
    write_csv(metric_audit_path, metric_audit)

    generated_paths = [completion_path, seed_audit_path, section_audit_path, metric_audit_path]
    if not args.audit_only:
        expected_by_group = expected_seed_map(expected, records)
        seed_values = metric_seed_rows(records)
        seed_summary = aggregate_seed_rows(
            seed_values,
            ("method", "family", "protocol", "dataset", "split", "metric"),
            expected_by_group,
            args.confidence_level,
        )
        paired_seed = paired_seed_comparisons(
            records, expected, args.reference_method, args.confidence_level
        )
        raw_cache: dict[Path, RawPrediction | Exception] = {}
        classwise_values, classwise_availability = classwise_seed_rows(records, raw_cache)
        classwise_summary = aggregate_seed_rows(
            classwise_values,
            (
                "method",
                "protocol",
                "dataset",
                "split",
                "class_id",
                "class_name",
                "is_rare",
                "metric",
            ),
            expected_by_group,
            args.confidence_level,
        )
        rare_summary = [row for row in classwise_summary if row.get("is_rare")]
        ood_values = ood_seed_rows(records, expected)
        ood_summary = aggregate_seed_rows(
            ood_values,
            (
                "method",
                "protocol",
                "dataset",
                "split",
                "detector",
                "detector_parameter",
                "scenario",
                "ood_category",
                "metric",
            ),
            expected_by_group,
            args.confidence_level,
        )
        calibration_values = calibration_seed_rows(records)
        calibration_summary = aggregate_seed_rows(
            calibration_values,
            (
                "method",
                "protocol",
                "dataset",
                "split",
                "calibration_variant",
                "metric",
            ),
            expected_by_group,
            args.confidence_level,
        )
        selective_values = selective_seed_rows(records)
        selective_summary = aggregate_seed_rows(
            selective_values,
            (
                "method",
                "protocol",
                "dataset",
                "split",
                "selector",
                "operating_kind",
                "target",
                "metric",
            ),
            expected_by_group,
            args.confidence_level,
        )
        patient_bootstrap = patient_cluster_bootstraps(
            records,
            expected,
            args.bootstrap,
            args.confidence_level,
            args.random_seed,
            raw_cache,
        )
        paired_patient = paired_patient_bootstraps(
            records,
            expected,
            args.reference_method,
            args.bootstrap,
            args.confidence_level,
            args.random_seed,
            raw_cache,
        )
        summary_payload = {
            "schema_version": 1,
            "script_version": SCRIPT_VERSION,
            "confidence_level": args.confidence_level,
            "seed_summary": seed_summary,
            "paired_seed_comparisons": paired_seed,
            "patient_cluster_bootstrap": patient_bootstrap,
            "paired_patient_bootstrap": paired_patient,
            "classwise_summary": classwise_summary,
            "rare_class_summary": rare_summary,
            "classwise_availability": classwise_availability,
            "ood_summary": ood_summary,
            "calibration_summary": calibration_summary,
            "selective_summary": selective_summary,
            "statistical_notes": {
                "seed_sd": "sample SD with ddof=1",
                "t_ci": "two-sided Student-t CI for the seed mean",
                "percentile_ci": "empirical quantiles of seed estimates, not a bootstrap CI",
                "paired_effect": "Cohen dz and small-sample-corrected Hedges gz",
                "patient_ci": "patient-cluster percentile bootstrap",
                "multiplicity": "Holm correction across all estimable contrasts in each output family",
                "contrast": "method_a - method_b; benefit_difference is direction-adjusted",
            },
        }
        output_tables = {
            "seed_values.csv": seed_values,
            "seed_summary.csv": seed_summary,
            "paired_seed_comparisons.csv": paired_seed,
            "patient_cluster_bootstrap.csv": patient_bootstrap,
            "paired_patient_bootstrap.csv": paired_patient,
            "classwise_seed_values.csv": classwise_values,
            "classwise_summary.csv": classwise_summary,
            "rare_class_summary.csv": rare_summary,
            "classwise_availability.csv": classwise_availability,
            "ood_seed_values.csv": ood_values,
            "ood_summary.csv": ood_summary,
            "calibration_seed_values.csv": calibration_values,
            "calibration_summary.csv": calibration_summary,
            "selective_seed_values.csv": selective_values,
            "selective_summary.csv": selective_summary,
        }
        summary_json_path = output_dir / "summary.json"
        atomic_json(summary_json_path, summary_payload)
        generated_paths.append(summary_json_path)
        for filename, table in output_tables.items():
            path = output_dir / filename
            write_csv(path, table)
            generated_paths.append(path)
        latex_path = output_dir / "summary.tex"
        atomic_text(
            latex_path,
            latex_summary(
                seed_summary,
                [row for row in paired_seed if row.get("p_value") is not None],
                manifest["complete_missing_matrix"],
                expected,
            ),
        )
        generated_paths.append(latex_path)

    manifest["generated_outputs"] = [
        generated_file_entry(path, output_dir) for path in generated_paths
    ]
    manifest["result_manifest_self_hash"] = None
    manifest["notes"].append(
        "result_manifest.json excludes its own SHA256 because embedding a self-hash is recursive"
    )
    manifest_path = output_dir / "result_manifest.json"
    atomic_json(manifest_path, manifest)
    incomplete = not manifest["summary"]["complete"]
    if args.fail_on_incomplete and incomplete:
        return 2
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"aggregate_results.py: {type(error).__name__}: {error}", file=sys.stderr)
        raise
