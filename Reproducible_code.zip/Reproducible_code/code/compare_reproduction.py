#!/usr/bin/env python3
"""Compare regenerated scientific aggregates with the packaged references.

This comparator intentionally ignores timestamps, absolute paths, file hashes, and
other provenance that must change on a new machine. Run all strict completeness
audits first. The candidate aggregate root must mirror the stable subdirectory
layout under ``reference_outputs/aggregates``.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence


CSV_PLANS: dict[str, tuple[str, ...]] = {
    "ptbxl/seed_summary.csv": (
        "method", "family", "protocol", "dataset", "split", "metric"
    ),
    "ptbxl/ood_summary.csv": (
        "method", "protocol", "dataset", "split", "detector",
        "detector_parameter", "scenario", "ood_category", "metric",
    ),
    "ptbxl/calibration_summary.csv": (
        "method", "protocol", "dataset", "split", "calibration_variant", "metric"
    ),
    "ptbxl/selective_summary.csv": (
        "method", "protocol", "dataset", "split", "selector",
        "operating_kind", "target", "metric",
    ),
    "auxiliary/noise_summary.csv": ("category", "context", "variant", "metric"),
    "auxiliary/wearable_summary.csv": (
        "dataset", "model", "section", "metric", "metric_id"
    ),
    "auxiliary/wearable_comparisons.csv": (
        "dataset", "metric_id", "method_a", "method_b", "difference_direction"
    ),
    "promised_extensions/summary.csv": ("protocol", "tag", "metric"),
    "promised_extensions/paired_effects.csv": (
        "protocol", "candidate", "baseline", "metric"
    ),
    "promised_extensions/representation_diagnostics_summary.csv": (
        "protocol", "tag", "kind", "left_or_source", "right", "metric"
    ),
    "promised_extensions/source_weight_diagnostics_summary.csv": (
        "protocol", "tag", "metric"
    ),
    "noise_gate_extensions/summary_aggregate.csv": ("gate", "snr_label", "metric"),
    "noise_gate_extensions/source_corruption.csv": ("gate", "seed", "variant", "source"),
    "noise_shift_calibration_audit/calibration_metrics.csv": (
        "seed", "snr_index", "snr_label", "split", "calibration_variant", "stratum"
    ),
    "promised_postprocess/rare_seed_summary.csv": (
        "protocol", "method", "rare_threshold", "metric"
    ),
    "promised_postprocess/selective_seed_summary.csv": (
        "protocol", "method", "target_coverage", "metric"
    ),
    "promised_postprocess/ood_paired_seed.csv": (
        "protocol", "scenario", "method_a", "detector_a", "method_b", "detector_b", "metric"
    ),
    "promised_postprocess/ood_alert_seed_summary.csv": (
        "protocol", "method", "detector", "scenario", "prevalence",
        "target_sensitivity", "metric",
    ),
}


class ComparisonError(RuntimeError):
    """Raised when a candidate output is missing or has an invalid schema."""


def read_csv_rows(path: Path, key_columns: Sequence[str]) -> tuple[list[str], dict[tuple[str, ...], dict[str, str]]]:
    if not path.is_file():
        raise ComparisonError(f"missing file: {path}")
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ComparisonError(f"missing CSV header: {path}")
        missing = [column for column in key_columns if column not in reader.fieldnames]
        if missing:
            raise ComparisonError(f"{path}: missing key columns {missing}")
        rows: dict[tuple[str, ...], dict[str, str]] = {}
        for row_number, row in enumerate(reader, start=2):
            key = tuple(row[column] for column in key_columns)
            if key in rows:
                raise ComparisonError(f"{path}:{row_number}: duplicate scientific key {key}")
            rows[key] = dict(row)
    return list(reader.fieldnames), rows


def parse_number(value: str) -> float | None:
    text = value.strip().lower()
    if text in {"", "none", "null"}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def numeric_equal(reference: float, candidate: float, rtol: float, atol: float) -> bool:
    if math.isnan(reference) or math.isnan(candidate):
        return math.isnan(reference) and math.isnan(candidate)
    if math.isinf(reference) or math.isinf(candidate):
        return reference == candidate
    return math.isclose(reference, candidate, rel_tol=rtol, abs_tol=atol)


def compare_csv(
    reference_path: Path,
    candidate_path: Path,
    key_columns: Sequence[str],
    rtol: float,
    atol: float,
    errors: list[str],
) -> None:
    reference_fields, reference_rows = read_csv_rows(reference_path, key_columns)
    candidate_fields, candidate_rows = read_csv_rows(candidate_path, key_columns)
    if reference_fields != candidate_fields:
        errors.append(f"CSV columns differ: {candidate_path}")
        return
    if set(reference_rows) != set(candidate_rows):
        missing = len(set(reference_rows) - set(candidate_rows))
        extra = len(set(candidate_rows) - set(reference_rows))
        errors.append(f"CSV row keys differ: {candidate_path} (missing={missing}, extra={extra})")
        return
    for key in sorted(reference_rows):
        reference = reference_rows[key]
        candidate = candidate_rows[key]
        for column in reference_fields:
            if column in key_columns:
                continue
            left = reference[column]
            right = candidate[column]
            left_number = parse_number(left)
            right_number = parse_number(right)
            if left_number is not None and right_number is not None:
                if not numeric_equal(left_number, right_number, rtol, atol):
                    errors.append(
                        f"numeric mismatch {candidate_path}:{key}:{column}: "
                        f"reference={left} candidate={right}"
                    )
            elif left != right:
                errors.append(
                    f"text mismatch {candidate_path}:{key}:{column}: "
                    f"reference={left!r} candidate={right!r}"
                )


def compare_json_value(
    reference: Any,
    candidate: Any,
    location: str,
    rtol: float,
    atol: float,
    errors: list[str],
) -> None:
    if isinstance(reference, Mapping):
        if not isinstance(candidate, Mapping):
            errors.append(f"JSON type mismatch at {location}")
            return
        if set(reference) != set(candidate):
            errors.append(f"JSON keys differ at {location}")
            return
        for key in sorted(reference):
            compare_json_value(
                reference[key], candidate[key], f"{location}.{key}", rtol, atol, errors
            )
        return
    if isinstance(reference, list):
        if not isinstance(candidate, list) or len(reference) != len(candidate):
            errors.append(f"JSON list shape differs at {location}")
            return
        for index, (left, right) in enumerate(zip(reference, candidate)):
            compare_json_value(left, right, f"{location}[{index}]", rtol, atol, errors)
        return
    if isinstance(reference, (int, float)) and not isinstance(reference, bool):
        if not isinstance(candidate, (int, float)) or isinstance(candidate, bool):
            errors.append(f"JSON numeric type mismatch at {location}")
            return
        if not numeric_equal(float(reference), float(candidate), rtol, atol):
            errors.append(
                f"JSON numeric mismatch at {location}: "
                f"reference={reference} candidate={candidate}"
            )
        return
    if reference != candidate:
        errors.append(
            f"JSON value mismatch at {location}: reference={reference!r} candidate={candidate!r}"
        )


def compare_modular_summary(
    reference_root: Path,
    candidate_root: Path,
    rtol: float,
    atol: float,
    errors: list[str],
) -> None:
    relative = Path("modular_pipeline/summary.json")
    reference_path = reference_root / relative
    candidate_path = candidate_root / relative
    if not reference_path.is_file() or not candidate_path.is_file():
        errors.append(f"missing modular summary: {candidate_path}")
        return
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    candidate = json.loads(candidate_path.read_text(encoding="utf-8"))
    for key in ("status", "schema", "method"):
        if reference.get(key) != candidate.get(key):
            errors.append(f"modular summary field differs: {key}")
    compare_json_value(
        reference.get("statistics"),
        candidate.get("statistics"),
        "modular_pipeline.statistics",
        rtol,
        atol,
        errors,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, required=True)
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--rtol", type=float, default=1e-5)
    parser.add_argument("--atol", type=float, default=1e-7)
    parser.add_argument("--max-errors", type=int, default=100)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.rtol < 0 or args.atol < 0:
        raise ComparisonError("tolerances must be non-negative")
    if args.max_errors <= 0:
        raise ComparisonError("--max-errors must be positive")
    errors: list[str] = []
    completed = 0
    for relative, key_columns in CSV_PLANS.items():
        try:
            compare_csv(
                args.reference_root / relative,
                args.candidate_root / relative,
                key_columns,
                args.rtol,
                args.atol,
                errors,
            )
            completed += 1
        except (ComparisonError, OSError, csv.Error, ValueError) as exc:
            errors.append(f"{relative}: {type(exc).__name__}: {exc}")
        if len(errors) >= args.max_errors:
            break
    if len(errors) < args.max_errors:
        try:
            compare_modular_summary(
                args.reference_root, args.candidate_root, args.rtol, args.atol, errors
            )
            completed += 1
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append(f"modular_pipeline/summary.json: {type(exc).__name__}: {exc}")

    if errors:
        print(
            f"Reproduction comparison failed: {len(errors)} mismatch(es) "
            f"across {completed} checked outputs."
        )
        for error in errors[: args.max_errors]:
            print(f"- {error}")
        return 1
    print(
        f"Reproduction comparison passed: {completed} scientific outputs match "
        f"within rtol={args.rtol:g}, atol={args.atol:g}."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
