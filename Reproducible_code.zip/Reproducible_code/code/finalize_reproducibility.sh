#!/usr/bin/env bash
# Finalise the Paper46 AutoDL run into one audited reproducibility snapshot.
#
# This program is intentionally AutoDL-only.  It copies formal result
# artefacts, but never copies raw waveforms, source archives, credentials, or
# private keys.  The default staging area is /dev/shm because the canonical
# PTB result root may itself be a symlink into /dev/shm and the root overlay is
# intentionally kept small.
# It never invokes shutdown or power-management commands; the user keeps sole
# control of the server after finalisation and synchronization.

set -Eeuo pipefail
umask 077
IFS=$'\n\t'

PYTHON="${PYTHON:-/root/miniconda3/bin/python}"
CONDA_BIN="${CONDA_BIN:-/root/miniconda3/bin/conda}"
REVISION_ROOT="${REVISION_ROOT:-/root/Paper46_revision}"
EXPERIMENT_DIR="${EXPERIMENT_DIR:-${REVISION_ROOT}/experiments}"
CACHE_DIR="${CACHE_DIR:-${REVISION_ROOT}/cache}"
TRUSTFED_CACHE="${TRUSTFED_CACHE:-/root/autodl-tmp/TrustFedECG/cache}"
WEARABLE_DATA_ROOT="${WEARABLE_DATA_ROOT:-/root/autodl-tmp/Paper54/data_processed}"
PTB_RESULTS="${PTB_RESULTS:-${REVISION_ROOT}/results_final/ptbxl}"
WEARABLE_RESULTS="${WEARABLE_RESULTS:-${REVISION_ROOT}/results_final/wearables}"
NOISE_RESULTS="${NOISE_RESULTS:-${REVISION_ROOT}/results_final/noise_sqi}"
PTB_EXTENSION_RESULTS="${PTB_EXTENSION_RESULTS:-/dev/shm/Paper46_revision_results_missing/ptbxl}"
NOISE_GATE_RESULTS="${NOISE_GATE_RESULTS:-/dev/shm/Paper46_revision_results_missing/noise_gate}"
NOISE_SHIFT_RESULTS="${NOISE_SHIFT_RESULTS:-/dev/shm/Paper46_noise_shift_calibration/results}"
NOISE_SHIFT_AUDIT_ROOT="${NOISE_SHIFT_AUDIT_ROOT:-/dev/shm/Paper46_noise_shift_calibration/audit}"
NOISE_SHIFT_AUDIT_JSON="${NOISE_SHIFT_AUDIT_JSON:-${NOISE_SHIFT_AUDIT_ROOT}/manifest.json}"
MODULAR_RESULTS="${MODULAR_RESULTS:-/dev/shm/Paper46_modular_pipeline/results}"
MODULAR_AUDIT_ROOT="${MODULAR_AUDIT_ROOT:-/dev/shm/Paper46_modular_pipeline/audit}"
MODULAR_AUDIT_JSON="${MODULAR_AUDIT_JSON:-${MODULAR_AUDIT_ROOT}/audit.json}"
MODULAR_ROOT_MARKER="${MODULAR_ROOT_MARKER:-/dev/shm/Paper46_modular_pipeline/modular_pipeline.complete}"
NOISE_CHECKPOINT_ROOT="${NOISE_CHECKPOINT_ROOT:-${REVISION_ROOT}/checkpoints_final/noise_sqi}"
NOISE_GATE_CHECKPOINT_ROOT="${NOISE_GATE_CHECKPOINT_ROOT:-/dev/shm/Paper46_revision_checkpoints_missing/noise_gate}"
LOG_ROOT="${LOG_ROOT:-${REVISION_ROOT}/logs_final}"
PTB_EXTENSION_LOG_DIR="${PTB_EXTENSION_LOG_DIR:-/dev/shm/Paper46_logs_missing/ptbxl}"
NOISE_GATE_LOG_DIR="${NOISE_GATE_LOG_DIR:-/dev/shm/Paper46_logs_missing/noise_gate}"
NOISE_SHIFT_LOG_DIR="${NOISE_SHIFT_LOG_DIR:-/dev/shm/Paper46_logs_missing/noise_shift}"
MODULAR_LOG_DIR="${MODULAR_LOG_DIR:-/dev/shm/Paper46_logs_missing/modular_pipeline}"
NOISE_GATE_PRESANITIZE_ROOT="${NOISE_GATE_PRESANITIZE_ROOT:-/dev/shm/Paper46_noise_gate_presanitize}"
PTB_ATTEMPT1_LOG_DIR="${PTB_ATTEMPT1_LOG_DIR:-/dev/shm/Paper46_logs_missing/ptbxl_attempt1}"
MODULAR_EARLY_ROOT="${MODULAR_EARLY_ROOT:-/dev/shm/Paper46_modular_pipeline_early_20260822}"
MODULAR_EARLY_LOG_DIR="${MODULAR_EARLY_LOG_DIR:-/dev/shm/Paper46_logs_missing/modular_pipeline_early_20260822}"
MODULAR_ATTEMPT2_ROOT="${MODULAR_ATTEMPT2_ROOT:-/dev/shm/Paper46_modular_pipeline_attempt2_missing_seed}"
MODULAR_ATTEMPT2_LOG_DIR="${MODULAR_ATTEMPT2_LOG_DIR:-/dev/shm/Paper46_logs_missing/modular_pipeline_attempt2_missing_seed}"
PROMISED_POSTPROCESS_ROOT="${PROMISED_POSTPROCESS_ROOT:-/dev/shm/Paper46_postprocess_final/results_v3}"
PROMISED_POSTPROCESS_LOG="${PROMISED_POSTPROCESS_LOG:-/dev/shm/Paper46_postprocess_final/run_v3.log}"
PROMISED_POSTPROCESS_MARKER="${PROMISED_POSTPROCESS_MARKER:-/dev/shm/Paper46_postprocess_final/promised_postprocess.complete}"
SMOKE_PTB_ROOT="${SMOKE_PTB_ROOT:-/dev/shm/Paper46_extension_smoke_ptb}"
SMOKE_NOISE_ROOT="${SMOKE_NOISE_ROOT:-/dev/shm/Paper46_extension_smoke_noise}"
SMOKE_NOISE_CHECKPOINT_ROOT="${SMOKE_NOISE_CHECKPOINT_ROOT:-/dev/shm/Paper46_extension_smoke_noise_ckpt}"
SMOKE_PTB_AUDIT_ROOT="${SMOKE_PTB_AUDIT_ROOT:-/dev/shm/ptb_v2_smoke}"
SMOKE_AUX_AUDIT_ROOT="${SMOKE_AUX_AUDIT_ROOT:-/dev/shm/aggregate_aux_smoke}"
BUNDLE_LINK="${BUNDLE_LINK:-${REVISION_ROOT}/reproducibility_bundle}"
BUNDLE_STAGING_ROOT="${BUNDLE_STAGING_ROOT:-${BUNDLE_STAGE:-/dev/shm/Paper46_reproducibility_bundle}}"

readonly EXPECTED_PTB_RESULTS=212
readonly EXPECTED_WEARABLE_RESULTS=345
readonly EXPECTED_NOISE_RESULTS=3
readonly EXPECTED_PTB_EXTENSION_RESULTS=221
readonly EXPECTED_NOISE_GATE_RESULTS=9
readonly EXPECTED_NOISE_SHIFT_RESULTS=3
readonly EXPECTED_MODULAR_RESULTS=8
readonly EXPECTED_PTB_TASKS=25
readonly EXPECTED_WEARABLE_TASKS=75
readonly EXPECTED_NOISE_TASKS=3
readonly EXPECTED_PTB_EXTENSION_TASKS=66
readonly EXPECTED_NOISE_GATE_TASKS=9
readonly EXPECTED_NOISE_SHIFT_TASKS=3
readonly EXPECTED_MODULAR_TASKS=8
readonly EXPECTED_MODULAR_EVALUATOR_SHA256="015ccd9cd47b1b3d0343cd8e551eb3c3c974235578f71690112b7a4d8c448913"
readonly EXPECTED_MODULAR_AUDITOR_SHA256="1936a165808d96f3001f138a989bcdc98635916b251477c29b3214ae336ec503"
readonly EXPECTED_MODULAR_LAUNCHER_SHA256="6c6754294b7684fab41e328ff29ee2c8140bdb0a4ac758699249eb0c5e3871f9"
readonly EXPECTED_MHEALTH_DATA_MANIFEST_SHA256="1a89f466f865d9562dcba8bbd6de0c6bfdffb47dee27867d6493da9e548680d6"
readonly EXPECTED_WESAD_DATA_MANIFEST_SHA256="f07ec6eac63acd50aed038ff1b3e3d6301509c4cf5461ba7ae0825459da1d977"

STAGING=""
PUBLISHED=""

die() {
  printf 'FINALIZE ERROR: %s\n' "$*" >&2
  exit 1
}

on_exit() {
  local status=$?
  trap - EXIT
  if (( status != 0 )) && [[ -n "${STAGING}" && -d "${STAGING}" ]]; then
    {
      date --iso-8601=seconds
      printf 'exit_status=%s\n' "${status}"
      printf 'The incomplete staging directory was preserved for diagnosis.\n'
    } > "${STAGING}/FINALIZATION_FAILED.txt" 2>/dev/null || true
    printf 'Incomplete staging preserved at %s\n' "${STAGING}" >&2
  fi
  exit "${status}"
}
trap on_exit EXIT

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "required command is unavailable: $1"
}

count_matching_files() {
  local root="$1"
  local pattern="$2"
  find -L "${root}" -type f -name "${pattern}" -printf '1\n' | wc -l | tr -d '[:space:]'
}

count_top_matching_files() {
  local root="$1"
  local pattern="$2"
  find -L "${root}" -maxdepth 1 -type f -name "${pattern}" -printf '1\n' | \
    wc -l | tr -d '[:space:]'
}

assert_count() {
  local description="$1"
  local observed="$2"
  local expected="$3"
  [[ "${observed}" == "${expected}" ]] || \
    die "${description}: expected ${expected}, observed ${observed}"
}

assert_nonempty_tree() {
  local description="$1"
  local root="$2"
  [[ -d "${root}" ]] || die "${description}: directory is absent: ${root}"
  find -L "${root}" -type f -size +0c -print -quit | grep -q . || \
    die "${description}: no non-empty regular file found under ${root}"
}

check_single_completion() {
  local description="$1"
  local log_file="$2"
  local marker="$3"
  [[ -s "${log_file}" ]] || die "${description}: missing or empty log ${log_file}"
  [[ -s "${marker}" ]] || die "${description}: missing completion marker ${marker}"
  [[ ! "${log_file}" -nt "${marker}" ]] || \
    die "${description}: log is newer than completion marker"
}

check_exit_codes() {
  local description="$1"
  local directory="$2"
  local marker_name="$3"
  local expected="$4"
  local marker="${directory}/${marker_name}"
  local exit_files=()
  local path status

  [[ -s "${marker}" ]] || die "${description}: missing completion marker ${marker}"
  shopt -s nullglob
  exit_files=("${directory}"/*.exit)
  shopt -u nullglob
  assert_count "${description} exit files" "${#exit_files[@]}" "${expected}"
  for path in "${exit_files[@]}"; do
    status="$(tr -d '[:space:]' < "${path}")"
    [[ "${status}" =~ ^[0-9]+$ ]] || die "${description}: malformed exit code in ${path}"
    [[ "${status}" == "0" ]] || die "${description}: non-zero exit code ${status} in ${path}"
  done
  if find "${directory}" -maxdepth 1 -type f \
      \( -name '*.exit' -o -name '*.log' \) -newer "${marker}" -print -quit | grep -q .; then
    die "${description}: a task log or exit file is newer than ${marker}"
  fi
}

check_noise_shift_completion() {
  local directory="$1"
  local marker="${directory}/noise_shift_calibration.complete"
  local audit_log="${directory}/audit.log"
  local seed exit_file task_log status

  [[ -s "${marker}" ]] || \
    die "noise-shift-calibration: missing completion marker ${marker}"
  assert_count "noise-shift-calibration exit files" \
    "$(count_top_matching_files "${directory}" '*.exit')" \
    "${EXPECTED_NOISE_SHIFT_TASKS}"
  # The independent strict audit is run separately after the worker marker,
  # so audit.log is intentionally allowed to be newer.  Keep the
  # worker contract exact: three named seed logs/exits and no other .log file.
  assert_count "noise-shift-calibration log files" \
    "$(count_top_matching_files "${directory}" '*.log')" \
    "$((EXPECTED_NOISE_SHIFT_TASKS + 1))"
  [[ -s "${audit_log}" ]] || \
    die "noise-shift-calibration: missing or empty independent audit log ${audit_log}"

  for seed in 7 13 42; do
    exit_file="${directory}/noise_shift_seed${seed}.exit"
    task_log="${directory}/noise_shift_seed${seed}.log"
    [[ -s "${exit_file}" ]] || \
      die "noise-shift-calibration: missing or empty exit file ${exit_file}"
    [[ -s "${task_log}" ]] || \
      die "noise-shift-calibration: missing or empty task log ${task_log}"
    status="$(tr -d '[:space:]' < "${exit_file}")"
    [[ "${status}" =~ ^[0-9]+$ ]] || \
      die "noise-shift-calibration: malformed exit code in ${exit_file}"
    [[ "${status}" == "0" ]] || \
      die "noise-shift-calibration: non-zero exit code ${status} in ${exit_file}"
    [[ ! "${exit_file}" -nt "${marker}" ]] || \
      die "noise-shift-calibration: worker exit is newer than ${marker}: ${exit_file}"
    [[ ! "${task_log}" -nt "${marker}" ]] || \
      die "noise-shift-calibration: worker log is newer than ${marker}: ${task_log}"
  done
}

snapshot_tree() {
  local source="$1"
  local destination="$2"
  local method_file="$3"
  local source_device destination_device method
  [[ -d "${source}" ]] || die "snapshot source is absent: ${source}"
  mkdir -p -- "${destination}"
  source_device="$(stat -c '%d' -- "$(readlink -f "${source}")")"
  destination_device="$(stat -c '%d' -- "${destination}")"
  if [[ "${source_device}" == "${destination_device}" ]]; then
    cp -alL -- "${source}/." "${destination}/"
    method="hardlink_same_filesystem"
  else
    cp -aL -- "${source}/." "${destination}/"
    method="byte_copy_cross_filesystem"
  fi
  printf 'method=%s\nsource=%s\nresolved=%s\ndestination=%s\n' \
    "${method}" "${source}" "$(readlink -f "${source}")" "${destination}" \
    > "${method_file}"
}

freeze_tree() {
  local slug="$1"
  local source="$2"
  local destination="$3"
  local source_inventory="${STAGING}/inventories/${slug}_source_sha256.tsv"
  local bundle_inventory="${STAGING}/inventories/${slug}_bundle_sha256.tsv"
  hash_tree "${source}" "${source_inventory}"
  snapshot_tree "${source}" "${destination}" \
    "${STAGING}/inventories/${slug}_snapshot_method.txt"
  hash_tree "${destination}" "${bundle_inventory}"
  cmp -s "${source_inventory}" "${bundle_inventory}" || \
    die "${slug}: source and bundle hashes differ"
}

# Copy only human-readable diagnostic evidence.  This is used for logs, smoke
# evidence and failed-attempt provenance so an NPZ/checkpoint/archive can never
# enter those distribution subtrees accidentally.  The inventory deliberately
# covers only the allowlisted files that were copied.
freeze_text_tree() {
  local slug="$1"
  local source="$2"
  local destination="$3"
  local source_inventory="${STAGING}/inventories/${slug}_source_sha256.tsv"
  local bundle_inventory="${STAGING}/inventories/${slug}_bundle_sha256.tsv"
  local omitted_inventory="${STAGING}/inventories/${slug}_omitted_sha256.tsv"
  local file relative digest bytes copied=0
  [[ -d "${source}" ]] || die "text snapshot source is absent: ${source}"
  mkdir -p -- "${destination}"
  printf 'sha256\tbytes\trelative_path\n' > "${source_inventory}"
  printf 'sha256\tbytes\trelative_path\treason\n' > "${omitted_inventory}"
  while IFS= read -r -d '' file; do
    case "$(basename "${file}")" in
      *.json|*.csv|*.tsv|*.txt|*.tex|*.log|*.out|*.exit|*.complete) ;;
      *)
        relative="${file#"${source}"/}"
        digest="$(sha256sum -- "${file}")"
        digest="${digest%% *}"
        bytes="$(stat -c '%s' -- "${file}")"
        printf '%s\t%s\t%s\t%s\n' \
          "${digest}" "${bytes}" "${relative}" "not_in_text_distribution_allowlist" \
          >> "${omitted_inventory}"
        continue
        ;;
    esac
    relative="${file#"${source}"/}"
    [[ "${relative}" != "${file}" ]] || die "cannot relativize text artefact ${file}"
    mkdir -p -- "${destination}/$(dirname "${relative}")"
    cp -pL -- "${file}" "${destination}/${relative}"
    cmp -s -- "${file}" "${destination}/${relative}" || \
      die "${slug}: copied text differs from source: ${relative}"
    digest="$(sha256sum -- "${file}")"
    digest="${digest%% *}"
    bytes="$(stat -c '%s' -- "${file}")"
    printf '%s\t%s\t%s\n' "${digest}" "${bytes}" "${relative}" >> "${source_inventory}"
    copied=$((copied + 1))
  done < <(find -L "${source}" -type f -print0 | sort -z)
  (( copied > 0 )) || die "${slug}: no allowlisted text evidence found under ${source}"
  hash_tree "${destination}" "${bundle_inventory}"
  cmp -s "${source_inventory}" "${bundle_inventory}" || \
    die "${slug}: source and bundle text hashes differ"
}

# Preserve a failed attempt without distributing its arrays or checkpoints.
# Every source file is represented in a SHA/bytes inventory, while only named
# manifests/summaries/audits and textual logs/markers are copied.
freeze_failed_attempt_provenance() {
  local slug="$1"
  local result_root="$2"
  local log_root="$3"
  local destination="${STAGING}/provenance/${slug}"
  local file relative base digest bytes source_domain source_root target copied=0
  [[ -d "${result_root}" ]] || die "${slug}: result provenance root is absent: ${result_root}"
  [[ -d "${log_root}" ]] || die "${slug}: log provenance root is absent: ${log_root}"
  mkdir -p "${destination}/metadata" "${destination}/logs"
  printf 'source_domain\tsha256\tbytes\trelative_path\n' \
    > "${destination}/source_sha256.tsv"
  for source_domain in results logs; do
    if [[ "${source_domain}" == results ]]; then
      source_root="${result_root}"
    else
      source_root="${log_root}"
    fi
    while IFS= read -r -d '' file; do
      relative="${file#"${source_root}"/}"
      digest="$(sha256sum -- "${file}")"
      digest="${digest%% *}"
      bytes="$(stat -c '%s' -- "${file}")"
      printf '%s\t%s\t%s\t%s\n' \
        "${source_domain}" "${digest}" "${bytes}" "${relative}" \
        >> "${destination}/source_sha256.tsv"
      base="$(basename "${file}")"
      if [[ "${source_domain}" == logs ]]; then
        case "${base}" in
          *.json|*.csv|*.tsv|*.txt|*.tex|*.log|*.out|*.exit|*.complete) ;;
          *) continue ;;
        esac
        target="${destination}/logs/${relative}"
      else
        case "${base}" in
          manifest.json|summary.json|audit.json|audit_manifest.json|completion_matrix.json|*.complete) ;;
          *) continue ;;
        esac
        target="${destination}/metadata/${relative}"
      fi
      mkdir -p -- "$(dirname "${target}")"
      cp -pL -- "${file}" "${target}"
      cmp -s -- "${file}" "${target}" || \
        die "${slug}: failed-attempt provenance copy mismatch: ${relative}"
      copied=$((copied + 1))
    done < <(find -L "${source_root}" -type f -print0 | sort -z)
  done
  (( copied > 0 )) || die "${slug}: no safe failed-attempt metadata/log was copied"
  hash_tree "${destination}" "${STAGING}/inventories/${slug}_bundle_sha256.tsv"
}

record_command() {
  local path="$1"
  shift
  printf '%q ' "$@" >> "${path}"
  printf '\n' >> "${path}"
}

run_logged() {
  local command_record="$1"
  local log_file="$2"
  shift 2
  record_command "${command_record}" "$@"
  "$@" > "${log_file}" 2>&1
}

hash_tree() {
  local root="$1"
  local output="$2"
  local file relative digest bytes
  [[ -d "${root}" ]] || die "cannot hash absent tree: ${root}"
  printf 'sha256\tbytes\trelative_path\n' > "${output}"
  while IFS= read -r -d '' file; do
    relative="${file#"${root}"/}"
    digest="$(sha256sum -- "${file}")"
    digest="${digest%% *}"
    bytes="$(stat -c '%s' -- "${file}")"
    printf '%s\t%s\t%s\n' "${digest}" "${bytes}" "${relative}" >> "${output}"
  done < <(find -L "${root}" -type f -print0 | sort -z)
}

append_file_hash() {
  local domain="$1"
  local path="$2"
  local output="$3"
  local digest bytes
  [[ -f "${path}" ]] || die "required data input is absent: ${path}"
  digest="$(sha256sum -- "${path}")"
  digest="${digest%% *}"
  bytes="$(stat -c '%s' -- "${path}")"
  printf '%s\t%s\t%s\t%s\n' "${domain}" "${digest}" "${bytes}" "${path}" >> "${output}"
}

append_tree_hashes() {
  local domain="$1"
  local root="$2"
  local output="$3"
  local file
  [[ -d "${root}" ]] || die "required data directory is absent: ${root}"
  while IFS= read -r -d '' file; do
    append_file_hash "${domain}" "${file}" "${output}"
  done < <(find -L "${root}" -maxdepth 1 -type f -print0 | sort -z)
}

# Hard AutoDL guard.  This prevents accidental local execution even if paths
# with similar names are mounted on another operating system.
[[ "$(uname -s)" == "Linux" ]] || die "this script may run only on the AutoDL Linux server"
[[ "$(id -u)" == "0" ]] || die "the canonical AutoDL run is owned by root"
[[ "${REVISION_ROOT}" == /root/* ]] || die "REVISION_ROOT must remain under /root on AutoDL"
[[ "${BUNDLE_LINK}" == "${REVISION_ROOT}"/* ]] || die "BUNDLE_LINK must remain inside REVISION_ROOT"
[[ "${BUNDLE_STAGING_ROOT}" == /dev/shm/* ]] || die "BUNDLE_STAGING_ROOT must remain under /dev/shm"
[[ "${PTB_EXTENSION_RESULTS}" == /dev/shm/* ]] || die "PTB extension root must remain under /dev/shm"
[[ "${NOISE_GATE_RESULTS}" == /dev/shm/* ]] || die "noise-gate extension root must remain under /dev/shm"
[[ "${NOISE_SHIFT_RESULTS}" == /dev/shm/* ]] || die "noise-shift root must remain under /dev/shm"
[[ "${NOISE_SHIFT_AUDIT_ROOT}" == /dev/shm/* ]] || die "noise-shift audit root must remain under /dev/shm"
[[ "${NOISE_SHIFT_AUDIT_JSON}" == "${NOISE_SHIFT_AUDIT_ROOT}"/* ]] || \
  die "noise-shift audit manifest must remain inside NOISE_SHIFT_AUDIT_ROOT"
[[ "${MODULAR_RESULTS}" == /dev/shm/* ]] || die "modular result root must remain under /dev/shm"
[[ "${MODULAR_AUDIT_ROOT}" == /dev/shm/* ]] || die "modular audit root must remain under /dev/shm"
[[ "${MODULAR_AUDIT_JSON}" == "${MODULAR_AUDIT_ROOT}"/* ]] || \
  die "modular audit JSON must remain inside MODULAR_AUDIT_ROOT"
[[ "${MODULAR_ROOT_MARKER}" == /dev/shm/* ]] || \
  die "modular root marker must remain under /dev/shm"
[[ "${NOISE_GATE_PRESANITIZE_ROOT}" == /dev/shm/* ]] || \
  die "noise-gate presanitize root must remain under /dev/shm"
[[ "${PTB_ATTEMPT1_LOG_DIR}" == /dev/shm/* ]] || \
  die "PTB attempt-1 provenance root must remain under /dev/shm"
for provenance_root in "${MODULAR_EARLY_ROOT}" "${MODULAR_EARLY_LOG_DIR}" \
    "${MODULAR_ATTEMPT2_ROOT}" "${MODULAR_ATTEMPT2_LOG_DIR}"; do
  [[ "${provenance_root}" == /dev/shm/* ]] || \
    die "modular failed-attempt provenance must remain under /dev/shm: ${provenance_root}"
done
[[ "${NOISE_GATE_CHECKPOINT_ROOT}" == /dev/shm/* ]] || \
  die "noise-gate checkpoint root must remain under /dev/shm"
[[ -d /root/autodl-tmp ]] || die "AutoDL data volume /root/autodl-tmp is absent"
[[ -x "${PYTHON}" ]] || die "remote Python is absent: ${PYTHON}"
[[ -x "${CONDA_BIN}" ]] || die "remote conda is absent: ${CONDA_BIN}"

for command in awk basename bash cat cmp cp date dirname find flock grep hostname id \
    ln mkdir mv nvidia-smi readlink sha256sum sort stat tr uname wc xargs; do
  require_command "${command}"
done

[[ -d "${EXPERIMENT_DIR}" ]] || die "experiment code is absent: ${EXPERIMENT_DIR}"
[[ -f "${EXPERIMENT_DIR}/run_noise_shift_calibration_matrix.sh" ]] || \
  die "noise-shift calibration matrix launcher is absent"
for required_source in evaluate_modular_pipeline.py audit_modular_pipeline.py \
    run_modular_pipeline_matrix.sh audit_noise_gate_extensions.py \
    audit_noise_shift_calibration.py; do
  [[ -f "${EXPERIMENT_DIR}/${required_source}" ]] || \
    die "required final experiment source is absent: ${required_source}"
done
wearable_preprocessing_root="${EXPERIMENT_DIR}/wearable_preprocessing"
[[ -d "${wearable_preprocessing_root}" ]] || \
  die "exact wearable_preprocessing source tree is absent"
for relative in \
    preprocessing/prep_mhealth.py \
    preprocessing/prep_wesad.py \
    utils/signal_utils.py; do
  source_path="${wearable_preprocessing_root}/${relative}"
  [[ -f "${source_path}" && -s "${source_path}" && ! -L "${source_path}" ]] || \
    die "required wearable preprocessing source is absent, empty, or a symlink: ${relative}"
done
for source_hash_contract in \
    "evaluate_modular_pipeline.py:${EXPECTED_MODULAR_EVALUATOR_SHA256}" \
    "audit_modular_pipeline.py:${EXPECTED_MODULAR_AUDITOR_SHA256}" \
    "run_modular_pipeline_matrix.sh:${EXPECTED_MODULAR_LAUNCHER_SHA256}"; do
  source_name="${source_hash_contract%%:*}"
  expected_hash="${source_hash_contract#*:}"
  observed_hash="$(sha256sum -- "${EXPERIMENT_DIR}/${source_name}")"
  observed_hash="${observed_hash%% *}"
  [[ "${observed_hash}" == "${expected_hash}" ]] || \
    die "final modular source SHA mismatch for ${source_name}: expected ${expected_hash}, observed ${observed_hash}"
done
[[ -d "${PTB_RESULTS}" ]] || die "PTB result root is absent: ${PTB_RESULTS}"
[[ -d "${WEARABLE_RESULTS}" ]] || die "wearable result root is absent: ${WEARABLE_RESULTS}"
for wearable_manifest_contract in \
    "mhealth:${EXPECTED_MHEALTH_DATA_MANIFEST_SHA256}" \
    "wesad:${EXPECTED_WESAD_DATA_MANIFEST_SHA256}"; do
  wearable_dataset="${wearable_manifest_contract%%:*}"
  expected_hash="${wearable_manifest_contract#*:}"
  wearable_manifest="${WEARABLE_RESULTS}/${wearable_dataset}/data_manifest.json"
  [[ -f "${wearable_manifest}" && -s "${wearable_manifest}" && ! -L "${wearable_manifest}" ]] || \
    die "required wearable data manifest is absent, empty, or a symlink: ${wearable_manifest}"
  observed_hash="$(sha256sum -- "${wearable_manifest}")"
  observed_hash="${observed_hash%% *}"
  [[ "${observed_hash}" == "${expected_hash}" ]] || \
    die "wearable data manifest SHA mismatch for ${wearable_dataset}: expected ${expected_hash}, observed ${observed_hash}"
done
[[ -d "${NOISE_RESULTS}" ]] || die "noise/SQI result root is absent: ${NOISE_RESULTS}"
[[ -d "${PTB_EXTENSION_RESULTS}" ]] || \
  die "PTB extension result root is absent: ${PTB_EXTENSION_RESULTS}"
[[ -d "${NOISE_GATE_RESULTS}" ]] || \
  die "noise-gate result root is absent: ${NOISE_GATE_RESULTS}"
[[ -d "${NOISE_SHIFT_RESULTS}" ]] || \
  die "noise-shift calibration root is absent: ${NOISE_SHIFT_RESULTS}"
[[ -d "${NOISE_SHIFT_AUDIT_ROOT}" ]] || \
  die "noise-shift strict audit root is absent: ${NOISE_SHIFT_AUDIT_ROOT}"
[[ -s "${NOISE_SHIFT_AUDIT_JSON}" ]] || \
  die "noise-shift strict audit manifest is absent: ${NOISE_SHIFT_AUDIT_JSON}"
[[ -d "${MODULAR_RESULTS}" ]] || \
  die "modular pipeline result root is absent: ${MODULAR_RESULTS}"
[[ -d "${MODULAR_AUDIT_ROOT}" ]] || \
  die "modular pipeline audit root is absent: ${MODULAR_AUDIT_ROOT}"
[[ -s "${MODULAR_AUDIT_JSON}" ]] || \
  die "modular pipeline audit JSON is absent: ${MODULAR_AUDIT_JSON}"
[[ -d "${NOISE_GATE_PRESANITIZE_ROOT}" ]] || \
  die "noise-gate original backup is absent: ${NOISE_GATE_PRESANITIZE_ROOT}"
[[ -d "${PTB_ATTEMPT1_LOG_DIR}" ]] || \
  die "PTB attempt-1 provenance logs are absent: ${PTB_ATTEMPT1_LOG_DIR}"
[[ -d "${MODULAR_EARLY_ROOT}" ]] || \
  die "modular early-code provenance root is absent: ${MODULAR_EARLY_ROOT}"
[[ -d "${MODULAR_EARLY_LOG_DIR}" ]] || \
  die "modular early-code log provenance is absent: ${MODULAR_EARLY_LOG_DIR}"
[[ -d "${MODULAR_ATTEMPT2_ROOT}" ]] || \
  die "modular missing-seed attempt provenance root is absent: ${MODULAR_ATTEMPT2_ROOT}"
[[ -d "${MODULAR_ATTEMPT2_LOG_DIR}" ]] || \
  die "modular missing-seed attempt log provenance is absent: ${MODULAR_ATTEMPT2_LOG_DIR}"
[[ -d "${NOISE_CHECKPOINT_ROOT}" ]] || \
  die "formal noise checkpoint root is absent: ${NOISE_CHECKPOINT_ROOT}"
[[ -d "${NOISE_GATE_CHECKPOINT_ROOT}" ]] || \
  die "noise-gate checkpoint root is absent: ${NOISE_GATE_CHECKPOINT_ROOT}"
[[ -d "${PROMISED_POSTPROCESS_ROOT}" ]] || \
  die "promised postprocess root is absent: ${PROMISED_POSTPROCESS_ROOT}"
[[ -d "${LOG_ROOT}" ]] || die "formal log root is absent: ${LOG_ROOT}"
[[ "$(readlink -f "${PTB_RESULTS}")" != *prefingerprint* ]] || \
  die "PTB_RESULTS resolves to an archived pre-fingerprint result tree"
[[ "$(readlink -f "${PTB_EXTENSION_RESULTS}")" != *prefingerprint* ]] || \
  die "PTB_EXTENSION_RESULTS resolves to a pre-fingerprint result tree"
[[ "$(readlink -f "${PTB_RESULTS}")" != "$(readlink -f "${PTB_EXTENSION_RESULTS}")" ]] || \
  die "formal PTB and extension PTB roots must remain separate"

exec 9> "${REVISION_ROOT}/.finalize_reproducibility.lock"
flock -n 9 || die "another finalisation process already holds the lock"

# The launchers' own completion contract is checked before any aggregation or
# copying.  A stale marker is rejected if a task log/exit file is newer.
check_exit_codes PTB-XL "${LOG_ROOT}/ptbxl" ptbxl_matrix.complete "${EXPECTED_PTB_TASKS}"
check_exit_codes wearables "${LOG_ROOT}/wearables" wearables_matrix.complete "${EXPECTED_WEARABLE_TASKS}"
check_exit_codes noise/SQI "${LOG_ROOT}/noise_sqi" noise_sqi.complete "${EXPECTED_NOISE_TASKS}"
check_exit_codes PTB-XL-extensions "${PTB_EXTENSION_LOG_DIR}" missing_matrix.complete \
  "${EXPECTED_PTB_EXTENSION_TASKS}"
check_exit_codes noise-gate-extensions "${NOISE_GATE_LOG_DIR}" noise_gate_matrix.complete \
  "${EXPECTED_NOISE_GATE_TASKS}"
check_noise_shift_completion "${NOISE_SHIFT_LOG_DIR}"
check_exit_codes modular-pipeline "${MODULAR_LOG_DIR}" \
  modular_pipeline.complete "${EXPECTED_MODULAR_TASKS}"
[[ -s "${MODULAR_ROOT_MARKER}" ]] || \
  die "modular pipeline root completion marker is absent: ${MODULAR_ROOT_MARKER}"
[[ -s "${MODULAR_AUDIT_ROOT}/modular_pipeline_audit.complete" ]] || \
  die "modular pipeline audit completion marker is absent"
[[ ! "${MODULAR_AUDIT_JSON}" -nt "${MODULAR_AUDIT_ROOT}/modular_pipeline_audit.complete" ]] || \
  die "modular pipeline audit JSON is newer than its completion marker"
if find "${MODULAR_RESULTS}" "${MODULAR_AUDIT_ROOT}" -type f \
    -newer "${MODULAR_ROOT_MARKER}" -print -quit | grep -q .; then
  die "a modular result/audit file is newer than the root completion marker"
fi
check_single_completion promised-postprocess "${PROMISED_POSTPROCESS_LOG}" \
  "${PROMISED_POSTPROCESS_MARKER}"

assert_count "PTB result JSON" \
  "$(count_matching_files "${PTB_RESULTS}" 'seed_*.json')" "${EXPECTED_PTB_RESULTS}"
assert_count "PTB raw-prediction NPZ" \
  "$(count_matching_files "${PTB_RESULTS}" 'seed_*_raw.npz')" "${EXPECTED_PTB_RESULTS}"
assert_count "PTB OOD-score NPZ" \
  "$(count_matching_files "${PTB_RESULTS}" 'seed_*_ood_scores.npz')" "${EXPECTED_PTB_RESULTS}"
assert_count "wearable result JSON" \
  "$(count_matching_files "${WEARABLE_RESULTS}" 'seed_*.json')" "${EXPECTED_WEARABLE_RESULTS}"
assert_count "wearable prediction NPZ" \
  "$(count_matching_files "${WEARABLE_RESULTS}" 'seed_*_predictions.npz')" "${EXPECTED_WEARABLE_RESULTS}"
assert_count "noise/SQI result JSON" \
  "$(count_matching_files "${NOISE_RESULTS}/canonical" 'seed_*.json')" "${EXPECTED_NOISE_RESULTS}"
assert_count "noise/SQI curves NPZ" \
  "$(count_matching_files "${NOISE_RESULTS}/canonical" 'seed_*_curves.npz')" "${EXPECTED_NOISE_RESULTS}"
assert_count "PTB extension result JSON" \
  "$(count_matching_files "${PTB_EXTENSION_RESULTS}" 'seed_*.json')" "${EXPECTED_PTB_EXTENSION_RESULTS}"
assert_count "PTB extension raw-prediction NPZ" \
  "$(count_matching_files "${PTB_EXTENSION_RESULTS}" 'seed_*_raw.npz')" "${EXPECTED_PTB_EXTENSION_RESULTS}"
assert_count "PTB extension OOD-score NPZ" \
  "$(count_matching_files "${PTB_EXTENSION_RESULTS}" 'seed_*_ood_scores.npz')" "${EXPECTED_PTB_EXTENSION_RESULTS}"
assert_count "noise-gate result JSON" \
  "$(count_matching_files "${NOISE_GATE_RESULTS}" 'seed_*.json')" "${EXPECTED_NOISE_GATE_RESULTS}"
assert_count "noise-gate curves NPZ" \
  "$(count_matching_files "${NOISE_GATE_RESULTS}" 'seed_*_curves.npz')" "${EXPECTED_NOISE_GATE_RESULTS}"
assert_count "noise-gate checkpoint JSON" \
  "$(count_matching_files "${NOISE_GATE_CHECKPOINT_ROOT}" 'seed_*.json')" "${EXPECTED_NOISE_GATE_RESULTS}"
assert_count "noise-gate checkpoint NPZ" \
  "$(count_matching_files "${NOISE_GATE_CHECKPOINT_ROOT}" 'seed_*.npz')" "${EXPECTED_NOISE_GATE_RESULTS}"
assert_count "noise-shift calibration JSON" \
  "$(count_top_matching_files "${NOISE_SHIFT_RESULTS}" 'seed_*.json')" "${EXPECTED_NOISE_SHIFT_RESULTS}"
assert_count "noise-shift calibration NPZ" \
  "$(count_top_matching_files "${NOISE_SHIFT_RESULTS}" 'seed_*_calibration.npz')" "${EXPECTED_NOISE_SHIFT_RESULTS}"
assert_count "modular PTB result JSON" \
  "$(count_top_matching_files "${MODULAR_RESULTS}/ptb" 'seed_*.json')" 5
assert_count "modular PTB arrays NPZ" \
  "$(count_top_matching_files "${MODULAR_RESULTS}/ptb" 'seed_*_arrays.npz')" 5
assert_count "modular noise result JSON" \
  "$(count_top_matching_files "${MODULAR_RESULTS}/noise" 'seed_*.json')" 3
assert_count "modular noise arrays NPZ" \
  "$(count_top_matching_files "${MODULAR_RESULTS}/noise" 'seed_*_arrays.npz')" 3
[[ -s "${MODULAR_RESULTS}/manifest.json" && -s "${MODULAR_RESULTS}/summary.json" ]] || \
  die "modular pipeline result manifest/summary is absent"
assert_count "noise-gate presanitize JSON backup" \
  "$(count_matching_files "${NOISE_GATE_PRESANITIZE_ROOT}" 'seed_*.json')" 9
assert_count "noise-gate presanitize curves backup" \
  "$(count_matching_files "${NOISE_GATE_PRESANITIZE_ROOT}" 'seed_*_curves.npz')" 9
assert_nonempty_tree "PTB first memory-limited attempt logs" "${PTB_ATTEMPT1_LOG_DIR}"

# Smoke artefacts are diagnostic only and never contribute to the formal
# completion decision.  They are nevertheless required to be present and are
# frozen in a separately labelled subtree.
assert_count "PTB extension smoke JSON" \
  "$(count_matching_files "${SMOKE_PTB_ROOT}" 'seed_*.json')" 9
assert_count "PTB extension smoke raw NPZ" \
  "$(count_matching_files "${SMOKE_PTB_ROOT}" 'seed_*_raw.npz')" 9
assert_count "PTB extension smoke OOD NPZ" \
  "$(count_matching_files "${SMOKE_PTB_ROOT}" 'seed_*_ood_scores.npz')" 9
assert_nonempty_tree "noise extension smoke" "${SMOKE_NOISE_ROOT}"
assert_nonempty_tree "noise extension smoke checkpoints" "${SMOKE_NOISE_CHECKPOINT_ROOT}"
assert_nonempty_tree "PTB auditor smoke" "${SMOKE_PTB_AUDIT_ROOT}"
assert_nonempty_tree "auxiliary auditor smoke" "${SMOKE_AUX_AUDIT_ROOT}"

mkdir -p "${BUNDLE_STAGING_ROOT}"
BUILD_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STAGING="${BUNDLE_STAGING_ROOT}/reproducibility_bundle-${BUILD_STAMP}-$$"
[[ ! -e "${STAGING}" && ! -L "${STAGING}" ]] || die "unique bundle version already exists: ${STAGING}"
mkdir -- "${STAGING}"
mkdir -p \
  "${STAGING}/aggregates" \
  "${STAGING}/aggregates/noise_shift_calibration_audit" \
  "${STAGING}/aggregates/noise_shift_calibration_audit_existing" \
  "${STAGING}/checkpoints/noise_sqi" \
  "${STAGING}/checkpoints/noise_gate" \
  "${STAGING}/code" \
  "${STAGING}/configs/cache_manifests" \
  "${STAGING}/environment" \
  "${STAGING}/inventories" \
  "${STAGING}/logs/finalization" \
  "${STAGING}/logs/formal" \
  "${STAGING}/logs/ptbxl_extension" \
  "${STAGING}/logs/noise_gate" \
  "${STAGING}/logs/noise_shift" \
  "${STAGING}/logs/modular_pipeline" \
  "${STAGING}/logs/postprocess" \
  "${STAGING}/provenance/noise_gate_migration" \
  "${STAGING}/provenance/ptbxl_attempt1_logs" \
  "${STAGING}/provenance/modular_early_code" \
  "${STAGING}/provenance/modular_attempt2_missing_seed" \
  "${STAGING}/results/formal/ptbxl" \
  "${STAGING}/results/formal/wearables" \
  "${STAGING}/results/formal/noise_sqi" \
  "${STAGING}/results/extensions/ptbxl_missing" \
  "${STAGING}/results/extensions/noise_gate" \
  "${STAGING}/results/extensions/noise_shift_calibration" \
  "${STAGING}/results/extensions/modular_pipeline" \
  "${STAGING}/smoke/ptbxl_extension" \
  "${STAGING}/smoke/noise_extension" \
  "${STAGING}/smoke/noise_checkpoints" \
  "${STAGING}/smoke/ptbxl_audit" \
  "${STAGING}/smoke/auxiliary_audit"

COMMAND_RECORD="${STAGING}/logs/finalization/commands_executed.sh"
{
  printf '#!/usr/bin/env bash\n'
  printf '# Exact commands executed by finalize_reproducibility.sh on AutoDL.\n'
  printf 'set -euo pipefail\n'
} > "${COMMAND_RECORD}"

# Validate every completed JSON and its same-directory binary pair before the
# heavier strict aggregators run.  This is intentionally executed remotely.
record_command "${COMMAND_RECORD}" "${PYTHON}" - "${PTB_RESULTS}" \
  "${WEARABLE_RESULTS}" "${NOISE_RESULTS}" "${PTB_EXTENSION_RESULTS}" \
  "${NOISE_GATE_RESULTS}" "${NOISE_GATE_CHECKPOINT_ROOT}" \
  "${NOISE_SHIFT_RESULTS}" "${NOISE_CHECKPOINT_ROOT}" \
  "${PROMISED_POSTPROCESS_ROOT}" "${MODULAR_RESULTS}" "${MODULAR_AUDIT_JSON}" \
  "${STAGING}/inventories/preflight_completeness.json"
"${PYTHON}" - "${PTB_RESULTS}" "${WEARABLE_RESULTS}" "${NOISE_RESULTS}" \
    "${PTB_EXTENSION_RESULTS}" "${NOISE_GATE_RESULTS}" \
    "${NOISE_GATE_CHECKPOINT_ROOT}" "${NOISE_SHIFT_RESULTS}" \
    "${NOISE_CHECKPOINT_ROOT}" "${PROMISED_POSTPROCESS_ROOT}" \
    "${MODULAR_RESULTS}" "${MODULAR_AUDIT_JSON}" \
    "${STAGING}/inventories/preflight_completeness.json" <<'PY'
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

(
    ptb_root, wearable_root, noise_root, ptb_extension_root,
    noise_gate_root, noise_gate_checkpoint_root, noise_shift_root,
    noise_checkpoint_root, postprocess_root, modular_root, modular_audit_path,
    output,
) = map(Path, sys.argv[1:])

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def object_at(path):
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"top-level JSON is not an object: {path}")
    return value

def load_complete(paths, expected, binary_suffix, label):
    paths = sorted(paths)
    if len(paths) != expected:
        raise SystemExit(f"{label}: expected {expected} JSON files, found {len(paths)}")
    seen = set()
    for path in paths:
        match = re.fullmatch(r"seed_([0-9]+)\.json", path.name)
        if not match:
            raise SystemExit(f"{label}: unexpected JSON name {path}")
        identity = str(path.resolve())
        if identity in seen:
            raise SystemExit(f"{label}: duplicate resolved JSON {path}")
        seen.add(identity)
        payload = object_at(path)
        if payload.get("status") != "complete":
            raise SystemExit(f"{label}: status is not complete in {path}")
        binary = path.with_name(path.stem + binary_suffix)
        if not binary.is_file() or binary.stat().st_size <= 0:
            raise SystemExit(f"{label}: missing or empty paired artefact {binary}")
    return len(paths)

def require_declared_hash(path, declaration, label):
    if not path.is_file() or path.stat().st_size <= 0:
        raise SystemExit(f"{label}: missing or empty artefact {path}")
    if not isinstance(declaration, dict):
        raise SystemExit(f"{label}: absent artefact declaration for {path}")
    if declaration.get("bytes") not in (None, path.stat().st_size):
        raise SystemExit(f"{label}: byte count mismatch for {path}")
    if declaration.get("sha256") != sha256(path):
        raise SystemExit(f"{label}: SHA256 mismatch for {path}")

ptb = load_complete(
    ptb_root.resolve().rglob("seed_*.json"), 212, "_raw.npz", "PTB"
)
# PTB has a second required binary artefact for every canonical cell.
for path in sorted(ptb_root.resolve().rglob("seed_*.json")):
    ood = path.with_name(path.stem + "_ood_scores.npz")
    if not ood.is_file() or ood.stat().st_size <= 0:
        raise SystemExit(f"PTB: missing or empty paired OOD artefact {ood}")

wearable = load_complete(
    wearable_root.resolve().rglob("seed_*.json"), 345,
    "_predictions.npz", "wearable",
)
noise = load_complete(
    (noise_root.resolve() / "canonical").glob("seed_*.json"), 3,
    "_curves.npz", "noise/SQI",
)

ptb_extension = load_complete(
    ptb_extension_root.resolve().rglob("seed_*.json"), 221,
    "_raw.npz", "PTB extension",
)
for path in sorted(ptb_extension_root.resolve().rglob("seed_*.json")):
    ood = path.with_name(path.stem + "_ood_scores.npz")
    if not ood.is_file() or ood.stat().st_size <= 0:
        raise SystemExit(f"PTB extension: missing or empty paired OOD artefact {ood}")

gate_pairs = set()
for path in sorted(noise_gate_root.resolve().rglob("seed_*.json")):
    payload = object_at(path)
    if payload.get("status") != "complete" or payload.get("canonical") is not True:
        raise SystemExit(f"noise gate: incomplete or noncanonical result {path}")
    seed = int(payload.get("seed", -1))
    gate = payload.get("environment", {}).get("gate_architecture")
    if gate not in {"independent_sigmoid", "global_sigmoid", "sample_softmax"}:
        raise SystemExit(f"noise gate: invalid gate architecture in {path}")
    if seed not in {7, 13, 42} or (gate, seed) in gate_pairs:
        raise SystemExit(f"noise gate: invalid/duplicate gate-seed pair {(gate, seed)}")
    gate_pairs.add((gate, seed))
    curves = path.with_name(path.stem + "_curves.npz")
    require_declared_hash(curves, payload.get("raw_npz"), "noise gate")
if len(gate_pairs) != 9:
    raise SystemExit(f"noise gate: expected 9 gate-seed pairs, found {len(gate_pairs)}")

gate_checkpoint_pairs = set()
for path in sorted(noise_gate_checkpoint_root.resolve().rglob("seed_*.json")):
    payload = object_at(path)
    if payload.get("status") != "complete":
        raise SystemExit(f"noise gate checkpoint: incomplete {path}")
    seed = int(payload.get("seed", -1))
    gate = payload.get("checkpoint_provenance", {}).get("gate_architecture")
    if gate not in {"independent_sigmoid", "global_sigmoid", "sample_softmax"}:
        # The gate is also an explicit directory component in the frozen tree.
        gate = next((item for item in path.parts if item in {
            "independent_sigmoid", "global_sigmoid", "sample_softmax"
        }), None)
    if seed not in {7, 13, 42} or gate is None or (gate, seed) in gate_checkpoint_pairs:
        raise SystemExit(f"noise gate checkpoint: invalid/duplicate pair {(gate, seed)}")
    gate_checkpoint_pairs.add((gate, seed))
    weights = path.with_suffix(".npz")
    require_declared_hash(
        weights, {"sha256": payload.get("weights_sha256")}, "noise gate checkpoint"
    )
if gate_checkpoint_pairs != gate_pairs:
    raise SystemExit("noise gate result/checkpoint identities do not match")

shift_manifest = object_at(noise_shift_root / "manifest.json")
if shift_manifest.get("complete") is not True:
    raise SystemExit("noise shift calibration manifest is not complete")
if shift_manifest.get("observed_seeds") != [7, 13, 42]:
    raise SystemExit("noise shift calibration manifest has unexpected seed order/content")
shift_seeds = set()
for path in sorted(noise_shift_root.glob("seed_*.json")):
    payload = object_at(path)
    seed = int(payload.get("seed", -1))
    if payload.get("status") != "complete" or seed not in {7, 13, 42} or seed in shift_seeds:
        raise SystemExit(f"noise shift calibration: invalid result {path}")
    shift_seeds.add(seed)
    calibration = path.with_name(path.stem + "_calibration.npz")
    require_declared_hash(calibration, payload.get("raw_npz"), "noise shift calibration")
if shift_seeds != {7, 13, 42}:
    raise SystemExit(f"noise shift calibration seeds are incomplete: {sorted(shift_seeds)}")

for seed in (7, 13, 42):
    metadata_path = noise_checkpoint_root / "canonical" / "trust_full" / f"seed_{seed}.json"
    weights_path = metadata_path.with_suffix(".npz")
    metadata = object_at(metadata_path)
    if metadata.get("status") != "complete" or int(metadata.get("seed", -1)) != seed:
        raise SystemExit(f"formal noise checkpoint is incomplete: {metadata_path}")
    require_declared_hash(
        weights_path, {"sha256": metadata.get("weights_sha256")}, "formal noise checkpoint"
    )

postprocess_completion = object_at(postprocess_root / "completion_matrix.json")
postprocess_payload = object_at(postprocess_root / "postprocess_results.json")
postprocess_manifest = object_at(postprocess_root / "manifest.json")
if postprocess_completion.get("complete") is not True:
    raise SystemExit("promised postprocess completion matrix is incomplete")
if postprocess_payload.get("audit", {}).get("complete") is not True:
    raise SystemExit("promised postprocess audit is incomplete")
if len(postprocess_manifest.get("outputs", [])) < 1:
    raise SystemExit("promised postprocess manifest has no declared output")

modular_manifest = object_at(modular_root / "manifest.json")
modular_summary = object_at(modular_root / "summary.json")
modular_audit = object_at(modular_audit_path)
if modular_manifest.get("status") != "complete":
    raise SystemExit("modular pipeline result manifest is incomplete")
if modular_manifest.get("counts", {}).get("ptb_results") != 5:
    raise SystemExit("modular pipeline manifest does not contain five PTB results")
if modular_manifest.get("counts", {}).get("noise_results") != 3:
    raise SystemExit("modular pipeline manifest does not contain three noise results")
guards = modular_manifest.get("protocol_guards", {})
if guards.get("neural_training_or_parameter_update_performed") is not False:
    raise SystemExit("modular pipeline unexpectedly reports neural training")
if guards.get("all_thresholds_validation_only") is not True:
    raise SystemExit("modular pipeline threshold guard is not validation-only")
if guards.get("server_shutdown_requested") is not False:
    raise SystemExit("modular pipeline reports a shutdown request")
if modular_summary.get("status") != "complete":
    raise SystemExit("modular pipeline cross-seed summary is incomplete")
audit_complete = modular_audit.get("complete", modular_audit.get("status") == "complete")
audit_issue_count = modular_audit.get("issue_count", modular_audit.get("error_count"))
if audit_complete is not True or audit_issue_count != 0:
    raise SystemExit("modular pipeline strict audit is incomplete/nonzero-issue")

payload = {
    "schema": "paper46-final-preflight-v3",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "counts": {
        "ptbxl_formal": ptb,
        "wearables_formal": wearable,
        "noise_sqi_formal": noise,
        "ptbxl_extensions": ptb_extension,
        "noise_gate_extensions": len(gate_pairs),
        "noise_gate_checkpoints": len(gate_checkpoint_pairs),
        "noise_shift_calibration": len(shift_seeds),
        "formal_noise_trust_checkpoints": 3,
        "modular_pipeline_results": 8,
    },
    "paired_artifacts": {
        "ptbxl": ["json", "raw_npz", "ood_npz"],
        "wearables": ["json", "predictions_npz"],
        "noise_sqi": ["json", "curves_npz"],
        "ptbxl_extensions": ["json", "raw_npz", "ood_npz"],
        "noise_gate_extensions": ["json", "curves_npz", "checkpoint_json", "checkpoint_npz"],
        "noise_shift_calibration": ["json", "calibration_npz", "manifest"],
        "modular_pipeline": ["8 seed_json", "8 arrays_npz", "manifest", "summary", "strict_audit"],
    },
    "promised_postprocess_complete": True,
    "modular_pipeline_audit_complete": True,
}
output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

# Authenticate the already completed strict noise-shift audit before doing a
# fresh staging audit below.  This rejects a stale/partial audit tree and binds
# its manifest, CSVs, auditor source and all three result pairs to current
# bytes.  The existing audit is later frozen separately for provenance.
record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${NOISE_SHIFT_AUDIT_JSON}" "${NOISE_SHIFT_RESULTS}" \
  "${EXPERIMENT_DIR}/audit_noise_shift_calibration.py" \
  "${STAGING}/inventories/noise_shift_existing_audit_preflight.json"
"${PYTHON}" - \
    "${NOISE_SHIFT_AUDIT_JSON}" "${NOISE_SHIFT_RESULTS}" \
    "${EXPERIMENT_DIR}/audit_noise_shift_calibration.py" \
    "${STAGING}/inventories/noise_shift_existing_audit_preflight.json" <<'PY'
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

manifest_path, results_root, auditor_path, output_path = map(Path, sys.argv[1:])
manifest_path = manifest_path.resolve()
audit_root = manifest_path.parent
results_root = results_root.resolve()
auditor_path = auditor_path.resolve()

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

payload = json.loads(manifest_path.read_text(encoding="utf-8"))
if payload.get("schema") != "paper46-noise-shift-calibration-audit-v1":
    raise SystemExit("existing noise-shift audit schema mismatch")
if payload.get("complete") is not True or payload.get("issue_count") != 0:
    raise SystemExit("existing noise-shift audit is incomplete/nonzero-issue")
if payload.get("issues") != []:
    raise SystemExit("existing noise-shift audit contains issue rows")
expected = payload.get("expected", {})
observed = payload.get("observed", {})
if expected.get("seeds") != [7, 13, 42] or expected.get("metric_rows") != 252:
    raise SystemExit("existing noise-shift audit expected contract mismatch")
if expected.get("waveform_arrays") != 0:
    raise SystemExit("existing noise-shift audit does not exclude waveform arrays")
if observed.get("result_pairs") != 3 or observed.get("valid_seeds") != [7, 13, 42]:
    raise SystemExit("existing noise-shift audit valid seed/result-pair mismatch")
if observed.get("metric_rows") != 252:
    raise SystemExit("existing noise-shift audit metric row count mismatch")

source_manifest = results_root / "manifest.json"
source_decl = payload.get("source_manifest", {})
if Path(str(source_decl.get("path", ""))).resolve() != source_manifest:
    raise SystemExit("existing noise-shift audit points to a different result manifest")
if source_decl.get("sha256") != sha256(source_manifest):
    raise SystemExit("existing noise-shift audit result-manifest SHA mismatch")
auditor_decl = payload.get("auditor", {})
if Path(str(auditor_decl.get("path", ""))).resolve() != auditor_path:
    raise SystemExit("existing noise-shift audit points to a different auditor")
if auditor_decl.get("sha256") != sha256(auditor_path):
    raise SystemExit("existing noise-shift auditor SHA mismatch")

results = payload.get("results")
if not isinstance(results, list) or len(results) != 3:
    raise SystemExit("existing noise-shift audit does not declare three results")
seen = set()
for row in results:
    seed = row.get("seed")
    if seed not in {7, 13, 42} or seed in seen:
        raise SystemExit(f"existing noise-shift audit duplicate/invalid seed: {seed}")
    seen.add(seed)
    for role, suffix in (("json", ".json"), ("npz", "_calibration.npz")):
        path = results_root / f"seed_{seed}{suffix}"
        declaration = row.get(role, {})
        if Path(str(declaration.get("path", ""))).resolve() != path:
            raise SystemExit(f"existing noise-shift audit {role} path mismatch: seed={seed}")
        if declaration.get("bytes") != path.stat().st_size or declaration.get("sha256") != sha256(path):
            raise SystemExit(f"existing noise-shift audit {role} bytes/SHA mismatch: seed={seed}")
if seen != {7, 13, 42}:
    raise SystemExit("existing noise-shift audit seed set mismatch")

csv_contract = {
    "metrics": (audit_root / "calibration_metrics.csv", 252),
    "issues": (audit_root / "issues.csv", 0),
}
for role, (path, rows) in csv_contract.items():
    declaration = payload.get("csv", {}).get(role, {})
    if Path(str(declaration.get("path", ""))).resolve() != path:
        raise SystemExit(f"existing noise-shift audit {role} CSV path mismatch")
    if declaration.get("rows") != rows:
        raise SystemExit(f"existing noise-shift audit {role} CSV row mismatch")
    if declaration.get("bytes") != path.stat().st_size or declaration.get("sha256") != sha256(path):
        raise SystemExit(f"existing noise-shift audit {role} CSV bytes/SHA mismatch")

expected_files = {manifest_path, audit_root / "calibration_metrics.csv", audit_root / "issues.csv"}
actual_files = {path.resolve() for path in audit_root.iterdir() if path.is_file()}
if actual_files != expected_files:
    raise SystemExit("existing noise-shift audit has an unexpected/missing file set")

audit = {
    "schema": "paper46-noise-shift-existing-audit-preflight-v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "issue_count": 0,
    "valid_seeds": [7, 13, 42],
    "metric_rows": 252,
    "existing_manifest_sha256": sha256(manifest_path),
    "auditor_sha256": sha256(auditor_path),
    "all_three_result_pairs_bytes_sha256_bound": True,
}
output_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

# Independently close the serialization-migration chain.  The trusted backup
# is opened only on AutoDL with allow_pickle=True; it is never copied into the
# bundle.  For all nine gate/seed pairs this audit proves that the declared
# source/target hashes match the backup/current bytes, that identity metadata
# agrees, and that only test_record_id changed from object strings to fixed
# Unicode while every other array retained shape, dtype and exact values.
record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${NOISE_GATE_RESULTS}" "${NOISE_GATE_PRESANITIZE_ROOT}" \
  "${EXPERIMENT_DIR}/sanitize_noise_curves.py" \
  "${STAGING}/provenance/noise_gate_migration/migration_audit.json" \
  "${STAGING}/provenance/noise_gate_migration/presanitize_source_sha256.tsv"
"${PYTHON}" - \
    "${NOISE_GATE_RESULTS}" "${NOISE_GATE_PRESANITIZE_ROOT}" \
    "${EXPERIMENT_DIR}/sanitize_noise_curves.py" \
    "${STAGING}/provenance/noise_gate_migration/migration_audit.json" \
    "${STAGING}/provenance/noise_gate_migration/presanitize_source_sha256.tsv" <<'PY'
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

current_root, backup_root, sanitizer_path, audit_path, source_list_path = map(
    Path, sys.argv[1:]
)
current_root = current_root.resolve()
backup_root = backup_root.resolve()
sanitizer_path = sanitizer_path.resolve()

GATES = ("global_sigmoid", "independent_sigmoid", "sample_softmax")
SEEDS = (7, 13, 42)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SystemExit(f"migration JSON is not an object: {path}")
    return value

def exact_equal(left: np.ndarray, right: np.ndarray) -> bool:
    if left.shape != right.shape or left.dtype != right.dtype:
        return False
    if np.issubdtype(left.dtype, np.inexact):
        return bool(np.array_equal(left, right, equal_nan=True))
    return bool(np.array_equal(left, right))

expected_rel_json = {
    Path(gate) / "canonical" / f"seed_{seed}.json"
    for gate in GATES for seed in SEEDS
}
expected_rel_npz = {
    Path(gate) / "canonical" / f"seed_{seed}_curves.npz"
    for gate in GATES for seed in SEEDS
}
for root, label in ((current_root, "current"), (backup_root, "presanitize")):
    observed_json = {path.relative_to(root) for path in root.rglob("seed_*.json")}
    observed_npz = {path.relative_to(root) for path in root.rglob("seed_*_curves.npz")}
    if observed_json != expected_rel_json or observed_npz != expected_rel_npz:
        raise SystemExit(
            f"{label} noise-gate file set differs from the exact 9-pair contract"
        )

sanitizer_sha = sha256(sanitizer_path)
rows = []
source_rows = []
for gate in GATES:
    for seed in SEEDS:
        relative_json = Path(gate) / "canonical" / f"seed_{seed}.json"
        relative_npz = Path(gate) / "canonical" / f"seed_{seed}_curves.npz"
        current_json = current_root / relative_json
        current_npz = current_root / relative_npz
        backup_json = backup_root / relative_json
        backup_npz = backup_root / relative_npz
        for path in (current_json, current_npz, backup_json, backup_npz):
            if not path.is_file() or path.stat().st_size <= 0:
                raise SystemExit(f"migration pair is missing/empty: {path}")

        current_payload = load_json(current_json)
        backup_payload = load_json(backup_json)
        current_gate = current_payload.get("environment", {}).get("gate_architecture")
        backup_gate = backup_payload.get("environment", {}).get("gate_architecture")
        if int(current_payload.get("seed", -1)) != seed or int(backup_payload.get("seed", -1)) != seed:
            raise SystemExit(f"migration seed mismatch: gate={gate} seed={seed}")
        if current_gate != gate or backup_gate != gate:
            raise SystemExit(f"migration gate mismatch: expected={gate}, current={current_gate}, backup={backup_gate}")

        source_sha = sha256(backup_npz)
        target_sha = sha256(current_npz)
        if backup_payload.get("raw_npz", {}).get("sha256") != source_sha:
            raise SystemExit(f"presanitize raw_npz SHA mismatch: {backup_json}")
        current_raw = current_payload.get("raw_npz", {})
        if current_raw.get("sha256") != target_sha:
            raise SystemExit(f"current raw_npz SHA mismatch: {current_json}")
        if Path(str(current_raw.get("path", ""))).resolve() != current_npz.resolve():
            raise SystemExit(f"current raw_npz path mismatch: {current_json}")

        migrations = current_payload.get("artifact_migrations")
        if not isinstance(migrations, list) or len(migrations) != 1:
            raise SystemExit(f"expected exactly one artifact_migrations entry: {current_json}")
        migration = migrations[0]
        expected_verification = {
            "object_key_whitelist_enforced": True,
            "all_object_values_verified_strings": True,
            "non_object_shape_dtype_and_values_unchanged": True,
            "sanitized_npz_loaded_with_allow_pickle_false": True,
        }
        if migration.get("type") != "object_string_to_fixed_unicode":
            raise SystemExit(f"wrong migration type: {current_json}")
        if migration.get("keys") != ["test_record_id"]:
            raise SystemExit(f"migration changed keys other than test_record_id: {current_json}")
        if migration.get("source_sha256") != source_sha or migration.get("target_sha256") != target_sha:
            raise SystemExit(f"artifact_migrations source/target SHA mismatch: {current_json}")
        if Path(str(migration.get("backup_npz", ""))).resolve() != backup_npz.resolve():
            raise SystemExit(f"artifact_migrations backup_npz mismatch: {current_json}")
        if Path(str(migration.get("backup_json", ""))).resolve() != backup_json.resolve():
            raise SystemExit(f"artifact_migrations backup_json mismatch: {current_json}")
        if migration.get("tool") != sanitizer_path.name or migration.get("tool_sha256") != sanitizer_sha:
            raise SystemExit(f"artifact_migrations sanitizer SHA mismatch: {current_json}")
        if migration.get("verification") != expected_verification:
            raise SystemExit(f"artifact_migrations verification contract mismatch: {current_json}")

        with np.load(backup_npz, allow_pickle=True) as old_archive:
            with np.load(current_npz, allow_pickle=False) as new_archive:
                if set(old_archive.files) != set(new_archive.files):
                    raise SystemExit(f"migration changed NPZ key set: {relative_npz}")
                changed = []
                array_contract = []
                for key in old_archive.files:
                    old = np.asarray(old_archive[key])
                    new = np.asarray(new_archive[key])
                    if key == "test_record_id":
                        if old.dtype.kind != "O" or new.dtype.kind != "U" or old.ndim != 1 or old.shape != new.shape:
                            raise SystemExit(
                                f"test_record_id is not object->Unicode with stable shape: {relative_npz}"
                            )
                        original_items = old.tolist()
                        if not all(isinstance(item, (str, np.str_)) for item in original_items):
                            raise SystemExit(f"non-string object in test_record_id: {relative_npz}")
                        old_values = np.asarray([str(item) for item in original_items], dtype=str)
                        if old_values.shape != new.shape or not np.array_equal(old_values, new):
                            raise SystemExit(f"test_record_id values changed: {relative_npz}")
                        changed.append(key)
                    else:
                        if old.dtype.hasobject or new.dtype.hasobject:
                            raise SystemExit(f"unexpected object array {key}: {relative_npz}")
                        if not exact_equal(old, new):
                            raise SystemExit(f"non-target array changed: {relative_npz}:{key}")
                    array_contract.append({
                        "key": key,
                        "shape": [int(value) for value in new.shape],
                        "source_dtype": str(old.dtype),
                        "target_dtype": str(new.dtype),
                        "value_equal": True,
                    })
                if changed != ["test_record_id"]:
                    raise SystemExit(f"wrong migrated array set: {relative_npz}:{changed}")

        rows.append({
            "gate": gate,
            "seed": seed,
            "relative_json": relative_json.as_posix(),
            "relative_npz": relative_npz.as_posix(),
            "backup_json_sha256": sha256(backup_json),
            "source_npz_sha256": source_sha,
            "target_npz_sha256": target_sha,
            "current_json_sha256": sha256(current_json),
            "changed_keys": ["test_record_id"],
            "arrays": array_contract,
        })
        for role, path in (("backup_json", backup_json), ("backup_npz", backup_npz)):
            source_rows.append((gate, seed, role, sha256(path), path.stat().st_size, relative_json if role == "backup_json" else relative_npz))

audit = {
    "schema": "paper46-noise-gate-migration-independent-audit-v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "issue_count": 0,
    "pair_count": len(rows),
    "presanitize_source_file_count": len(source_rows),
    "contract": {
        "gate_seed_pairs": "3 gates x 3 seeds",
        "only_change": "test_record_id object dtype -> fixed Unicode; shape and string values unchanged",
        "all_other_arrays": "identical shape, dtype and values (NaN-aware exact equality)",
        "artifact_migrations_source_target_sha_bound": True,
        "backup_payload_distributed": False,
    },
    "sanitizer": {"filename": sanitizer_path.name, "sha256": sanitizer_sha},
    "pairs": rows,
}
audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
with source_list_path.open("w", encoding="utf-8", newline="\n") as handle:
    handle.write("gate\tseed\trole\tsha256\tbytes\trelative_path\n")
    for gate, seed, role, digest, size, relative in source_rows:
        handle.write(f"{gate}\t{seed}\t{role}\t{digest}\t{size}\t{relative.as_posix()}\n")
PY

# Bind the v3 promised postprocess byte-for-byte to the current formal
# 212/3/345 roots and the current postprocess source.  This reconstructs the
# exact input inventory independently; a complete-looking stale output tree is
# rejected even if its own output hashes remain internally consistent.
record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${PTB_RESULTS}" "${NOISE_RESULTS}" "${WEARABLE_RESULTS}" \
  "${PROMISED_POSTPROCESS_ROOT}" \
  "${EXPERIMENT_DIR}/postprocess_promised_metrics.py" \
  "${STAGING}/inventories/promised_postprocess_input_binding.json"
"${PYTHON}" - \
    "${PTB_RESULTS}" "${NOISE_RESULTS}" "${WEARABLE_RESULTS}" \
    "${PROMISED_POSTPROCESS_ROOT}" \
    "${EXPERIMENT_DIR}/postprocess_promised_metrics.py" \
    "${STAGING}/inventories/promised_postprocess_input_binding.json" <<'PY'
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ptb_root, noise_root, wearable_root, output_root, script_path, audit_path = map(
    Path, sys.argv[1:]
)
ptb_root, noise_root, wearable_root, output_root, script_path = (
    path.resolve() for path in (ptb_root, noise_root, wearable_root, output_root, script_path)
)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SystemExit(f"postprocess binding JSON is not an object: {path}")
    return value

def declared_path(value, json_path: Path) -> Path:
    path = Path(str(value))
    return path.resolve() if path.is_absolute() else (json_path.parent / path).resolve()

expected = {}
def add(path: Path, role: str) -> None:
    path = path.resolve()
    if not path.is_file() or path.stat().st_size <= 0:
        raise SystemExit(f"current postprocess input absent/empty: {path}")
    if str(path) in expected:
        raise SystemExit(f"duplicate reconstructed postprocess input: {path}")
    expected[str(path)] = {
        "role": role,
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }

ptb_json = []
for path in sorted(ptb_root.rglob("seed_*.json")):
    payload = load_json(path)
    if "run_definition" not in payload or "model" not in payload:
        continue
    ptb_json.append(path)
    add(path, "ptb_json")
    add(path.with_name(path.stem + "_raw.npz"), "raw_npz")
    add(path.with_name(path.stem + "_ood_scores.npz"), "ood_npz")
if len(ptb_json) != 212:
    raise SystemExit(f"reconstructed PTB postprocess inputs != 212 cells: {len(ptb_json)}")

noise_json = []
for seed in (7, 13, 42):
    candidates = [
        path for path in noise_root.rglob(f"seed_{seed}.json")
        if path.parent.name == "canonical"
    ]
    if len(candidates) != 1:
        raise SystemExit(f"noise seed {seed}: expected one canonical JSON, found {len(candidates)}")
    path = candidates[0]
    payload = load_json(path)
    noise_json.append(path)
    add(path, "noise_json")
    add(declared_path(payload.get("raw_npz", {}).get("path"), path), "noise_curves")

wearable_json = []
for path in sorted(wearable_root.rglob("seed_*.json")):
    payload = load_json(path)
    if payload.get("schema") != "paper46-wearable-loso-v1":
        continue
    wearable_json.append(path)
    add(path, "wearable_json")
    add(declared_path(payload.get("prediction_file", {}).get("path"), path), "wearable_prediction")
if len(wearable_json) != 345:
    raise SystemExit(f"reconstructed wearable postprocess inputs != 345 cells: {len(wearable_json)}")

manifest_path = output_root / "manifest.json"
manifest = load_json(manifest_path)
if manifest.get("schema") != "paper46-promised-postprocess-v1":
    raise SystemExit("postprocess schema/version mismatch")
arguments = manifest.get("arguments", {})
root_contract = {
    "ptb_root": ptb_root,
    "noise_root": noise_root,
    "wearables_root": wearable_root,
    "output_dir": output_root,
}
for key, expected_root in root_contract.items():
    if Path(str(arguments.get(key, ""))).resolve() != expected_root:
        raise SystemExit(f"postprocess argument {key} is stale or points to another tree")
if arguments.get("bootstrap") != 2000 or arguments.get("target_sensitivity") != 0.95:
    raise SystemExit("postprocess bootstrap/sensitivity contract mismatch")
if arguments.get("fail_on_incomplete") is not True:
    raise SystemExit("postprocess was not run with --fail-on-incomplete")

script_decl = manifest.get("script", {})
script_sha = sha256(script_path)
if Path(str(script_decl.get("path", ""))).resolve() != script_path:
    raise SystemExit("postprocess manifest is bound to a different script path")
if script_decl.get("sha256") != script_sha:
    raise SystemExit("postprocess manifest script SHA differs from current frozen source")

declared_inputs = manifest.get("inputs")
if not isinstance(declared_inputs, list) or len(declared_inputs) != len(expected):
    raise SystemExit(
        f"postprocess input inventory length mismatch: declared={len(declared_inputs) if isinstance(declared_inputs, list) else 'invalid'} expected={len(expected)}"
    )
observed = {}
for item in declared_inputs:
    if not isinstance(item, dict):
        raise SystemExit("postprocess input declaration is not an object")
    path = str(Path(str(item.get("path", ""))).resolve())
    if path in observed:
        raise SystemExit(f"duplicate postprocess manifest input: {path}")
    observed[path] = {
        "role": item.get("role"), "path": path,
        "bytes": item.get("bytes"), "sha256": item.get("sha256"),
    }
if observed != expected:
    missing = sorted(set(expected) - set(observed))
    extra = sorted(set(observed) - set(expected))
    wrong = sorted(path for path in set(expected) & set(observed) if expected[path] != observed[path])
    raise SystemExit(
        f"postprocess inputs are stale: missing={missing[:3]} extra={extra[:3]} mismatched={wrong[:3]}"
    )

declared_outputs = manifest.get("outputs")
if not isinstance(declared_outputs, list):
    raise SystemExit("postprocess output declarations are absent")
actual_output_files = {
    path.resolve() for path in output_root.iterdir()
    if path.is_file() and path.name != "manifest.json"
}
declared_output_files = set()
for item in declared_outputs:
    path = Path(str(item.get("path", ""))).resolve()
    if path.parent != output_root or path in declared_output_files:
        raise SystemExit(f"postprocess output declaration escapes/duplicates current root: {path}")
    if not path.is_file() or path.stat().st_size != item.get("bytes") or sha256(path) != item.get("sha256"):
        raise SystemExit(f"postprocess output bytes/SHA mismatch: {path}")
    declared_output_files.add(path)
if declared_output_files != actual_output_files:
    raise SystemExit("postprocess output tree contains undeclared or missing files")

role_counts = {}
for item in expected.values():
    role_counts[item["role"]] = role_counts.get(item["role"], 0) + 1
required_role_counts = {
    "ptb_json": 212, "raw_npz": 212, "ood_npz": 212,
    "noise_json": 3, "noise_curves": 3,
    "wearable_json": 345, "wearable_prediction": 345,
}
if role_counts != required_role_counts:
    raise SystemExit(f"postprocess reconstructed role counts mismatch: {role_counts}")

audit = {
    "schema": "paper46-postprocess-current-input-binding-v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "issue_count": 0,
    "manifest_sha256": sha256(manifest_path),
    "script_sha256": script_sha,
    "input_count": len(expected),
    "role_counts": role_counts,
    "output_count": len(actual_output_files),
    "contracts": {
        "current_formal_roots_exactly_matched": True,
        "every_input_bytes_and_sha256_matched": True,
        "script_path_and_sha256_matched": True,
        "all_nonmanifest_outputs_declared_and_hashed": True,
        "stale_tree_rejected": True,
    },
}
audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

# Validate the exact source snapshot remotely.  No Python code is executed on
# the local workstation by this workflow.
mapfile -d '' PYTHON_SOURCES < <(find "${EXPERIMENT_DIR}" -type f -name '*.py' -print0 | sort -z)
(( ${#PYTHON_SOURCES[@]} > 0 )) || die "no Python sources found"
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/python_compile.log" \
  "${PYTHON}" -m py_compile "${PYTHON_SOURCES[@]}"
while IFS= read -r -d '' shell_source; do
  run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/bash_syntax_$(basename "${shell_source}").log" \
    bash -n "${shell_source}"
done < <(find "${EXPERIMENT_DIR}" -maxdepth 1 -type f -name '*.sh' -print0 | sort -z)

# Generate, rather than hand-edit, the exact 60-group/212-record expectation.
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/expected_config.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/make_expected_config.py" \
  "${STAGING}/configs/expected_ptbxl_results.json"
if [[ -f "${REVISION_ROOT}/expected_ptbxl_results.json" ]]; then
  if cmp -s "${REVISION_ROOT}/expected_ptbxl_results.json" \
      "${STAGING}/configs/expected_ptbxl_results.json"; then
    printf 'status=identical\nexisting=%s\nfrozen=%s\n' \
      "${REVISION_ROOT}/expected_ptbxl_results.json" \
      "${STAGING}/configs/expected_ptbxl_results.json" \
      > "${STAGING}/configs/expected_config_source_comparison.txt"
  else
    # A convenience copy left by an earlier code generation is not an input
    # to this run.  Record the drift and use only the freshly generated,
    # frozen config so an obsolete pre-fingerprint file cannot contaminate the
    # strict audit.
    printf 'status=different_existing_not_used\nexisting=%s\nfrozen=%s\n' \
      "${REVISION_ROOT}/expected_ptbxl_results.json" \
      "${STAGING}/configs/expected_ptbxl_results.json" \
      > "${STAGING}/configs/expected_config_source_comparison.txt"
  fi
else
  printf 'status=no_existing_copy_frozen_generator_used\nfrozen=%s\n' \
    "${STAGING}/configs/expected_ptbxl_results.json" \
    > "${STAGING}/configs/expected_config_source_comparison.txt"
fi

# Strict PTB audit first, then the full 2,000-replicate patient aggregation.
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/aggregate_ptbxl_audit.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/aggregate_results.py" \
  "${PTB_RESULTS}" \
  --output-dir "${STAGING}/aggregates/ptbxl_audit" \
  --expected-config "${STAGING}/configs/expected_ptbxl_results.json" \
  --audit-only --fail-on-incomplete

run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/aggregate_ptbxl.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/aggregate_results.py" \
  "${PTB_RESULTS}" \
  --output-dir "${STAGING}/aggregates/ptbxl" \
  --expected-config "${STAGING}/configs/expected_ptbxl_results.json" \
  --bootstrap 2000 --confidence-level 0.95 --random-seed 2026 \
  --reference-method trust_full --fail-on-incomplete

# The auxiliary auditor enforces exactly 345 wearable cells and three
# canonical noise/SQI seeds, then performs its preregistered bootstrap.
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/aggregate_auxiliary.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/aggregate_auxiliary.py" \
  --wearables-root "${WEARABLE_RESULTS}" \
  --noise-root "${NOISE_RESULTS}" \
  --output-dir "${STAGING}/aggregates/auxiliary" \
  --bootstrap 10000 --fail-on-incomplete

# The 221 extension fits are deliberately audited as a disjoint closed
# matrix.  This program checks exact paths/counts, all three artefacts per fit,
# fingerprints, frozen code hashes, split/label alignment, 66 launcher exits,
# the completion marker, gate structure and representation diagnostics; it
# also emits the extension seed summaries and paired effects.
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/audit_promised_extensions.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/audit_promised_extensions.py" \
  --results-dir "${PTB_EXTENSION_RESULTS}" \
  --reference-results-dir "${PTB_RESULTS}" \
  --output-dir "${STAGING}/aggregates/promised_extensions" \
  --log-dir "${PTB_EXTENSION_LOG_DIR}" \
  --experiment-dir "${EXPERIMENT_DIR}" \
  --fail-on-incomplete

# Re-audit the safely migrated nine-cell noise-gate matrix.  The independent
# auditor rejects object-dtype members, reconstructs fingerprints and all
# declared SHA chains, checks result/checkpoint pairing and launcher logs, and
# produces the strict gate comparison aggregate in the unpublished staging.
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/audit_noise_gate_extensions.log" \
  "${PYTHON}" "${EXPERIMENT_DIR}/audit_noise_gate_extensions.py" \
  --results-root "${NOISE_GATE_RESULTS}" \
  --checkpoint-root "${NOISE_GATE_CHECKPOINT_ROOT}" \
  --log-root "${NOISE_GATE_LOG_DIR}" \
  --experiment-dir "${EXPERIMENT_DIR}" \
  --output-dir "${STAGING}/aggregates/noise_gate_extensions" \
  --fail-on-incomplete

# Re-run the independent noise-shift auditor against the current three-pair
# result root into unpublished staging.  Its manifest authenticates the exact
# auditor SHA, result JSON/NPZ bytes, official-fold protocol, fixed array set,
# clean-fold-9 temperature refit and all 252 recomputed metric rows.
cp -p -- "${EXPERIMENT_DIR}/audit_noise_shift_calibration.py" \
  "${STAGING}/code/audit_noise_shift_calibration.py"
cmp -s -- "${EXPERIMENT_DIR}/audit_noise_shift_calibration.py" \
  "${STAGING}/code/audit_noise_shift_calibration.py" || \
  die "frozen noise-shift auditor copy mismatch"
run_logged "${COMMAND_RECORD}" "${STAGING}/logs/finalization/audit_noise_shift_calibration.log" \
  "${PYTHON}" "${STAGING}/code/audit_noise_shift_calibration.py" \
  --results-root "${NOISE_SHIFT_RESULTS}" \
  --output-dir "${STAGING}/aggregates/noise_shift_calibration_audit" \
  --fail-on-incomplete
hash_tree "${STAGING}/aggregates/noise_shift_calibration_audit" \
  "${STAGING}/inventories/noise_shift_fresh_audit_sha256.tsv"

# The promised post-hoc metrics were already computed remotely against the
# immutable 212/345/3 roots.  Freeze their complete, self-audited output as an
# aggregate subtree and compare source/bundle hashes byte-for-byte.
hash_tree "${PROMISED_POSTPROCESS_ROOT}" \
  "${STAGING}/inventories/promised_postprocess_source_sha256.tsv"
snapshot_tree "${PROMISED_POSTPROCESS_ROOT}" \
  "${STAGING}/aggregates/promised_postprocess" \
  "${STAGING}/inventories/promised_postprocess_snapshot_method.txt"
hash_tree "${STAGING}/aggregates/promised_postprocess" \
  "${STAGING}/inventories/promised_postprocess_bundle_sha256.tsv"
cmp -s "${STAGING}/inventories/promised_postprocess_source_sha256.tsv" \
  "${STAGING}/inventories/promised_postprocess_bundle_sha256.tsv" || \
  die "promised postprocess copy hash mismatch"

record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${STAGING}/aggregates/ptbxl/result_manifest.json" \
  "${STAGING}/aggregates/ptbxl_audit/result_manifest.json" \
  "${STAGING}/aggregates/auxiliary/manifest.json" \
  "${STAGING}/aggregates/promised_extensions/audit_manifest.json" \
  "${STAGING}/aggregates/noise_gate_extensions/audit_manifest.json" \
  "${STAGING}/aggregates/noise_shift_calibration_audit/manifest.json" \
  "${STAGING}/aggregates/promised_postprocess/completion_matrix.json" \
  "${STAGING}/aggregates/promised_postprocess/postprocess_results.json" \
  "${STAGING}/aggregates/promised_postprocess/manifest.json" \
  "${STAGING}/provenance/noise_gate_migration/migration_audit.json" \
  "${STAGING}/inventories/promised_postprocess_input_binding.json" \
  "${STAGING}/inventories/noise_shift_existing_audit_preflight.json"
"${PYTHON}" - \
    "${STAGING}/aggregates/ptbxl/result_manifest.json" \
    "${STAGING}/aggregates/ptbxl_audit/result_manifest.json" \
    "${STAGING}/aggregates/auxiliary/manifest.json" \
    "${STAGING}/aggregates/promised_extensions/audit_manifest.json" \
    "${STAGING}/aggregates/noise_gate_extensions/audit_manifest.json" \
    "${STAGING}/aggregates/noise_shift_calibration_audit/manifest.json" \
    "${STAGING}/aggregates/promised_postprocess/completion_matrix.json" \
    "${STAGING}/aggregates/promised_postprocess/postprocess_results.json" \
    "${STAGING}/aggregates/promised_postprocess/manifest.json" \
    "${STAGING}/provenance/noise_gate_migration/migration_audit.json" \
    "${STAGING}/inventories/promised_postprocess_input_binding.json" \
    "${STAGING}/inventories/noise_shift_existing_audit_preflight.json" <<'PY'
import json
import hashlib
import sys
from pathlib import Path

(
    ptb_path, ptb_audit_path, auxiliary_path, extension_path,
    noise_gate_audit_path, noise_shift_audit_path,
    postprocess_completion_path, postprocess_results_path,
    postprocess_manifest_path, migration_audit_path,
    postprocess_binding_path, noise_shift_existing_preflight_path,
) = map(Path, sys.argv[1:])
ptb = json.loads(ptb_path.read_text(encoding="utf-8"))
ptb_audit = json.loads(ptb_audit_path.read_text(encoding="utf-8"))
auxiliary = json.loads(auxiliary_path.read_text(encoding="utf-8"))
extension = json.loads(extension_path.read_text(encoding="utf-8"))
noise_gate_audit = json.loads(noise_gate_audit_path.read_text(encoding="utf-8"))
noise_shift_audit = json.loads(noise_shift_audit_path.read_text(encoding="utf-8"))
postprocess_completion = json.loads(postprocess_completion_path.read_text(encoding="utf-8"))
postprocess_results = json.loads(postprocess_results_path.read_text(encoding="utf-8"))
postprocess_manifest = json.loads(postprocess_manifest_path.read_text(encoding="utf-8"))
migration_audit = json.loads(migration_audit_path.read_text(encoding="utf-8"))
postprocess_binding = json.loads(postprocess_binding_path.read_text(encoding="utf-8"))
noise_shift_existing_preflight = json.loads(noise_shift_existing_preflight_path.read_text(encoding="utf-8"))
if ptb.get("summary", {}).get("complete") is not True:
    raise SystemExit("PTB aggregate manifest is not complete")
if ptb_audit.get("summary", {}).get("complete") is not True:
    raise SystemExit("PTB audit-only manifest is not complete")
completion = auxiliary.get("completion", {})
if completion.get("complete") is not True:
    raise SystemExit("auxiliary aggregate manifest is not complete")
if completion.get("wearable_valid") != 345 or completion.get("noise_valid") != 3:
    raise SystemExit(f"unexpected auxiliary valid counts: {completion}")
if extension.get("complete") is not True or extension.get("issue_count") != 0:
    raise SystemExit("promised extension strict audit is incomplete")
if extension.get("expected_record_count") != 221 or extension.get("loaded_record_count") != 221:
    raise SystemExit("promised extension strict audit has wrong record count")
if extension.get("task_log_count") != 66:
    raise SystemExit("promised extension strict audit has wrong task-log count")
if noise_gate_audit.get("complete") is not True or noise_gate_audit.get("issue_count") != 0:
    raise SystemExit("noise-gate extension strict audit is incomplete")
if noise_gate_audit.get("observed_valid_cells") != 9:
    raise SystemExit("noise-gate extension strict audit has wrong valid-cell count")
if noise_shift_audit.get("complete") is not True or noise_shift_audit.get("issue_count") != 0:
    raise SystemExit("fresh noise-shift strict audit is incomplete")
noise_shift_observed = noise_shift_audit.get("observed", {})
if noise_shift_observed.get("result_pairs") != 3:
    raise SystemExit("fresh noise-shift strict audit has wrong result-pair count")
if noise_shift_observed.get("valid_seeds") != [7, 13, 42]:
    raise SystemExit("fresh noise-shift strict audit has wrong valid seeds")
if noise_shift_observed.get("metric_rows") != 252:
    raise SystemExit("fresh noise-shift strict audit has wrong metric-row count")
if noise_shift_existing_preflight.get("complete") is not True or noise_shift_existing_preflight.get("issue_count") != 0:
    raise SystemExit("existing noise-shift audit preflight is incomplete")
if postprocess_completion.get("complete") is not True:
    raise SystemExit("promised postprocess completion matrix is incomplete")
if postprocess_results.get("audit", {}).get("complete") is not True:
    raise SystemExit("promised postprocess results audit is incomplete")
if migration_audit.get("complete") is not True or migration_audit.get("issue_count") != 0:
    raise SystemExit("noise-gate migration audit is incomplete")
if migration_audit.get("pair_count") != 9:
    raise SystemExit("noise-gate migration audit has wrong pair count")
if migration_audit.get("presanitize_source_file_count") != 18:
    raise SystemExit("noise-gate migration audit has wrong source-file count")
if postprocess_binding.get("complete") is not True or postprocess_binding.get("issue_count") != 0:
    raise SystemExit("promised postprocess current-input binding is incomplete")
if postprocess_binding.get("input_count") != 1332:
    raise SystemExit("promised postprocess current-input binding has wrong input count")

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

postprocess_root = postprocess_manifest_path.parent
for declaration in postprocess_manifest.get("outputs", []):
    source_name = Path(str(declaration.get("path", ""))).name
    frozen = postprocess_root / source_name
    if not frozen.is_file():
        raise SystemExit(f"promised postprocess declared output is absent: {source_name}")
    if frozen.stat().st_size != declaration.get("bytes"):
        raise SystemExit(f"promised postprocess size mismatch: {source_name}")
    if sha256(frozen) != declaration.get("sha256"):
        raise SystemExit(f"promised postprocess SHA256 mismatch: {source_name}")
PY

# Freeze current source text only.  Generated __pycache__ and caches are not
# admitted to `code/`; separately labelled smoke artefacts are frozen later
# under `smoke/`.  Exact wearable preprocessing keeps its relative layout.
while IFS= read -r -d '' source; do
  cp -p -- "${source}" "${STAGING}/code/$(basename "${source}")"
done < <(find "${EXPERIMENT_DIR}" -maxdepth 1 -type f \
  \( -name '*.py' -o -name '*.sh' -o -name 'README.md' \) -print0 | sort -z)

if [[ -d "${EXPERIMENT_DIR}/wearable_preprocessing" ]]; then
  while IFS= read -r -d '' source; do
    relative="${source#"${EXPERIMENT_DIR}"/}"
    mkdir -p "${STAGING}/code/$(dirname "${relative}")"
    cp -p -- "${source}" "${STAGING}/code/${relative}"
  done < <(find "${EXPERIMENT_DIR}/wearable_preprocessing" -type f \
    \( -name '*.py' -o -name '*.md' -o -name '*.txt' \) -print0 | sort -z)
else
  die "exact wearable_preprocessing source tree is absent"
fi

# Preserve JSON label/split/data manifests, never feature arrays or waveforms.
shopt -s nullglob
for source in "${CACHE_DIR}"/*.json; do
  cp -p -- "${source}" "${STAGING}/configs/cache_manifests/$(basename "${source}")"
done
shopt -u nullglob

# Snapshot formal results, disjoint extension results, inference-only shift
# calibration and both checkpoint families.  `freeze_tree` follows source
# symlinks, uses hard links only on the same filesystem, and always performs a
# fresh source-versus-bundle SHA256 comparison.
freeze_tree formal_ptbxl_results "${PTB_RESULTS}" \
  "${STAGING}/results/formal/ptbxl"
freeze_tree formal_wearable_results "${WEARABLE_RESULTS}" \
  "${STAGING}/results/formal/wearables"
for wearable_manifest_contract in \
    "mhealth:${EXPECTED_MHEALTH_DATA_MANIFEST_SHA256}" \
    "wesad:${EXPECTED_WESAD_DATA_MANIFEST_SHA256}"; do
  wearable_dataset="${wearable_manifest_contract%%:*}"
  expected_hash="${wearable_manifest_contract#*:}"
  wearable_manifest="${STAGING}/results/formal/wearables/${wearable_dataset}/data_manifest.json"
  [[ -f "${wearable_manifest}" && -s "${wearable_manifest}" && ! -L "${wearable_manifest}" ]] || \
    die "frozen wearable data manifest is absent, empty, or a symlink: ${wearable_manifest}"
  observed_hash="$(sha256sum -- "${wearable_manifest}")"
  observed_hash="${observed_hash%% *}"
  [[ "${observed_hash}" == "${expected_hash}" ]] || \
    die "frozen wearable data manifest SHA mismatch for ${wearable_dataset}: expected ${expected_hash}, observed ${observed_hash}"
done
freeze_tree formal_noise_sqi_results "${NOISE_RESULTS}" \
  "${STAGING}/results/formal/noise_sqi"
freeze_tree extension_ptbxl_results "${PTB_EXTENSION_RESULTS}" \
  "${STAGING}/results/extensions/ptbxl_missing"
freeze_tree extension_noise_gate_results "${NOISE_GATE_RESULTS}" \
  "${STAGING}/results/extensions/noise_gate"
freeze_tree noise_shift_calibration_results "${NOISE_SHIFT_RESULTS}" \
  "${STAGING}/results/extensions/noise_shift_calibration"
freeze_tree noise_shift_existing_strict_audit "${NOISE_SHIFT_AUDIT_ROOT}" \
  "${STAGING}/aggregates/noise_shift_calibration_audit_existing"
freeze_tree modular_pipeline_results "${MODULAR_RESULTS}" \
  "${STAGING}/results/extensions/modular_pipeline"
freeze_tree modular_pipeline_audit "${MODULAR_AUDIT_ROOT}" \
  "${STAGING}/aggregates/modular_pipeline_audit"
freeze_tree formal_noise_sqi_checkpoints "${NOISE_CHECKPOINT_ROOT}" \
  "${STAGING}/checkpoints/noise_sqi"
freeze_tree extension_noise_gate_checkpoints "${NOISE_GATE_CHECKPOINT_ROOT}" \
  "${STAGING}/checkpoints/noise_gate"

# Smoke output is evidence that the remote execution and both auditors were
# exercised, but is explicitly separated and never counted as paper results.
# Only allowlisted text metadata is distributed; smoke NPZ/checkpoints remain
# on the server and cannot introduce object arrays or raw payloads.
freeze_text_tree smoke_ptbxl_extension "${SMOKE_PTB_ROOT}" \
  "${STAGING}/smoke/ptbxl_extension"
freeze_text_tree smoke_noise_extension "${SMOKE_NOISE_ROOT}" \
  "${STAGING}/smoke/noise_extension"
freeze_text_tree smoke_noise_checkpoints "${SMOKE_NOISE_CHECKPOINT_ROOT}" \
  "${STAGING}/smoke/noise_checkpoints"
freeze_text_tree smoke_ptbxl_audit "${SMOKE_PTB_AUDIT_ROOT}" \
  "${STAGING}/smoke/ptbxl_audit"
freeze_text_tree smoke_auxiliary_audit "${SMOKE_AUX_AUDIT_ROOT}" \
  "${STAGING}/smoke/auxiliary_audit"

# The pre-migration object-NPZ files are deliberately not distributed.  Their
# source SHA/bytes list and the independent 9-pair migration audit were written
# above under provenance/noise_gate_migration; those are the complete portable
# migration record.

# Preserve the first memory-limited PTB attempt logs as historical provenance.
# Their exits are intentionally not part of formal completeness; only the
# current formal PTB log root passed the 25-exit completion gate above.
freeze_text_tree ptbxl_attempt1_log_provenance "${PTB_ATTEMPT1_LOG_DIR}" \
  "${STAGING}/provenance/ptbxl_attempt1_logs"

# Preserve both superseded modular runs as provenance without mixing either
# into the formal 5+3 result/audit contract.  Only named JSON manifests,
# summaries/audits, text logs and a SHA/bytes listing of every source file are
# portable; their prediction/checkpoint NPZ payloads stay on the server.
freeze_failed_attempt_provenance modular_early_code \
  "${MODULAR_EARLY_ROOT}" "${MODULAR_EARLY_LOG_DIR}"
freeze_failed_attempt_provenance modular_attempt2_missing_seed \
  "${MODULAR_ATTEMPT2_ROOT}" "${MODULAR_ATTEMPT2_LOG_DIR}"

# Copy every formal launcher log (including the original three matrices, the
# 221-fit extension, the nine gate runs, and named smoke logs), plus the
# /dev/shm shift-calibration, modular-pipeline and promised-postprocess records.
# A subsequent credential scan is a hard publication gate.
freeze_text_tree formal_logs "${LOG_ROOT}" "${STAGING}/logs/formal"
freeze_text_tree ptbxl_extension_logs "${PTB_EXTENSION_LOG_DIR}" \
  "${STAGING}/logs/ptbxl_extension"
freeze_text_tree noise_gate_logs "${NOISE_GATE_LOG_DIR}" \
  "${STAGING}/logs/noise_gate"
freeze_text_tree noise_shift_logs "${NOISE_SHIFT_LOG_DIR}" \
  "${STAGING}/logs/noise_shift"
# Re-validate the frozen copy so a concurrent source-log mutation between the
# preflight check and snapshot cannot enter the published bundle unnoticed.
check_noise_shift_completion "${STAGING}/logs/noise_shift"
freeze_text_tree modular_pipeline_logs "${MODULAR_LOG_DIR}" \
  "${STAGING}/logs/modular_pipeline"
cp -p -- "${MODULAR_ROOT_MARKER}" \
  "${STAGING}/logs/modular_pipeline/root_modular_pipeline.complete"
cmp -s -- "${MODULAR_ROOT_MARKER}" \
  "${STAGING}/logs/modular_pipeline/root_modular_pipeline.complete" || \
  die "modular root marker copy mismatch"
cp -p -- "${PROMISED_POSTPROCESS_LOG}" \
  "${STAGING}/logs/postprocess/$(basename "${PROMISED_POSTPROCESS_LOG}")"
cp -p -- "${PROMISED_POSTPROCESS_MARKER}" \
  "${STAGING}/logs/postprocess/$(basename "${PROMISED_POSTPROCESS_MARKER}")"
cmp -s -- "${PROMISED_POSTPROCESS_LOG}" \
  "${STAGING}/logs/postprocess/$(basename "${PROMISED_POSTPROCESS_LOG}")" || \
  die "promised postprocess log copy mismatch"
cmp -s -- "${PROMISED_POSTPROCESS_MARKER}" \
  "${STAGING}/logs/postprocess/$(basename "${PROMISED_POSTPROCESS_MARKER}")" || \
  die "promised postprocess marker copy mismatch"

# Hash the actual formal inputs in place but do not copy them.  Optional raw
# source archives are recorded when present; the training inputs and all 25
# subject caches are mandatory.
DATA_HASHES="${STAGING}/inventories/data_sha256.tsv"
printf 'domain\tsha256\tbytes\tabsolute_source_path\n' > "${DATA_HASHES}"
append_tree_hashes trustfed_cache "${TRUSTFED_CACHE}" "${DATA_HASHES}"
append_tree_hashes revision_sidecars "${CACHE_DIR}" "${DATA_HASHES}"

assert_count "MHEALTH per-subject cache" \
  "$(count_top_matching_files "${WEARABLE_DATA_ROOT}/mhealth" 'S*.npz')" 10
assert_count "WESAD per-subject cache" \
  "$(count_top_matching_files "${WEARABLE_DATA_ROOT}/wesad" 'S*.npz')" 15
while IFS= read -r -d '' source; do
  append_file_hash mhealth_subject_cache "${source}" "${DATA_HASHES}"
done < <(find "${WEARABLE_DATA_ROOT}/mhealth" -maxdepth 1 -type f -name 'S*.npz' -print0 | sort -z)
while IFS= read -r -d '' source; do
  append_file_hash wesad_subject_cache "${source}" "${DATA_HASHES}"
done < <(find "${WEARABLE_DATA_ROOT}/wesad" -maxdepth 1 -type f -name 'S*.npz' -print0 | sort -z)

OPTIONAL_DATA="${STAGING}/inventories/optional_data_availability.tsv"
printf 'status\tabsolute_source_path\n' > "${OPTIONAL_DATA}"
for source in \
    /root/autodl-tmp/Dataset/stress_raw/MHEALTH.zip \
    /root/autodl-tmp/Dataset/stress_raw/WESAD.zip; do
  if [[ -f "${source}" ]]; then
    append_file_hash official_source_archive "${source}" "${DATA_HASHES}"
    printf 'hashed\t%s\n' "${source}" >> "${OPTIONAL_DATA}"
  else
    printf 'not_present_optional\t%s\n' "${source}" >> "${OPTIONAL_DATA}"
  fi
done

hash_tree "${STAGING}/code" "${STAGING}/inventories/frozen_code_sha256.tsv"

# Close time-of-check/time-of-copy gaps using the later source inventories
# produced by freeze_tree.  This binds every postprocess manifest input to the
# exact copied formal file, and binds the pairwise migration proof to both the
# copied current gate tree and freshly re-hashed server-only backup bytes.
record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${STAGING}" "${PTB_RESULTS}" "${NOISE_RESULTS}" "${WEARABLE_RESULTS}" \
  "${NOISE_SHIFT_RESULTS}" "${PROMISED_POSTPROCESS_ROOT}" \
  "${NOISE_GATE_PRESANITIZE_ROOT}" \
  "${STAGING}/inventories/final_binding_recheck.json"
"${PYTHON}" - \
    "${STAGING}" "${PTB_RESULTS}" "${NOISE_RESULTS}" "${WEARABLE_RESULTS}" \
    "${NOISE_SHIFT_RESULTS}" "${PROMISED_POSTPROCESS_ROOT}" \
    "${NOISE_GATE_PRESANITIZE_ROOT}" \
    "${STAGING}/inventories/final_binding_recheck.json" <<'PY'
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

staging, ptb_root, noise_root, wearable_root, noise_shift_root, postprocess_root, backup_root, output = map(
    Path, sys.argv[1:]
)
staging = staging.resolve()
ptb_root, noise_root, wearable_root, noise_shift_root, postprocess_root, backup_root = (
    path.resolve() for path in (
        ptb_root, noise_root, wearable_root, noise_shift_root, postprocess_root, backup_root
    )
)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def read_inventory(name: str) -> dict[str, tuple[str, int]]:
    path = staging / "inventories" / name
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines or lines[0] != "sha256\tbytes\trelative_path":
        raise SystemExit(f"invalid inventory header: {path}")
    rows = {}
    for line in lines[1:]:
        digest, size, relative = line.split("\t", 2)
        if relative in rows:
            raise SystemExit(f"duplicate inventory path: {path}:{relative}")
        rows[relative] = (digest, int(size))
    return rows

formal = [
    (ptb_root, read_inventory("formal_ptbxl_results_source_sha256.tsv")),
    (noise_root, read_inventory("formal_noise_sqi_results_source_sha256.tsv")),
    (wearable_root, read_inventory("formal_wearable_results_source_sha256.tsv")),
]
postprocess_manifest_path = staging / "aggregates" / "promised_postprocess" / "manifest.json"
postprocess_manifest = json.loads(postprocess_manifest_path.read_text(encoding="utf-8"))
checked_inputs = 0
for declaration in postprocess_manifest.get("inputs", []):
    path = Path(str(declaration.get("path", ""))).resolve()
    match = None
    for root, inventory in formal:
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            continue
        match = inventory.get(relative)
        break
    if match is None:
        raise SystemExit(f"postprocess input is absent from later formal source inventory: {path}")
    if match != (declaration.get("sha256"), declaration.get("bytes")):
        raise SystemExit(f"postprocess input changed before formal snapshot: {path}")
    checked_inputs += 1
if checked_inputs != 1332:
    raise SystemExit(f"final postprocess binding expected 1332 inputs, observed {checked_inputs}")

code_inventory = read_inventory("frozen_code_sha256.tsv")
script_decl = postprocess_manifest.get("script", {})
script_name = Path(str(script_decl.get("path", ""))).name
if code_inventory.get(script_name) != (
    script_decl.get("sha256"), (staging / "code" / script_name).stat().st_size
):
    raise SystemExit("postprocess script changed before frozen-code snapshot")

noise_shift_inventory = read_inventory(
    "noise_shift_calibration_results_source_sha256.tsv"
)
fresh_shift_manifest_path = (
    staging / "aggregates" / "noise_shift_calibration_audit" / "manifest.json"
)
fresh_shift = json.loads(fresh_shift_manifest_path.read_text(encoding="utf-8"))
fresh_observed = fresh_shift.get("observed", {})
if fresh_shift.get("complete") is not True or fresh_shift.get("issue_count") != 0:
    raise SystemExit("fresh noise-shift audit is incomplete at final binding recheck")
if fresh_observed.get("valid_seeds") != [7, 13, 42] or fresh_observed.get("metric_rows") != 252:
    raise SystemExit("fresh noise-shift audit seed/metric contract changed")
fresh_rows = fresh_shift.get("results")
if not isinstance(fresh_rows, list) or len(fresh_rows) != 3:
    raise SystemExit("fresh noise-shift audit does not contain three result rows")
seen_shift_seeds = set()
for row in fresh_rows:
    seed = row.get("seed")
    if seed not in {7, 13, 42} or seed in seen_shift_seeds:
        raise SystemExit(f"fresh noise-shift audit duplicate/invalid seed: {seed}")
    seen_shift_seeds.add(seed)
    for role in ("json", "npz"):
        declaration = row.get(role, {})
        path = Path(str(declaration.get("path", ""))).resolve()
        try:
            relative = path.relative_to(noise_shift_root).as_posix()
        except ValueError as exc:
            raise SystemExit(f"fresh noise-shift {role} escapes current result root: {path}") from exc
        expected_relative = f"seed_{seed}.json" if role == "json" else f"seed_{seed}_calibration.npz"
        if relative != expected_relative:
            raise SystemExit(f"fresh noise-shift {role} path mismatch: {relative}")
        if noise_shift_inventory.get(relative) != (
            declaration.get("sha256"), declaration.get("bytes")
        ):
            raise SystemExit(f"noise-shift result changed before snapshot: {relative}")
        frozen_path = staging / "results" / "extensions" / "noise_shift_calibration" / relative
        if not frozen_path.is_file() or frozen_path.stat().st_size != declaration.get("bytes") or \
                sha256(frozen_path) != declaration.get("sha256"):
            raise SystemExit(f"frozen noise-shift result bytes/SHA mismatch: {relative}")
if seen_shift_seeds != {7, 13, 42}:
    raise SystemExit("fresh noise-shift audit seed set mismatch")

shift_source_manifest = fresh_shift.get("source_manifest", {})
if Path(str(shift_source_manifest.get("path", ""))).resolve() != noise_shift_root / "manifest.json":
    raise SystemExit("fresh noise-shift audit points to a different result manifest")
if noise_shift_inventory.get("manifest.json") is None or \
        noise_shift_inventory["manifest.json"][0] != shift_source_manifest.get("sha256"):
    raise SystemExit("noise-shift result manifest changed before snapshot")
frozen_shift_source_manifest = (
    staging / "results" / "extensions" / "noise_shift_calibration" / "manifest.json"
)
if sha256(frozen_shift_source_manifest) != shift_source_manifest.get("sha256"):
    raise SystemExit("frozen noise-shift result manifest SHA mismatch")
shift_auditor = fresh_shift.get("auditor", {})
shift_auditor_name = Path(str(shift_auditor.get("path", ""))).name
if code_inventory.get(shift_auditor_name) is None or \
        code_inventory[shift_auditor_name][0] != shift_auditor.get("sha256"):
    raise SystemExit("noise-shift auditor changed before frozen-code snapshot")
fresh_audit_root = fresh_shift_manifest_path.parent
for role, expected_rows in (("metrics", 252), ("issues", 0)):
    declaration = fresh_shift.get("csv", {}).get(role, {})
    path = Path(str(declaration.get("path", ""))).resolve()
    if path.parent != fresh_audit_root or declaration.get("rows") != expected_rows:
        raise SystemExit(f"fresh noise-shift {role} CSV path/row contract mismatch")
    if not path.is_file() or path.stat().st_size != declaration.get("bytes") or \
            sha256(path) != declaration.get("sha256"):
        raise SystemExit(f"fresh noise-shift {role} CSV bytes/SHA mismatch")

existing_shift_preflight = json.loads(
    (staging / "inventories" / "noise_shift_existing_audit_preflight.json").read_text(
        encoding="utf-8"
    )
)
existing_shift_inventory = read_inventory(
    "noise_shift_existing_strict_audit_source_sha256.tsv"
)
if existing_shift_inventory.get("manifest.json") is None or \
        existing_shift_inventory["manifest.json"][0] != existing_shift_preflight.get("existing_manifest_sha256"):
    raise SystemExit("existing noise-shift audit changed before its frozen snapshot")
existing_frozen_root = staging / "aggregates" / "noise_shift_calibration_audit_existing"
for relative, (digest, size) in existing_shift_inventory.items():
    path = existing_frozen_root / relative
    if not path.is_file() or path.stat().st_size != size or sha256(path) != digest:
        raise SystemExit(f"frozen existing noise-shift audit bytes/SHA mismatch: {relative}")
if code_inventory.get("audit_noise_shift_calibration.py") is None or \
        code_inventory["audit_noise_shift_calibration.py"][0] != existing_shift_preflight.get("auditor_sha256"):
    raise SystemExit("existing noise-shift audit is bound to a different frozen auditor")

migration_path = staging / "provenance" / "noise_gate_migration" / "migration_audit.json"
migration = json.loads(migration_path.read_text(encoding="utf-8"))
gate_inventory = read_inventory("extension_noise_gate_results_source_sha256.tsv")
if migration.get("complete") is not True or migration.get("pair_count") != 9:
    raise SystemExit("migration audit was not complete at final binding recheck")
migration_rows = migration.get("pairs")
if not isinstance(migration_rows, list) or len(migration_rows) != 9:
    raise SystemExit("migration audit pair rows are incomplete at final binding recheck")
for row in migration_rows:
    relative_json = row["relative_json"]
    relative_npz = row["relative_npz"]
    json_entry = gate_inventory.get(relative_json)
    npz_entry = gate_inventory.get(relative_npz)
    if json_entry is None or json_entry[0] != row.get("current_json_sha256"):
        raise SystemExit(f"current gate JSON changed before snapshot: {relative_json}")
    if npz_entry is None or npz_entry[0] != row.get("target_npz_sha256"):
        raise SystemExit(f"current gate NPZ changed before snapshot: {relative_npz}")
    backup_json = backup_root / relative_json
    backup_npz = backup_root / relative_npz
    if sha256(backup_json) != row.get("backup_json_sha256"):
        raise SystemExit(f"presanitize JSON changed after migration audit: {relative_json}")
    if sha256(backup_npz) != row.get("source_npz_sha256"):
        raise SystemExit(f"presanitize NPZ changed after migration audit: {relative_npz}")

sanitizer = migration.get("sanitizer", {})
sanitizer_name = sanitizer.get("filename")
if code_inventory.get(sanitizer_name) is None or code_inventory[sanitizer_name][0] != sanitizer.get("sha256"):
    raise SystemExit("noise-gate sanitizer changed before frozen-code snapshot")

payload = {
    "schema": "paper46-final-binding-recheck-v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "issue_count": 0,
    "postprocess_inputs_bound_to_later_formal_source_and_bundle_inventories": checked_inputs,
    "noise_gate_migration_pairs_bound_to_later_snapshot_and_rehashed_backup": 9,
    "noise_shift_fresh_audit_pairs_bound_to_later_result_snapshot": 3,
    "noise_shift_fresh_audit_metric_rows": 252,
    "noise_shift_existing_audit_bound_to_frozen_copy": True,
    "postprocess_manifest_sha256": sha256(postprocess_manifest_path),
    "migration_audit_sha256": sha256(migration_path),
}
output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

# Capture the environment without dumping process variables, shell history, or
# authentication stores.
run_logged "${COMMAND_RECORD}" "${STAGING}/environment/pip_freeze.txt" \
  "${PYTHON}" -m pip freeze --all
run_logged "${COMMAND_RECORD}" "${STAGING}/environment/conda_list_explicit.txt" \
  "${CONDA_BIN}" list --explicit --prefix "$(dirname "$(dirname "${PYTHON}")")"
run_logged "${COMMAND_RECORD}" "${STAGING}/environment/conda_list.json" \
  "${CONDA_BIN}" list --json --prefix "$(dirname "$(dirname "${PYTHON}")")"
record_command "${COMMAND_RECORD}" "${CONDA_BIN}" env export \
  --prefix "$(dirname "$(dirname "${PYTHON}")")"
# `conda env export` may emit user-configured environment variables.  Stream
# the canonical export through a root-level YAML-section filter so dependency
# provenance is retained without ever writing those variable values to disk.
"${CONDA_BIN}" env export --prefix "$(dirname "$(dirname "${PYTHON}")")" \
    2> "${STAGING}/logs/finalization/conda_export_stderr.log" | \
  awk '
    /^variables:[[:space:]]*$/ {
      skipping_variables = 1
      print "# conda environment variables intentionally omitted by security policy"
      next
    }
    skipping_variables && /^[^[:space:]#]/ { skipping_variables = 0 }
    !skipping_variables { print }
  ' > "${STAGING}/environment/conda_environment.yml"
printf 'Package/dependency export retained; conda environment variables were intentionally omitted.\n' \
  > "${STAGING}/environment/conda_variables_policy.txt"
record_command "${COMMAND_RECORD}" nvidia-smi
nvidia-smi > "${STAGING}/environment/nvidia-smi.txt"
record_command "${COMMAND_RECORD}" nvidia-smi -q
nvidia-smi -q > "${STAGING}/environment/nvidia-smi-query.txt"
record_command "${COMMAND_RECORD}" uname -a
uname -a > "${STAGING}/environment/uname.txt"
if command -v lscpu >/dev/null 2>&1; then
  record_command "${COMMAND_RECORD}" lscpu
  lscpu > "${STAGING}/environment/lscpu.txt"
fi
if command -v free >/dev/null 2>&1; then
  record_command "${COMMAND_RECORD}" free -h
  free -h > "${STAGING}/environment/memory.txt"
fi
if command -v df >/dev/null 2>&1; then
  record_command "${COMMAND_RECORD}" df -h
  df -h > "${STAGING}/environment/filesystems.txt"
fi
if [[ -f /etc/os-release ]]; then
  cp -p -- /etc/os-release "${STAGING}/environment/os-release.txt"
fi
if command -v nvcc >/dev/null 2>&1; then
  record_command "${COMMAND_RECORD}" nvcc --version
  nvcc --version > "${STAGING}/environment/nvcc-version.txt" 2>&1
else
  printf 'nvcc executable not present; PyTorch CUDA runtime is recorded separately.\n' \
    > "${STAGING}/environment/nvcc-not-present.txt"
fi
record_command "${COMMAND_RECORD}" "${PYTHON}" - \
  "${STAGING}/environment/python_runtime.json"
"${PYTHON}" - "${STAGING}/environment/python_runtime.json" <<'PY'
import importlib
import json
import platform
import sys
from pathlib import Path

packages = {}
for name in ("numpy", "scipy", "sklearn", "pandas", "torch"):
    try:
        module = importlib.import_module(name)
        packages[name] = getattr(module, "__version__", "unknown")
    except Exception as exc:
        packages[name] = f"unavailable:{type(exc).__name__}"
payload = {
    "python": sys.version,
    "executable": sys.executable,
    "implementation": platform.python_implementation(),
    "platform": platform.platform(),
    "machine": platform.machine(),
    "processor": platform.processor(),
    "packages": packages,
}
try:
    import torch
    payload["torch_runtime"] = {
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "device_count": torch.cuda.device_count(),
        "devices": [torch.cuda.get_device_name(index) for index in range(torch.cuda.device_count())],
    }
except Exception as exc:
    payload["torch_runtime"] = {"error": f"{type(exc).__name__}: {exc}"}
Path(sys.argv[1]).write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
PY
{
  printf 'captured_at='; date --iso-8601=seconds
  printf 'python='; "${PYTHON}" --version 2>&1
  printf 'python_executable=%s\n' "${PYTHON}"
  printf 'hostname='; hostname
  printf 'ptb_results_link=%s\n' "${PTB_RESULTS}"
  printf 'ptb_results_resolved=%s\n' "$(readlink -f "${PTB_RESULTS}")"
} > "${STAGING}/environment/runtime_identity.txt"

cat > "${STAGING}/README.md" <<'EOF'
# Paper46 frozen AutoDL reproducibility snapshot

This is a private, file-hashed snapshot of the completed revision experiments.
It contains frozen source code and wearable preprocessing, all formal and
reviewer-prompted result artefacts, actual noise-model checkpoints, strict
aggregate/audit outputs, text-only smoke evidence, allowlisted launcher logs, configurations,
and complete software/hardware provenance.

Publication was gated on all of the following disjoint contracts:

* frozen formal matrices: 212 PTB result triplets, 345 wearable result pairs,
  and three canonical noise/SQI result pairs, with 25/75/3 zero-valued task
  exits and fresh completion markers;
* reviewer-prompted fits: 221 PTB extension triplets in exactly 49 groups,
  with 66 zero-valued task exits, plus nine noise-gate result/checkpoint pairs
  with nine zero-valued exits;
* inference-only noise-shift calibration: three seed JSON/NPZ pairs, three
  zero-valued exits, a fresh completion marker and `manifest.complete=true`;
  the existing strict audit is authenticated and frozen, then the frozen
  auditor is re-run into staging with three valid seeds, zero issues and 252
  recomputed metric rows, and finally bound to the copied result/code hashes;
* inference-only modular Softmax+SQI+Mahalanobis pipeline: five PTB and three
  noise seed pairs, eight zero-valued worker exits, root/log/audit completion
  markers, and an independent zero-error strict audit;
* strict formal PTB and auxiliary aggregates, the independent 221-fit
  extension audit/aggregate with zero issues, and the complete promised-metric
  postprocess (rare thresholds, selectivity, paired OOD tests and alarm burden),
  byte-bound to all 1,332 current formal inputs and rechecked against the later
  source/bundle snapshot inventories.

The safely migrated noise-gate tree is the only formal gate input and passed
the independent object-free strict audit.  The nine pre-migration object-NPZ
files are never distributed: `provenance/noise_gate_migration/` contains only
their SHA/bytes source list and an independent pairwise migration manifest
proving the sole array change was `test_record_id` object strings to fixed
Unicode.  The first memory-limited PTB attempt logs are also retained there
and never enter formal completion or any estimate.

Two superseded modular attempts are recorded only under provenance: an early-
code run and a final-code run missing the required `N.set_seed` argument.  For
each, the bundle keeps allowlisted textual logs/named manifests plus a SHA/bytes
listing of source files, but no failed-attempt arrays or checkpoints.  Neither
attempt is part of the formal 5-PTB + 3-noise completion contract.

Smoke trees are preserved under `smoke/` only as allowlisted text metadata for
execution-chain evidence.  Their NPZ/checkpoint payloads remain server-side;
smoke is explicitly non-formal and is not included in any paper estimate.

It contains no object-bearing NPZ member (including structured object fields),
PTB-XL, Chapman, MHEALTH or WESAD
waveform, raw dataset ZIP/archive/pickle, SSH credential, token, private key,
or shell environment/history.
Files named `*_raw.npz` under PTB result trees are raw *prediction records* used
for patient-cluster statistics, not ECG waveforms.  Prediction artefacts can
contain labels and patient/subject identifiers and must remain private unless
source-data licences and de-identification rules permit redistribution.

The top-level layout is:

```text
code/          frozen runners, aggregators and exact wearable preprocessing
configs/       generated PTB expected-config and cache JSON manifests
results/       formal 212/345/3 plus PTB/gate/shift/modular artefacts
checkpoints/   copied formal noise/SQI and extension gate checkpoints
aggregates/    strict formal, extension, gate, modular and postprocess outputs
smoke/         text-only, separately labelled non-formal evidence
logs/          all commands/logs/exits/markers and finalisation logs
provenance/    migration SHA/manifest and text/SHA failed-attempt evidence
environment/   pip/conda/Python/CUDA/GPU/CPU/OS/filesystem capture
inventories/   source/bundle/data/code SHA256 tables and preflight report
```

`SHA256SUMS` authenticates every regular bundle file except itself.  Each copied
result, checkpoint and postprocess tree has a source inventory and a fresh
bundle inventory which had to compare byte-for-byte.  Logs/smoke use a strict
text-only subset inventory plus SHA/bytes lists for omitted files; failed attempts additionally receive full source
SHA/bytes lists without copying binary payloads.  `MANIFEST.json` and
`BUNDLE_COMPLETE` are written only after every formal exit/marker/count,
strict audit, aggregate, declared artefact hash, source-copy comparison and
embedded-secret scan succeeds.

The stable server path `/root/Paper46_revision/reproducibility_bundle` may be a
symbolic link to this versioned snapshot in `/dev/shm`.  When PTB files are
hard-linked, the completed formal source must remain unwritten.  Copy the
snapshot to durable local
storage immediately with a link-following transfer (for example, `rsync -aL`).
After copying, run `sha256sum -c SHA256SUMS` from the bundle root.

This finalizer never trains a model, modifies a result, deletes a prior bundle,
or shuts down the server.  Server shutdown remains a manual user action.
EOF

# Enforce the portable distribution allowlist after all source snapshots are
# present.  Results/checkpoints may contain only JSON and contract-named NPZ;
# logs/smoke/provenance are text-only.  Every admitted NPZ is inspected through
# its NPY header and `dtype.hasobject` is a hard error (including structured
# dtypes with an object field).  Raw-waveform member names,
# raw-data filenames, nested archives and pickle payloads are also rejected.
record_command "${COMMAND_RECORD}" "${PYTHON}" - "${STAGING}" \
  "${STAGING}/inventories/distribution_safety_audit.json"
"${PYTHON}" - "${STAGING}" \
    "${STAGING}/inventories/distribution_safety_audit.json" <<'PY'
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
archive_suffixes = {
    ".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".7z", ".rar",
    ".pickle", ".pkl", ".joblib", ".pt", ".pth", ".ckpt", ".npy",
}
text_suffixes = {
    ".json", ".csv", ".tsv", ".txt", ".tex", ".log", ".out",
    ".exit", ".complete",
}
result_npz_name = re.compile(
    r"seed_[0-9]+_(raw|ood_scores|predictions|curves|calibration|arrays)\.npz$"
)
checkpoint_npz_name = re.compile(r"seed_[0-9]+\.npz$")
seed_json_name = re.compile(r"seed_[0-9]+\.json$")
wearable_data_manifests = {
    Path("results/formal/wearables/mhealth/data_manifest.json"),
    Path("results/formal/wearables/wesad/data_manifest.json"),
}
raw_member = re.compile(
    r"^((train|val|valid|test)[_-]?)?(raw[_-]?)?(ecg[_-]?)?(signals?|waveforms?)$",
    re.IGNORECASE,
)
raw_filename = re.compile(
    r"(^|[_-])(ptbxl|chapman|mhealth|wesad)?[_-]?(signals?|waveforms?|raw[_-]?ecg)($|[_-])",
    re.IGNORECASE,
)

npz_count = 0
array_count = 0
category_counts = {}
for path in sorted(item for item in root.rglob("*") if item.is_file()):
    relative = path.relative_to(root)
    parts = relative.parts
    top = parts[0] if parts else ""
    suffix = path.suffix.lower()
    category_counts[top] = category_counts.get(top, 0) + 1

    if suffix in archive_suffixes:
        raise SystemExit(f"prohibited archive/pickle/raw-array file in bundle: {relative}")
    if top in {"results", "checkpoints", "smoke", "provenance"} and \
            raw_filename.search(path.stem) and not path.name.endswith("_raw.npz"):
        raise SystemExit(f"raw-waveform-like filename in bundle: {relative}")

    if top == "results":
        if suffix == ".json":
            if not (seed_json_name.fullmatch(path.name) or path.name in {
                "manifest.json", "summary.json", "sanitization_manifest.json"
            } or relative in wearable_data_manifests):
                raise SystemExit(f"non-allowlisted result JSON: {relative}")
        elif suffix == ".npz":
            if result_npz_name.fullmatch(path.name) is None:
                raise SystemExit(f"non-contract result NPZ: {relative}")
        else:
            raise SystemExit(f"non-allowlisted result file: {relative}")
    elif top == "checkpoints":
        if suffix == ".json":
            if seed_json_name.fullmatch(path.name) is None and path.name not in {
                "manifest.json", "summary.json"
            }:
                raise SystemExit(f"non-contract checkpoint JSON: {relative}")
        elif suffix == ".npz":
            if checkpoint_npz_name.fullmatch(path.name) is None:
                raise SystemExit(f"non-contract checkpoint NPZ: {relative}")
        else:
            raise SystemExit(f"non-allowlisted checkpoint file: {relative}")
    elif top in {"logs", "smoke", "provenance"}:
        command_record = Path("logs/finalization/commands_executed.sh")
        if suffix not in text_suffixes and relative != command_record:
            raise SystemExit(f"non-text {top} file entered distribution: {relative}")
        if top == "provenance" and suffix == ".npz":
            raise SystemExit(f"NPZ is forbidden in portable provenance: {relative}")

    if suffix != ".npz":
        continue
    npz_count += 1
    try:
        with zipfile.ZipFile(path, "r") as archive:
            all_members = [info for info in archive.infolist() if not info.is_dir()]
            members = [info for info in all_members if info.filename.endswith(".npy")]
            if not members:
                raise SystemExit(f"NPZ has no NPY members: {relative}")
            if len(members) != len(all_members):
                raise SystemExit(f"NPZ contains a non-NPY member: {relative}")
            member_names = [info.filename for info in members]
            if len(member_names) != len(set(member_names)):
                raise SystemExit(f"NPZ contains duplicate member names: {relative}")
            for info in members:
                key = info.filename[:-4]
                if raw_member.search(key):
                    raise SystemExit(f"raw-waveform-like NPZ member {key!r}: {relative}")
                with archive.open(info, "r") as handle:
                    version = np.lib.format.read_magic(handle)
                    if version == (1, 0):
                        shape, fortran, dtype = np.lib.format.read_array_header_1_0(handle)
                    elif version in ((2, 0), (3, 0)):
                        shape, fortran, dtype = np.lib.format.read_array_header_2_0(handle)
                    else:
                        raise SystemExit(f"unsupported NPY version {version}: {relative}:{key}")
                if np.dtype(dtype).hasobject:
                    raise SystemExit(f"object-dtype NPZ member is forbidden: {relative}:{key}")
                array_count += 1
    except zipfile.BadZipFile as exc:
        raise SystemExit(f"invalid NPZ container {relative}: {exc}") from exc

presanitize_portable = root / "provenance" / "noise_gate_migration"
if not (presanitize_portable / "migration_audit.json").is_file():
    raise SystemExit("portable noise-gate migration audit is absent")
if not (presanitize_portable / "presanitize_source_sha256.tsv").is_file():
    raise SystemExit("portable presanitize source SHA list is absent")
if any(path.suffix.lower() == ".npz" for path in (root / "provenance").rglob("*")):
    raise SystemExit("an NPZ entered provenance")

payload = {
    "schema": "paper46-distribution-safety-audit-v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "complete": True,
    "issue_count": 0,
    "npz_files_header_audited": npz_count,
    "npz_array_headers_audited": array_count,
    "top_level_file_counts_before_this_audit": category_counts,
    "contracts": {
        "results_and_checkpoints_filename_allowlist": True,
        "logs_smoke_provenance_text_only": True,
        "object_dtype_arrays_absent": True,
        "structured_dtype_object_fields_absent": True,
        "raw_waveforms_and_source_archives_absent": True,
        "presanitize_object_npz_distributed": False,
    },
}
output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

# Search text files for common embedded-secret forms.  Pattern fragments are
# split here so the scanner does not match its own source code.
credential_pattern='BEGIN [A-Z ]*PRIVATE'' KEY|pass''word[[:space:]_-]*:[[:space:]]*|pass''word[[:space:]_-]*=[^=]|pass''wd[[:space:]_-]*:[[:space:]]*|pass''wd[[:space:]_-]*=[^=]|pass''phrase[[:space:]_-]*:[[:space:]]*|api[_-]?key[[:space:]]*[:=]|access[_-]?to''ken[[:space:]]*[:=]|client[_-]?se''cret[[:space:]]*[:=]|[?&]to''ken=|[?&]api[_-]?key=|authorization:[[:space:]]*(bearer|basic)|https?://[^/@[:space:]]+:[^/@[:space:]]+@'
set +e
grep -IRIlEi "${credential_pattern}" "${STAGING}" \
  > "${STAGING}/logs/finalization/credential_scan_hits.txt"
credential_scan_status=$?
set -e
if (( credential_scan_status == 0 )); then
  die "potential credential material detected; inspect credential_scan_hits.txt"
elif (( credential_scan_status != 1 )); then
  die "credential scan could not be completed (grep exit ${credential_scan_status})"
fi
printf 'No common embedded-secret pattern was detected in bundle text files.\n' \
  > "${STAGING}/logs/finalization/credential_scan_passed.txt"

cat > "${STAGING}/BUNDLE_COMPLETE" <<EOF
status=complete
created_at=$(date --iso-8601=seconds)
ptbxl_results=${EXPECTED_PTB_RESULTS}
wearable_results=${EXPECTED_WEARABLE_RESULTS}
noise_sqi_results=${EXPECTED_NOISE_RESULTS}
ptbxl_extension_results=${EXPECTED_PTB_EXTENSION_RESULTS}
noise_gate_results=${EXPECTED_NOISE_GATE_RESULTS}
noise_shift_calibration_results=${EXPECTED_NOISE_SHIFT_RESULTS}
noise_shift_strict_audit_metric_rows=252
modular_pipeline_results=${EXPECTED_MODULAR_RESULTS}
ptbxl_tasks=${EXPECTED_PTB_TASKS}
wearable_tasks=${EXPECTED_WEARABLE_TASKS}
noise_sqi_tasks=${EXPECTED_NOISE_TASKS}
ptbxl_extension_tasks=${EXPECTED_PTB_EXTENSION_TASKS}
noise_gate_tasks=${EXPECTED_NOISE_GATE_TASKS}
noise_shift_calibration_tasks=${EXPECTED_NOISE_SHIFT_TASKS}
modular_pipeline_tasks=${EXPECTED_MODULAR_TASKS}
formal_aggregates_complete=yes
promised_extension_audit_complete=yes
promised_postprocess_complete=yes
noise_gate_strict_audit_complete=yes
noise_shift_existing_strict_audit_complete=yes
noise_shift_fresh_staging_strict_audit_complete=yes
noise_shift_time_of_copy_binding_complete=yes
modular_pipeline_strict_audit_complete=yes
postprocess_current_input_binding_complete=yes
final_time_of_copy_binding_recheck_complete=yes
distribution_safety_audit_complete=yes
noise_gate_presanitize_object_npz_included=no
noise_gate_migration_manifest_and_source_sha_included=yes
ptbxl_attempt1_logs_included_provenance_only=yes
modular_early_code_included_provenance_only=yes
modular_attempt2_missing_seed_included_provenance_only=yes
checkpoints_included=yes
smoke_text_metadata_included_nonformal=yes
object_dtype_npz_included=no
structured_object_field_npz_included=no
raw_waveforms_included=no
credentials_included=no
server_shutdown_performed=no
EOF

record_command "${COMMAND_RECORD}" "${PYTHON}" - "${STAGING}" \
  "$(readlink -f "${PTB_RESULTS}")"
"${PYTHON}" - "${STAGING}" "$(readlink -f "${PTB_RESULTS}")" <<'PY'
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(sys.argv[1]).resolve()
ptb_source = sys.argv[2]

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def inventory_rows(name):
    path = root / "inventories" / name
    lines = path.read_text(encoding="utf-8").splitlines()
    return max(0, len(lines) - 1)

def table_rows(relative):
    lines = (root / relative).read_text(encoding="utf-8").splitlines()
    return max(0, len(lines) - 1)

files = [path for path in root.rglob("*") if path.is_file()]
manifest = {
    "schema": "paper46-reproducibility-bundle-v5",
    "status": "complete",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "canonical_server_link": "/root/Paper46_revision/reproducibility_bundle",
    "ptb_source_resolved_at_capture": ptb_source,
    "frozen_modular_source_sha256": {
        "evaluate_modular_pipeline.py": "015ccd9cd47b1b3d0343cd8e551eb3c3c974235578f71690112b7a4d8c448913",
        "audit_modular_pipeline.py": "1936a165808d96f3001f138a989bcdc98635916b251477c29b3214ae336ec503",
        "run_modular_pipeline_matrix.sh": "6c6754294b7684fab41e328ff29ee2c8140bdb0a4ac758699249eb0c5e3871f9",
    },
    "expected_counts": {
        "ptbxl_results": 212,
        "wearable_results": 345,
        "noise_sqi_results": 3,
        "ptbxl_extension_results": 221,
        "noise_gate_results": 9,
        "noise_shift_calibration_results": 3,
        "noise_shift_strict_audit_metric_rows": 252,
        "modular_pipeline_results": 8,
        "ptbxl_matrix_tasks": 25,
        "wearable_matrix_tasks": 75,
        "noise_sqi_tasks": 3,
        "ptbxl_extension_tasks": 66,
        "noise_gate_tasks": 9,
        "noise_shift_calibration_tasks": 3,
        "modular_pipeline_tasks": 8,
    },
    "strict_aggregates": {
        "ptbxl": "aggregates/ptbxl/result_manifest.json",
        "ptbxl_audit": "aggregates/ptbxl_audit/result_manifest.json",
        "auxiliary": "aggregates/auxiliary/manifest.json",
        "promised_extensions": "aggregates/promised_extensions/audit_manifest.json",
        "promised_postprocess": "aggregates/promised_postprocess/postprocess_results.json",
        "noise_gate_extensions": "aggregates/noise_gate_extensions/audit_manifest.json",
        "noise_shift_calibration": "aggregates/noise_shift_calibration_audit/manifest.json",
        "noise_shift_calibration_existing": "aggregates/noise_shift_calibration_audit_existing/manifest.json",
        "noise_shift_existing_preflight": "inventories/noise_shift_existing_audit_preflight.json",
        "modular_pipeline": "aggregates/modular_pipeline_audit/audit.json",
        "noise_gate_migration": "provenance/noise_gate_migration/migration_audit.json",
        "postprocess_input_binding": "inventories/promised_postprocess_input_binding.json",
        "final_time_of_copy_binding": "inventories/final_binding_recheck.json",
        "distribution_safety": "inventories/distribution_safety_audit.json",
    },
    "inventories": {
        "data_files_hashed": inventory_rows("data_sha256.tsv"),
        "frozen_code_files": inventory_rows("frozen_code_sha256.tsv"),
        "formal_ptbxl_result_files": inventory_rows("formal_ptbxl_results_bundle_sha256.tsv"),
        "formal_wearable_result_files": inventory_rows("formal_wearable_results_bundle_sha256.tsv"),
        "formal_noise_sqi_result_files": inventory_rows("formal_noise_sqi_results_bundle_sha256.tsv"),
        "extension_ptbxl_result_files": inventory_rows("extension_ptbxl_results_bundle_sha256.tsv"),
        "extension_noise_gate_result_files": inventory_rows("extension_noise_gate_results_bundle_sha256.tsv"),
        "noise_shift_calibration_files": inventory_rows("noise_shift_calibration_results_bundle_sha256.tsv"),
        "noise_shift_fresh_audit_files": inventory_rows("noise_shift_fresh_audit_sha256.tsv"),
        "noise_shift_existing_audit_files": inventory_rows("noise_shift_existing_strict_audit_bundle_sha256.tsv"),
        "modular_pipeline_result_files": inventory_rows("modular_pipeline_results_bundle_sha256.tsv"),
        "modular_pipeline_audit_files": inventory_rows("modular_pipeline_audit_bundle_sha256.tsv"),
        "formal_noise_sqi_checkpoint_files": inventory_rows("formal_noise_sqi_checkpoints_bundle_sha256.tsv"),
        "extension_noise_gate_checkpoint_files": inventory_rows("extension_noise_gate_checkpoints_bundle_sha256.tsv"),
        "promised_postprocess_files": inventory_rows("promised_postprocess_bundle_sha256.tsv"),
        "smoke_ptbxl_extension_files": inventory_rows("smoke_ptbxl_extension_bundle_sha256.tsv"),
        "smoke_noise_extension_files": inventory_rows("smoke_noise_extension_bundle_sha256.tsv"),
        "smoke_noise_checkpoint_files": inventory_rows("smoke_noise_checkpoints_bundle_sha256.tsv"),
        "smoke_ptbxl_audit_files": inventory_rows("smoke_ptbxl_audit_bundle_sha256.tsv"),
        "smoke_auxiliary_audit_files": inventory_rows("smoke_auxiliary_audit_bundle_sha256.tsv"),
        "formal_log_files": inventory_rows("formal_logs_bundle_sha256.tsv"),
        "ptbxl_extension_log_files": inventory_rows("ptbxl_extension_logs_bundle_sha256.tsv"),
        "noise_gate_log_files": inventory_rows("noise_gate_logs_bundle_sha256.tsv"),
        "noise_shift_log_files": inventory_rows("noise_shift_logs_bundle_sha256.tsv"),
        "modular_pipeline_log_files": inventory_rows("modular_pipeline_logs_bundle_sha256.tsv"),
        "noise_gate_presanitize_source_files_hashed_not_copied": table_rows("provenance/noise_gate_migration/presanitize_source_sha256.tsv"),
        "ptbxl_attempt1_provenance_log_files": inventory_rows("ptbxl_attempt1_log_provenance_bundle_sha256.tsv"),
        "modular_early_code_safe_provenance_files": inventory_rows("modular_early_code_bundle_sha256.tsv"),
        "modular_attempt2_safe_provenance_files": inventory_rows("modular_attempt2_missing_seed_bundle_sha256.tsv"),
    },
    "snapshot_before_manifest": {
        "regular_files": len(files),
        "bytes": sum(path.stat().st_size for path in files),
    },
    "security": {
        "raw_waveforms_or_source_archives_copied": False,
        "credentials_copied": False,
        "process_environment_or_shell_history_copied": False,
        "object_dtype_npz_copied": False,
        "structured_dtype_with_object_field_copied": False,
        "presanitize_object_npz_copied": False,
        "failed_modular_binary_payloads_copied": False,
        "prediction_identifiers_may_require_restricted_handling": True,
        "server_shutdown_performed": False,
    },
    "integrity": {
        "source_and_bundle_result_checkpoint_postprocess_inventories_compared": True,
        "logs_and_smoke_text_allowlist_inventories_compared": True,
        "all_formal_exit_codes_and_completion_markers_checked": True,
        "all_strict_audits_complete": True,
        "noise_gate_object_free_migration_strictly_audited": True,
        "noise_gate_migration_source_target_arrays_pairwise_verified": True,
        "promised_postprocess_bound_to_current_formal_input_hashes": True,
        "postprocess_and_migration_bindings_rechecked_at_snapshot_time": True,
        "noise_shift_existing_and_fresh_strict_audits_complete": True,
        "noise_shift_fresh_audit_bound_to_snapshot_result_and_code_hashes": True,
        "distribution_npz_headers_object_free": True,
        "modular_pipeline_three_completion_markers_checked": True,
        "ptbxl_attempt1_excluded_from_formal_completeness": True,
        "two_superseded_modular_attempts_excluded_from_formal_completeness": True,
        "sha256sums_excludes_itself": True,
        "manifest_self_sha256": None,
    },
}
temporary = root / ".MANIFEST.json.tmp"
temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
os.replace(temporary, root / "MANIFEST.json")
PY

# Generate the final all-files checksum only after every other bundle file is
# immutable.  SHA256SUMS intentionally cannot include its own hash.
printf 'The finaliser verified SHA256SUMS before atomic publication.\n' \
  > "${STAGING}/logs/finalization/sha256_verification.txt"
(
  cd "${STAGING}"
  find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  sha256sum -c SHA256SUMS >/dev/null
)

# The version directory has intentionally kept the same absolute path during
# aggregation, so absolute paths captured by aggregate manifests remain valid.
# It was unpublished staging until this point.  Atomically replace only the
# stable root-level symlink; never move the completed directory or delete a
# prior version.
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
PUBLISHED="${STAGING}"

LINK_TMP="${REVISION_ROOT}/.reproducibility_bundle.link.${STAMP}.$$"
ln -s -- "${PUBLISHED}" "${LINK_TMP}"
if [[ -L "${BUNDLE_LINK}" ]]; then
  mv -Tf -- "${LINK_TMP}" "${BUNDLE_LINK}"
elif [[ -e "${BUNDLE_LINK}" ]]; then
  PREVIOUS="${REVISION_ROOT}/reproducibility_bundle.previous.${STAMP}.$$"
  mv -- "${BUNDLE_LINK}" "${PREVIOUS}"
  if ! mv -T -- "${LINK_TMP}" "${BUNDLE_LINK}"; then
    mv -- "${PREVIOUS}" "${BUNDLE_LINK}" || true
    die "failed to publish bundle link; prior directory restoration was attempted"
  fi
else
  mv -T -- "${LINK_TMP}" "${BUNDLE_LINK}"
fi

[[ -s "${BUNDLE_LINK}/BUNDLE_COMPLETE" ]] || die "published bundle lacks BUNDLE_COMPLETE"
(
  cd "$(readlink -f "${BUNDLE_LINK}")"
  sha256sum -c SHA256SUMS >/dev/null
)
STAGING=""

printf 'FINAL_BUNDLE=%s\n' "${BUNDLE_LINK}"
printf 'REAL_BUNDLE=%s\n' "$(readlink -f "${BUNDLE_LINK}")"
printf 'STATUS=complete\n'
