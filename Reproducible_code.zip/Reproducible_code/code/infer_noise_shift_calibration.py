#!/usr/bin/env python3
"""Post-hoc calibration under paired acquisition noise, without retraining.

This is an inference-only companion to the frozen ``run_noise_sqi.py`` runner.
For each canonical seed it verifies and loads the existing ``trust_full``
checkpoint, recomputes every ECG-derived source on official PTB-XL fold 9 and
fold 10 at clean/24/18/12/6/0/-6 dB, and stores raw and temperature-scaled
logits/probabilities.  The single temperature is fitted on *clean fold 9 only*
and is then frozen for every fold and SNR.

No training API is called.  Existing noise-result JSON/NPZ files are used only
to authenticate the canonical run and recover the folds1-8-only HRV medians.
Waveforms are never written to the output.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence

import numpy as np
import scipy
import sklearn
import torch
from scipy import optimize
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

import data_adapter as D
import revisionlib as R
import run_noise_sqi as N


SCRIPT_VERSION = "paper46-noise-shift-calibration-v1"
SEEDS = (7, 13, 42)
SNRS: tuple[float | None, ...] = (None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0)
MODEL_NAME = "trust_full"
TEMPERATURE_BOUNDS = (0.05, 20.0)
TEMPERATURE_XATOL = 1e-8


class InferenceAuditError(RuntimeError):
    """Raised when a supposedly canonical input cannot be authenticated."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: str | Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(array)
    return hashlib.sha256(memoryview(contiguous).cast("B")).hexdigest()


def strict(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return strict(value.tolist())
    if isinstance(value, np.generic):
        return strict(value.item())
    if isinstance(value, torch.Tensor):
        return strict(value.detach().cpu().numpy())
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): strict(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict(item) for item in value]
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        strict(value), sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                strict(value), handle, indent=2, sort_keys=True, ensure_ascii=False,
                allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(path: Path, arrays: Mapping[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_object(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise InferenceAuditError(f"top-level JSON is not an object: {path}")
    return value


def parse_seeds(text: str) -> tuple[int, ...]:
    try:
        values = tuple(dict.fromkeys(int(item.strip()) for item in text.split(",") if item.strip()))
    except ValueError as exc:
        raise argparse.ArgumentTypeError("--seeds must be comma-separated integers") from exc
    if not values or any(value not in SEEDS for value in values):
        raise argparse.ArgumentTypeError(f"seeds must be selected from {SEEDS}")
    return values


def artifact(path: Path, role: str, known_sha256: str | None = None) -> dict[str, Any]:
    if not path.is_file():
        raise InferenceAuditError(f"missing {role}: {path}")
    return {
        "role": role, "path": str(path.resolve()), "bytes": path.stat().st_size,
        "sha256": known_sha256 if known_sha256 is not None else sha256_file(path),
    }


def locate_declared_artifact(payload: Mapping[str, Any], json_path: Path) -> Path:
    declaration = payload.get("raw_npz", {})
    declared = Path(str(declaration.get("path", "")))
    candidates = [declared]
    if declared.name:
        candidates.append(json_path.with_name(declared.name))
    candidates.append(json_path.with_name(f"{json_path.stem}_curves.npz"))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise InferenceAuditError(f"canonical raw curves are absent for {json_path}")


def validate_canonical_arguments(arguments: Mapping[str, Any], seed: int) -> None:
    expected = {
        "epochs": 40,
        "batch_size": 256,
        "eval_batch_size": 512,
        "feature_chunk_size": 256,
        "learning_rate": 1e-3,
        "rare_threshold": 50,
        "snrs": list(SNRS),
        "sqi_sensitivity": "both",
        "run_2x2": True,
        "retrain_sqi_configs": ["joint_minus20", "joint_plus20", "uniform", "psqi_only"],
        "q_min_percent": [5.0, 10.0, 20.0, 30.0],
        "seeds": list(SEEDS),
        "smoke": False,
    }
    for key, wanted in expected.items():
        actual = arguments.get(key)
        if strict(actual) != strict(wanted):
            raise InferenceAuditError(
                f"canonical argument mismatch for seed={seed}: {key}={actual!r}, expected {wanted!r}"
            )
    if any(arguments.get(key) is not None for key in ("limit_train", "limit_val", "limit_test")):
        raise InferenceAuditError(f"canonical seed={seed} contains a split limit")


def authenticate_seed(
    seed: int, args: argparse.Namespace, protocol: Mapping[str, Any], device: torch.device,
) -> tuple[torch.nn.Module, np.ndarray, dict[str, Any], list[dict[str, Any]]]:
    result_json = args.canonical_results_root / f"seed_{seed}.json"
    result = load_object(result_json)
    if result.get("status") != "complete" or result.get("canonical") is not True:
        raise InferenceAuditError(f"noise result is incomplete/noncanonical: {result_json}")
    if int(result.get("seed", -1)) != seed or result.get("full_fold_run") is not True:
        raise InferenceAuditError(f"noise result seed/split mismatch: {result_json}")
    arguments = result.get("environment", {}).get("arguments", {})
    if not isinstance(arguments, Mapping):
        raise InferenceAuditError(f"noise result arguments are absent: {result_json}")
    validate_canonical_arguments(arguments, seed)

    original_args = argparse.Namespace(**dict(arguments))
    original_args.cache_dir = str(args.cache_dir)
    original_args.trustfed_cache = str(args.trustfed_cache)
    qconfigs = N.quality_configs()
    configs = N.model_configs(original_args, qconfigs)
    recomputed_run_payload = N.run_fingerprint_payload(original_args, seed, protocol, configs)
    if N.fingerprint(recomputed_run_payload) != result.get("run_fingerprint"):
        raise InferenceAuditError(f"canonical run fingerprint mismatch: {result_json}")

    raw_curves = locate_declared_artifact(result, result_json)
    if sha256_file(raw_curves) != result.get("raw_npz", {}).get("sha256"):
        raise InferenceAuditError(f"canonical raw-curve checksum mismatch: {raw_curves}")

    checkpoint_json = args.checkpoint_root / MODEL_NAME / f"seed_{seed}.json"
    checkpoint_npz = args.checkpoint_root / MODEL_NAME / f"seed_{seed}.npz"
    checkpoint = load_object(checkpoint_json)
    if checkpoint.get("status") != "complete" or int(checkpoint.get("seed", -1)) != seed:
        raise InferenceAuditError(f"checkpoint is incomplete/wrong seed: {checkpoint_json}")
    if checkpoint.get("weights_sha256") != sha256_file(checkpoint_npz):
        raise InferenceAuditError(f"checkpoint checksum mismatch: {checkpoint_npz}")
    provenance = checkpoint.get("checkpoint_provenance")
    if not isinstance(provenance, Mapping):
        raise InferenceAuditError(f"checkpoint provenance is absent: {checkpoint_json}")
    checkpoint_fingerprint = str(checkpoint.get("checkpoint_fingerprint", ""))
    if N.fingerprint(provenance) != checkpoint_fingerprint:
        raise InferenceAuditError(f"checkpoint provenance fingerprint mismatch: {checkpoint_json}")
    result_checkpoint_fingerprint = (
        result.get("training", {}).get(MODEL_NAME, {}).get("checkpoint_fingerprint")
    )
    if result_checkpoint_fingerprint != checkpoint_fingerprint:
        raise InferenceAuditError(f"result/checkpoint generation mismatch for seed={seed}")

    expected_model = {
        "name": "trust_full", "family": "trust", "sqi_source": True,
        "quality_gate": True, "quality_config": "canonical", "analysis_role": "primary",
    }
    if strict(checkpoint.get("model")) != expected_model:
        raise InferenceAuditError(f"checkpoint model is not canonical trust_full: {checkpoint_json}")
    if provenance.get("training_protocol_version") != N.SCRIPT_VERSION:
        raise InferenceAuditError(f"checkpoint training protocol drift: {checkpoint_json}")
    code_expectations = {
        "script_sha256": sha256_file(Path(N.__file__).resolve()),
        "revisionlib_sha256": sha256_file(Path(R.__file__).resolve()),
        "data_adapter_sha256": sha256_file(Path(D.__file__).resolve()),
    }
    for key, wanted in code_expectations.items():
        if provenance.get(key) != wanted:
            raise InferenceAuditError(f"checkpoint {key} differs from frozen inference code")
    if provenance.get("signals_sha256") != protocol["signals_sha256"]:
        raise InferenceAuditError(f"checkpoint signal dataset differs for seed={seed}")
    provenance_expectations = {
        "train_index_sha256": N.sha256_array(protocol["train_index"]),
        "val_index_sha256": N.sha256_array(protocol["val_index"]),
        "labels_sha256": N.sha256_array(protocol["labels"]),
        "record_id_order_sha256": protocol["record_id_order_sha256"],
        "ptbxl_adapter_manifest_sha256": protocol["adapter_manifest_sha256"],
        "n_classes": len(protocol["class_names"]),
        "class_names": protocol["class_names"],
        "epochs": 40, "batch_size": 256, "learning_rate": 1e-3, "seed": seed,
    }
    for key, wanted in provenance_expectations.items():
        if strict(provenance.get(key)) != strict(wanted):
            raise InferenceAuditError(f"checkpoint provenance mismatch for {key}, seed={seed}")
    if strict(result.get("class_names")) != strict(protocol["class_names"]):
        raise InferenceAuditError(f"canonical result class order differs for seed={seed}")
    result_train_counts = np.bincount(
        protocol["labels"][protocol["train_index"]], minlength=len(protocol["class_names"]),
    )
    expected_rare = np.flatnonzero(result_train_counts < 50)
    if strict(result.get("rare_ids")) != strict(expected_rare):
        raise InferenceAuditError(f"canonical result rare-class definition differs for seed={seed}")

    config = N.ModelConfig(**checkpoint["model"])
    model, _ = N.load_checkpoint(
        config, seed, len(protocol["class_names"]), checkpoint_fingerprint,
        args.checkpoint_root, device,
    )
    medians = np.asarray(result.get("hrv_imputation", {}).get("medians"), dtype=np.float32)
    if medians.shape != (8,) or not np.isfinite(medians).all():
        raise InferenceAuditError(f"invalid folds1-8 HRV medians: {result_json}")

    inputs = [
        artifact(Path(__file__).resolve(), "inference_script"),
        artifact(Path(N.__file__).resolve(), "frozen_noise_runner"),
        artifact(Path(R.__file__).resolve(), "revisionlib"),
        artifact(Path(D.__file__).resolve(), "data_adapter"),
        artifact(args.cache_dir / "ptbxl_adapter_manifest.json", "adapter_manifest"),
        artifact(
            Path(protocol["adapter"].signals.path).resolve(), "ptbxl_signal_mmap",
            known_sha256=protocol["signals_sha256"],
        ),
        artifact(result_json, "canonical_noise_json"),
        artifact(raw_curves, "canonical_noise_curves"),
        artifact(checkpoint_json, "checkpoint_json"),
        artifact(checkpoint_npz, "checkpoint_weights"),
    ]
    return model, medians, result, inputs


def softmax(logits: np.ndarray) -> np.ndarray:
    values = np.asarray(logits, dtype=np.float64)
    values = values - values.max(axis=1, keepdims=True)
    exp_values = np.exp(values)
    exp_values /= np.maximum(exp_values.sum(axis=1, keepdims=True), 1e-300)
    return exp_values


def nll(probabilities: np.ndarray, labels: np.ndarray) -> float:
    chosen = probabilities[np.arange(len(labels)), labels]
    return float(-np.mean(np.log(np.clip(chosen, 1e-15, 1.0))))


def brier(probabilities: np.ndarray, labels: np.ndarray) -> float:
    one_hot = np.zeros_like(probabilities, dtype=np.float64)
    one_hot[np.arange(len(labels)), labels] = 1.0
    return float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1)))


def calibration_error(
    confidence: np.ndarray, correctness: np.ndarray, bins: int, *, adaptive: bool,
) -> tuple[float | None, int]:
    confidence = np.asarray(confidence, dtype=np.float64).reshape(-1)
    correctness = np.asarray(correctness, dtype=np.float64).reshape(-1)
    if len(confidence) == 0:
        return None, 0
    if adaptive:
        quantiles = np.quantile(confidence, np.linspace(0.0, 1.0, bins + 1))
        interior = np.unique(quantiles[1:-1])
        assignments = np.searchsorted(interior, confidence, side="right")
        n_bins = len(interior) + 1
    else:
        assignments = np.minimum((np.clip(confidence, 0.0, 1.0) * bins).astype(int), bins - 1)
        n_bins = bins
    total = float(len(confidence))
    error = 0.0
    nonempty = 0
    for index in range(n_bins):
        mask = assignments == index
        if not mask.any():
            continue
        nonempty += 1
        error += float(mask.sum()) / total * abs(
            float(correctness[mask].mean()) - float(confidence[mask].mean())
        )
    return error, nonempty


def calibration_metrics(
    probabilities: np.ndarray, labels: np.ndarray, bins: int,
) -> dict[str, Any]:
    probabilities = np.asarray(probabilities, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    if len(labels) == 0:
        return {
            "support": 0, "accuracy": None, "balanced_accuracy": None,
            "macro_f1": None, "nll": None, "brier": None,
            "ece_equal_width": None, "ece_adaptive": None,
            "classwise_ece": None, "classwise_ece_adaptive": None,
            "classwise_supported_ece": None,
            "classwise_supported_ece_adaptive": None,
        }
    prediction = probabilities.argmax(axis=1)
    confidence = probabilities.max(axis=1)
    correctness = prediction == labels
    ece, equal_nonempty = calibration_error(confidence, correctness, bins, adaptive=False)
    adaptive, adaptive_nonempty = calibration_error(confidence, correctness, bins, adaptive=True)
    class_equal: list[float] = []
    class_adaptive: list[float] = []
    supported_equal: list[float] = []
    supported_adaptive: list[float] = []
    for class_id in range(probabilities.shape[1]):
        truth = labels == class_id
        current_equal, _ = calibration_error(
            probabilities[:, class_id], truth, bins, adaptive=False,
        )
        current_adaptive, _ = calibration_error(
            probabilities[:, class_id], truth, bins, adaptive=True,
        )
        assert current_equal is not None and current_adaptive is not None
        class_equal.append(current_equal)
        class_adaptive.append(current_adaptive)
        if truth.any():
            supported_equal.append(current_equal)
            supported_adaptive.append(current_adaptive)
    return {
        "support": len(labels),
        "accuracy": float(accuracy_score(labels, prediction)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, prediction)),
        "macro_f1": float(f1_score(
            labels, prediction, labels=np.arange(probabilities.shape[1]),
            average="macro", zero_division=0,
        )),
        "nll": nll(probabilities, labels), "brier": brier(probabilities, labels),
        "ece_equal_width": ece, "ece_equal_width_nonempty_bins": equal_nonempty,
        "ece_adaptive": adaptive, "ece_adaptive_nonempty_bins": adaptive_nonempty,
        "classwise_ece": float(np.mean(class_equal)),
        "classwise_ece_adaptive": float(np.mean(class_adaptive)),
        "classwise_supported_ece": float(np.mean(supported_equal)) if supported_equal else None,
        "classwise_supported_ece_adaptive": (
            float(np.mean(supported_adaptive)) if supported_adaptive else None
        ),
        "classes": probabilities.shape[1], "true_supported_classes": len(supported_equal),
        "bins_requested": bins,
    }


def stratified_metrics(
    probabilities: np.ndarray, labels: np.ndarray, rare_ids: np.ndarray, bins: int,
) -> dict[str, Any]:
    rare = np.isin(labels, rare_ids)
    return {
        "all": calibration_metrics(probabilities, labels, bins),
        "rare_true_label": calibration_metrics(probabilities[rare], labels[rare], bins),
        "frequent_true_label": calibration_metrics(probabilities[~rare], labels[~rare], bins),
    }


def fit_temperature(logits: np.ndarray, labels: np.ndarray) -> dict[str, Any]:
    logits = np.asarray(logits, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    log_bounds = tuple(math.log(value) for value in TEMPERATURE_BOUNDS)

    def objective(log_temperature: float) -> float:
        return nll(softmax(logits / math.exp(log_temperature)), labels)

    result = optimize.minimize_scalar(
        objective, bounds=log_bounds, method="bounded",
        options={"xatol": TEMPERATURE_XATOL, "maxiter": 1000},
    )
    if not result.success or not math.isfinite(float(result.fun)):
        raise RuntimeError(f"temperature optimization failed: {result.message}")
    temperature = math.exp(float(result.x))
    return {
        "value": temperature, "fit_split": "clean official fold 9 only",
        "objective": "multiclass negative log-likelihood",
        "parameterization": "bounded scalar log-temperature",
        "bounds": list(TEMPERATURE_BOUNDS), "xatol": TEMPERATURE_XATOL,
        "optimizer_success": bool(result.success), "optimizer_message": str(result.message),
        "iterations": int(result.nfev), "raw_fold9_nll": objective(0.0),
        "scaled_fold9_nll": float(result.fun),
        "same_temperature_frozen_for_all_snr_and_fold10": True,
    }


def protocol_namespace(args: argparse.Namespace) -> argparse.Namespace:
    return argparse.Namespace(
        trustfed_cache=str(args.trustfed_cache), cache_dir=str(args.cache_dir),
        limit_train=None, limit_val=None, limit_test=None,
    )


def derive_condition(
    model: torch.nn.Module, adapter: D.DatasetAdapter, protocol: Mapping[str, Any],
    medians: np.ndarray, qconfig: N.QualityConfig, seed: int, snr: float | None,
    args: argparse.Namespace, device: torch.device,
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, Any]]:
    outputs: dict[str, dict[str, np.ndarray]] = {}
    provenance: dict[str, Any] = {}
    for split_name, index_key, seed_name in (
        ("validation", "val_index", "validation-paired-noise"),
        ("test", "test_index", "test-paired-noise"),
    ):
        features = N.derive_features(
            adapter, protocol[index_key], snr=snr,
            noise_seed=N.stable_seed(seed, seed_name),
            chunk_size=args.feature_chunk_size, include_ecg=snr is not None,
        )
        imputed = N.impute_hrv(features, medians)
        arrays = N.make_arrays(
            adapter, protocol[index_key], features, protocol["labels"], qconfig,
        )
        raw = N.predict_trust(
            model, arrays, args.eval_batch_size, device, collect_features=False,
        )
        logits = np.asarray(raw["logits"], dtype=np.float32)
        probability = np.asarray(raw["prob"], dtype=np.float32)
        reconstructed = softmax(logits)
        maximum_difference = float(np.max(np.abs(reconstructed - probability)))
        if maximum_difference > 2e-6:
            raise RuntimeError(
                f"probability/logit identity failed at {N.snr_label(snr)}/{split_name}: "
                f"max difference={maximum_difference}"
            )
        achieved = (
            np.full(len(protocol[index_key]), np.nan, dtype=np.float32)
            if snr is None else np.asarray(features["achieved_snr"], dtype=np.float32)
        )
        outputs[split_name] = {
            "logits": logits, "prob": probability,
            "y": np.asarray(arrays["y"], dtype=np.int64), "achieved_snr": achieved,
        }
        provenance[split_name] = {
            "records": len(arrays["y"]), "hrv_values_imputed": imputed,
            "base_noise_sha256": None if snr is None else features["base_noise_sha256"],
            "achieved_snr_mean": None if snr is None else float(np.mean(achieved)),
            "achieved_snr_sd": None if snr is None else float(np.std(achieved)),
            "probability_equals_softmax_decision_logits_max_abs": maximum_difference,
        }
        del features, arrays, raw
        gc.collect()
    return outputs, provenance


def existing_complete(json_path: Path, npz_path: Path, run_fingerprint: str) -> bool:
    if not json_path.is_file() and not npz_path.is_file():
        return False
    if not json_path.is_file() or not npz_path.is_file():
        raise InferenceAuditError(f"incomplete existing output pair: {json_path}, {npz_path}")
    payload = load_object(json_path)
    if payload.get("status") != "complete":
        raise InferenceAuditError(f"existing output status is incomplete: {json_path}")
    if payload.get("run_fingerprint") != run_fingerprint:
        raise InferenceAuditError(f"existing output fingerprint differs; use --force: {json_path}")
    if payload.get("raw_npz", {}).get("sha256") != sha256_file(npz_path):
        raise InferenceAuditError(f"existing output NPZ checksum mismatch: {npz_path}")
    return True


def run_seed(args: argparse.Namespace, seed: int, device: torch.device) -> tuple[Path, Path]:
    N.set_seed(seed)
    protocol = N.load_protocol(protocol_namespace(args), seed)
    model, medians, canonical_result, inputs = authenticate_seed(seed, args, protocol, device)
    qconfig = N.quality_configs()["canonical"]
    train_counts = np.bincount(
        protocol["labels"][protocol["train_index"]], minlength=len(protocol["class_names"]),
    )
    rare_ids = np.flatnonzero(train_counts < args.rare_threshold)
    run_definition = {
        "script_version": SCRIPT_VERSION,
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "frozen_runner_version": N.SCRIPT_VERSION,
        "seed": seed, "model": MODEL_NAME,
        "snrs": [N.snr_label(value) for value in SNRS],
        "splits": "official folds 9 and 10; no split limits",
        "train_index_sha256": sha256_array(protocol["train_index"]),
        "validation_index_sha256": sha256_array(protocol["val_index"]),
        "test_index_sha256": sha256_array(protocol["test_index"]),
        "labels_sha256": sha256_array(protocol["labels"]),
        "signals_sha256": protocol["signals_sha256"],
        "record_id_order_sha256": protocol["record_id_order_sha256"],
        "checkpoint_fingerprint": canonical_result["training"][MODEL_NAME]["checkpoint_fingerprint"],
        "input_hashes": {item["role"]: item["sha256"] for item in inputs},
        "eval_batch_size": args.eval_batch_size,
        "feature_chunk_size": args.feature_chunk_size,
        "calibration_bins": args.calibration_bins,
        "temperature": {
            "fit_split": "clean fold9 only", "bounds": list(TEMPERATURE_BOUNDS),
            "xatol": TEMPERATURE_XATOL,
        },
        "rare_threshold": args.rare_threshold,
    }
    run_fingerprint = fingerprint(run_definition)
    json_path = args.output_dir / f"seed_{seed}.json"
    npz_path = args.output_dir / f"seed_{seed}_calibration.npz"
    if not args.force and existing_complete(json_path, npz_path, run_fingerprint):
        print(f"[resume] calibration seed={seed}", flush=True)
        return json_path, npz_path

    condition_raw: dict[str, dict[str, dict[str, np.ndarray]]] = {}
    condition_provenance: dict[str, Any] = {}
    for snr in SNRS:
        label = N.snr_label(snr)
        print(f"[seed={seed}] inference {label} fold9/fold10", flush=True)
        condition_raw[label], condition_provenance[label] = derive_condition(
            model, protocol["adapter"], protocol, medians, qconfig, seed, snr,
            args, device,
        )

    clean_validation = condition_raw["clean"]["validation"]
    temperature = fit_temperature(clean_validation["logits"], clean_validation["y"])
    temperature_value = float(temperature["value"])
    reports: dict[str, Any] = {}
    raw_arrays: MutableMapping[str, np.ndarray] = {
        "snr_db": np.asarray([np.nan if value is None else value for value in SNRS], dtype=np.float32),
        "snr_label": np.asarray([N.snr_label(value) for value in SNRS]),
        "validation_y": np.asarray(protocol["labels"][protocol["val_index"]], dtype=np.int16),
        "test_y": np.asarray(protocol["labels"][protocol["test_index"]], dtype=np.int16),
        "validation_index": np.asarray(protocol["val_index"], dtype=np.int64),
        "test_index": np.asarray(protocol["test_index"], dtype=np.int64),
        "validation_record_id": np.asarray(
            protocol["adapter"].metadata.iloc[protocol["val_index"]]["record_id"]
            .astype(str).tolist(),
            dtype=str,
        ),
        "test_record_id": np.asarray(
            protocol["adapter"].metadata.iloc[protocol["test_index"]]["record_id"]
            .astype(str).tolist(),
            dtype=str,
        ),
        "validation_patient": protocol["patient"][protocol["val_index"]].astype(str),
        "test_patient": protocol["patient"][protocol["test_index"]].astype(str),
        "class_names": np.asarray(protocol["class_names"], dtype=str),
        "train_class_support": train_counts.astype(np.int64),
        "rare_ids": rare_ids.astype(np.int16),
        "temperature": np.asarray(temperature_value, dtype=np.float64),
    }
    for split_name in ("validation", "test"):
        raw_arrays[f"{split_name}_logits_raw"] = np.stack([
            condition_raw[N.snr_label(snr)][split_name]["logits"] for snr in SNRS
        ]).astype(np.float32)
        raw_arrays[f"{split_name}_prob_raw"] = np.stack([
            condition_raw[N.snr_label(snr)][split_name]["prob"] for snr in SNRS
        ]).astype(np.float32)
        raw_arrays[f"{split_name}_logits_ts"] = (
            raw_arrays[f"{split_name}_logits_raw"] / temperature_value
        ).astype(np.float32)
        raw_arrays[f"{split_name}_prob_ts"] = np.stack([
            softmax(values / temperature_value)
            for values in raw_arrays[f"{split_name}_logits_raw"]
        ]).astype(np.float32)
        raw_arrays[f"{split_name}_achieved_snr"] = np.stack([
            condition_raw[N.snr_label(snr)][split_name]["achieved_snr"] for snr in SNRS
        ]).astype(np.float32)

    for condition_index, snr in enumerate(SNRS):
        label = N.snr_label(snr)
        reports[label] = {
            "snr_db": snr, "provenance": condition_provenance[label], "splits": {},
        }
        for split_name in ("validation", "test"):
            labels = raw_arrays[f"{split_name}_y"].astype(np.int64)
            reports[label]["splits"][split_name] = {
                "raw": stratified_metrics(
                    raw_arrays[f"{split_name}_prob_raw"][condition_index], labels,
                    rare_ids, args.calibration_bins,
                ),
                "temperature_scaled": stratified_metrics(
                    raw_arrays[f"{split_name}_prob_ts"][condition_index], labels,
                    rare_ids, args.calibration_bins,
                ),
            }

    atomic_npz(npz_path, raw_arrays)
    payload = {
        "status": "complete", "schema": SCRIPT_VERSION,
        "run_definition": run_definition, "run_fingerprint": run_fingerprint,
        "seed": seed, "model": MODEL_NAME,
        "protocol": {
            "train": len(protocol["train_index"]), "validation": len(protocol["val_index"]),
            "test": len(protocol["test_index"]),
            "rule": "official PTB-XL folds1-8 / fold9 / fold10",
            "all_noisy_ecg_sources_recomputed": ["ecg", "sqi6", "quality", "hrv8", "spec36"],
            "paired_noise_across_snr": True,
            "temperature_fit_uses_test": False,
        },
        "class_names": protocol["class_names"],
        "train_class_support": train_counts,
        "rare_definition": f"folds1-8 record support < {args.rare_threshold}",
        "rare_ids": rare_ids,
        "rare_names": [protocol["class_names"][index] for index in rare_ids],
        "temperature": temperature, "conditions": reports,
        "metric_definitions": {
            "ece_equal_width": f"top-label ECE with {args.calibration_bins} equal-width bins",
            "ece_adaptive": f"top-label ECE with up to {args.calibration_bins} empirical-quantile bins",
            "classwise_ece": "macro one-vs-rest ECE over all model classes",
            "classwise_supported_ece": "macro one-vs-rest ECE over true-label-supported classes in the reported subgroup",
            "brier": "mean multiclass sum-of-squares Brier score",
            "nll": "mean multiclass negative log likelihood",
            "rare_frequent_strata": "partition by each record's true label; probabilities retain the full class simplex",
        },
        "inputs": inputs,
        "raw_npz": {
            "role": "calibration_npz",
            "path": str(npz_path.resolve()), "bytes": npz_path.stat().st_size,
            "sha256": sha256_file(npz_path),
            "axis_convention": "condition first, then record, then class; no waveform is stored",
        },
        "environment": {
            "created_at_utc": utc_now(), "python": platform.python_version(),
            "platform": platform.platform(), "numpy": np.__version__,
            "scipy": scipy.__version__, "sklearn": sklearn.__version__,
            "torch": torch.__version__, "cuda_available": torch.cuda.is_available(),
            "cuda_version": torch.version.cuda, "device": str(device),
            "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
            "command": sys.argv,
        },
    }
    atomic_json(json_path, payload)
    print(f"[saved] {json_path} and {npz_path}", flush=True)
    del model, condition_raw, raw_arrays
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return json_path, npz_path


def write_manifest(args: argparse.Namespace) -> None:
    entries = []
    for seed in SEEDS:
        json_path = args.output_dir / f"seed_{seed}.json"
        npz_path = args.output_dir / f"seed_{seed}_calibration.npz"
        if json_path.is_file() and npz_path.is_file():
            entries.append({
                "seed": seed,
                "json": artifact(json_path, "calibration_json"),
                "npz": artifact(npz_path, "calibration_npz"),
            })
    atomic_json(args.output_dir / "manifest.json", {
        "schema": SCRIPT_VERSION, "created_at_utc": utc_now(),
        "complete": len(entries) == len(SEEDS), "expected_seeds": list(SEEDS),
        "observed_seeds": [item["seed"] for item in entries],
        "script": artifact(Path(__file__).resolve(), "inference_script"),
        "results": entries,
        "note": "manifest.json is intentionally not self-hashed",
    })


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=parse_seeds, default=SEEDS)
    parser.add_argument("--worker-seed", type=int)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--trustfed-cache", type=Path, default=Path(D.DEFAULT_TRUSTFED_CACHE))
    parser.add_argument("--cache-dir", type=Path, default=Path("/root/Paper46_revision/cache"))
    parser.add_argument(
        "--checkpoint-root", type=Path,
        default=Path("/root/Paper46_revision/checkpoints_final/noise_sqi/canonical"),
        help="directory containing trust_full/seed_<seed>.json and .npz",
    )
    parser.add_argument(
        "--canonical-results-root", type=Path,
        default=Path("/root/Paper46_revision/results_final/noise_sqi/canonical"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path("/dev/shm/Paper46_noise_shift_calibration/results"),
    )
    parser.add_argument("--eval-batch-size", type=int, default=512)
    parser.add_argument("--feature-chunk-size", type=int, default=256)
    parser.add_argument("--calibration-bins", type=int, default=15)
    parser.add_argument("--rare-threshold", type=int, default=50)
    parser.add_argument("--force", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    for name in ("trustfed_cache", "cache_dir", "checkpoint_root", "canonical_results_root", "output_dir"):
        setattr(args, name, getattr(args, name).resolve())
    if args.worker_seed is not None and args.worker_seed not in args.seeds:
        raise SystemExit("--worker-seed must be declared in --seeds")
    if args.eval_batch_size < 1 or args.feature_chunk_size != 256:
        raise SystemExit("eval batch must be positive and canonical feature chunk size must equal 256")
    if args.calibration_bins < 2 or args.rare_threshold != 50:
        raise SystemExit("calibration bins must be >=2 and canonical rare threshold must equal 50")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    selected = (args.worker_seed,) if args.worker_seed is not None else args.seeds
    for seed in selected:
        run_seed(args, seed, device)
    write_manifest(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
