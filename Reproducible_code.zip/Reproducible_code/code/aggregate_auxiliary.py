#!/usr/bin/env python3
"""Audit and aggregate the Paper46 wearable and noise/SQI experiments.

This program is deliberately read-only with respect to experiment roots.  It
expects the complete canonical matrix produced by ``run_wearables_revision.py``
and ``run_noise_sqi.py``, verifies the JSON/NPZ contract and checksums, and
writes compact statistical artefacts to a separate output directory.

Wearable inference respects the repeated LOSO design: each seed is first
averaged over held-out subjects, and only those three seed-level means enter
the reported mean, sample SD and Student-t confidence interval.  Model
contrasts remain paired at held-out-subject x seed resolution; uncertainty is
estimated by resampling held-out subjects as clusters (all seeds travel with a
resampled subject).  Noise/SQI contrasts are paired by seed.  Holm adjustments
are made within each dataset/metric or analysis/context/metric family.

No missing cell is imputed.  ``--fail-on-incomplete`` makes any missing,
duplicate or invalid canonical cell produce a non-zero exit after all audit
artefacts have been written.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import platform
import re
import sys
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import scipy
from scipy import stats


SCRIPT_VERSION = "paper46-auxiliary-aggregate-v1"
WEARABLE_SCHEMA = "paper46-wearable-loso-v1"
NOISE_SCHEMA = "paper46-noise-sqi-v1"
WEARABLE_SEEDS = (7, 42, 2026)
NOISE_SEEDS = (7, 13, 42)
NOISE_CONDITIONS = ("clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB")
NOISE_RETRAINED = (
    "trust_qretrain__joint_minus20",
    "trust_qretrain__joint_plus20",
    "trust_qretrain__uniform",
    "trust_qretrain__psqi_only",
)
NOISE_TRAINED_MODELS = (
    "softmax_modular",
    "sqi_source0_gate0",
    "sqi_source0_gate1",
    "sqi_source1_gate0",
) + NOISE_RETRAINED
SQI_NAMES = ("kSQI", "abs_skew_SQI", "pSQI_5_15Hz", "basSQI", "flat", "sat")
QUALITY_CONFIG_NAMES = (
    "canonical",
    *(f"coef_{name}_{suffix}" for name in SQI_NAMES for suffix in ("minus20", "plus20")),
    "joint_minus20", "joint_plus20", "uniform", "psqi_only",
)

DATASETS: dict[str, dict[str, Any]] = {
    "mhealth": {
        "subjects": tuple(f"S{index}" for index in range(1, 11)),
        "models": ("trust_full", "concat_matched", "ecg_only", "motion_only"),
        "sources": ("ecg", "motion"),
        "classes": 12,
        "raw_labels": tuple(range(1, 13)),
    },
    "wesad": {
        "subjects": tuple(
            f"S{index}" for index in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17)
        ),
        "models": ("trust_full", "concat_matched", "ecg_only", "ppg_only", "motion_only"),
        "sources": ("ecg", "ppg", "motion"),
        "classes": 4,
        "raw_labels": (1, 2, 3, 4),
    },
}

WEARABLE_SECTIONS = {
    "diagnosis_raw": "diagnosis_raw",
    "diagnosis_temperature_scaled": "diagnosis_temperature_scaled",
    "calibration": "calibration",
    "selective_prediction": "selective_prediction",
    "alarm_rejection_burden": "alarm_rejection_burden",
    "stress_tests": "stress_tests",
    "source_weight_analysis": "source_weight_analysis",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    value = np.ascontiguousarray(array)
    digest = hashlib.sha256()
    digest.update(value.dtype.str.encode("ascii"))
    digest.update(json.dumps(list(value.shape), separators=(",", ":")).encode("ascii"))
    digest.update(value.tobytes(order="C"))
    return digest.hexdigest()


def stable_seed(*parts: Any) -> int:
    value = "\x1f".join(str(part) for part in parts)
    return int.from_bytes(hashlib.sha256(value.encode("utf-8")).digest()[:8], "little")


def canonical_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def strict_value(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return strict_value(value.item())
    if isinstance(value, np.ndarray):
        return strict_value(value.tolist())
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): strict_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict_value(item) for item in value]
    return value


def atomic_json(path: Path, payload: Any, pretty: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            dump_options: dict[str, Any] = {
                "sort_keys": True, "ensure_ascii": False, "allow_nan": False,
            }
            if pretty:
                dump_options["indent"] = 2
            else:
                dump_options["separators"] = (",", ":")
            json.dump(strict_value(payload), handle, **dump_options)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_csv(path: Path, rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: strict_value(row.get(key)) for key in fields})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("top-level JSON value is not an object")
    return payload


def npz_headers(path: Path) -> dict[str, dict[str, Any]]:
    """Read embedded NPY headers without materialising compressed arrays."""

    result: dict[str, dict[str, Any]] = {}
    with zipfile.ZipFile(path, "r") as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.endswith(".npy"):
                continue
            key = member.filename[:-4]
            with archive.open(member, "r") as handle:
                version = np.lib.format.read_magic(handle)
                if version == (1, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_1_0(handle)
                elif version in ((2, 0), (3, 0)):
                    shape, fortran, dtype = np.lib.format.read_array_header_2_0(handle)
                else:
                    raise ValueError(f"unsupported NPY header version {version} in {key}")
            dtype = np.dtype(dtype)
            result[key] = {
                "shape": [int(item) for item in shape],
                "dtype": dtype.str,
                "dtype_kind": dtype.kind,
                "fortran_order": bool(fortran),
                "compressed_bytes": int(member.compress_size),
                "uncompressed_bytes": int(member.file_size),
                "crc32": f"{member.CRC:08x}",
            }
    if not result:
        raise ValueError("NPZ contains no NPY members")
    return result


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def list_item_name(item: Any, index: int) -> str:
    if isinstance(item, Mapping):
        for key in ("class_name", "name", "source", "method", "class_id"):
            if key in item and isinstance(item[key], (str, int)):
                return f"{key}={item[key]}"
    return str(index)


def flatten_numbers(node: Any, prefix: str = "") -> list[tuple[str, float]]:
    rows: list[tuple[str, float]] = []
    if is_number(node):
        rows.append((prefix or "value", float(node)))
    elif isinstance(node, Mapping):
        for key in sorted(node, key=str):
            child = f"{prefix}.{key}" if prefix else str(key)
            rows.extend(flatten_numbers(node[key], child))
    elif isinstance(node, list):
        for index, item in enumerate(node):
            child = f"{prefix}[{list_item_name(item, index)}]" if prefix else f"[{list_item_name(item, index)}]"
            rows.extend(flatten_numbers(item, child))
    return rows


def add_issue(
    issues: list[dict[str, Any]], scope: str, cell: str, message: str,
    severity: str = "error",
) -> None:
    issues.append({"scope": scope, "cell": cell, "severity": severity, "message": message})


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def resolve_declared_file(declared: Any, json_path: Path) -> Path:
    path = Path(str(declared))
    if path.is_absolute():
        return path
    return (json_path.parent / path).resolve()


def expected_validation(dataset: str, heldout: str) -> str:
    subjects = DATASETS[dataset]["subjects"]
    return subjects[(subjects.index(heldout) + 1) % len(subjects)]


def expected_model_sources(dataset: str, model: str) -> tuple[str, ...]:
    if model.endswith("_only"):
        return (model[: -len("_only")],)
    return tuple(DATASETS[dataset]["sources"])


def recompute_wearable_run_key(payload: Mapping[str, Any]) -> str:
    provenance = payload["provenance"]
    environment = provenance["environment"]
    arguments = environment["arguments"]
    relevant = {
        "script_version": payload["schema"],
        "dataset": payload["dataset"],
        "heldout_subject": payload["heldout_subject"],
        "model": payload["model"],
        "seed": payload["seed"],
        "epochs": arguments["epochs"],
        "batch_size": arguments["batch_size"],
        "learning_rate": arguments["learning_rate"],
        "device": arguments["device"],
        "torch_threads": arguments["torch_threads"],
        "torch_version": environment["torch"],
        "cuda_version": environment["torch_cuda"],
        "stress_snrs": arguments["stress_snrs"],
        "stress": not arguments["no_stress"],
        "code_hashes": provenance["code_sha256"],
        "data_combined_sha256": provenance["data_combined_sha256"],
    }
    return canonical_hash(relevant)


def audit_wearable_cell(
    path: Path, dataset: str, heldout: str, model: str, seed: int,
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    cell = f"{dataset}/{heldout}/{model}/seed_{seed}"
    audit: dict[str, Any] = {
        "kind": "wearable", "cell": cell, "expected_json": str(path),
        "present": path.is_file(), "valid": False, "errors": [],
    }
    if not path.is_file():
        audit["errors"].append("missing JSON")
        return None, audit
    errors: list[str] = audit["errors"]
    try:
        payload = load_json(path)
        audit["json_sha256"] = sha256_file(path)
        require(payload.get("status") == "complete", "status is not complete", errors)
        require(payload.get("schema") == WEARABLE_SCHEMA, "unexpected schema", errors)
        require(payload.get("dataset") == dataset, "dataset mismatch", errors)
        require(payload.get("heldout_subject") == heldout, "held-out subject mismatch", errors)
        require(payload.get("validation_subject") == expected_validation(dataset, heldout), "validation subject mismatch", errors)
        require(payload.get("model") == model, "model mismatch", errors)
        require(payload.get("seed") == seed, "seed mismatch", errors)
        require(payload.get("family") == ("trust" if model == "trust_full" else "softmax"), "model family mismatch", errors)

        run_key = payload.get("run_key")
        require(isinstance(run_key, str) and re.fullmatch(r"[0-9a-f]{64}", run_key) is not None, "malformed run_key", errors)
        try:
            require(run_key == recompute_wearable_run_key(payload), "run_key does not match recorded configuration", errors)
        except (KeyError, TypeError, ValueError) as exc:
            errors.append(f"cannot reconstruct run_key: {exc}")

        split = payload.get("split", {})
        subjects = DATASETS[dataset]["subjects"]
        validation = expected_validation(dataset, heldout)
        expected_train = [item for item in subjects if item not in (heldout, validation)]
        require(split.get("strategy") == "cyclic-next-subject validation, independent of seed", "split strategy mismatch", errors)
        require(split.get("test") == [heldout], "test split mismatch", errors)
        require(split.get("validation") == [validation], "validation split mismatch", errors)
        require(split.get("train") == expected_train, "training-subject split mismatch", errors)

        protocol = payload.get("label_protocol", {})
        raw_labels = list(DATASETS[dataset]["raw_labels"])
        require(protocol.get("included_raw_labels") == raw_labels, "included raw labels mismatch", errors)
        require(protocol.get("mapping") == {str(value): value - 1 for value in raw_labels}, "label mapping mismatch", errors)
        class_names = protocol.get("class_names")
        require(isinstance(class_names, list) and len(class_names) == DATASETS[dataset]["classes"], "class-name count mismatch", errors)

        model_sources = payload.get("model_definition", {}).get("sources")
        require(model_sources == list(expected_model_sources(dataset, model)), "model sources mismatch", errors)

        provenance = payload.get("provenance", {})
        environment = provenance.get("environment", {})
        arguments = environment.get("arguments", {})
        canonical_config = {
            "epochs": arguments.get("epochs"),
            "batch_size": arguments.get("batch_size"),
            "learning_rate": arguments.get("learning_rate"),
            "torch_threads": arguments.get("torch_threads"),
            "stress_snrs": arguments.get("stress_snrs"),
            "no_stress": arguments.get("no_stress"),
        }
        audit["configuration"] = canonical_config
        require(
            canonical_config == {
                "epochs": 30, "batch_size": 128, "learning_rate": 1e-3,
                "torch_threads": 1, "stress_snrs": [10.0, 0.0, -5.0],
                "no_stress": False,
            },
            "non-canonical wearable configuration", errors,
        )
        for code_path, declared_hash in provenance.get("code_sha256", {}).items():
            resolved_code = Path(code_path)
            require(resolved_code.is_file(), f"provenance code file missing: {code_path}", errors)
            if resolved_code.is_file():
                require(sha256_file(resolved_code) == declared_hash, f"provenance code SHA mismatch: {code_path}", errors)
        manifest_path = Path(str(provenance.get("data_manifest_path", "")))
        require(manifest_path.is_file(), "data manifest is missing", errors)
        if manifest_path.is_file():
            manifest = load_json(manifest_path)
            require(manifest.get("combined_sha256") == provenance.get("data_combined_sha256"), "data manifest hash mismatch", errors)

        prediction_info = payload.get("prediction_file", {})
        prediction_path = resolve_declared_file(prediction_info.get("path", ""), path)
        audit["prediction_path"] = str(prediction_path)
        require(
            prediction_path.resolve() == path.with_name(f"seed_{seed}_predictions.npz").resolve(),
            "prediction_file.path is not the canonical sibling NPZ", errors,
        )
        require(prediction_path.is_file(), "prediction NPZ is missing", errors)
        if prediction_path.is_file():
            actual_sha = sha256_file(prediction_path)
            audit["prediction_sha256"] = actual_sha
            require(actual_sha == prediction_info.get("sha256"), "prediction NPZ SHA-256 mismatch", errors)
            headers = npz_headers(prediction_path)
            audit["npz_header"] = headers
            required = {
                "y", "subject", "prob_raw", "prob_temperature_scaled", "logits_raw",
                "pred", "selection_confidence", "source_names",
            }
            require(required.issubset(headers), f"NPZ keys missing: {sorted(required - set(headers))}", errors)
            require(all(row["dtype_kind"] != "O" for row in headers.values()), "NPZ contains object dtype", errors)
            if required.issubset(headers):
                n = headers["y"]["shape"][0] if len(headers["y"]["shape"]) == 1 else -1
                classes = DATASETS[dataset]["classes"]
                require(n > 0, "invalid y shape", errors)
                require(headers["subject"]["shape"] == [n], "subject shape mismatch", errors)
                require(headers["prob_raw"]["shape"] == [n, classes], "raw probability shape mismatch", errors)
                require(headers["prob_temperature_scaled"]["shape"] == [n, classes], "temperature-scaled probability shape mismatch", errors)
                require(headers["logits_raw"]["shape"] == [n, classes], "logit shape mismatch", errors)
                require(headers["pred"]["shape"] == [n], "prediction shape mismatch", errors)
                require(headers["selection_confidence"]["shape"] == [n], "confidence shape mismatch", errors)
                require(payload.get("diagnosis_raw", {}).get("n") == n, "diagnosis n does not match NPZ", errors)
                with np.load(prediction_path, allow_pickle=False) as archive:
                    y = np.asarray(archive["y"])
                    subjects_npz = np.asarray(archive["subject"]).astype(str)
                    sources_npz = tuple(np.asarray(archive["source_names"]).astype(str).tolist())
                    raw_prob = np.asarray(archive["prob_raw"])
                    scaled_prob = np.asarray(archive["prob_temperature_scaled"])
                    pred = np.asarray(archive["pred"])
                    require(np.all((y >= 0) & (y < classes)), "labels outside canonical range", errors)
                    require(np.all(subjects_npz == heldout), "NPZ subject column is not the held-out subject", errors)
                    require(sources_npz == expected_model_sources(dataset, model), "NPZ source_names mismatch", errors)
                    require(np.isfinite(raw_prob).all() and np.isfinite(scaled_prob).all(), "non-finite probabilities", errors)
                    require(np.allclose(raw_prob.sum(axis=1), 1.0, atol=2e-4), "raw probabilities do not sum to one", errors)
                    require(np.allclose(scaled_prob.sum(axis=1), 1.0, atol=2e-4), "scaled probabilities do not sum to one", errors)
                    require(np.array_equal(pred, raw_prob.argmax(axis=1)), "stored predictions disagree with argmax", errors)
                    split_counts = payload.get("data_audit", {}).get("split_counts", {})
                    require(split_counts.get("test", {}).get("subjects") == [heldout], "data-audit test subject mismatch", errors)
                    require(split_counts.get("validation", {}).get("subjects") == [validation], "data-audit validation subject mismatch", errors)
                    require(split_counts.get("train", {}).get("subjects") == expected_train, "data-audit training subjects mismatch", errors)
                    require(split_counts.get("test", {}).get("windows") == n, "data-audit test-window count mismatch", errors)
                    label_counts = np.bincount(y.astype(np.int64), minlength=classes).tolist()
                    require(split_counts.get("test", {}).get("class_counts") == label_counts, "data-audit test label counts mismatch", errors)
                    classwise = payload.get("diagnosis_raw", {}).get("classwise", [])
                    require(
                        isinstance(classwise, list) and len(classwise) == classes
                        and [row.get("support") for row in classwise] == label_counts,
                        "diagnosis classwise supports do not match NPZ labels", errors,
                    )
                    audit["label_sha256"] = sha256_array(y)
                    audit["subject_sha256"] = sha256_array(subjects_npz)
                if model == "trust_full":
                    trust_keys = {"u", "source_w", "source_u", "source_q", "source_prob"}
                    require(trust_keys.issubset(headers), f"trust NPZ keys missing: {sorted(trust_keys - set(headers))}", errors)
                    source_count = len(DATASETS[dataset]["sources"])
                    if trust_keys.issubset(headers):
                        require(headers["u"]["shape"] == [n], "vacuity shape mismatch", errors)
                        for key in ("source_w", "source_u", "source_q"):
                            require(headers[key]["shape"] == [n, source_count], f"{key} shape mismatch", errors)
                        require(headers["source_prob"]["shape"] == [n, source_count, classes], "source_prob shape mismatch", errors)
        audit["valid"] = not errors
        return (payload if not errors else None), audit
    except Exception as exc:
        errors.append(f"audit exception: {type(exc).__name__}: {exc}")
        return None, audit


def locate_noise_files(root: Path) -> dict[int, list[Path]]:
    index: dict[int, list[Path]] = defaultdict(list)
    for path in sorted(root.rglob("seed_*.json")):
        match = re.fullmatch(r"seed_(\d+)\.json", path.name)
        if match is None:
            continue
        try:
            payload = load_json(path)
        except Exception:
            continue
        if (
            "run_fingerprint" in payload and "conditions" in payload
            and payload.get("canonical") is True and payload.get("full_fold_run") is True
        ):
            index[int(match.group(1))].append(path)
    return index


def audit_noise_cell(path: Path, seed: int) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    cell = f"noise/canonical/seed_{seed}"
    audit: dict[str, Any] = {
        "kind": "noise", "cell": cell, "expected_json": str(path),
        "present": path.is_file(), "valid": False, "errors": [],
    }
    if not path.is_file():
        audit["errors"].append("missing JSON")
        return None, audit
    errors: list[str] = audit["errors"]
    try:
        payload = load_json(path)
        audit["json_sha256"] = sha256_file(path)
        require(payload.get("status") == "complete", "status is not complete", errors)
        require(payload.get("seed") == seed, "seed mismatch", errors)
        require(payload.get("canonical") is True, "canonical flag is not true", errors)
        require(payload.get("full_fold_run") is True, "full_fold_run flag is not true", errors)
        fingerprint = payload.get("run_fingerprint")
        require(isinstance(fingerprint, str) and re.fullmatch(r"[0-9a-f]{64}", fingerprint) is not None, "malformed run_fingerprint", errors)
        require(payload.get("split", {}).get("rule") == "official PTB-XL folds 1-8 / 9 / 10", "split rule mismatch", errors)
        require(all(int(payload.get("split", {}).get(key, 0)) > 0 for key in ("train", "validation", "test")), "empty split", errors)
        n_classes = payload.get("n_classes")
        class_names = payload.get("class_names")
        require(isinstance(n_classes, int) and n_classes > 1, "invalid class count", errors)
        require(isinstance(class_names, list) and len(class_names) == n_classes, "class names mismatch", errors)
        rare_ids = payload.get("rare_ids")
        require(isinstance(rare_ids, list) and all(isinstance(value, int) and 0 <= value < n_classes for value in rare_ids), "rare IDs invalid", errors)
        require(len(payload.get("rare_names", [])) == len(rare_ids or []), "rare names mismatch", errors)

        environment = payload.get("environment", {})
        arguments = environment.get("arguments", {})
        canonical_config = {
            "epochs": arguments.get("epochs"),
            "batch_size": arguments.get("batch_size"),
            "eval_batch_size": arguments.get("eval_batch_size"),
            "feature_chunk_size": arguments.get("feature_chunk_size"),
            "learning_rate": arguments.get("learning_rate"),
            "snrs": arguments.get("snrs"),
            "q_min_percent": arguments.get("q_min_percent"),
            "sqi_sensitivity": arguments.get("sqi_sensitivity"),
            "retrain_sqi_configs": arguments.get("retrain_sqi_configs"),
            "run_2x2": arguments.get("run_2x2"),
            "source_corruption_snr": arguments.get("source_corruption_snr"),
            "rare_threshold": arguments.get("rare_threshold"),
            "fixed_coverages": arguments.get("fixed_coverages"),
            "risk_targets": arguments.get("risk_targets"),
            "alarm_quantile": arguments.get("alarm_quantile"),
            "smoke": arguments.get("smoke"),
            "limit_train": arguments.get("limit_train"),
            "limit_val": arguments.get("limit_val"),
            "limit_test": arguments.get("limit_test"),
            "seeds": arguments.get("seeds"),
        }
        audit["configuration"] = canonical_config
        expected_config = {
            "epochs": 40, "batch_size": 256, "eval_batch_size": 512,
            "feature_chunk_size": 256, "learning_rate": 1e-3,
            "snrs": [None, 24.0, 18.0, 12.0, 6.0, 0.0, -6.0],
            "q_min_percent": [5.0, 10.0, 20.0, 30.0],
            "sqi_sensitivity": "both",
            "retrain_sqi_configs": ["joint_minus20", "joint_plus20", "uniform", "psqi_only"],
            "run_2x2": True, "source_corruption_snr": 0.0,
            "rare_threshold": 50,
            "fixed_coverages": [0.95, 0.90, 0.80, 0.70, 0.50],
            "risk_targets": [0.01, 0.05, 0.10], "alarm_quantile": 0.95,
            "smoke": False,
            "limit_train": None, "limit_val": None, "limit_test": None,
            "seeds": [7, 13, 42],
        }
        require(canonical_config == expected_config, "non-canonical noise/SQI configuration", errors)
        require(environment.get("script_version") == NOISE_SCHEMA, "noise script version mismatch", errors)

        conditions = payload.get("conditions", {})
        inference = payload.get("sqi_coefficient_sensitivity_inference_only", {})
        trained = payload.get("trained_model_robustness", {})
        quality_configs = payload.get("quality_configs", {})
        require(set(quality_configs) == set(QUALITY_CONFIG_NAMES), "quality-configuration set mismatch", errors)
        require(
            quality_configs.get("canonical", {}).get("coefficients")
            == [0.2, 0.0, 0.5, 0.3, -0.5, -0.5],
            "canonical SQI coefficients mismatch", errors,
        )
        require(set(conditions) == set(NOISE_CONDITIONS), "condition set mismatch", errors)
        require(set(inference) == set(NOISE_CONDITIONS), "inference condition set mismatch", errors)
        for condition in NOISE_CONDITIONS:
            inference_condition = inference.get(condition, {})
            require(
                set(inference_condition) == set(QUALITY_CONFIG_NAMES),
                f"inference SQI configuration set mismatch for {condition}", errors,
            )
            for quality_name in QUALITY_CONFIG_NAMES:
                require(
                    inference_condition.get(quality_name, {}).get("analysis_type")
                    == "inference_only_no_parameter_update",
                    f"inference analysis type mismatch for {condition}/{quality_name}", errors,
                )
        require(set(trained) == set(NOISE_TRAINED_MODELS), "trained-model set mismatch", errors)
        expected_factors = {
            "softmax_modular": (True, False, "canonical", "baseline"),
            "sqi_source0_gate0": (False, False, "canonical", "2x2"),
            "sqi_source0_gate1": (False, True, "canonical", "2x2"),
            "sqi_source1_gate0": (True, False, "canonical", "2x2"),
            "trust_qretrain__joint_minus20": (True, True, "joint_minus20", "retrained_sqi_sensitivity"),
            "trust_qretrain__joint_plus20": (True, True, "joint_plus20", "retrained_sqi_sensitivity"),
            "trust_qretrain__uniform": (True, True, "uniform", "retrained_sqi_sensitivity"),
            "trust_qretrain__psqi_only": (True, True, "psqi_only", "retrained_sqi_sensitivity"),
        }
        for name in NOISE_TRAINED_MODELS:
            require(set(trained.get(name, {})) == set(NOISE_CONDITIONS), f"condition set mismatch for {name}", errors)
            source, gate, quality_name, role = expected_factors[name]
            for condition in NOISE_CONDITIONS:
                report = trained.get(name, {}).get(condition, {})
                require(report.get("analysis_type") == "retrained_from_scratch", f"analysis type mismatch for {name}/{condition}", errors)
                require(report.get("analysis_role") == role, f"analysis role mismatch for {name}/{condition}", errors)
                require(
                    report.get("factors") == {
                        "sqi_vector_source": source,
                        "quality_used_by_gate": gate,
                        "quality_config": quality_name,
                    },
                    f"model factors mismatch for {name}/{condition}", errors,
                )
        training = payload.get("training", {})
        require(set(training) == {"trust_full", *NOISE_TRAINED_MODELS}, "trained-checkpoint set mismatch", errors)
        for name in ("trust_full", *NOISE_TRAINED_MODELS):
            training_entry = training.get(name, {})
            require(training_entry.get("status") in ("trained", "reused"), f"checkpoint status mismatch for {name}", errors)
            checkpoint_fingerprint = training_entry.get("checkpoint_fingerprint")
            require(
                isinstance(checkpoint_fingerprint, str)
                and re.fullmatch(r"[0-9a-f]{64}", checkpoint_fingerprint) is not None,
                f"checkpoint fingerprint malformed for {name}", errors,
            )
        require(tuple(payload.get("retrained_sqi_model_names", ())) == NOISE_RETRAINED, "retrained SQI model list mismatch", errors)
        factorial = payload.get("source_sqi_input_x_quality_gate_2x2", {})
        expected_factorial = {
            "source0_gate0": "trained_model_robustness.sqi_source0_gate0",
            "source0_gate1": "trained_model_robustness.sqi_source0_gate1",
            "source1_gate0": "trained_model_robustness.sqi_source1_gate0",
            "source1_gate1": "conditions (primary trust_full)",
        }
        for key, value in expected_factorial.items():
            require(factorial.get(key) == value, f"2x2 mapping mismatch: {key}", errors)
        guards = payload.get("protocol_guards", {})
        for key in (
            "thresholds_fold9_only", "density_fit_folds1_8_only",
            "density_reference_clean_fold9_only", "hrv_imputation_folds1_8_only",
            "noise_realisation_paired_across_snr",
        ):
            require(guards.get(key) is True, f"protocol guard is false/missing: {key}", errors)
        require(guards.get("test_tuning") is False, "test_tuning guard is not false", errors)
        require(guards.get("all_noisy_ecg_sources_recomputed") == ["sqi6", "quality", "hrv8", "spec36"], "noisy-source recomputation guard mismatch", errors)
        require(guards.get("score_direction") == "higher means reject / more OOD", "risk direction mismatch", errors)

        raw_info = payload.get("raw_npz", {})
        raw_path = resolve_declared_file(raw_info.get("path", ""), path)
        audit["curves_path"] = str(raw_path)
        require(
            raw_path.resolve() == path.with_name(f"seed_{seed}_curves.npz").resolve(),
            "raw_npz.path is not the canonical sibling NPZ", errors,
        )
        require(raw_path.is_file(), "curves NPZ is missing", errors)
        if raw_path.is_file():
            actual_sha = sha256_file(raw_path)
            audit["curves_sha256"] = actual_sha
            require(actual_sha == raw_info.get("sha256"), "curves NPZ SHA-256 mismatch", errors)
            headers = npz_headers(raw_path)
            audit["npz_header"] = headers
            required = {
                "snr_db", "snr_label", "test_y", "test_index", "test_record_id",
                "test_patient", "rare_ids", "class_names", "trust_pred",
                "softmax_pred", "softmax_msp_risk", "sqi6", "quality", "vacuity",
                "density", "composite", "sqi_plus_composite", "source_w", "source_u",
            }
            require(required.issubset(headers), f"curves NPZ keys missing: {sorted(required - set(headers))}", errors)
            require(all(row["dtype_kind"] != "O" for row in headers.values()), "curves NPZ contains object dtype", errors)
            if required.issubset(headers):
                condition_count = len(NOISE_CONDITIONS)
                test_shape = headers["test_y"]["shape"]
                n = test_shape[0] if len(test_shape) == 1 else -1
                require(n > 0, "invalid test_y shape", errors)
                for key in ("test_index", "test_record_id", "test_patient"):
                    require(headers[key]["shape"] == [n], f"{key} shape mismatch", errors)
                require(headers["snr_db"]["shape"] == [condition_count], "snr_db shape mismatch", errors)
                require(headers["snr_label"]["shape"] == [condition_count], "snr_label shape mismatch", errors)
                for key in ("trust_pred", "softmax_pred", "softmax_msp_risk", "quality", "vacuity", "density", "composite", "sqi_plus_composite"):
                    require(headers[key]["shape"] == [condition_count, n], f"{key} shape mismatch", errors)
                require(headers["sqi6"]["shape"] == [condition_count, n, 6], "sqi6 shape mismatch", errors)
                for key in ("source_w", "source_u"):
                    require(headers[key]["shape"] == [condition_count, n, 4], f"{key} shape mismatch", errors)
                with np.load(raw_path, allow_pickle=False) as archive:
                    labels = np.asarray(archive["test_y"])
                    indices = np.asarray(archive["test_index"])
                    snr_labels = tuple(np.asarray(archive["snr_label"]).astype(str).tolist())
                    names = np.asarray(archive["class_names"]).astype(str).tolist()
                    npz_rare = np.asarray(archive["rare_ids"]).astype(int).tolist()
                    require(snr_labels == NOISE_CONDITIONS, "NPZ SNR labels mismatch", errors)
                    require(names == class_names, "NPZ class names mismatch", errors)
                    require(npz_rare == rare_ids, "NPZ rare IDs mismatch", errors)
                    require(np.all((labels >= 0) & (labels < n_classes)), "NPZ labels outside class range", errors)
                    require(len(np.unique(indices)) == n, "test indices are not unique", errors)
                    audit["label_sha256"] = sha256_array(labels)
                    audit["test_index_sha256"] = sha256_array(indices)
                    audit["test_record_id_sha256"] = sha256_array(
                        np.asarray(archive["test_record_id"]).astype(str)
                    )
                    audit["test_patient_sha256"] = sha256_array(
                        np.asarray(archive["test_patient"]).astype(str)
                    )
        audit["valid"] = not errors
        return (payload if not errors else None), audit
    except Exception as exc:
        errors.append(f"audit exception: {type(exc).__name__}: {exc}")
        return None, audit


def audit_inputs(wearables_root: Path, noise_root: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any], list[dict[str, Any]]]:
    audits: list[dict[str, Any]] = []
    wearable_records: list[dict[str, Any]] = []
    noise_records: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []

    expected_wearable_paths: set[Path] = set()
    for dataset, config in DATASETS.items():
        for heldout, model, seed in itertools.product(config["subjects"], config["models"], WEARABLE_SEEDS):
            path = wearables_root / dataset / f"loso_{heldout}" / model / f"seed_{seed}.json"
            expected_wearable_paths.add(path.resolve())
            payload, cell_audit = audit_wearable_cell(path, dataset, heldout, model, seed)
            audits.append(cell_audit)
            if payload is None:
                for message in cell_audit["errors"]:
                    add_issue(issues, "wearable", cell_audit["cell"], message)
            else:
                wearable_records.append({"path": path, "payload": payload, "audit": cell_audit})

    for path in sorted(wearables_root.rglob("seed_*.json")):
        if path.resolve() in expected_wearable_paths:
            continue
        try:
            payload = load_json(path)
        except Exception:
            continue
        if payload.get("schema") == WEARABLE_SCHEMA:
            add_issue(issues, "wearable", str(path), "unexpected extra wearable result cell")

    noise_index = locate_noise_files(noise_root)
    used_noise_paths: set[Path] = set()
    for seed in NOISE_SEEDS:
        candidates = noise_index.get(seed, [])
        if len(candidates) != 1:
            placeholder = noise_root / "canonical" / f"seed_{seed}.json"
            cell_audit = {
                "kind": "noise", "cell": f"noise/canonical/seed_{seed}",
                "expected_json": str(placeholder), "present": bool(candidates),
                "valid": False,
                "errors": ["missing JSON" if not candidates else f"duplicate canonical candidates: {[str(item) for item in candidates]}"],
            }
            audits.append(cell_audit)
            for message in cell_audit["errors"]:
                add_issue(issues, "noise", cell_audit["cell"], message)
            continue
        path = candidates[0]
        used_noise_paths.add(path.resolve())
        payload, cell_audit = audit_noise_cell(path, seed)
        audits.append(cell_audit)
        if payload is None:
            for message in cell_audit["errors"]:
                add_issue(issues, "noise", cell_audit["cell"], message)
        else:
            noise_records.append({"path": path, "payload": payload, "audit": cell_audit})
    for seed, paths in noise_index.items():
        for path in paths:
            if path.resolve() not in used_noise_paths:
                add_issue(issues, "noise", str(path), f"unexpected extra noise result for seed {seed}")

    wearable_configs = {canonical_hash(record["audit"]["configuration"]) for record in wearable_records}
    if len(wearable_configs) > 1:
        add_issue(issues, "wearable", "configuration", "canonical configuration differs across valid cells")
    wearable_label_groups: dict[tuple[str, str], set[tuple[str, str]]] = defaultdict(set)
    for record in wearable_records:
        payload, cell_audit = record["payload"], record["audit"]
        wearable_label_groups[(payload["dataset"], payload["heldout_subject"])].add(
            (cell_audit["label_sha256"], cell_audit["subject_sha256"])
        )
    for (dataset, heldout), fingerprints in wearable_label_groups.items():
        if len(fingerprints) != 1:
            add_issue(
                issues, "wearable", f"{dataset}/{heldout}",
                "test labels/subject vector differ across models or seeds",
            )
    noise_signatures = set()
    for record in noise_records:
        payload = record["payload"]
        signature = {
            "configuration": record["audit"]["configuration"],
            "split": payload.get("split"), "n_classes": payload.get("n_classes"),
            "class_names": payload.get("class_names"), "rare_definition": payload.get("rare_definition"),
            "rare_ids": payload.get("rare_ids"), "rare_names": payload.get("rare_names"),
            "quality_configs": payload.get("quality_configs"),
            "condition_names": list(payload.get("conditions", {})),
            "inference_condition_names": list(payload.get("sqi_coefficient_sensitivity_inference_only", {})),
            "trained_model_names": list(payload.get("trained_model_robustness", {})),
            "retrained_names": payload.get("retrained_sqi_model_names"),
            "factorial": payload.get("source_sqi_input_x_quality_gate_2x2"),
            "protocol_guards": payload.get("protocol_guards"),
            "noise_protocol": payload.get("noise_protocol"),
        }
        noise_signatures.add(canonical_hash(signature))
    if len(noise_signatures) > 1:
        add_issue(issues, "noise", "configuration", "canonical protocol differs across valid seeds")
    noise_test_fingerprints = {
        (
            record["audit"]["label_sha256"],
            record["audit"]["test_index_sha256"],
            record["audit"]["test_record_id_sha256"],
            record["audit"]["test_patient_sha256"],
        )
        for record in noise_records
    }
    if len(noise_test_fingerprints) > 1:
        add_issue(issues, "noise", "test-fold", "test labels/indices/records/patients differ across seeds")

    completion = {
        "schema": SCRIPT_VERSION,
        "expected": {
            "wearable_json": 345, "wearable_prediction_npz": 345,
            "mhealth": {"subjects": 10, "models": 4, "seeds": list(WEARABLE_SEEDS), "cells": 120},
            "wesad": {"subjects": 15, "models": 5, "seeds": list(WEARABLE_SEEDS), "cells": 225},
            "noise_json": 3, "noise_curves_npz": 3, "noise_seeds": list(NOISE_SEEDS),
        },
        "observed_valid": {
            "wearable_cells": len(wearable_records), "noise_cells": len(noise_records),
        },
        "complete": len(wearable_records) == 345 and len(noise_records) == 3 and not issues,
        "issue_count": len(issues),
        "issues": issues,
        "cells": audits,
    }
    return wearable_records, noise_records, completion, issues


def flatten_wearables(records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        payload = record["payload"]
        for source_key, section in WEARABLE_SECTIONS.items():
            for metric, value in flatten_numbers(payload.get(source_key, {})):
                rows.append({
                    "dataset": payload["dataset"], "model": payload["model"],
                    "heldout_subject": payload["heldout_subject"], "seed": payload["seed"],
                    "section": section, "metric": metric,
                    "metric_id": f"{section}.{metric}", "value": value,
                    "json_path": str(record["path"]),
                })
    return rows


def summary_stats(values: Sequence[float], confidence: float = 0.95) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    n = len(array)
    mean = float(np.mean(array)) if n else None
    if n < 2:
        return {"n": n, "mean": mean, "sd": None, "ci_level": confidence, "ci_low": None, "ci_high": None}
    sd = float(np.std(array, ddof=1))
    half = float(stats.t.ppf((1.0 + confidence) / 2.0, n - 1) * sd / math.sqrt(n))
    return {
        "n": n, "mean": mean, "sd": sd, "ci_level": confidence,
        "ci_low": mean - half, "ci_high": mean + half,
    }


def wearable_seed_means(fold_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in fold_rows:
        grouped[(row["dataset"], row["model"], row["section"], row["metric"], row["metric_id"], row["seed"])].append(row)
    result = []
    for key, rows in sorted(grouped.items(), key=lambda item: tuple(str(value) for value in item[0])):
        dataset, model, section, metric, metric_id, seed = key
        expected = list(DATASETS[dataset]["subjects"])
        values_by_subject = defaultdict(list)
        for row in rows:
            values_by_subject[row["heldout_subject"]].append(float(row["value"]))
        observed = [subject for subject in expected if subject in values_by_subject]
        unexpected = sorted(set(values_by_subject) - set(expected))
        duplicates = {subject: len(values) for subject, values in values_by_subject.items() if len(values) != 1}
        values = [values_by_subject[subject][0] for subject in observed if len(values_by_subject[subject]) == 1]
        result.append({
            "dataset": dataset, "model": model, "section": section, "metric": metric,
            "metric_id": metric_id, "seed": seed,
            "subject_mean": float(np.mean(values)) if values else None,
            "n_subjects_observed": len(values), "n_subjects_expected": len(expected),
            "complete_subjects": observed == expected and not unexpected and not duplicates,
            "missing_subjects": [subject for subject in expected if subject not in observed],
            "unexpected_subjects": unexpected,
            "duplicate_subject_counts": duplicates,
        })
    return result


def wearable_summaries(seed_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in seed_rows:
        grouped[(row["dataset"], row["model"], row["section"], row["metric"], row["metric_id"])].append(row)
    result = []
    for key, rows in sorted(grouped.items(), key=lambda item: tuple(str(value) for value in item[0])):
        values = [float(row["subject_mean"]) for row in rows if row["subject_mean"] is not None]
        seeds = sorted(int(row["seed"]) for row in rows if row["subject_mean"] is not None)
        summary = summary_stats(values)
        result.append({
            "dataset": key[0], "model": key[1], "section": key[2],
            "metric": key[3], "metric_id": key[4], **summary,
            "seeds_observed": seeds, "seeds_expected": list(WEARABLE_SEEDS),
            "complete_seeds": seeds == list(WEARABLE_SEEDS) and all(row["complete_subjects"] for row in rows),
        })
    return result


def holm_adjust(pvalues: Sequence[float | None]) -> list[float | None]:
    result: list[float | None] = [None] * len(pvalues)
    valid = [(index, float(value)) for index, value in enumerate(pvalues) if value is not None and math.isfinite(float(value))]
    ordered = sorted(valid, key=lambda item: item[1])
    running = 0.0
    m = len(ordered)
    for rank, (index, value) in enumerate(ordered):
        running = max(running, (m - rank) * value)
        result[index] = min(1.0, running)
    return result


def one_sample_t(values: Sequence[float]) -> tuple[float | None, float | None, float | None]:
    array = np.asarray(values, dtype=np.float64)
    if len(array) < 2:
        return None, None, None
    sd = float(np.std(array, ddof=1))
    mean = float(np.mean(array))
    if sd <= 0.0:
        return (0.0 if mean == 0.0 else math.copysign(math.inf, mean), 1.0 if mean == 0.0 else 0.0, None)
    statistic = mean / (sd / math.sqrt(len(array)))
    pvalue = float(2.0 * stats.t.sf(abs(statistic), len(array) - 1))
    return float(statistic), pvalue, float(mean / sd)


def cluster_bootstrap(
    subject_differences: Mapping[str, Sequence[float]], repetitions: int, seed: int,
) -> dict[str, Any]:
    subjects = sorted(subject_differences)
    cluster_means = np.asarray(
        [np.mean(np.asarray(subject_differences[subject], dtype=np.float64)) for subject in subjects],
        dtype=np.float64,
    )
    if not len(cluster_means):
        return {"clusters": 0, "repetitions": repetitions, "ci_low": None, "ci_high": None, "pvalue": None}
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(cluster_means), size=(repetitions, len(cluster_means)))
    sampled = cluster_means[indices].mean(axis=1)
    lower, upper = np.quantile(sampled, (0.025, 0.975))
    below = (np.count_nonzero(sampled <= 0.0) + 1.0) / (repetitions + 1.0)
    above = (np.count_nonzero(sampled >= 0.0) + 1.0) / (repetitions + 1.0)
    return {
        "clusters": len(cluster_means), "repetitions": repetitions,
        "ci_low": float(lower), "ci_high": float(upper),
        "pvalue": float(min(1.0, 2.0 * min(below, above))),
    }


def wearable_comparisons(
    fold_rows: Sequence[Mapping[str, Any]], bootstrap: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    index: dict[tuple[str, str, str, int], dict[str, float]] = defaultdict(dict)
    for row in fold_rows:
        index[(row["dataset"], row["metric_id"], row["heldout_subject"], int(row["seed"]))][row["model"]] = float(row["value"])
    differences: list[dict[str, Any]] = []
    for (dataset, metric_id, subject, seed), values in sorted(index.items()):
        if "trust_full" not in values:
            continue
        for comparator in DATASETS[dataset]["models"]:
            if comparator == "trust_full" or comparator not in values:
                continue
            differences.append({
                "dataset": dataset, "metric_id": metric_id,
                "method_a": "trust_full", "method_b": comparator,
                "heldout_subject": subject, "seed": seed,
                "value_a": values["trust_full"], "value_b": values[comparator],
                "difference_a_minus_b": values["trust_full"] - values[comparator],
            })
    grouped: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in differences:
        grouped[(row["dataset"], row["metric_id"], row["method_a"], row["method_b"])].append(row)
    comparisons: list[dict[str, Any]] = []
    for key, rows in sorted(grouped.items()):
        subject_values: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            subject_values[row["heldout_subject"]].append(row["difference_a_minus_b"])
        cluster_means = [float(np.mean(values)) for _, values in sorted(subject_values.items())]
        t_stat, t_p, cohen_dz = one_sample_t(cluster_means)
        boot = cluster_bootstrap(subject_values, bootstrap, stable_seed("wearable", *key, bootstrap))
        comparisons.append({
            "dataset": key[0], "metric_id": key[1], "method_a": key[2], "method_b": key[3],
            "difference_direction": "method_a_minus_method_b",
            "n_subject_seed_pairs": len(rows), "n_subject_clusters": len(subject_values),
            "mean_paired_difference": float(np.mean([row["difference_a_minus_b"] for row in rows])),
            "mean_subject_cluster_difference": float(np.mean(cluster_means)),
            "paired_t_on_subject_means_statistic": t_stat,
            "paired_t_on_subject_means_pvalue": t_p,
            "paired_cohen_dz_on_subject_means": cohen_dz,
            "cluster_bootstrap_repetitions": bootstrap,
            "cluster_bootstrap_ci_low": boot["ci_low"],
            "cluster_bootstrap_ci_high": boot["ci_high"],
            "cluster_bootstrap_pvalue": boot["pvalue"],
        })
    families: dict[tuple[str, str], list[int]] = defaultdict(list)
    for index_row, row in enumerate(comparisons):
        families[(row["dataset"], row["metric_id"])].append(index_row)
    for family_indices in families.values():
        t_adjusted = holm_adjust([comparisons[index]["paired_t_on_subject_means_pvalue"] for index in family_indices])
        b_adjusted = holm_adjust([comparisons[index]["cluster_bootstrap_pvalue"] for index in family_indices])
        for position, index_row in enumerate(family_indices):
            comparisons[index_row]["paired_t_holm_pvalue"] = t_adjusted[position]
            comparisons[index_row]["cluster_bootstrap_holm_pvalue"] = b_adjusted[position]
            comparisons[index_row]["holm_family_size"] = len(family_indices)
    return differences, comparisons


def add_noise_values(
    rows: list[dict[str, Any]], seed: int, category: str, context: str,
    variant: str, node: Any, prefix: str = "",
) -> None:
    for metric, value in flatten_numbers(node, prefix):
        rows.append({
            "seed": seed, "category": category, "context": context,
            "variant": variant, "metric": metric, "value": value,
        })


def flatten_noise(records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        payload = record["payload"]
        seed = int(payload["seed"])
        for condition, report in payload.get("conditions", {}).items():
            core = {key: report.get(key) for key in ("snr_db", "achieved_snr", "diagnosis", "gate_correlations", "mean_quality", "mean_vacuity") if key in report}
            add_noise_values(rows, seed, "model", condition, "trust_full", core)
            vacuity_selection = report.get("selection", {}).get("vacuity_only", {}).get("condition_matched_fold9")
            if vacuity_selection is not None:
                add_noise_values(rows, seed, "model", condition, "trust_full", vacuity_selection, "selective")
            for method, method_report in report.get("selection", {}).items():
                add_noise_values(rows, seed, "score_selection", condition, method, method_report)
            for method, detection in report.get("clean_vs_corrupted_detection", {}).items():
                add_noise_values(rows, seed, "corruption_detector", condition, method, detection)

        for condition, configurations in payload.get("sqi_coefficient_sensitivity_inference_only", {}).items():
            for configuration, report in configurations.items():
                add_noise_values(rows, seed, "inference_sqi", condition, configuration, report)

        for model, conditions in payload.get("trained_model_robustness", {}).items():
            for condition, report in conditions.items():
                common = {key: report.get(key) for key in ("diagnosis", "fold9_accuracy", "gate_correlations") if key in report}
                add_noise_values(rows, seed, "model", condition, model, common)
                selective = report.get("selective_vacuity_fold9_selected", report.get("selective_msp"))
                if selective is not None:
                    add_noise_values(rows, seed, "model", condition, model, selective, "selective")

        source_corruption = payload.get("source_corruption") or {}
        context = f"snr={source_corruption.get('snr_db')}"
        for variant, report in source_corruption.get("variants", {}).items():
            add_noise_values(rows, seed, "source_corruption", context, variant, report)
    return rows


def noise_summaries(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, str], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["category"], row["context"], row["variant"], row["metric"])].append(row)
    result = []
    for key, values in sorted(grouped.items()):
        seed_values = {int(row["seed"]): float(row["value"]) for row in values}
        summary = summary_stats([seed_values[seed] for seed in sorted(seed_values)])
        result.append({
            "category": key[0], "context": key[1], "variant": key[2], "metric": key[3],
            **summary, "seeds_observed": sorted(seed_values), "seeds_expected": list(NOISE_SEEDS),
            "complete_seeds": sorted(seed_values) == list(NOISE_SEEDS),
        })
    return result


def noise_reference(category: str, variants: Iterable[str]) -> str | None:
    available = set(variants)
    preferences = {
        "model": "trust_full",
        "inference_sqi": "canonical",
        "score_selection": "composite",
        "corruption_detector": "composite",
        "source_corruption": "full_acquisition",
    }
    preferred = preferences.get(category)
    return preferred if preferred in available else None


def noise_comparisons(rows: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    index: dict[tuple[str, str, str, int], dict[str, float]] = defaultdict(dict)
    variants_by_family: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    for row in rows:
        family = (row["category"], row["context"], row["metric"])
        index[(*family, int(row["seed"]))][row["variant"]] = float(row["value"])
        variants_by_family[family].add(row["variant"])
    differences: list[dict[str, Any]] = []
    for family, variants in sorted(variants_by_family.items()):
        reference = noise_reference(family[0], variants)
        if reference is None:
            continue
        for comparator in sorted(variants - {reference}):
            for seed in NOISE_SEEDS:
                values = index.get((*family, seed), {})
                if reference not in values or comparator not in values:
                    continue
                differences.append({
                    "category": family[0], "context": family[1], "metric": family[2],
                    "variant_a": reference, "variant_b": comparator, "seed": seed,
                    "value_a": values[reference], "value_b": values[comparator],
                    "difference_a_minus_b": values[reference] - values[comparator],
                })
    grouped: dict[tuple[str, str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in differences:
        grouped[(row["category"], row["context"], row["metric"], row["variant_a"], row["variant_b"])].append(row)
    comparisons = []
    for key, pair_rows in sorted(grouped.items()):
        values = [row["difference_a_minus_b"] for row in sorted(pair_rows, key=lambda item: item["seed"])]
        t_stat, pvalue, cohen_dz = one_sample_t(values)
        summary = summary_stats(values)
        comparisons.append({
            "category": key[0], "context": key[1], "metric": key[2],
            "variant_a": key[3], "variant_b": key[4],
            "difference_direction": "variant_a_minus_variant_b",
            "n_paired_seeds": len(values), "mean_paired_difference": summary["mean"],
            "sd_paired_difference": summary["sd"], "paired_difference_ci_low": summary["ci_low"],
            "paired_difference_ci_high": summary["ci_high"], "paired_t_statistic": t_stat,
            "paired_t_pvalue": pvalue, "paired_cohen_dz": cohen_dz,
            "seeds_observed": sorted(row["seed"] for row in pair_rows),
        })
    families: dict[tuple[str, str, str], list[int]] = defaultdict(list)
    for index_row, row in enumerate(comparisons):
        families[(row["category"], row["context"], row["metric"])].append(index_row)
    for family_indices in families.values():
        adjusted = holm_adjust([comparisons[index]["paired_t_pvalue"] for index in family_indices])
        for position, index_row in enumerate(family_indices):
            comparisons[index_row]["paired_t_holm_pvalue"] = adjusted[position]
            comparisons[index_row]["holm_family_size"] = len(family_indices)
    return differences, comparisons


def latex_escape(value: Any) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
        "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(character, character) for character in text)


def format_estimate(row: Mapping[str, Any]) -> str:
    mean = row.get("mean")
    if mean is None:
        return "NA"
    sd = row.get("sd")
    low, high = row.get("ci_low"), row.get("ci_high")
    if sd is None or low is None or high is None:
        return f"{mean:.6g}"
    return f"{mean:.6g} $\\pm$ {sd:.6g} [{low:.6g}, {high:.6g}]"


def latex_tables(wearable: Sequence[Mapping[str, Any]], noise: Sequence[Mapping[str, Any]]) -> str:
    lines = [
        "% Auto-generated by aggregate_auxiliary.py; values are mean +/- sample SD [95% t-CI].",
        r"\begin{longtable}{lllll}",
        r"Dataset & Model & Section & Metric & Estimate \\ \hline",
    ]
    for row in wearable:
        lines.append(" & ".join((
            latex_escape(row["dataset"]), latex_escape(row["model"]),
            latex_escape(row["section"]), latex_escape(row["metric"]),
            format_estimate(row),
        )) + r" \\")
    lines.extend((r"\end{longtable}", "", r"\begin{longtable}{lllll}", r"Analysis & Context & Variant & Metric & Estimate \\ \hline"))
    for row in noise:
        lines.append(" & ".join((
            latex_escape(row["category"]), latex_escape(row["context"]),
            latex_escape(row["variant"]), latex_escape(row["metric"]),
            format_estimate(row),
        )) + r" \\")
    lines.extend((r"\end{longtable}", ""))
    return "\n".join(lines)


def completion_rows(completion: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for cell in completion["cells"]:
        rows.append({
            "kind": cell.get("kind"), "cell": cell.get("cell"),
            "present": cell.get("present"), "valid": cell.get("valid"),
            "json_path": cell.get("expected_json"),
            "binary_path": cell.get("prediction_path", cell.get("curves_path")),
            "json_sha256": cell.get("json_sha256"),
            "binary_sha256": cell.get("prediction_sha256", cell.get("curves_sha256")),
            "errors": " | ".join(cell.get("errors", [])),
        })
    return rows


def write_outputs(
    output_dir: Path, completion: dict[str, Any], wearable_fold: list[dict[str, Any]],
    wearable_seed: list[dict[str, Any]], wearable_summary: list[dict[str, Any]],
    wearable_differences: list[dict[str, Any]], wearable_comparison: list[dict[str, Any]],
    noise_values: list[dict[str, Any]], noise_summary: list[dict[str, Any]],
    noise_differences: list[dict[str, Any]], noise_comparison: list[dict[str, Any]],
    args: argparse.Namespace,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []

    def write_json(name: str, payload: Any) -> None:
        path = output_dir / name
        atomic_json(path, payload, pretty=name != "auxiliary_results.json")
        generated.append(path)

    def write_csv(name: str, rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> None:
        path = output_dir / name
        atomic_csv(path, rows, fields)
        generated.append(path)

    write_json("completion_matrix.json", completion)
    write_csv("completion_matrix.csv", completion_rows(completion), (
        "kind", "cell", "present", "valid", "json_path", "binary_path",
        "json_sha256", "binary_sha256", "errors",
    ))
    combined = {
        "schema": SCRIPT_VERSION, "created_at_utc": utc_now(),
        "design": {
            "wearable": "per-seed mean across LOSO subjects, then three-seed mean/SD/95% Student-t CI; paired TrustOOD contrasts at subject x seed; subject-cluster bootstrap; Holm within dataset x metric",
            "noise": "three-seed mean/SD/95% Student-t CI; reference-vs-variant paired-seed t comparisons; Holm within analysis x context x metric",
            "missing_data": "not imputed",
            "difference_direction": "reference minus comparator; interpret sign using the metric definition",
        },
        "completion": completion,
        "wearable": {
            "fold_values": wearable_fold, "seed_subject_means": wearable_seed,
            "summary": wearable_summary, "paired_differences": wearable_differences,
            "comparisons": wearable_comparison,
        },
        "noise_sqi": {
            "seed_values": noise_values, "summary": noise_summary,
            "paired_differences": noise_differences, "comparisons": noise_comparison,
        },
    }
    write_json("auxiliary_results.json", combined)
    write_csv("wearable_fold_values.csv", wearable_fold, (
        "dataset", "model", "heldout_subject", "seed", "section", "metric",
        "metric_id", "value", "json_path",
    ))
    write_csv("wearable_seed_subject_means.csv", wearable_seed, (
        "dataset", "model", "section", "metric", "metric_id", "seed", "subject_mean",
        "n_subjects_observed", "n_subjects_expected", "complete_subjects",
        "missing_subjects", "unexpected_subjects", "duplicate_subject_counts",
    ))
    summary_fields = (
        "dataset", "model", "section", "metric", "metric_id", "n", "mean", "sd",
        "ci_level", "ci_low", "ci_high", "seeds_observed", "seeds_expected", "complete_seeds",
    )
    write_csv("wearable_summary.csv", wearable_summary, summary_fields)
    write_csv("wearable_paired_differences.csv", wearable_differences, (
        "dataset", "metric_id", "method_a", "method_b", "heldout_subject", "seed",
        "value_a", "value_b", "difference_a_minus_b",
    ))
    write_csv("wearable_comparisons.csv", wearable_comparison, (
        "dataset", "metric_id", "method_a", "method_b", "difference_direction",
        "n_subject_seed_pairs", "n_subject_clusters", "mean_paired_difference",
        "mean_subject_cluster_difference", "paired_t_on_subject_means_statistic",
        "paired_t_on_subject_means_pvalue", "paired_t_holm_pvalue",
        "paired_cohen_dz_on_subject_means", "cluster_bootstrap_repetitions",
        "cluster_bootstrap_ci_low", "cluster_bootstrap_ci_high",
        "cluster_bootstrap_pvalue", "cluster_bootstrap_holm_pvalue", "holm_family_size",
    ))
    write_csv("noise_seed_values.csv", noise_values, (
        "seed", "category", "context", "variant", "metric", "value",
    ))
    write_csv("noise_summary.csv", noise_summary, (
        "category", "context", "variant", "metric", "n", "mean", "sd", "ci_level",
        "ci_low", "ci_high", "seeds_observed", "seeds_expected", "complete_seeds",
    ))
    write_csv("noise_paired_differences.csv", noise_differences, (
        "category", "context", "metric", "variant_a", "variant_b", "seed",
        "value_a", "value_b", "difference_a_minus_b",
    ))
    write_csv("noise_comparisons.csv", noise_comparison, (
        "category", "context", "metric", "variant_a", "variant_b", "difference_direction",
        "n_paired_seeds", "mean_paired_difference", "sd_paired_difference",
        "paired_difference_ci_low", "paired_difference_ci_high", "paired_t_statistic",
        "paired_t_pvalue", "paired_t_holm_pvalue", "paired_cohen_dz", "seeds_observed",
        "holm_family_size",
    ))
    latex_path = output_dir / "auxiliary_tables.tex"
    atomic_text(latex_path, latex_tables(wearable_summary, noise_summary))
    generated.append(latex_path)

    input_files = []
    for cell in completion["cells"]:
        if cell.get("json_sha256"):
            input_files.append({"role": f"{cell['kind']}_json", "path": cell["expected_json"], "sha256": cell["json_sha256"]})
        binary_path = cell.get("prediction_path", cell.get("curves_path"))
        binary_hash = cell.get("prediction_sha256", cell.get("curves_sha256"))
        if binary_path and binary_hash:
            input_files.append({"role": f"{cell['kind']}_npz", "path": binary_path, "sha256": binary_hash})
    manifest = {
        "schema": SCRIPT_VERSION,
        "created_at_utc": utc_now(),
        "command": sys.argv,
        "arguments": {
            "wearables_root": str(args.wearables_root), "noise_root": str(args.noise_root),
            "output_dir": str(args.output_dir), "bootstrap": args.bootstrap,
            "fail_on_incomplete": args.fail_on_incomplete,
        },
        "script": {"path": str(Path(__file__).resolve()), "sha256": sha256_file(Path(__file__).resolve())},
        "environment": {
            "python": platform.python_version(), "platform": platform.platform(),
            "numpy": np.__version__, "scipy": scipy.__version__,
        },
        "completion": {
            "complete": completion["complete"], "issue_count": completion["issue_count"],
            "wearable_valid": completion["observed_valid"]["wearable_cells"],
            "noise_valid": completion["observed_valid"]["noise_cells"],
        },
        "inputs": input_files,
        "outputs": [
            {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
            for path in generated
        ],
        "manifest_note": "manifest.json is intentionally not self-hashed",
    }
    atomic_json(output_dir / "manifest.json", manifest)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--wearables-root", required=True, type=Path)
    parser.add_argument("--noise-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=10000, help="subject-cluster bootstrap repetitions")
    parser.add_argument("--fail-on-incomplete", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.bootstrap < 100:
        raise SystemExit("--bootstrap must be at least 100")
    args.wearables_root = args.wearables_root.resolve()
    args.noise_root = args.noise_root.resolve()
    args.output_dir = args.output_dir.resolve()
    if not args.wearables_root.is_dir():
        raise SystemExit(f"wearables root not found: {args.wearables_root}")
    if not args.noise_root.is_dir():
        raise SystemExit(f"noise root not found: {args.noise_root}")
    for read_only_root in (args.wearables_root, args.noise_root):
        try:
            args.output_dir.relative_to(read_only_root)
        except ValueError:
            continue
        raise SystemExit("--output-dir must be outside both read-only result roots")

    wearable_records, noise_records, completion, _ = audit_inputs(args.wearables_root, args.noise_root)
    wearable_fold = flatten_wearables(wearable_records)
    wearable_seed = wearable_seed_means(wearable_fold)
    wearable_summary = wearable_summaries(wearable_seed)
    wearable_differences, wearable_comparison = wearable_comparisons(wearable_fold, args.bootstrap)
    noise_values = flatten_noise(noise_records)
    noise_summary = noise_summaries(noise_values)
    noise_differences, noise_comparison = noise_comparisons(noise_values)
    write_outputs(
        args.output_dir, completion, wearable_fold, wearable_seed, wearable_summary,
        wearable_differences, wearable_comparison, noise_values, noise_summary,
        noise_differences, noise_comparison, args,
    )
    print(
        f"[aggregate] wearable={len(wearable_records)}/345 noise={len(noise_records)}/3 "
        f"issues={completion['issue_count']} output={args.output_dir}", flush=True,
    )
    return 2 if args.fail_on_incomplete and not completion["complete"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
