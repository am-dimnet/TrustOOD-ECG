#!/usr/bin/env python3
"""Zero-copy adapters for the TrustFedECG PTB-XL and Chapman caches.

The TrustFedECG waveform caches are the authoritative signal tensors.  They are
opened read-only with ``numpy.load(..., mmap_mode="r")`` and are never copied to
another full-size waveform file.  TrustFedECG stores int16 microvolts, so this
module exposes a lazy millivolt view which converts only the requested slice to
float32 and divides it by 1000.

Small, reproducible sidecars can be prepared for Paper46 revision experiments:

* PTB-XL metadata, complete raw SCP code dictionaries, and two 70-class labels:
  ``y_legacy`` exactly reproduces Paper41's full-cohort frequency rule, while
  ``y_trainfreq`` uses code-presence frequencies from official folds 1--8 only.
* Strict unknown-code OOD splits for train-frequency thresholds 40, 80 and 160.
  Every training/validation record containing a held-out raw code is purged.
* Six SQIs, eight HRV descriptors, 36 spectral descriptors and scalar quality.
  These are computed deterministically in bounded chunks directly from the mmap.

No command in this module writes or rewrites a waveform tensor.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import platform
import sys
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence

import numpy as np
import pandas as pd
import scipy
from scipy import stats as scipy_stats
from scipy.signal import butter, filtfilt, find_peaks, welch


ADAPTER_VERSION = "paper46-data-adapter-v2"
TARGET_FS = 100
TARGET_LEN = 1000
N_LEADS = 12
UV_PER_MV = 1000.0
BASELINE_CODES = frozenset({"SR", "NORM"})
DEFAULT_OOD_THRESHOLDS = (40, 80, 160)

DEFAULT_TRUSTFED_CACHE = Path("/root/autodl-tmp/TrustFedECG/cache")
DEFAULT_PTBXL_RAW = Path(
    "/root/autodl-tmp/Dataset/"
    "ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3"
)
DEFAULT_CHAPMAN_RAW = Path("/root/autodl-tmp/Dataset/chapman-shaoxing-1.0.0")
DEFAULT_OUTPUT_DIR = DEFAULT_TRUSTFED_CACHE / "paper46_adapter"

HRV_NAMES = (
    "HR",
    "meanRR",
    "SDNN",
    "RMSSD",
    "pNN50",
    "CVRR",
    "RR_range",
    "RR_median",
)
SQI_NAMES = ("kSQI", "abs_skew_SQI", "pSQI_5_15Hz", "basSQI", "flat", "sat")
SPEC_BANDS_HZ = ((0.5, 4.0), (4.0, 15.0), (15.0, 40.0))
SPEC_NAMES = tuple(
    f"lead{lead:02d}_{lo:g}_{hi:g}Hz_relpower"
    for lead in range(N_LEADS)
    for lo, hi in SPEC_BANDS_HZ
)


class AdapterError(RuntimeError):
    """Raised when a cache, metadata table or row alignment is unsafe to use."""


@dataclass(frozen=True)
class DatasetPaths:
    name: str
    signals: Path
    trustfed_meta: Path
    raw_root: Path
    trustfed_manifest: Path


@dataclass
class PTBLabelState:
    raw_codes: list[dict[str, Any]]
    names: list[str]
    labels_legacy: list[str]
    labels_trainfreq: list[str]
    y_legacy: np.ndarray
    y_trainfreq: np.ndarray
    full_presence: Counter[str]
    train_presence: Counter[str]


@dataclass
class DatasetAdapter:
    """Opened dataset sidecars plus a lazy, read-only millivolt signal view."""

    name: str
    signals: "MillivoltSignalView"
    metadata: pd.DataFrame
    valid: np.ndarray
    y_legacy: np.ndarray | None = None
    y_trainfreq: np.ndarray | None = None
    label_names: list[str] | None = None
    sqi6: np.ndarray | None = None
    quality: np.ndarray | None = None
    hrv8: np.ndarray | None = None
    spec36: np.ndarray | None = None

    def valid_indices(self) -> np.ndarray:
        return np.flatnonzero(self.valid)

    def batch(
        self,
        indices: Sequence[int] | np.ndarray,
        *,
        label_version: str = "trainfreq",
        include_signals: bool = True,
    ) -> dict[str, np.ndarray]:
        """Materialise one indexed batch; the full waveform tensor is never converted."""

        raw_indices = np.asarray(indices)
        if raw_indices.dtype == np.bool_:
            raise ValueError("batch indices must be integer row indices, not a boolean mask")
        rows = np.atleast_1d(raw_indices).astype(np.int64, copy=False)
        if rows.ndim != 1:
            raise ValueError("batch indices must be one-dimensional")
        if np.any(rows < 0) or np.any(rows >= len(self.signals)):
            raise IndexError("batch row index is out of bounds")
        if label_version not in {"legacy", "trainfreq", "none"}:
            raise ValueError("label_version must be 'legacy', 'trainfreq' or 'none'")

        result: dict[str, np.ndarray] = {
            "index": rows,
            "valid": self.valid[rows],
        }
        if include_signals:
            # Only these rows become float32 mV; ``signals`` remains an int16 mmap.
            result["signals"] = self.signals[rows]
        labels = self.y_legacy if label_version == "legacy" else self.y_trainfreq
        if label_version != "none" and labels is not None:
            result["y"] = np.asarray(labels[rows])
        for name in ("sqi6", "quality", "hrv8", "spec36"):
            values = getattr(self, name)
            if values is not None:
                result[name] = np.asarray(values[rows])
        return result

    def iter_batches(
        self,
        batch_size: int,
        indices: Sequence[int] | np.ndarray | None = None,
        *,
        label_version: str = "trainfreq",
        include_signals: bool = True,
    ) -> Iterator[dict[str, np.ndarray]]:
        """Yield bounded indexed batches, defaulting to all valid records."""

        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        rows = self.valid_indices() if indices is None else np.asarray(indices)
        if rows.dtype == np.bool_:
            raise ValueError("batch indices must be integer row indices, not a boolean mask")
        rows = np.atleast_1d(rows).astype(np.int64, copy=False)
        if rows.ndim != 1:
            raise ValueError("batch indices must be one-dimensional")
        for start in range(0, len(rows), batch_size):
            yield self.batch(
                rows[start : start + batch_size],
                label_version=label_version,
                include_signals=include_signals,
            )


class MillivoltSignalView:
    """Lazy float32-mV view over a read-only int16-microvolt ``.npy`` mmap."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self._uv = np.load(self.path, mmap_mode="r", allow_pickle=False)
        if not isinstance(self._uv, np.memmap):
            raise AdapterError(f"{self.path} did not open as np.memmap")
        if self._uv.dtype != np.int16:
            raise AdapterError(f"{self.path}: expected int16 microvolts, got {self._uv.dtype}")
        if self._uv.ndim != 3 or tuple(self._uv.shape[1:]) != (N_LEADS, TARGET_LEN):
            raise AdapterError(
                f"{self.path}: expected (N,{N_LEADS},{TARGET_LEN}), got {self._uv.shape}"
            )

    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(self._uv.shape)

    @property
    def dtype(self) -> np.dtype:
        return np.dtype(np.float32)

    @property
    def raw_microvolts(self) -> np.memmap:
        """The underlying read-only mmap; callers must not attempt to mutate it."""

        return self._uv

    def __len__(self) -> int:
        return int(self._uv.shape[0])

    def __getitem__(self, key: Any) -> np.ndarray:
        # Conversion necessarily allocates the requested slice, never the full tensor.
        return np.asarray(self._uv[key], dtype=np.float32) / np.float32(UV_PER_MV)

    def iter_chunks(self, chunk_size: int) -> Iterator[tuple[int, int, np.ndarray]]:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        for start in range(0, len(self), chunk_size):
            stop = min(start + chunk_size, len(self))
            yield start, stop, self[start:stop]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def sha256_array_bytes(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(array)
    return hashlib.sha256(memoryview(contiguous).cast("B")).hexdigest()


def _tmp_path(target: Path) -> Path:
    return target.with_name(f".{target.name}.tmp-{os.getpid()}")


def write_json_atomic(payload: Any, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(target)
    try:
        with tmp.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            tmp.unlink()


def write_jsonl_atomic(rows: Iterable[Mapping[str, Any]], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(target)
    try:
        with tmp.open("w", encoding="utf-8", newline="\n") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
                handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            tmp.unlink()


def write_csv_atomic(frame: pd.DataFrame, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(target)
    try:
        frame.to_csv(tmp, index=False, lineterminator="\n")
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            tmp.unlink()


def write_npy_atomic(array: np.ndarray, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(target)
    try:
        with tmp.open("wb") as handle:
            np.save(handle, array, allow_pickle=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            tmp.unlink()


def write_npz_atomic(target: Path, **arrays: np.ndarray) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(target)
    try:
        with tmp.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, target)
    finally:
        if tmp.exists():
            tmp.unlink()


def canonical_id(value: Any) -> str:
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        integer = text[:-2]
        if integer.lstrip("+-").isdigit():
            return integer
    return text


def bool_array(values: Sequence[Any]) -> np.ndarray:
    series = pd.Series(values)
    if pd.api.types.is_bool_dtype(series):
        return series.to_numpy(dtype=bool)
    if pd.api.types.is_numeric_dtype(series):
        return series.fillna(0).to_numpy(dtype=np.int64) != 0
    lowered = series.fillna("").astype(str).str.strip().str.lower()
    unknown = sorted(set(lowered) - {"true", "false", "1", "0", "yes", "no", ""})
    if unknown:
        raise AdapterError(f"unrecognised boolean values: {unknown[:5]}")
    return lowered.isin({"true", "1", "yes"}).to_numpy(dtype=bool)


def require_columns(frame: pd.DataFrame, columns: Sequence[str], source: Path) -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise AdapterError(f"{source}: missing columns {missing}")


def load_trustfed_meta(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    frame = pd.read_csv(path)
    require_columns(frame, ("record_id", "patient_id", "strat_fold", "valid"), path)
    frame = frame.copy()
    frame["valid"] = bool_array(frame["valid"])
    frame.insert(0, "raw_index", np.arange(len(frame), dtype=np.int64))
    return frame


def parse_scp_codes(value: Any, row_index: int) -> dict[str, Any]:
    if isinstance(value, dict):
        parsed = value
    else:
        try:
            parsed = ast.literal_eval(str(value))
        except (SyntaxError, ValueError) as exc:
            raise AdapterError(f"row {row_index}: invalid scp_codes: {exc}") from exc
    if not isinstance(parsed, dict):
        raise AdapterError(f"row {row_index}: scp_codes must be a dictionary")
    result: dict[str, Any] = {}
    for raw_code, raw_score in parsed.items():
        code = str(raw_code).strip()
        if not code:
            raise AdapterError(f"row {row_index}: empty SCP code")
        if isinstance(raw_score, np.generic):
            score: Any = raw_score.item()
        elif isinstance(raw_score, (int, float, str, bool)) or raw_score is None:
            score = raw_score
        else:
            score = str(raw_score)
        result[code] = score
    return result


def presence_counter(raw_codes: Sequence[Mapping[str, Any]], mask: np.ndarray | None = None) -> Counter[str]:
    if mask is None:
        indices: Iterable[int] = range(len(raw_codes))
    else:
        if len(mask) != len(raw_codes):
            raise AdapterError("presence mask length mismatch")
        indices = np.flatnonzero(mask)
    counts: Counter[str] = Counter()
    for index in indices:
        # A code is present if it is a key, including PTB likelihood 0.0 entries.
        counts.update(set(raw_codes[int(index)].keys()))
    return counts


def salient_label(codes: Mapping[str, Any], frequencies: Mapping[str, int]) -> str:
    findings = [code for code in codes if code not in BASELINE_CODES]
    if findings:
        return min(findings, key=lambda code: (int(frequencies.get(code, 0)), code))
    return "NORM"


def construct_ptb_labels(
    database: pd.DataFrame,
    statement_codes: set[str],
    allow_noncanonical: bool = False,
) -> PTBLabelState:
    require_columns(database, ("ecg_id", "scp_codes", "strat_fold"), Path("ptbxl_database.csv"))
    raw_codes = [parse_scp_codes(value, i) for i, value in enumerate(database["scp_codes"])]
    observed_codes = set().union(*(set(row) for row in raw_codes)) if raw_codes else set()
    undefined = sorted(observed_codes - statement_codes)
    if undefined:
        raise AdapterError(f"raw database contains SCP codes absent from scp_statements.csv: {undefined}")

    full_presence = presence_counter(raw_codes)
    folds = pd.to_numeric(database["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    train_mask = np.isin(folds, np.arange(1, 9, dtype=np.int64))
    train_presence = presence_counter(raw_codes, train_mask)

    labels_legacy = [salient_label(codes, full_presence) for codes in raw_codes]
    labels_trainfreq = [salient_label(codes, train_presence) for codes in raw_codes]

    # This is exactly Paper41: names=sorted(df.label.unique()) under full-cohort counts.
    names = sorted(set(labels_legacy))
    if not allow_noncanonical and len(names) != 70:
        raise AdapterError(f"canonical PTB-XL must yield 70 Paper41 classes, got {len(names)}")
    outside = sorted(set(labels_trainfreq) - set(names))
    if outside:
        raise AdapterError(
            "train-frequency rule selected codes outside the canonical Paper41 class space: "
            f"{outside}"
        )
    name_to_index = {name: index for index, name in enumerate(names)}
    y_legacy = np.asarray([name_to_index[label] for label in labels_legacy], dtype=np.int16)
    y_trainfreq = np.asarray([name_to_index[label] for label in labels_trainfreq], dtype=np.int16)
    return PTBLabelState(
        raw_codes=raw_codes,
        names=names,
        labels_legacy=labels_legacy,
        labels_trainfreq=labels_trainfreq,
        y_legacy=y_legacy,
        y_trainfreq=y_trainfreq,
        full_presence=full_presence,
        train_presence=train_presence,
    )


def load_ptb_sources(
    paths: DatasetPaths, allow_noncanonical: bool = False
) -> tuple[MillivoltSignalView, pd.DataFrame, pd.DataFrame, PTBLabelState, set[str]]:
    database_path = paths.raw_root / "ptbxl_database.csv"
    statements_path = paths.raw_root / "scp_statements.csv"
    if not database_path.is_file():
        raise FileNotFoundError(database_path)
    if not statements_path.is_file():
        raise FileNotFoundError(statements_path)
    database = pd.read_csv(database_path)
    statements = pd.read_csv(statements_path, index_col=0)
    statement_codes = {str(code).strip() for code in statements.index if str(code).strip()}
    state = construct_ptb_labels(database, statement_codes, allow_noncanonical=allow_noncanonical)
    meta = load_trustfed_meta(paths.trustfed_meta)
    signals = MillivoltSignalView(paths.signals)
    return signals, meta, database, state, statement_codes


def audit_ptb_alignment(
    signals: MillivoltSignalView, meta: pd.DataFrame, database: pd.DataFrame
) -> dict[str, Any]:
    n = len(database)
    if len(signals) != n or len(meta) != n:
        raise AdapterError(
            f"PTB row-count mismatch: signals={len(signals)}, meta={len(meta)}, raw={n}"
        )
    raw_ids = np.asarray([canonical_id(value) for value in database["ecg_id"]], dtype=str)
    cache_ids = np.asarray([canonical_id(value) for value in meta["record_id"]], dtype=str)
    if len(set(raw_ids.tolist())) != n:
        raise AdapterError("PTB raw ecg_id values are not unique")
    if len(set(cache_ids.tolist())) != n:
        raise AdapterError("PTB TrustFed record_id values are not unique")
    mismatch = np.flatnonzero(raw_ids != cache_ids)
    if mismatch.size:
        i = int(mismatch[0])
        raise AdapterError(
            f"PTB row order/ecg_id mismatch at {i}: raw={raw_ids[i]!r}, cache={cache_ids[i]!r}"
        )

    raw_patient = np.asarray([canonical_id(value) for value in database["patient_id"]], dtype=str)
    cache_patient = np.asarray([canonical_id(value) for value in meta["patient_id"]], dtype=str)
    if not np.array_equal(raw_patient, cache_patient):
        i = int(np.flatnonzero(raw_patient != cache_patient)[0])
        raise AdapterError(f"PTB patient_id mismatch at row {i}")
    raw_fold = pd.to_numeric(database["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    cache_fold = pd.to_numeric(meta["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    if not np.array_equal(raw_fold, cache_fold):
        i = int(np.flatnonzero(raw_fold != cache_fold)[0])
        raise AdapterError(f"PTB strat_fold mismatch at row {i}")
    if not set(np.unique(raw_fold)).issubset(set(range(1, 11))):
        raise AdapterError(f"PTB unexpected folds: {np.unique(raw_fold).tolist()}")
    return {
        "n_records": n,
        "n_valid": int(meta["valid"].sum()),
        "signals_shape": list(signals.shape),
        "signals_storage_dtype": str(signals.raw_microvolts.dtype),
        "signals_exposed_dtype": "float32",
        "signals_storage_unit": "microvolt",
        "signals_exposed_unit": "mV",
        "scale_divisor": UV_PER_MV,
        "ecg_id_order_exact": True,
        "patient_id_order_exact": True,
        "strat_fold_order_exact": True,
    }


def assert_patient_disjoint(folds: np.ndarray, patient_ids: Sequence[Any], valid: np.ndarray) -> None:
    patients = np.asarray([canonical_id(value) for value in patient_ids], dtype=str)
    groups = {
        "train": set(patients[valid & np.isin(folds, np.arange(1, 9))]) - {""},
        "validation": set(patients[valid & (folds == 9)]) - {""},
        "test": set(patients[valid & (folds == 10)]) - {""},
    }
    pairs = (("train", "validation"), ("train", "test"), ("validation", "test"))
    for left, right in pairs:
        overlap = groups[left] & groups[right]
        if overlap:
            examples = sorted(overlap)[:5]
            raise AdapterError(f"patient leakage between {left} and {right}: {examples}")


def build_strict_ood_split(
    raw_codes: Sequence[Mapping[str, Any]],
    labels_trainfreq: Sequence[str],
    train_presence: Mapping[str, int],
    folds: np.ndarray,
    patient_ids: Sequence[Any],
    valid: np.ndarray,
    threshold: int,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    if threshold <= 0:
        raise ValueError("OOD threshold must be positive")
    all_nonbaseline = sorted(
        set().union(*(set(row) for row in raw_codes)) - set(BASELINE_CODES)
    )
    heldout = sorted(code for code in all_nonbaseline if int(train_presence.get(code, 0)) < threshold)
    heldout_set = set(heldout)
    known_set = set(all_nonbaseline) - heldout_set
    has_heldout = np.asarray(
        [bool((set(codes) - set(BASELINE_CODES)) & heldout_set) for codes in raw_codes],
        dtype=bool,
    )
    has_known = np.asarray(
        [bool((set(codes) - set(BASELINE_CODES)) & known_set) for codes in raw_codes],
        dtype=bool,
    )
    train_all = valid & np.isin(folds, np.arange(1, 9))
    val_all = valid & (folds == 9)
    test_all = valid & (folds == 10)
    masks = {
        "train_id": train_all & ~has_heldout,
        "train_purged": train_all & has_heldout,
        "val_id": val_all & ~has_heldout,
        "val_purged": val_all & has_heldout,
        "test_id": test_all & ~has_heldout,
        "test_ood": test_all & has_heldout,
        "test_ood_pure": test_all & has_heldout & ~has_known,
        "test_ood_mixed": test_all & has_heldout & has_known,
    }

    # Hard assertions make accidental leakage or an index-order error fail closed.
    assert_patient_disjoint(folds, patient_ids, valid)
    if np.any(masks["train_id"] & has_heldout) or np.any(masks["val_id"] & has_heldout):
        raise AdapterError(f"tau={threshold}: held-out raw code leaked into ID train/validation")
    if np.any(masks["test_id"] & has_heldout):
        raise AdapterError(f"tau={threshold}: held-out raw code leaked into ID test")
    if np.any(masks["test_ood"] & ~has_heldout):
        raise AdapterError(f"tau={threshold}: OOD test contains a record without held-out code")
    if not np.array_equal(masks["test_ood"], masks["test_ood_pure"] | masks["test_ood_mixed"]):
        raise AdapterError(f"tau={threshold}: pure/mixed OOD masks do not partition OOD test")
    for prefix, all_mask in (("train", train_all), ("val", val_all), ("test", test_all)):
        left = masks[f"{prefix}_id"]
        right = masks["test_ood" if prefix == "test" else f"{prefix}_purged"]
        if np.any(left & right) or not np.array_equal(left | right, all_mask):
            raise AdapterError(f"tau={threshold}: {prefix} masks do not form a partition")
    labels_array = np.asarray(labels_trainfreq, dtype=str)
    if np.any(np.isin(labels_array[masks["train_id"]], heldout)):
        raise AdapterError(f"tau={threshold}: train-frequency labels leak held-out code into train_id")

    indices = {name: np.flatnonzero(mask).astype(np.int64) for name, mask in masks.items()}
    summary = {
        "threshold": int(threshold),
        "definition": "non-baseline raw SCP code presence in folds 1-8 is < threshold",
        "heldout_codes": heldout,
        "heldout_train_presence": {code: int(train_presence.get(code, 0)) for code in heldout},
        "n_heldout_codes": len(heldout),
        "counts": {name: int(mask.sum()) for name, mask in masks.items()},
        "assertions": {
            "patient_disjoint_official_folds": True,
            "heldout_absent_from_train_id_raw_code_sets": True,
            "heldout_absent_from_val_id_raw_code_sets": True,
            "test_id_has_no_heldout_raw_code": True,
            "test_ood_has_at_least_one_heldout_raw_code": True,
            "train_val_records_with_any_heldout_code_are_purged": True,
        },
    }
    return indices, summary


def source_signal_identity(paths: DatasetPaths, signals: MillivoltSignalView) -> dict[str, Any]:
    reported_sha: str | None = None
    if paths.trustfed_manifest.is_file():
        try:
            payload = json.loads(paths.trustfed_manifest.read_text(encoding="utf-8"))
            value = payload.get(paths.name, {}).get("signals_sha256")
            if isinstance(value, str) and value:
                reported_sha = value
        except (OSError, json.JSONDecodeError):
            reported_sha = None
    with paths.signals.open("rb") as handle:
        header = handle.read(4096)
    return {
        "path": str(paths.signals.resolve()),
        "shape": list(signals.shape),
        "dtype": str(signals.raw_microvolts.dtype),
        "unit": "microvolt",
        "size_bytes": paths.signals.stat().st_size,
        "npy_header_prefix_sha256": hashlib.sha256(header).hexdigest(),
        "trustfed_manifest_reported_sha256": reported_sha,
    }


def script_identity() -> dict[str, Any]:
    script = Path(__file__).resolve()
    return {
        "adapter_version": ADAPTER_VERSION,
        "script_path": str(script),
        "script_sha256": sha256_file(script),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
    }


def selected_ptb_metadata(database: pd.DataFrame, trustfed_meta: pd.DataFrame) -> pd.DataFrame:
    columns = (
        "ecg_id",
        "patient_id",
        "age",
        "sex",
        "height",
        "weight",
        "site",
        "device",
        "strat_fold",
        "filename_lr",
    )
    require_columns(database, columns, Path("ptbxl_database.csv"))
    frame = database.loc[:, columns].copy()
    frame.insert(0, "raw_index", np.arange(len(frame), dtype=np.int64))
    frame["record_id"] = trustfed_meta["record_id"].map(canonical_id).to_numpy()
    frame["valid"] = trustfed_meta["valid"].to_numpy(dtype=bool)
    frame["dataset"] = "ptbxl"
    return frame


def raw_code_json_rows(database: pd.DataFrame, state: PTBLabelState) -> Iterator[dict[str, Any]]:
    for raw_index, (ecg_id, codes) in enumerate(zip(database["ecg_id"], state.raw_codes)):
        scores = {code: codes[code] for code in sorted(codes)}
        yield {
            "raw_index": raw_index,
            "ecg_id": int(ecg_id) if str(ecg_id).lstrip("+-").isdigit() else canonical_id(ecg_id),
            "codes": sorted(codes),
            "scores": scores,
        }


def prepare_ptb_metadata(
    paths: DatasetPaths,
    output_dir: Path,
    thresholds: Sequence[int],
    force: bool,
    allow_noncanonical: bool = False,
) -> dict[str, Any]:
    signals, trustfed_meta, database, state, statement_codes = load_ptb_sources(
        paths, allow_noncanonical=allow_noncanonical
    )
    alignment = audit_ptb_alignment(signals, trustfed_meta, database)
    valid = trustfed_meta["valid"].to_numpy(dtype=bool)
    folds = pd.to_numeric(database["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    metadata = selected_ptb_metadata(database, trustfed_meta)
    split_payloads: dict[int, tuple[dict[str, np.ndarray], dict[str, Any]]] = {}
    for threshold in sorted(set(int(value) for value in thresholds)):
        split_payloads[threshold] = build_strict_ood_split(
            state.raw_codes,
            state.labels_trainfreq,
            state.train_presence,
            folds,
            database["patient_id"].to_numpy(),
            valid,
            threshold,
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    targets = {
        "metadata": output_dir / "ptbxl_metadata.csv",
        "y_legacy": output_dir / "ptbxl_y_legacy.npy",
        "y_trainfreq": output_dir / "ptbxl_y_trainfreq.npy",
        "codes": output_dir / "ptbxl_raw_scp_codes.jsonl",
        "labels": output_dir / "ptbxl_labels.json",
        "manifest": output_dir / "ptbxl_adapter_manifest.json",
    }
    split_targets = {
        threshold: output_dir / f"ptbxl_strict_ood_tau{threshold}.npz"
        for threshold in split_payloads
    }
    required = [*targets.values(), *split_targets.values()]
    existing = [path for path in required if path.exists()]
    if existing and not force and len(existing) == len(required):
        audit_ptb_outputs(paths, output_dir, signals, state, len(database))
        for threshold, (expected, _) in split_payloads.items():
            with np.load(split_targets[threshold], allow_pickle=False) as cached:
                for key, indices in expected.items():
                    if key not in cached or not np.array_equal(cached[key], indices):
                        raise AdapterError(
                            f"tau={threshold}: existing strict-OOD split mismatch for {key}"
                        )
        return {
            "dataset": "ptbxl",
            "status": "reused_existing",
            "n_records": len(database),
            "n_valid": int(valid.sum()),
            "n_classes": len(state.names),
            "legacy_changed_vs_trainfreq": int(np.sum(state.y_legacy != state.y_trainfreq)),
            "outputs": {name: str(path) for name, path in targets.items()},
            "strict_ood": {
                str(threshold): summary
                for threshold, (_, summary) in split_payloads.items()
            },
        }
    if existing and not force:
        raise FileExistsError(
            "partial PTB adapter outputs exist; pass --audit to diagnose or --force to "
            "replace the complete sidecar set. Existing: "
            + ", ".join(str(path) for path in existing[:5])
        )

    label_payload = {
        "format_version": ADAPTER_VERSION,
        "names": state.names,
        "name_to_index": {name: index for index, name in enumerate(state.names)},
        "baseline_codes": sorted(BASELINE_CODES),
        "raw_scp_statement_count": len(statement_codes),
        "legacy_rule": {
            "frequency_scope": "all 21799 records",
            "selection": "rarest non-baseline code; tie break lexicographic; fallback NORM",
            "presence_includes_zero_likelihood_keys": True,
        },
        "trainfreq_rule": {
            "frequency_scope": "official strat_fold 1-8 only",
            "selection": "rarest non-baseline code; unseen train code has frequency 0; "
            "tie break lexicographic; fallback NORM",
            "presence_includes_zero_likelihood_keys": True,
        },
        "full_code_presence_counts": {
            code: int(state.full_presence.get(code, 0)) for code in sorted(state.full_presence)
        },
        "trainfold_code_presence_counts": {
            code: int(state.train_presence.get(code, 0)) for code in sorted(state.full_presence)
        },
        "y_legacy_counts": {
            name: int(np.sum(state.y_legacy == index)) for index, name in enumerate(state.names)
        },
        "y_trainfreq_counts": {
            name: int(np.sum(state.y_trainfreq == index)) for index, name in enumerate(state.names)
        },
        "strict_ood": {
            str(threshold): summary for threshold, (_, summary) in split_payloads.items()
        },
    }

    write_csv_atomic(metadata, targets["metadata"])
    write_npy_atomic(state.y_legacy, targets["y_legacy"])
    write_npy_atomic(state.y_trainfreq, targets["y_trainfreq"])
    write_jsonl_atomic(raw_code_json_rows(database, state), targets["codes"])
    write_json_atomic(label_payload, targets["labels"])
    for threshold, (indices, _) in split_payloads.items():
        write_npz_atomic(split_targets[threshold], **indices)

    database_path = paths.raw_root / "ptbxl_database.csv"
    statements_path = paths.raw_root / "scp_statements.csv"
    manifest = {
        "format_version": ADAPTER_VERSION,
        "created_at_utc": utc_now(),
        "derived_features_from_input": True,
        "waveform_copy_created": False,
        "row_order": "raw ptbxl_database.csv order == TrustFed cache row order",
        "alignment": alignment,
        "source": {
            "ptbxl_database": {
                "path": str(database_path.resolve()),
                "sha256": sha256_file(database_path),
            },
            "scp_statements": {
                "path": str(statements_path.resolve()),
                "sha256": sha256_file(statements_path),
            },
            "trustfed_meta": {
                "path": str(paths.trustfed_meta.resolve()),
                "sha256": sha256_file(paths.trustfed_meta),
            },
            "signals": source_signal_identity(paths, signals),
        },
        "outputs": {},
        "software": script_identity(),
    }
    for name, target in {**targets, **{f"strict_ood_tau{k}": v for k, v in split_targets.items()}}.items():
        if name == "manifest":
            continue
        manifest["outputs"][str(name)] = {
            "path": str(target.resolve()),
            "size_bytes": target.stat().st_size,
            "sha256": sha256_file(target),
        }
    write_json_atomic(manifest, targets["manifest"])
    return {
        "dataset": "ptbxl",
        "n_records": len(database),
        "n_valid": int(valid.sum()),
        "n_classes": len(state.names),
        "legacy_changed_vs_trainfreq": int(np.sum(state.y_legacy != state.y_trainfreq)),
        "outputs": {name: str(path) for name, path in targets.items()},
        "strict_ood": label_payload["strict_ood"],
    }


def audit_chapman_alignment(
    signals: MillivoltSignalView, meta: pd.DataFrame, raw_root: Path
) -> dict[str, Any]:
    if len(signals) != len(meta):
        raise AdapterError(f"Chapman row-count mismatch: signals={len(signals)}, meta={len(meta)}")
    waveform_root = raw_root / "WFDBRecords"
    if not waveform_root.is_dir():
        raise FileNotFoundError(waveform_root)
    headers = sorted(waveform_root.rglob("*.hea"))
    raw_ids = np.asarray([path.stem for path in headers], dtype=str)
    cache_ids = np.asarray([canonical_id(value) for value in meta["record_id"]], dtype=str)
    if len(raw_ids) != len(meta):
        raise AdapterError(f"Chapman raw header count={len(raw_ids)}, meta rows={len(meta)}")
    if len(set(raw_ids.tolist())) != len(raw_ids):
        raise AdapterError("Chapman .hea basenames are not unique")
    mismatch = np.flatnonzero(raw_ids != cache_ids)
    if mismatch.size:
        i = int(mismatch[0])
        raise AdapterError(
            f"Chapman row order/record_id mismatch at {i}: raw={raw_ids[i]!r}, "
            f"cache={cache_ids[i]!r}"
        )
    return {
        "n_records": len(meta),
        "n_valid": int(meta["valid"].sum()),
        "signals_shape": list(signals.shape),
        "signals_storage_dtype": str(signals.raw_microvolts.dtype),
        "signals_storage_unit": "microvolt",
        "signals_exposed_unit": "mV",
        "scale_divisor": UV_PER_MV,
        "record_id_order_exact": True,
    }


def audit_chapman_outputs(
    paths: DatasetPaths,
    output_dir: Path,
    signals: MillivoltSignalView,
    meta: pd.DataFrame,
) -> dict[str, Any]:
    target = output_dir / "chapman_metadata.csv"
    manifest_target = output_dir / "chapman_adapter_manifest.json"
    present = (target.is_file(), manifest_target.is_file())
    if not any(present):
        return {"present": False}
    if not all(present):
        raise AdapterError("partial Chapman adapter cache: metadata/manifest pair is incomplete")
    cached = pd.read_csv(target)
    if len(cached) != len(meta) or not np.array_equal(
        cached["raw_index"].to_numpy(), np.arange(len(meta))
    ):
        raise AdapterError("cached Chapman metadata row order is invalid")
    cached_ids = cached["record_id"].map(canonical_id).to_numpy(dtype=str)
    source_ids = meta["record_id"].map(canonical_id).to_numpy(dtype=str)
    if not np.array_equal(cached_ids, source_ids):
        raise AdapterError("cached Chapman metadata record_id order is stale")
    if not np.array_equal(bool_array(cached["valid"]), meta["valid"].to_numpy(dtype=bool)):
        raise AdapterError("cached Chapman metadata valid mask is stale")

    manifest = json.loads(manifest_target.read_text(encoding="utf-8"))
    source = manifest.get("source", {})
    if source.get("trustfed_meta", {}).get("sha256") != sha256_file(paths.trustfed_meta):
        raise AdapterError("cached Chapman metadata was derived from different TrustFed metadata")
    current_signal = source_signal_identity(paths, signals)
    saved_signal = source.get("signals", {})
    keys = (
        "shape",
        "dtype",
        "unit",
        "size_bytes",
        "npy_header_prefix_sha256",
        "trustfed_manifest_reported_sha256",
    )
    if any(saved_signal.get(key) != current_signal.get(key) for key in keys):
        raise AdapterError("cached Chapman metadata does not match the current signal mmap")
    if manifest.get("outputs", {}).get("metadata", {}).get("sha256") != sha256_file(target):
        raise AdapterError("Chapman metadata checksum differs from its manifest")
    return {"present": True, "n_rows": len(cached), "record_id_order_exact": True}


def prepare_chapman_metadata(
    paths: DatasetPaths, output_dir: Path, force: bool
) -> dict[str, Any]:
    signals = MillivoltSignalView(paths.signals)
    meta = load_trustfed_meta(paths.trustfed_meta)
    alignment = audit_chapman_alignment(signals, meta, paths.raw_root)
    target = output_dir / "chapman_metadata.csv"
    manifest_target = output_dir / "chapman_adapter_manifest.json"
    existing = [path for path in (target, manifest_target) if path.exists()]
    if existing and not force and len(existing) == 2:
        audit_chapman_outputs(paths, output_dir, signals, meta)
        return {
            "dataset": "chapman",
            "status": "reused_existing",
            "n_records": len(meta),
            "n_valid": int(meta["valid"].sum()),
            "outputs": {"metadata": str(target), "manifest": str(manifest_target)},
        }
    if existing and not force:
        raise FileExistsError(
            "partial Chapman adapter outputs exist; pass --audit to diagnose or --force to "
            "replace the complete sidecar set. Existing: "
            + ", ".join(str(path) for path in existing)
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    selected = meta.copy()
    selected["record_id"] = selected["record_id"].map(canonical_id)
    write_csv_atomic(selected, target)
    manifest = {
        "format_version": ADAPTER_VERSION,
        "created_at_utc": utc_now(),
        "derived_features_from_input": True,
        "waveform_copy_created": False,
        "row_order": "sorted WFDBRecords/**/*.hea path order == TrustFed cache row order",
        "alignment": alignment,
        "source": {
            "trustfed_meta": {
                "path": str(paths.trustfed_meta.resolve()),
                "sha256": sha256_file(paths.trustfed_meta),
            },
            "signals": source_signal_identity(paths, signals),
        },
        "outputs": {
            "metadata": {
                "path": str(target.resolve()),
                "size_bytes": target.stat().st_size,
                "sha256": sha256_file(target),
            }
        },
        "software": script_identity(),
    }
    write_json_atomic(manifest, manifest_target)
    return {
        "dataset": "chapman",
        "n_records": len(meta),
        "n_valid": int(meta["valid"].sum()),
        "outputs": {"metadata": str(target), "manifest": str(manifest_target)},
    }


def compute_sqi6(signals_mv: np.ndarray, fs: int = TARGET_FS) -> tuple[np.ndarray, np.ndarray]:
    """Paper46 six-SQI definition, averaged over leads, plus scalar quality."""

    signal = np.asarray(signals_mv, dtype=np.float32)
    if signal.ndim != 3:
        raise ValueError(f"expected (N,C,L), got {signal.shape}")
    length = signal.shape[-1]
    spectrum = np.fft.rfft(signal, axis=-1)
    power = spectrum.real**2 + spectrum.imag**2
    frequencies = np.fft.rfftfreq(length, d=1.0 / fs)
    total = power.sum(axis=-1) + 1e-8
    qrs = power[..., (frequencies >= 5.0) & (frequencies <= 15.0)].sum(axis=-1)
    baseline = power[..., (frequencies >= 0.0) & (frequencies <= 1.0)].sum(axis=-1)
    p_sqi = qrs / total
    bas_sqi = 1.0 - baseline / total
    with np.errstate(all="ignore"):
        kurtosis = scipy_stats.kurtosis(signal, axis=-1, fisher=True)
        skewness = np.abs(scipy_stats.skew(signal, axis=-1))
    k_sqi = np.tanh(np.clip(kurtosis, -5.0, 50.0) / 5.0)
    s_sqi = np.tanh(skewness)
    difference = np.abs(np.diff(signal, axis=-1))
    flat = (difference < 1e-4).mean(axis=-1)
    maximum = np.abs(signal).max(axis=-1, keepdims=True) + 1e-8
    saturation = (np.abs(signal) > 0.98 * maximum).mean(axis=-1)
    features = np.stack((k_sqi, s_sqi, p_sqi, bas_sqi, flat, saturation), axis=-1)
    features = np.nan_to_num(features.mean(axis=1), nan=0.0, posinf=0.0, neginf=0.0)
    features = features.astype(np.float32, copy=False)
    quality_linear = (
        0.5 * features[:, 2]
        + 0.3 * features[:, 3]
        + 0.2 * np.clip(features[:, 0], 0.0, 1.0)
        - 0.5 * features[:, 4]
        - 0.5 * features[:, 5]
    )
    quality = 1.0 / (1.0 + np.exp(-6.0 * (quality_linear - 0.3)))
    return features, quality.astype(np.float32)


def _bandpass(signal: np.ndarray, low: float, high: float, fs: int, order: int = 3) -> np.ndarray:
    b, a = butter(order, [low / (fs / 2.0), high / (fs / 2.0)], btype="band")
    return filtfilt(b, a, signal)


def rpeaks_paper44(signal: np.ndarray, fs: int = TARGET_FS) -> np.ndarray:
    """Deterministic Paper44/Paper46 lead-II R-peak detector."""

    filtered = _bandpass(np.asarray(signal, dtype=np.float32), 5.0, 15.0, fs)
    gradient = np.gradient(filtered)
    squared = gradient * gradient
    window = max(1, int(0.10 * fs))
    moving = np.convolve(squared, np.ones(window) / window, mode="same")
    threshold = 0.3 * np.mean(moving) + 0.1 * np.max(moving)
    peaks, _ = find_peaks(moving, height=threshold, distance=int(0.30 * fs))
    return peaks.astype(np.int64, copy=False)


def hrv8_one(lead_ii_mv: np.ndarray, fs: int = TARGET_FS) -> np.ndarray:
    try:
        peaks = rpeaks_paper44(lead_ii_mv, fs)
    except (ValueError, FloatingPointError):
        return np.full(8, np.nan, dtype=np.float32)
    if len(peaks) < 3:
        return np.full(8, np.nan, dtype=np.float32)
    rr = np.diff(peaks) / fs * 1000.0
    rr = rr[(rr > 250.0) & (rr < 2000.0)]
    if len(rr) < 2:
        return np.full(8, np.nan, dtype=np.float32)
    delta_rr = np.diff(rr)
    mean_rr = float(np.mean(rr))
    hr = 60000.0 / mean_rr
    sdnn = float(np.std(rr))
    rmssd = float(np.sqrt(np.mean(delta_rr**2)))
    pnn50 = float(np.mean(np.abs(delta_rr) > 50.0) * 100.0)
    cvrr = sdnn / mean_rr
    return np.asarray(
        (hr, mean_rr, sdnn, rmssd, pnn50, cvrr, np.ptp(rr), np.median(rr)),
        dtype=np.float32,
    )


def hrv8_chunk(signals_mv: np.ndarray, fs: int = TARGET_FS) -> np.ndarray:
    signal = np.asarray(signals_mv, dtype=np.float32)
    result = np.empty((len(signal), 8), dtype=np.float32)
    for index in range(len(signal)):
        result[index] = hrv8_one(signal[index, 1], fs=fs)  # fixed lead II
    return result


def _trapezoid(values: np.ndarray, x: np.ndarray, axis: int = -1) -> np.ndarray:
    if hasattr(np, "trapezoid"):
        return np.trapezoid(values, x, axis=axis)
    return np.trapz(values, x, axis=axis)  # pragma: no cover - NumPy < 2


def spec36_chunk(signals_mv: np.ndarray, fs: int = TARGET_FS) -> np.ndarray:
    """Relative Welch power in three bands for each of 12 leads (lead-major)."""

    signal = np.asarray(signals_mv, dtype=np.float32)
    frequencies, power = welch(
        signal,
        fs=fs,
        nperseg=min(256, signal.shape[-1]),
        axis=-1,
    )
    total = _trapezoid(power, frequencies, axis=-1) + 1e-8
    bands = []
    for low, high in SPEC_BANDS_HZ:
        select = (frequencies >= low) & (frequencies < high)
        bands.append(_trapezoid(power[..., select], frequencies[select], axis=-1) / total)
    # stack -> (batch, lead, band), then flatten in lead-major order.
    return np.stack(bands, axis=-1).reshape(len(signal), -1).astype(np.float32)


def feature_definition() -> dict[str, Any]:
    return {
        "derived_features_from_input": True,
        "input": {
            "storage": "TrustFedECG int16 microvolt mmap",
            "computation_unit": "float32 mV",
            "conversion": "float32(chunk) / 1000.0",
            "full_waveform_copy": False,
        },
        "sqi6": {
            "names": list(SQI_NAMES),
            "definition": "Paper46 trustlib.compute_sqi-equivalent, per lead then mean over 12 leads",
            "flat_threshold_mV": 1e-4,
            "qrs_band_hz": [5.0, 15.0],
            "baseline_band_hz": [0.0, 1.0],
        },
        "quality": {
            "definition": "sigmoid(6*(0.5*pSQI + 0.3*basSQI + 0.2*clip(kSQI,0,1) "
            "- 0.5*flat - 0.5*sat - 0.3))"
        },
        "hrv8": {
            "names": list(HRV_NAMES),
            "lead": "II (index 1)",
            "rpeak_detector": "Butterworth order 3, 5-15 Hz, filtfilt; gradient squared; "
            "100 ms moving average; threshold 0.3*mean+0.1*max; 300 ms minimum distance",
            "rr_filter_ms": "250 < RR < 2000",
            "undefined_imputation": "per-dataset median over valid records after extraction",
            "definition_source": "Paper44 code/prep_ptbxl.py, reused by original Paper46 cache",
        },
        "spec36": {
            "names": list(SPEC_NAMES),
            "bands_hz": [list(pair) for pair in SPEC_BANDS_HZ],
            "welch_nperseg": 256,
            "normalisation": "band trapezoidal power / total trapezoidal Welch power",
            "flatten_order": "lead-major, then ascending band",
            "definition_source": "Paper44 code/prep_ptbxl.py, reused by original Paper46 cache",
        },
    }


def _feature_targets(dataset: str, output_dir: Path) -> dict[str, Path]:
    return {
        "sqi6": output_dir / f"{dataset}_sqi6.npy",
        "quality": output_dir / f"{dataset}_quality.npy",
        "hrv8": output_dir / f"{dataset}_hrv8.npy",
        "spec36": output_dir / f"{dataset}_spec36.npy",
        "manifest": output_dir / f"{dataset}_features_manifest.json",
    }


def prepare_features(
    paths: DatasetPaths,
    output_dir: Path,
    chunk_size: int,
    force: bool,
) -> dict[str, Any]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    signals = MillivoltSignalView(paths.signals)
    meta = load_trustfed_meta(paths.trustfed_meta)
    if len(signals) != len(meta):
        raise AdapterError(f"{paths.name}: signal/meta row-count mismatch")
    valid = meta["valid"].to_numpy(dtype=bool)
    n = len(signals)
    targets = _feature_targets(paths.name, output_dir)
    existing = [path for path in targets.values() if path.exists()]
    if existing and not force and len(existing) == len(targets):
        audit = audit_feature_outputs(paths, output_dir)
        return {
            "dataset": paths.name,
            "status": "reused_existing",
            "n_records": n,
            "n_valid": int(valid.sum()),
            "outputs": {name: str(path) for name, path in targets.items()},
            "audit": audit,
        }
    if existing and not force:
        raise FileExistsError(
            f"partial {paths.name} feature outputs exist; pass --audit to diagnose or "
            "--force to replace the complete feature set. Existing: "
            + ", ".join(str(path) for path in existing)
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    temp_paths = {name: _tmp_path(path) for name, path in targets.items() if name != "manifest"}
    arrays: dict[str, np.memmap] = {}
    try:
        arrays["sqi6"] = np.lib.format.open_memmap(
            temp_paths["sqi6"], mode="w+", dtype=np.float32, shape=(n, 6)
        )
        arrays["quality"] = np.lib.format.open_memmap(
            temp_paths["quality"], mode="w+", dtype=np.float32, shape=(n,)
        )
        arrays["hrv8"] = np.lib.format.open_memmap(
            temp_paths["hrv8"], mode="w+", dtype=np.float32, shape=(n, 8)
        )
        arrays["spec36"] = np.lib.format.open_memmap(
            temp_paths["spec36"], mode="w+", dtype=np.float32, shape=(n, 36)
        )
        for array in arrays.values():
            array[:] = np.nan

        for start, stop, chunk_mv in signals.iter_chunks(chunk_size):
            local_valid = valid[start:stop]
            if np.any(local_valid):
                selected = chunk_mv[local_valid]
                sqi, quality = compute_sqi6(selected, fs=TARGET_FS)
                hrv = hrv8_chunk(selected, fs=TARGET_FS)
                spectral = spec36_chunk(selected, fs=TARGET_FS)
                local_rows = np.flatnonzero(local_valid) + start
                arrays["sqi6"][local_rows] = sqi
                arrays["quality"][local_rows] = quality
                arrays["hrv8"][local_rows] = hrv
                arrays["spec36"][local_rows] = spectral
            print(f"[{paths.name}] derived features {stop}/{n}", flush=True)

        # Match the original Paper44/Paper46 feature cache: HRV-only median imputation.
        valid_rows = np.flatnonzero(valid)
        imputation_medians: dict[str, float] = {}
        imputation_counts: dict[str, int] = {}
        for column, name in enumerate(HRV_NAMES):
            values = np.asarray(arrays["hrv8"][valid_rows, column], dtype=np.float32)
            missing = ~np.isfinite(values)
            finite = values[~missing]
            median = float(np.median(finite)) if finite.size else 0.0
            if missing.any():
                arrays["hrv8"][valid_rows[missing], column] = np.float32(median)
            imputation_medians[name] = median
            imputation_counts[name] = int(missing.sum())

        for name, array in arrays.items():
            array.flush()
            if np.any(~np.isfinite(np.asarray(array[valid]))):
                raise AdapterError(f"{paths.name} {name}: non-finite value remains in valid rows")
            if np.any(np.isfinite(np.asarray(array[~valid]))):
                raise AdapterError(f"{paths.name} {name}: invalid rows must remain NaN")
        del arrays
        arrays = {}
        for name, temp in temp_paths.items():
            os.replace(temp, targets[name])
    finally:
        arrays.clear()
        for temp in temp_paths.values():
            if temp.exists():
                temp.unlink()

    manifest = {
        "format_version": ADAPTER_VERSION,
        "created_at_utc": utc_now(),
        "dataset": paths.name,
        "n_records": n,
        "n_valid": int(valid.sum()),
        "chunk_size": int(chunk_size),
        "signals": source_signal_identity(paths, signals),
        "trustfed_meta_sha256": sha256_file(paths.trustfed_meta),
        "valid_mask_sha256": sha256_array_bytes(valid.astype(np.uint8)),
        "feature_definition": feature_definition(),
        "hrv_imputation_medians": imputation_medians,
        "hrv_imputation_counts": imputation_counts,
        "outputs": {},
        "software": script_identity(),
    }
    for name, target in targets.items():
        if name == "manifest":
            continue
        array = np.load(target, mmap_mode="r", allow_pickle=False)
        manifest["outputs"][name] = {
            "path": str(target.resolve()),
            "shape": list(array.shape),
            "dtype": str(array.dtype),
            "size_bytes": target.stat().st_size,
            "sha256": sha256_file(target),
        }
    write_json_atomic(manifest, targets["manifest"])
    return {
        "dataset": paths.name,
        "n_records": n,
        "n_valid": int(valid.sum()),
        "outputs": {name: str(path) for name, path in targets.items()},
        "hrv_imputation_counts": imputation_counts,
    }


def audit_feature_outputs(paths: DatasetPaths, output_dir: Path) -> dict[str, Any]:
    targets = _feature_targets(paths.name, output_dir)
    present = {name: path.is_file() for name, path in targets.items()}
    if not any(present.values()):
        return {"present": False}
    if not all(present.values()):
        missing = [name for name, value in present.items() if not value]
        raise AdapterError(f"{paths.name}: partial feature cache, missing {missing}")
    signals = MillivoltSignalView(paths.signals)
    meta = load_trustfed_meta(paths.trustfed_meta)
    valid = meta["valid"].to_numpy(dtype=bool)
    expected = {"sqi6": (len(signals), 6), "quality": (len(signals),), "hrv8": (len(signals), 8), "spec36": (len(signals), 36)}
    report: dict[str, Any] = {"present": True, "files": {}}
    for name, shape in expected.items():
        array = np.load(targets[name], mmap_mode="r", allow_pickle=False)
        if tuple(array.shape) != shape or array.dtype != np.float32:
            raise AdapterError(
                f"{targets[name]}: expected float32 {shape}, got {array.dtype} {array.shape}"
            )
        if np.any(~np.isfinite(np.asarray(array[valid]))):
            raise AdapterError(f"{targets[name]}: non-finite feature in valid row")
        report["files"][name] = {"shape": list(array.shape), "dtype": str(array.dtype)}
    manifest = json.loads(targets["manifest"].read_text(encoding="utf-8"))
    if manifest.get("dataset") != paths.name or int(manifest.get("n_records", -1)) != len(signals):
        raise AdapterError(f"{paths.name}: feature manifest dataset/row count mismatch")
    if manifest.get("trustfed_meta_sha256") != sha256_file(paths.trustfed_meta):
        raise AdapterError(f"{paths.name}: features were derived with different metadata")
    if manifest.get("valid_mask_sha256") != sha256_array_bytes(valid.astype(np.uint8)):
        raise AdapterError(f"{paths.name}: feature manifest valid mask does not match current meta")
    current_signal = source_signal_identity(paths, signals)
    saved_signal = manifest.get("signals", {})
    signal_identity_keys = (
        "shape",
        "dtype",
        "unit",
        "size_bytes",
        "npy_header_prefix_sha256",
        "trustfed_manifest_reported_sha256",
    )
    if any(saved_signal.get(key) != current_signal.get(key) for key in signal_identity_keys):
        raise AdapterError(f"{paths.name}: features do not match the current signal mmap")
    saved_outputs = manifest.get("outputs", {})
    for name in expected:
        entry = saved_outputs.get(name, {})
        if entry.get("sha256") != sha256_file(targets[name]):
            raise AdapterError(f"{targets[name]}: checksum differs from feature manifest")
    report["manifest_version"] = manifest.get("format_version")
    return report


def audit_ptb_outputs(
    paths: DatasetPaths,
    output_dir: Path,
    signals: MillivoltSignalView,
    state: PTBLabelState,
    n: int,
) -> dict[str, Any]:
    targets = {
        "metadata": output_dir / "ptbxl_metadata.csv",
        "y_legacy": output_dir / "ptbxl_y_legacy.npy",
        "y_trainfreq": output_dir / "ptbxl_y_trainfreq.npy",
        "codes": output_dir / "ptbxl_raw_scp_codes.jsonl",
        "labels": output_dir / "ptbxl_labels.json",
        "manifest": output_dir / "ptbxl_adapter_manifest.json",
    }
    present = {name: path.is_file() for name, path in targets.items()}
    if not any(present.values()):
        return {"present": False}
    if not all(present.values()):
        missing = [name for name, value in present.items() if not value]
        raise AdapterError(f"partial PTB adapter cache, missing {missing}")
    metadata = pd.read_csv(targets["metadata"])
    if len(metadata) != n or not np.array_equal(metadata["raw_index"], np.arange(n)):
        raise AdapterError("cached PTB metadata row order is invalid")
    cached_legacy = np.load(targets["y_legacy"], allow_pickle=False)
    cached_train = np.load(targets["y_trainfreq"], allow_pickle=False)
    if not np.array_equal(cached_legacy, state.y_legacy):
        raise AdapterError("cached y_legacy does not reproduce Paper41")
    if not np.array_equal(cached_train, state.y_trainfreq):
        raise AdapterError("cached y_trainfreq does not match folds 1-8 frequencies")
    with targets["codes"].open("r", encoding="utf-8") as handle:
        line_count = sum(1 for _ in handle)
    if line_count != n:
        raise AdapterError(f"cached raw SCP JSONL has {line_count} rows, expected {n}")
    labels = json.loads(targets["labels"].read_text(encoding="utf-8"))
    if labels.get("names") != state.names:
        raise AdapterError("cached PTB label-name order mismatch")
    manifest = json.loads(targets["manifest"].read_text(encoding="utf-8"))
    source = manifest.get("source", {})
    current_files = {
        "ptbxl_database": paths.raw_root / "ptbxl_database.csv",
        "scp_statements": paths.raw_root / "scp_statements.csv",
        "trustfed_meta": paths.trustfed_meta,
    }
    for name, path in current_files.items():
        if source.get(name, {}).get("sha256") != sha256_file(path):
            raise AdapterError(f"PTB adapter cache was derived from a different {name} file")
    current_signal = source_signal_identity(paths, signals)
    saved_signal = source.get("signals", {})
    signal_keys = (
        "shape",
        "dtype",
        "unit",
        "size_bytes",
        "npy_header_prefix_sha256",
        "trustfed_manifest_reported_sha256",
    )
    if any(saved_signal.get(key) != current_signal.get(key) for key in signal_keys):
        raise AdapterError("PTB adapter cache does not match the current signal mmap")
    manifest_outputs = manifest.get("outputs", {})
    for name, path in targets.items():
        if name == "manifest":
            continue
        entry = manifest_outputs.get(name, {})
        if entry.get("sha256") != sha256_file(path):
            raise AdapterError(f"{path}: checksum differs from PTB adapter manifest")
    return {
        "present": True,
        "n_rows": n,
        "n_classes": len(state.names),
        "legacy_exact": True,
        "trainfreq_exact": True,
        "raw_code_rows": line_count,
    }


def audit_dataset(
    paths: DatasetPaths,
    output_dir: Path,
    thresholds: Sequence[int],
    allow_noncanonical: bool = False,
) -> dict[str, Any]:
    if paths.name == "ptbxl":
        signals, meta, database, state, statement_codes = load_ptb_sources(
            paths, allow_noncanonical=allow_noncanonical
        )
        alignment = audit_ptb_alignment(signals, meta, database)
        folds = pd.to_numeric(database["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
        valid = meta["valid"].to_numpy(dtype=bool)
        splits: dict[str, Any] = {}
        for threshold in sorted(set(int(value) for value in thresholds)):
            _, summary = build_strict_ood_split(
                state.raw_codes,
                state.labels_trainfreq,
                state.train_presence,
                folds,
                database["patient_id"].to_numpy(),
                valid,
                threshold,
            )
            split_path = output_dir / f"ptbxl_strict_ood_tau{threshold}.npz"
            summary["cache_present"] = split_path.is_file()
            if split_path.is_file():
                cached = np.load(split_path, allow_pickle=False)
                expected, _ = build_strict_ood_split(
                    state.raw_codes,
                    state.labels_trainfreq,
                    state.train_presence,
                    folds,
                    database["patient_id"].to_numpy(),
                    valid,
                    threshold,
                )
                for name, indices in expected.items():
                    if name not in cached or not np.array_equal(cached[name], indices):
                        raise AdapterError(f"tau={threshold}: cached split mismatch for {name}")
            splits[str(threshold)] = summary
        return {
            "dataset": "ptbxl",
            "ok": True,
            "alignment": alignment,
            "n_statement_codes": len(statement_codes),
            "n_classes": len(state.names),
            "class_names": state.names,
            "legacy_changed_vs_trainfreq": int(np.sum(state.y_legacy != state.y_trainfreq)),
            "outputs": audit_ptb_outputs(paths, output_dir, signals, state, len(database)),
            "features": audit_feature_outputs(paths, output_dir),
            "strict_ood": splits,
        }
    if paths.name == "chapman":
        signals = MillivoltSignalView(paths.signals)
        meta = load_trustfed_meta(paths.trustfed_meta)
        alignment = audit_chapman_alignment(signals, meta, paths.raw_root)
        prepared_meta = output_dir / "chapman_metadata.csv"
        metadata_outputs = audit_chapman_outputs(paths, output_dir, signals, meta)
        return {
            "dataset": "chapman",
            "ok": True,
            "alignment": alignment,
            "metadata_cache_present": prepared_meta.is_file(),
            "metadata_outputs": metadata_outputs,
            "features": audit_feature_outputs(paths, output_dir),
        }
    raise ValueError(paths.name)


def open_dataset(
    name: str,
    trustfed_cache: str | Path = DEFAULT_TRUSTFED_CACHE,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
) -> DatasetAdapter:
    """Open prepared sidecars and a lazy mV signal view for downstream experiments."""

    cache = Path(trustfed_cache)
    output = Path(output_dir)
    if name not in {"ptbxl", "chapman"}:
        raise ValueError("name must be 'ptbxl' or 'chapman'")
    signals = MillivoltSignalView(cache / f"{name}_signals.npy")
    prepared_meta = output / f"{name}_metadata.csv"
    meta_path = prepared_meta if prepared_meta.is_file() else cache / f"{name}_meta.csv"
    metadata = pd.read_csv(meta_path)
    if "valid" not in metadata:
        raise AdapterError(f"{meta_path}: missing valid column")
    valid = bool_array(metadata["valid"])
    if len(metadata) != len(signals):
        raise AdapterError(f"{name}: prepared metadata does not align with signal mmap")

    kwargs: dict[str, Any] = {}
    if name == "ptbxl":
        y_legacy_path = output / "ptbxl_y_legacy.npy"
        y_trainfreq_path = output / "ptbxl_y_trainfreq.npy"
        labels_path = output / "ptbxl_labels.json"
        if y_legacy_path.is_file() and y_trainfreq_path.is_file() and labels_path.is_file():
            kwargs["y_legacy"] = np.load(y_legacy_path, mmap_mode="r", allow_pickle=False)
            kwargs["y_trainfreq"] = np.load(y_trainfreq_path, mmap_mode="r", allow_pickle=False)
            kwargs["label_names"] = json.loads(labels_path.read_text(encoding="utf-8"))["names"]
    for key in ("sqi6", "quality", "hrv8", "spec36"):
        path = output / f"{name}_{key}.npy"
        if path.is_file():
            kwargs[key] = np.load(path, mmap_mode="r", allow_pickle=False)
    return DatasetAdapter(name=name, signals=signals, metadata=metadata, valid=valid, **kwargs)


def load_strict_ood_split(
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    threshold: int = 80,
) -> dict[str, np.ndarray]:
    """Load the small, audited PTB strict-OOD index sidecar for ``threshold``."""

    if threshold <= 0:
        raise ValueError("threshold must be positive")
    path = Path(output_dir) / f"ptbxl_strict_ood_tau{int(threshold)}.npz"
    if not path.is_file():
        raise FileNotFoundError(path)
    expected = (
        "train_id",
        "train_purged",
        "val_id",
        "val_purged",
        "test_id",
        "test_ood",
        "test_ood_pure",
        "test_ood_mixed",
    )
    with np.load(path, allow_pickle=False) as payload:
        missing = [name for name in expected if name not in payload]
        if missing:
            raise AdapterError(f"{path}: missing strict-OOD arrays {missing}")
        result = {name: np.asarray(payload[name], dtype=np.int64) for name in expected}
    return result


def parse_thresholds(value: str) -> tuple[int, ...]:
    try:
        thresholds = tuple(sorted(set(int(item.strip()) for item in value.split(",") if item.strip())))
    except ValueError as exc:
        raise argparse.ArgumentTypeError("thresholds must be comma-separated positive integers") from exc
    if not thresholds or any(item <= 0 for item in thresholds):
        raise argparse.ArgumentTypeError("thresholds must be comma-separated positive integers")
    return thresholds


def make_paths(args: argparse.Namespace, name: str) -> DatasetPaths:
    cache = Path(args.trustfed_cache)
    raw_root = Path(args.ptbxl_raw if name == "ptbxl" else args.chapman_raw)
    return DatasetPaths(
        name=name,
        signals=cache / f"{name}_signals.npy",
        trustfed_meta=cache / f"{name}_meta.csv",
        raw_root=raw_root,
        trustfed_manifest=Path(args.trustfed_manifest),
    )


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Zero-copy TrustFedECG adapter and deterministic Paper46 sidecar builder"
    )
    parser.add_argument("--dataset", choices=("ptbxl", "chapman", "all"), default="all")
    parser.add_argument("--audit", action="store_true", help="read-only shape/order/ecg_id audit")
    parser.add_argument(
        "--prepare-metadata",
        action="store_true",
        help="write only small metadata/labels/raw-code/split sidecars",
    )
    parser.add_argument(
        "--prepare-features",
        action="store_true",
        help="write SQI6, quality, HRV8 and spec36 sidecars directly from the mmap",
    )
    parser.add_argument("--force", action="store_true", help="replace existing adapter sidecars")
    parser.add_argument("--chunk-size", type=int, default=256)
    parser.add_argument(
        "--ood-thresholds",
        type=parse_thresholds,
        default=DEFAULT_OOD_THRESHOLDS,
        help="raw train-fold code-presence thresholds (default: 40,80,160)",
    )
    parser.add_argument("--trustfed-cache", default=str(DEFAULT_TRUSTFED_CACHE))
    parser.add_argument(
        "--trustfed-manifest",
        default=str(DEFAULT_TRUSTFED_CACHE / "preprocess_manifest.json"),
    )
    parser.add_argument("--ptbxl-raw", default=str(DEFAULT_PTBXL_RAW))
    parser.add_argument("--chapman-raw", default=str(DEFAULT_CHAPMAN_RAW))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument(
        "--allow-noncanonical",
        action="store_true",
        help="permit a non-70-class PTB fixture; never use for the canonical experiment",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    if not (args.audit or args.prepare_metadata or args.prepare_features):
        parser.error("select at least one of --audit, --prepare-metadata, --prepare-features")
    if args.chunk_size <= 0:
        parser.error("--chunk-size must be positive")
    output_dir = Path(args.output_dir)
    names = ("ptbxl", "chapman") if args.dataset == "all" else (args.dataset,)
    reports: list[dict[str, Any]] = []
    for name in names:
        paths = make_paths(args, name)
        # Feature preparation also prepares the small alignment/label sidecars first.
        if args.prepare_metadata or args.prepare_features:
            if name == "ptbxl":
                reports.append(
                    prepare_ptb_metadata(
                        paths,
                        output_dir,
                        args.ood_thresholds,
                        force=args.force,
                        allow_noncanonical=args.allow_noncanonical,
                    )
                )
            else:
                reports.append(prepare_chapman_metadata(paths, output_dir, force=args.force))
        if args.prepare_features:
            reports.append(
                prepare_features(paths, output_dir, chunk_size=args.chunk_size, force=args.force)
            )
        if args.audit:
            reports.append(
                audit_dataset(
                    paths,
                    output_dir,
                    args.ood_thresholds,
                    allow_noncanonical=args.allow_noncanonical,
                )
            )
    print(json.dumps(reports, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
