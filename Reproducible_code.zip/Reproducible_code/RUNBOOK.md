# Reproduction Runbook

All commands in this document are intended for a Linux GPU server. They are not
training commands for a local workstation.

## 1. Define paths

Choose persistent locations and override the historical defaults as needed:

```bash
export PYTHON=/path/to/conda/env/bin/python
export REVISION_ROOT=/path/to/Paper46_revision
export EXPERIMENT_DIR=${REVISION_ROOT}/experiments
export DATASET_ROOT=/path/to/datasets
export TRUSTFED_CACHE=${DATASET_ROOT}/TrustFedECG/cache
export CACHE_DIR=${REVISION_ROOT}/cache
export RESULTS_DIR=${REVISION_ROOT}/results_final/ptbxl
export LOG_DIR=${REVISION_ROOT}/logs_final/ptbxl

mkdir -p "${EXPERIMENT_DIR}" "${CACHE_DIR}" "${RESULTS_DIR}" "${LOG_DIR}"
cp -a code/. "${EXPERIMENT_DIR}/"
cd "${EXPERIMENT_DIR}"
```

The formal launchers refuse to proceed when required inputs are missing. Extension
launchers default to `/dev/shm` for high-throughput temporary storage. Override
their result and log roots if persistent storage is required.

## 2. Build the PTB-XL and Chapman waveform cache

Expected official roots:

- PTB-XL contains `ptbxl_database.csv`, `scp_statements.csv`, and the `records100`
  WFDB records referenced by `filename_lr`.
- Chapman contains `ConditionNames_SNOMED-CT.csv` and `WFDBRecords/**/*.hea/.mat`.

```bash
"${PYTHON}" build_waveform_cache.py \
  --ptbxl-root "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-root "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --cache-dir "${TRUSTFED_CACHE}" \
  --workers 20 \
  --only all
```

Do not add `--force` unless replacing a fully identified cache in a new experiment
chain. The expected canonical shapes are `(21799, 12, 1000)` for PTB-XL and
`(45152, 12, 1000)` for Chapman. The reference run had 21,799 valid PTB-XL records
and 45,150 valid Chapman records.

## 3. Build and audit PTB-XL/Chapman sidecars

```bash
"${PYTHON}" data_adapter.py \
  --dataset all \
  --prepare-metadata --prepare-features \
  --ood-thresholds 40,80,160 \
  --chunk-size 256 \
  --trustfed-cache "${TRUSTFED_CACHE}" \
  --trustfed-manifest "${TRUSTFED_CACHE}/preprocess_manifest.json" \
  --ptbxl-raw "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-raw "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --output-dir "${CACHE_DIR}"

"${PYTHON}" data_adapter.py \
  --dataset all --audit \
  --ood-thresholds 40,80,160 \
  --trustfed-cache "${TRUSTFED_CACHE}" \
  --trustfed-manifest "${TRUSTFED_CACHE}/preprocess_manifest.json" \
  --ptbxl-raw "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-raw "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --output-dir "${CACHE_DIR}"
```

For the canonical cache, the strict OOD split counts are:

| Threshold | Held-out codes | Train ID / purged | Validation ID / purged | Test ID | OOD all / pure / mixed |
|---:|---:|---:|---:|---:|---:|
| 40 | 15 | 17,159 / 259 | 2,147 / 36 | 2,164 | 34 / 6 / 28 |
| 80 | 23 | 16,677 / 741 | 2,086 / 97 | 2,105 | 93 / 22 / 71 |
| 160 | 34 | 15,527 / 1,891 | 1,940 / 243 | 1,958 | 240 / 44 / 196 |

Stop if these assertions or the row-alignment audit fail.

## 4. Prepare wearable subject files

### MHEALTH

```bash
export WEARABLE_ROOT=${DATASET_ROOT}/wearable
mkdir -p "${WEARABLE_ROOT}/mhealth" "${WEARABLE_ROOT}/wesad"

"${PYTHON}" wearable_preprocessing/preprocessing/prep_mhealth.py \
  --dir "${DATASET_ROOT}/MHEALTHDATASET" \
  --out "${WEARABLE_ROOT}/mhealth"
```

The output must contain `S1.npz` through `S10.npz`.

### WESAD

```bash
"${PYTHON}" wearable_preprocessing/preprocessing/prep_wesad.py \
  --zip "${DATASET_ROOT}/WESAD.zip" \
  --out "${WEARABLE_ROOT}/wesad" \
  --tmp /dev/shm/paper46_wesad_extract
```

The output must contain `S2-S11` and `S13-S17`. Only deserialize a trusted and
verified official WESAD archive.

`prepare_wearables.py` provides a separate streaming archive-audit and compatibility
cache path. It is not the formal per-subject LOSO input.

## 5. Run the base PTB-XL matrix

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
RESULTS_DIR="${REVISION_ROOT}/results_final/ptbxl" \
LOG_DIR="${REVISION_ROOT}/logs_final/ptbxl" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
MAX_PARALLEL=20 EPOCHS=40 BATCH_SIZE=256 EVAL_BATCH_SIZE=512 \
bash run_ptbxl_matrix.sh
```

Completion requires exactly 25 zero-valued task exit files and
`ptbxl_matrix.complete`. The result root must contain 212 JSON/raw/OOD triplets.

## 6. Run canonical noise/SQI experiments

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
CHECKPOINT_DIR="${REVISION_ROOT}/checkpoints_final/noise_sqi" \
RESULTS_DIR="${REVISION_ROOT}/results_final/noise_sqi" \
LOG_DIR="${REVISION_ROOT}/logs_final/noise_sqi" \
bash run_noise_sqi_matrix.sh
```

Completion requires seeds 7, 13, and 42, paired conditions
`clean,24,18,12,6,0,-6`, and `noise_sqi.complete`.

## 7. Run the wearable LOSO matrix

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
DATA_ROOT="${WEARABLE_ROOT}" \
RESULTS_DIR="${REVISION_ROOT}/results_final/wearables" \
LOG_DIR="${REVISION_ROOT}/logs_final/wearables" \
MAX_PARALLEL=8 EPOCHS=30 BATCH_SIZE=128 \
bash run_wearables_matrix.sh
```

Completion requires 75 zero-valued task exits, 345 result pairs, and
`wearables_matrix.complete`.

## 8. Run reviewer-requested PTB extensions

Use a result root separate from the base 212-result matrix:

```bash
export EXTENSION_RESULTS=${REVISION_ROOT}/results_extensions/ptbxl
export EXTENSION_LOGS=${REVISION_ROOT}/logs_extensions/ptbxl

PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
RESULTS_DIR="${EXTENSION_RESULTS}" \
LOG_DIR="${EXTENSION_LOGS}" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
MAX_PARALLEL=20 EPOCHS=40 BATCH_SIZE=256 EVAL_BATCH_SIZE=512 \
bash run_ptbxl_missing_matrix.sh
```

Completion requires 66 zero-valued task exits and 221 JSON/raw/OOD triplets.

Audit the extension matrix:

```bash
"${PYTHON}" audit_promised_extensions.py \
  --results-dir "${EXTENSION_RESULTS}" \
  --reference-results-dir "${REVISION_ROOT}/results_final/ptbxl" \
  --output-dir "${REVISION_ROOT}/aggregate/promised_extensions" \
  --log-dir "${EXTENSION_LOGS}" \
  --experiment-dir "${EXPERIMENT_DIR}" \
  --fail-on-incomplete
```

The audit contract is 49 groups, 221 records, 442 NPZ artifacts, 66 task logs,
1,400 representation-diagnostic rows, and zero issues.

## 9. Run gate architecture extensions

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
RESULTS_DIR="${REVISION_ROOT}/results_extensions/noise_gate" \
CHECKPOINT_DIR="${REVISION_ROOT}/checkpoints_extensions/noise_gate" \
LOG_DIR="${REVISION_ROOT}/logs_extensions/noise_gate" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
MAX_PARALLEL=9 \
bash run_noise_gate_matrix.sh
```

Audit the gate matrix with:

```bash
"${PYTHON}" audit_noise_gate_extensions.py \
  --results-root "${REVISION_ROOT}/results_extensions/noise_gate" \
  --checkpoint-root "${REVISION_ROOT}/checkpoints_extensions/noise_gate" \
  --log-root "${REVISION_ROOT}/logs_extensions/noise_gate" \
  --experiment-dir "${EXPERIMENT_DIR}" \
  --output-dir "${REVISION_ROOT}/aggregate/noise_gate_extensions" \
  --fail-on-incomplete
```

The formal contract contains 9 cells, 63 condition rows, 252 gate-diagnostic
rows, and 216 source-corruption rows.

## 10. Run noise-shift calibration inference

This step does not train a model. It requires the canonical noise checkpoints and
results from step 6.

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
OUTPUT_DIR="${REVISION_ROOT}/results_extensions/noise_shift_calibration" \
LOG_DIR="${REVISION_ROOT}/logs_extensions/noise_shift_calibration" \
CHECKPOINT_ROOT="${REVISION_ROOT}/checkpoints_final/noise_sqi/canonical" \
CANONICAL_RESULTS_ROOT="${REVISION_ROOT}/results_final/noise_sqi/canonical" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
bash run_noise_shift_calibration_matrix.sh
```

Audit with:

```bash
"${PYTHON}" audit_noise_shift_calibration.py \
  --results-root "${REVISION_ROOT}/results_extensions/noise_shift_calibration" \
  --output-dir "${REVISION_ROOT}/aggregate/noise_shift_calibration" \
  --fail-on-incomplete
```

The expected output is 3 valid seeds and 252 metric rows.

## 11. Run the modular pipeline

This step is inference-only. It needs base PTB `softmax_modular` outputs and
canonical noise checkpoints/results.

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
PTB_RESULTS_DIR="${REVISION_ROOT}/results_final/ptbxl" \
NOISE_RESULTS_DIR="${REVISION_ROOT}/results_final/noise_sqi" \
NOISE_CHECKPOINT_DIR="${REVISION_ROOT}/checkpoints_final/noise_sqi" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
SHM_ROOT="${REVISION_ROOT}/results_extensions/modular_pipeline" \
LOG_DIR="${REVISION_ROOT}/logs_extensions/modular_pipeline" \
bash run_modular_pipeline_matrix.sh
```

The launcher runs 5 PTB and 3 noise workers, finalises the summary, and runs the
independent modular audit.

## 12. Audit and aggregate base PTB results

```bash
"${PYTHON}" make_expected_config.py \
  "${REVISION_ROOT}/expected_ptbxl_results.json"

"${PYTHON}" aggregate_results.py \
  "${REVISION_ROOT}/results_final/ptbxl" \
  --output-dir "${REVISION_ROOT}/aggregate/ptbxl_audit" \
  --expected-config "${REVISION_ROOT}/expected_ptbxl_results.json" \
  --audit-only --fail-on-incomplete

"${PYTHON}" aggregate_results.py \
  "${REVISION_ROOT}/results_final/ptbxl" \
  --output-dir "${REVISION_ROOT}/aggregate/ptbxl" \
  --expected-config "${REVISION_ROOT}/expected_ptbxl_results.json" \
  --bootstrap 2000 \
  --confidence-level 0.95 \
  --random-seed 2026 \
  --reference-method trust_full \
  --fail-on-incomplete
```

The expected base contract is 60 method/protocol groups, 212 result records, 636
artifacts, no duplicate identities, no unexpected records, and uniform code hashes.

## 13. Aggregate wearable and noise results

```bash
"${PYTHON}" aggregate_auxiliary.py \
  --wearables-root "${REVISION_ROOT}/results_final/wearables" \
  --noise-root "${REVISION_ROOT}/results_final/noise_sqi" \
  --output-dir "${REVISION_ROOT}/aggregate/auxiliary" \
  --bootstrap 10000 \
  --fail-on-incomplete
```

## 14. Postprocess promised metrics

```bash
"${PYTHON}" postprocess_promised_metrics.py \
  --ptb-root "${REVISION_ROOT}/results_final/ptbxl" \
  --noise-root "${REVISION_ROOT}/results_final/noise_sqi" \
  --wearables-root "${REVISION_ROOT}/results_final/wearables" \
  --output-dir "${REVISION_ROOT}/aggregate/promised_postprocess" \
  --bootstrap 2000 \
  --target-sensitivity 0.95 \
  --fail-on-incomplete
```

This step derives the rare-threshold, selective-coverage, OOD paired, and
prevalence-projection summaries from stored outputs without retraining.

## 15. Verify completion

At minimum, require:

- every launcher-specific `.exit` file equals zero;
- every expected completion marker exists;
- every independent audit reports `complete=true` or `status=complete` with zero
  issues/errors;
- the base PTB result manifest reports exactly 212 records and 60 groups;
- the auxiliary audit reports exactly 345 wearable cells and 3 noise cells;
- no smoke or partial run appears below a formal result root.

Compare final aggregate CSV/JSON files with `reference_outputs/aggregates/`. Small
floating-point differences may occur on a different CUDA stack, but protocol,
counts, seed sets, completion contracts, and qualitative conclusions must match.

For a machine-checkable comparison, arrange the new aggregate subdirectories to
mirror `reference_outputs/aggregates/` and run:

```bash
"${PYTHON}" compare_reproduction.py \
  --candidate-root "${REVISION_ROOT}/aggregate/reproduction_comparison" \
  --reference-root /path/to/Reproducible_code/reference_outputs/aggregates \
  --rtol 1e-5 --atol 1e-7
```

The candidate root in this command must contain copied or linked stable aggregate
subdirectories named `ptbxl`, `auxiliary`, `promised_extensions`,
`promised_postprocess`, `noise_gate_extensions`,
`noise_shift_calibration_audit`, and `modular_pipeline`.
