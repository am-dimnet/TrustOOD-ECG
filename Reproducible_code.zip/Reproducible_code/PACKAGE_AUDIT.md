# Package Audit

Audit date: 23 August 2026

## Scope

This audit covers the standalone `Reproducible_code` directory for the revised
TrustOOD-ECG study. No model training, data preprocessing, or experiment execution
was performed during local package assembly.

## Inventory

- 32 code files: 24 Python programs and 8 shell launchers.
- 9 configuration and input-contract files.
- 12 sanitized environment records.
- 60 de-identified reference aggregate and manuscript-table files.
- English README, runbook, table-provenance map, core requirements, integrity
  verifier, package audit, and checksum inventory.

## Completed checks

- Every Python file passed bytecode compilation with cache output redirected
  outside the package.
- Every shell launcher passed `bash -n` syntax validation.
- All 29 JSON files parsed successfully.
- All 39 CSV files parsed successfully.
- The numerical reproduction comparator passed a self-consistency test across 19
  stable scientific outputs.
- The complete package contains no CJK characters and no non-ASCII characters.
- No symbolic link is present.
- No raw waveform, `.npy`, `.npz`, checkpoint, pickle, `.pt`, or `.pth` artifact is
  distributed.
- No captured SSH host, password, private key, API credential, local workstation
  path, machine hostname, network mount, GPU serial number, or GPU UUID is included.
- `SHA256SUMS` inventories every other regular file in the package.

## Reproducibility closure

The package includes a raw-WFDB-to-waveform-cache builder for PTB-XL and Chapman,
the formal subject-level MHEALTH/WESAD preprocessors, all frozen training and
evaluation runners, strict completion audits, aggregate generators, a
machine-readable comparison against reference aggregates, exact input contracts,
and a table-provenance map.

Historical absolute paths retained inside result/cache manifests are provenance
fields. The launchers expose path-root environment variables for deployment. One
strict extension auditor checks the canonical historical paths embedded in the
formal run metadata; reproduce that exact audit under the canonical server layout
or update its expected path contract together with a new result root.

## Distribution boundary

Raw datasets remain subject to their original licences. Identifier-bearing
record-level predictions and checkpoints remain outside this package. No software
reuse licence has been selected by the authors; one should be added before public
distribution.
