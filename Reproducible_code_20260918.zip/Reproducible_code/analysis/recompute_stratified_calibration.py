"""New stratified calibration summaries from saved logits; no model execution."""
from pathlib import Path
import ast, json, hashlib, typing
import numpy as np
import pandas as pd
from scipy.special import softmax
from scipy.stats import t

import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--revision-root',required=True,type=Path,help='Controlled Revision2 archive root including server_results and frozen origin report')
parser.add_argument('--output-dir',required=True,type=Path,help='New output directory; do not overwrite frozen tables')
args=parser.parse_args()
B=args.revision_root.resolve();P=args.output_dir.resolve();O=P/'provenance'
P.mkdir(parents=True,exist_ok=False);O.mkdir()
code=B/'server_preparation/code/revisionlib.py'
names={'_softmax_np','_bin_indices','expected_calibration_error','classwise_ece',
       'negative_log_likelihood','multiclass_brier','calibration_metrics'}
tree=ast.parse(code.read_text())
parts=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(parts)==len(names)
ns=dict(vars(typing));ns.update(np=np,softmax=softmax)
exec(compile(ast.Module(body=parts,type_ignores=[]),str(code),'exec'),ns)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
origin=B/'analysis/final_arrays/origin_full.json'
assert sha(origin)=='f67d75e4a7b76961366c02161fdb00a97430e5370bcfaf9ff90ea403aadb4f01'
rows=[];evidence=[];checks=[]
methods=['trust_full','softmax_modular','concat_matched','deep_ensemble',
         'trust_pool_only','trust_fuse_only','tmc','tmdf']
# The branch tags are taken from the actual archive, not display labels.
existing=[p.name for p in (B/'server_results/results/formal/closed').iterdir() if p.is_dir()]
methods=[m if m in existing else {'trust_pool_only':'pool_only','trust_fuse_only':'fuse_only'}[m] for m in methods]
for method in methods:
    for seed in [7,13,42,99,2026]:
        jpath=B/f'server_results/results/formal/closed/{method}/seed_{seed}.json'
        j=json.loads(jpath.read_text());raw=jpath.with_name(j['artifacts']['raw_npz']['filename'])
        assert sha(raw)==j['artifacts']['raw_npz']['sha256']
        z=np.load(raw,allow_pickle=False)
        labels=z['test_y'];logits=z['test_logits'];temp=j['diagnosis']['calibration']['temperature']
        rare=np.isin(labels,j['rare_ids'])
        assert len(labels)==2198 and rare.sum()==45
        evidence.append(dict(method=method,seed=seed,json_sha256=sha(jpath),raw_sha256=sha(raw)))
        for var in ['raw','TS']:
            for stratum,mask in [('all',np.ones(len(labels),bool)),('rare',rare),('frequent',~rare)]:
                result=ns['calibration_metrics'](logits[mask].astype(np.float64)/(temp if var=='TS' else 1),labels[mask])
                metrics={k:float(v) for k,v in result.items() if np.ndim(v)==0}
                if stratum=='all':
                    prior=j['diagnosis']['calibration']['raw' if var=='raw' else 'temperature_scaled']
                    for k,v in metrics.items():
                        assert abs(v-prior[k])<1e-10,(method,seed,var,k,v,prior[k])
                    checks.append(dict(method=method,seed=seed,variant=var,all_metrics_match_original=True))
                rows.append(dict(method=method,seed=seed,protocol='closed',dataset='ptbxl',split='test',
                                 calibration_variant=var,stratum=stratum,support=int(mask.sum()),temperature=temp,**metrics))
df=pd.DataFrame(rows)
df.to_csv(P/'Supplementary_PTB_Stratified_Calibration.csv',index=False)
summary=[]
metrics=[k for k in rows[0] if k.startswith(('ece','classwise')) or k in ['nll','brier','accuracy']]
for key,g in df.groupby(['method','calibration_variant','stratum']):
    for metric in metrics:
        a=g[metric].to_numpy();m=float(a.mean());sd=float(a.std(ddof=1));half=t.ppf(.975,len(a)-1)*sd/np.sqrt(len(a))
        summary.append(dict(method=key[0],calibration_variant=key[1],stratum=key[2],metric=metric,
                            support=int(g.support.iloc[0]),mean=m,sd=sd,t_ci_lower=m-half,t_ci_upper=m+half,n=5))
pd.DataFrame(summary).to_csv(P/'Supplementary_PTB_Stratified_Calibration_Summary.csv',index=False)
(O/'stratified_calibration_provenance.json').write_text(json.dumps(dict(
    purpose='Saved-logit calculation only; no inference, training, or temperature refit',
    origin_sha256=sha(origin),implementation_sha256=sha(code),inputs=evidence,checks=checks,
    output_rows=len(rows),summary_rows=len(summary),
    outputs=[dict(name=p.name,sha256=sha(p)) for p in P.glob('Supplementary_PTB_Stratified_Calibration*.csv')]),indent=2)+'\n')
print('Verified all-stratum metrics against 80 original method/seed/calibration entries.')
print(pd.DataFrame(summary).query("method=='trust_full' and stratum=='rare' and metric in ['ece_fixed','nll','brier']").to_string(index=False))
