# Reanalysis of the retained original arrays

The private package sits beside this supplement. Preserve its relative
`../../server_results` relationship and the historical independent archive
under Paper46/Revision1/Reproducibility. The raw arrays and fitted models are
complete locally but intentionally not included in this distributable tree.

The exact executed statistical commands, exit codes, output checksums and
full origin report are retained in Revision2/analysis/final_arrays/logs,
analysis/final_promised_metrics and the appended local-finalization snapshot
of the private package. Completed statistics must not be rerun merely to
check a package. For an intentional independent reanalysis, use a new output
directory and the existing original array roots, with this package's scripts:

```bash
python revision2/run_revision2_core_statistics.py --root /path/to/Revision2/server_results --output /new/path/analysis --scope array-statistics
# Inspect the dry-run plan; append --execute only for an intentional reanalysis.
```

This requires the private exact-origin inventory, explicit 18-run reuse
manifest, code pins and command records, and rejects mixed/partial inputs.
The complete controlled archive and current scripts provide these materials.
No statistical claim can be reconstructed solely from the distributed
mean/SD summaries. The frozen replot command has a deliberately narrower
verification contract and explicitly reports that scope.
