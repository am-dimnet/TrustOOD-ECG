# Independent experiments

These commands preserve the separately validated historical noise and wearable designs. Define paths as in DATA_PREPARATION.md and use `historical_independent/code` as EXPERIMENT_DIR (wearable preprocessing is in revision2/code/wearable_preprocessing). Do not substitute old HRV-dependent formal PTB outputs. Each noise runner computes its own clean training-fold HRV medians.

## 6. Run canonical noise/SQI experiments

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
CHECKPOINT_DIR="${REVISION_ROOT}/checkpoints_final/noise_sqi" \
RESULTS_DIR="${REVISION_ROOT}/results_final/noise_sqi" \
LOG_DIR="${REVISION_ROOT}/logs_final/noise_sqi" \
bash run_noise_sqi_matrix.sh
```

Completion requires seeds 7, 13, and 42, paired conditions
`clean,24,18,12,6,0,-6`, and `noise_sqi.complete`.

## 7. Run the wearable LOSO matrix

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
DATA_ROOT="${WEARABLE_ROOT}" \
RESULTS_DIR="${REVISION_ROOT}/results_final/wearables" \
LOG_DIR="${REVISION_ROOT}/logs_final/wearables" \
MAX_PARALLEL=8 EPOCHS=30 BATCH_SIZE=128 \
bash run_wearables_matrix.sh
```

Completion requires 75 zero-valued task exits, 345 result pairs, and
`wearables_matrix.complete`.

## 9. Run gate architecture extensions

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
RESULTS_DIR="${REVISION_ROOT}/results_extensions/noise_gate" \
CHECKPOINT_DIR="${REVISION_ROOT}/checkpoints_extensions/noise_gate" \
LOG_DIR="${REVISION_ROOT}/logs_extensions/noise_gate" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
MAX_PARALLEL=9 \
bash run_noise_gate_matrix.sh
```

Audit the gate matrix with:

```bash
"${PYTHON}" audit_noise_gate_extensions.py \
  --results-root "${REVISION_ROOT}/results_extensions/noise_gate" \
  --checkpoint-root "${REVISION_ROOT}/checkpoints_extensions/noise_gate" \
  --log-root "${REVISION_ROOT}/logs_extensions/noise_gate" \
  --experiment-dir "${EXPERIMENT_DIR}" \
  --output-dir "${REVISION_ROOT}/aggregate/noise_gate_extensions" \
  --fail-on-incomplete
```

The formal contract contains 9 cells, 63 condition rows, 252 gate-diagnostic
rows, and 216 source-corruption rows.

## 10. Run noise-shift calibration inference

This step does not train a model. It requires the canonical noise checkpoints and
results from step 6.

```bash
PYTHON="${PYTHON}" \
REVISION_ROOT="${REVISION_ROOT}" \
EXPERIMENT_DIR="${EXPERIMENT_DIR}" \
OUTPUT_DIR="${REVISION_ROOT}/results_extensions/noise_shift_calibration" \
LOG_DIR="${REVISION_ROOT}/logs_extensions/noise_shift_calibration" \
CHECKPOINT_ROOT="${REVISION_ROOT}/checkpoints_final/noise_sqi/canonical" \
CANONICAL_RESULTS_ROOT="${REVISION_ROOT}/results_final/noise_sqi/canonical" \
CACHE_DIR="${CACHE_DIR}" \
TRUSTFED_CACHE="${TRUSTFED_CACHE}" \
bash run_noise_shift_calibration_matrix.sh
```

Audit with:

```bash
"${PYTHON}" audit_noise_shift_calibration.py \
  --results-root "${REVISION_ROOT}/results_extensions/noise_shift_calibration" \
  --output-dir "${REVISION_ROOT}/aggregate/noise_shift_calibration" \
  --fail-on-incomplete
```

The expected output is 3 valid seeds and 252 metric rows.

