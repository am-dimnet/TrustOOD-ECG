# Fresh scientific reproduction

Do not execute in an archived result directory. Define absolute `PYTHON`,
`NEW_ROOT`, `TRUSTFED_CACHE` and finish DATA_PREPARATION.md first.
Create the GPU environment from requirements-core.txt and the recorded pip
versions; the PyTorch CUDA wheel must match the host. Set deterministic
environment variables before training:

```bash
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"$PYTHON" plan_fresh_matrix.py --python "$PYTHON" --cache-root "$NEW_ROOT/cache" --wave-cache "$TRUSTFED_CACHE" --output "$NEW_ROOT/results" > "$NEW_ROOT/fresh_commands.sh"
```

Review and execute the generated commands on suitable GPUs, preserving each
command, stdout/stderr and exit code. There are 433 commands: all published
415 retrained cells and fresh runs of the 18 ECG-only cells. The script itself
only prints commands. Each command keeps the declared seed and 40 epochs.
The older revision2/run_matrix.py deliberately selects only 415 retrain cells
and therefore does not alone regenerate all 433 cells.

Save each JSON, raw NPZ, OOD NPZ and fitted-state PT, every ensemble member,
the four imputer manifests, raw HRV/masks, input hashes and environment exports.
Validation selects checkpoints; test/OOD data must not fit any component.
The published origin audit checks an exact historical/new mixed lineage;
fresh results must instead carry their own new provenance. Do not relabel
fresh ECG-only results as historical or forge the published fingerprints.

The underlying statistical implementations are aggregate_results.py
(formal means, paired seed tests, class metrics and 2,000 patient bootstrap),
audit_promised_extensions.py / audit_revision2_extensions.py (extensions),
postprocess_promised_metrics.py (rare, calibration, operating-point and
paired OOD analyses), and derive_reviewer6_tables.py (low-risk and alert
summaries). Their --help output specifies path overrides. The source and
matrix are complete; origin-specific audit manifests must be constructed
for a new run, rather than substituting new data into the original signed
archive or disabling validation. Frozen reference tables provide the
prespecified endpoints and full inference families for comparison.

For the five-seed modular PTB evaluation, use:

```bash
"$PYTHON" revision2/code/evaluate_modular_pipeline.py --mode ptb --ptb-seeds 7,13,42,99,2026 --ptb-results-dir "$NEW_ROOT/results/formal" --cache-dir "$NEW_ROOT/cache" --trustfed-cache "$TRUSTFED_CACHE" --cache-provenance-root "$NEW_ROOT" --experiment-dir revision2/code --device cpu --output-dir "$NEW_ROOT/modular_ptb"
```

Independent noise/wearable reproduction is in INDEPENDENT_RUNS.md. It is
separate from the corrected PTB matrix. No fresh experiment was executed
while building this supplement.
