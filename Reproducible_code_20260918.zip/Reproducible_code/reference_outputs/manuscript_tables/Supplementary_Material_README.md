# Supplementary tables for TrustOOD-ECG

This index accompanies the manuscript and versioned reproducibility supplement.

| File | Rows | Contents |
|---|---:|---|
| `Supplementary_Class_Distributions.csv` | 70 | Zero-based 70-class map; record and unique-patient counts; primary rare indicator (training support <50). Assigned labels, not all co-occurring raw codes. |
| `Supplementary_HRV_Imputation_Medians.csv` | 32 | Training-only vectors for closed and strict τ40/80/160. HR: beats/min; RR/SDNN/RMSSD/RR range/median: ms; pNN50: percent; CVRR: dimensionless. Includes finite training counts. |
| `Supplementary_HRV_Missing_Counts.csv` | 32 | Pre-imputation missingness by protocol, dataset and subset. affected_percent is percent of records; missing_values counts descriptor cells. Overlapping subsets must not be summed. |
| `Supplementary_Noise_Calibration_Metrics.csv` | 252 | Independent three-seed study: seven clean/noise conditions × validation/test × raw/TS × all/rare/frequent. Blank snr_db denotes clean. The clean-validation temperature is frozen across corruption conditions. |
| `Supplementary_PTB_Calibration_Summary.csv` | 15 | Formal Trust five-seed raw/TS calibration and fitted temperature. percentile_ci columns are seed-value percentiles, not bootstrap confidence intervals. Completeness flags identify missing or duplicate seeds. |
| `Supplementary_PTB_Stratified_Calibration.csv` | 240 | Eight models × five seeds × raw/TS × all/rare/frequent strata, from saved formal test logits and frozen temperatures. Total/rare/frequent support: 2198/45/2153 records. |
| `Supplementary_PTB_Stratified_Calibration_Summary.csv` | 336 | Mean, sample SD and seed t intervals for seven metrics from the preceding table; n=5 per cell. No model execution or temperature refitting. |
| `Supplementary_Rare_Class_Metrics.csv` | 17 | Seventeen primary rare classes; record/patient support; precision, recall, F1, AUROC and average precision means, SD and t intervals. Undefined precision/recall/F1 is set to zero by convention. |

## Metric and uncertainty conventions

Metric values are proportions unless marked percent; NLL uses natural logarithms.
Multiclass Brier sums squared class-probability errors and can exceed one.
SD is sample SD across seeds. Student-t intervals are unadjusted two-sided 95%
seed intervals, not patient-cluster or simultaneous intervals. They are not
truncated to natural bounds. Five-seed sets are 7,13,42,99,2026; independent
noise uses 7,13,42. Seed percentiles do not substitute for sampling intervals.

`raw` applies no temperature transform; `TS` divides saved logits by the
validation-fitted scalar. The temperature column on raw rows identifies the
paired fit and does not mean it was applied. Strata use true assigned labels
and fixed training support, not model predictions. Probabilities retain all
70 classes within each stratum. `support` counts records, not patients.

Formal `ece_fixed` and noise `ece_equal_width` use 15 equal-width top-label
bins. Formal adaptive ECE uses 15 sorted equal-count groups; independent noise
adaptive ECE uses empirical quantile boundaries with duplicates removed (up to
15 bins). Tied confidences can therefore be assigned differently; these variants
are not identical estimators. Classwise variants average
one-vs-rest calibration over all 70 output classes. Noise `classwise_supported_*`
restricts the class average to true-positive-supported classes in the stratum.
These definitions must not be mixed. The classification tables do not apply
quality or novelty rejection. Small rare strata limit interpretation.

Model tags: trust_full = Pool+Fuse TrustOOD-ECG; pool_only/fuse_only = branch
controls; concat_matched = matched concatenation; softmax_modular = classifier
used by the modular pipeline; deep_ensemble = ensemble; tmc = Trusted Multi-View
Classification; tmdf = implemented trusted multiview deep fusion control.

Empty metric cells mean non-estimable values, not zero. AUROC requires positive
and negative labels; average precision requires positives. Empty list fields
`[]` in completeness columns mean no missing/duplicate/unexpected seeds.

## Provenance

Formal corrected arrays are bound to origin_full.json SHA-256
f67d75e4a7b76961366c02161fdb00a97430e5370bcfaf9ff90ea403aadb4f01.
The independently valid noise study is a separate evidence source and cannot
replace the five-seed formal analysis. HRV tables derive from four training-only
imputation manifests. Supplement hashes and aggregate provenance accompany the
reproducibility package. Identifier-bearing arrays and states are retained only
in the controlled local archive. The isolated serialization attempt is excluded.
