from pathlib import Path
import hashlib,json,ast
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
for entry in manifest['files']:
    p=root/entry['path']
    assert p.is_file() and p.stat().st_size==entry['bytes'],entry['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],entry['path']
    if p.suffix=='.py':ast.parse(p.read_text())
print(json.dumps({'complete':True,'checked_files':len(manifest['files']),'scope':'package integrity and Python syntax only; no raw-data experiment'}))
