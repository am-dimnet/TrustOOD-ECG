# Data preparation

Run from `revision2/code`. Define `PYTHON`, `DATASET_ROOT`, `TRUSTFED_CACHE` (waveform cache), and `CACHE_DIR` (sidecar cache) as fresh absolute paths. Use PTB-XL 1.0.3 and the 45,152-record Chapman/Shaoxing/Ningbo 1.0.0 combined release. The historical directory label in commands does not mean the smaller original 10,646-record Chapman collection.

## 2. Build the PTB-XL and Chapman waveform cache

Expected official roots:

- PTB-XL contains `ptbxl_database.csv`, `scp_statements.csv`, and the `records100`
  WFDB records referenced by `filename_lr`.
- Chapman contains `ConditionNames_SNOMED-CT.csv` and `WFDBRecords/**/*.hea/.mat`.

```bash
"${PYTHON}" build_waveform_cache.py \
  --ptbxl-root "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-root "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --cache-dir "${TRUSTFED_CACHE}" \
  --workers 20 \
  --only all
```

Do not add `--force` unless replacing a fully identified cache in a new experiment
chain. The expected canonical shapes are `(21799, 12, 1000)` for PTB-XL and
`(45152, 12, 1000)` for Chapman. The reference run had 21,799 valid PTB-XL records
and 45,150 valid Chapman records.

## 3. Build and audit PTB-XL/Chapman sidecars

```bash
"${PYTHON}" data_adapter.py \
  --dataset all \
  --prepare-metadata --prepare-features \
  --ood-thresholds 40,80,160 \
  --chunk-size 256 \
  --trustfed-cache "${TRUSTFED_CACHE}" \
  --trustfed-manifest "${TRUSTFED_CACHE}/preprocess_manifest.json" \
  --ptbxl-raw "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-raw "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --output-dir "${CACHE_DIR}"

"${PYTHON}" data_adapter.py \
  --dataset all --audit \
  --ood-thresholds 40,80,160 \
  --trustfed-cache "${TRUSTFED_CACHE}" \
  --trustfed-manifest "${TRUSTFED_CACHE}/preprocess_manifest.json" \
  --ptbxl-raw "${DATASET_ROOT}/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3" \
  --chapman-raw "${DATASET_ROOT}/chapman-shaoxing-1.0.0" \
  --output-dir "${CACHE_DIR}"
```

For the canonical cache, the strict OOD split counts are:

| Threshold | Held-out codes | Train ID / purged | Validation ID / purged | Test ID | OOD all / pure / mixed |
|---:|---:|---:|---:|---:|---:|
| 40 | 15 | 17,159 / 259 | 2,147 / 36 | 2,164 | 34 / 6 / 28 |
| 80 | 23 | 16,677 / 741 | 2,086 / 97 | 2,105 | 93 / 22 / 71 |
| 160 | 34 | 15,527 / 1,891 | 1,940 / 243 | 1,958 | 240 / 44 / 196 |

Stop if these assertions or the row-alignment audit fail.

## 4. Prepare wearable subject files

### MHEALTH

```bash
export WEARABLE_ROOT=${DATASET_ROOT}/wearable
mkdir -p "${WEARABLE_ROOT}/mhealth" "${WEARABLE_ROOT}/wesad"

"${PYTHON}" wearable_preprocessing/preprocessing/prep_mhealth.py \
  --dir "${DATASET_ROOT}/MHEALTHDATASET" \
  --out "${WEARABLE_ROOT}/mhealth"
```

The output must contain `S1.npz` through `S10.npz`.

### WESAD

```bash
"${PYTHON}" wearable_preprocessing/preprocessing/prep_wesad.py \
  --zip "${DATASET_ROOT}/WESAD.zip" \
  --out "${WEARABLE_ROOT}/wesad" \
  --tmp /dev/shm/paper46_wesad_extract
```

The output must contain `S2-S11` and `S13-S17`. Only deserialize a trusted and
verified official WESAD archive.

`prepare_wearables.py` provides a separate streaming archive-audit and compatibility
cache path. It is not the formal per-subject LOSO input.


## Mandatory training-only HRV replacement

The adapter generates non-HRV sidecars and a legacy HRV file; the latter must never be used for the corrected matrix. Re-extract unfilled HRV and fit all four eligible training partitions as follows, from the package root:

```bash
"$PYTHON" revision2/prepare_training_only_cache.py --trustfed-cache "$TRUSTFED_CACHE" --source-cache "$CACHE_DIR" --output "$NEW_ROOT/cache" --execute
```

`NEW_ROOT` must be a new run directory. This writes `raw_hrv` and `closed`, `strict_tau40`, `strict_tau80`, `strict_tau160`, their manifests and frozen transforms. Any shape, membership, missingness or median-fit discrepancy must be resolved before training. Never infer missingness from already imputed values.
