#!/usr/bin/env python3
"""Re-extract unfilled HRV, fit each eligible training partition, freeze transforms.
Scientific preprocessing requires --execute; do not run before server authorization.
"""
from pathlib import Path
import argparse,json,sys,shutil,os
sys.path.insert(0,str(Path(__file__).resolve().parent/'code'))
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--trustfed-cache',type=Path,required=True);p.add_argument('--source-cache',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True);p.add_argument('--chunk-size',type=int,default=256);p.add_argument('--execute',action='store_true')
 p.add_argument('--datasets',default='ptbxl,chapman',choices=['ptbxl','ptbxl,chapman'])
 p.add_argument('--protocols',default='closed,strict_tau40,strict_tau80,strict_tau160')
 a=p.parse_args()
 if not a.execute:raise SystemExit('Preparation only. Supply --execute after server authorization.')
 if a.output.exists():raise SystemExit('Output already exists; choose a fresh directory (no overwrite).')
 import numpy as np
 import data_adapter as D
 import revision2_provenance as V
 adapters={n:D.open_dataset(n,a.trustfed_cache,a.source_cache) for n in a.datasets.split(',')}
 for n,ad in adapters.items():
  for key in ['sqi6','quality','spec36']:
   if getattr(ad,key) is None:raise ValueError(f'Missing {n} {key}')
  V.record_ids(ad,np.flatnonzero(ad.valid))
 # Verify official label/support counts before doing expensive extraction.
 ad=adapters['ptbxl'];fold=ad.metadata['strat_fold'].to_numpy(dtype=int)
 closed={k:np.flatnonzero(ad.valid & condition) for k,condition in [('train',fold<=8),('val',fold==9),('test',fold==10)]}
 assert [len(closed[k]) for k in ['train','val','test']]==[17418,2183,2198]
 assert len(ad.label_names)==70
 parts={'closed':closed}
 for tau,expected in [(40,(34,6)),(80,(93,22)),(160,(240,44))]:
  z=np.load(a.source_cache/f'ptbxl_strict_ood_tau{tau}.npz',allow_pickle=False)
  assert (len(z['test_ood']),len(z['test_ood_pure']))==expected
  parts[f'strict_tau{tau}']={'train':z['train_id'],'val':z['val_id'],'test':z['test_id'],'ood':z['test_ood']}
  assert not np.intersect1d(z['train_id'],z['val_id']).size
 requested=a.protocols.split(',')
 if any(k not in parts for k in requested):raise ValueError('Unknown protocol')
 if a.datasets=='ptbxl' and 'closed' in requested:raise ValueError('Closed evaluation also requires Chapman')
 parts={k:parts[k] for k in requested}
 for indices in parts.values():
  patients={k:set(ad.metadata.iloc[ix]['patient_id'].astype(str)) for k,ix in indices.items() if k in ['train','val','test']}
  assert not patients['train']&patients['val'] and not patients['train']&patients['test'] and not patients['val']&patients['test']
 a.output.mkdir(parents=True);rawdir=a.output/'raw_hrv';rawdir.mkdir();raw={};verified=[]
 # Waveform, row-order, label, and sidecar hashes are preserved in manifests.
 paths=list(a.source_cache.glob('*.npy'))+list(a.source_cache.glob('*.npz'))+list(a.source_cache.glob('*.csv'))+list(a.source_cache.glob('*.json'))
 paths += [a.trustfed_cache/f'{n}_signals.npy' for n in adapters]
 for path in paths:verified.append({'path':str(path.resolve()),'sha256':V.sha256(path)})
 for n,ad in adapters.items():
  h=np.full((len(ad.valid),8),np.nan,dtype=np.float32)
  for start,stop,wave in ad.signals.iter_chunks(a.chunk_size):
   local=ad.valid[start:stop]
   if local.any():h[np.flatnonzero(local)+start]=D.hrv8_chunk(wave[local],fs=D.TARGET_FS)
   print(n,stop,len(ad.valid),flush=True)
  np.save(rawdir/f'{n}_hrv8_raw.npy',h,allow_pickle=False)
  np.save(rawdir/f'{n}_missing_mask.npy',~np.isfinite(h),allow_pickle=False)
  raw[n]=h
 for protocol,indices in parts.items():
  out=a.output/protocol;out.mkdir()
  # Symlinks preserve immutable, byte-identical non-HRV inputs; never call legacy feature preparation here.
  for f in a.source_cache.iterdir():
   if f.is_file() and f.name not in ['ptbxl_hrv8.npy','chapman_hrv8.npy','ptbxl_features_manifest.json','chapman_features_manifest.json']:
    (out/f.name).symlink_to(f.resolve())
  med=V.fit_medians(raw['ptbxl'],indices['train']);outputs={};counts={}
  for n,ad in adapters.items():
   target=out/f'{n}_hrv8.npy';np.save(target,V.transform(raw[n],med,ad.valid),allow_pickle=False)
   outputs[n]={'filename':target.name,'sha256':V.sha256(target)}
   counts[n]={'missing_by_descriptor':(~np.isfinite(raw[n][ad.valid])).sum(0).tolist(),'affected_records':int((~np.isfinite(raw[n][ad.valid])).any(1).sum())}
  for split,ix in indices.items():counts['ptb_'+split]={'missing_by_descriptor':(~np.isfinite(raw['ptbxl'][ix])).sum(0).tolist(),'affected_records':int((~np.isfinite(raw['ptbxl'][ix])).any(1).sum())}
  manifest={'schema':V.SCHEMA,'preparation_sha256':V.sha256(__file__),'protocol':protocol,'train_indices':indices['train'].tolist(),'train_record_ids':V.record_ids(adapters['ptbxl'],indices['train']).tolist(),
   'medians':med.tolist(),'descriptor_names':list(D.HRV_NAMES),'counts':counts,'outputs':outputs,'verified_inputs':verified,
   'raw_hrv':{n:{'path':str((rawdir/f'{n}_hrv8_raw.npy').resolve()),'sha256':V.sha256(rawdir/f'{n}_hrv8_raw.npy')} for n in adapters}}
  (out/'training_only_hrv_manifest.json').write_text(json.dumps(manifest,indent=2))
 print(f'Prepared {list(parts)} training-only caches for {list(adapters)}. No model training was performed.')
if __name__=='__main__':main()
