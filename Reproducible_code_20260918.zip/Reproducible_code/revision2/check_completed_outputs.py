#!/usr/bin/env python3
"""Read-only integrity/identifier checks on corrected results; no model evaluation."""
from pathlib import Path
import argparse,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'code'))
def main():
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--stage',choices=['primary','all'],default='primary')
 p.add_argument('--available-only',action='store_true',help='Audit finished runs while explicitly reporting pending cells')
 a=p.parse_args()
 import numpy as np
 from revision2_provenance import sha256,SCHEMA
 jobs=json.loads((Path(__file__).parent/'configs/jobs.json').read_text());failures=[];count=0;pending=[]
 for j in jobs:
  if j['action']!='retrain' or (a.stage=='primary' and j['priority']!=1):continue
  d=a.root/j['family']/j['protocol']
  if j['protocol']=='strict':d=d/f"tau{j['tau']}"
  d=d/j['model'];path=d/f"seed_{j['seed']}.json"
  if a.available_only and not path.exists():pending.append(str(path));continue
  try:
   m=json.loads(path.read_text());assert m['status']=='complete'
   assert m['seed']==j['seed'] and m['protocol']==j['protocol']
   if j['protocol']=='strict':assert m['tau']==j['tau']
   args=m['environment']['arguments']
   for key,value in {'epochs':40,'batch_size':256,'eval_batch_size':512,'learning_rate':.001,'ensemble_members':5,'rare_threshold':50,'bootstrap':0}.items():assert args[key]==value,key
   for key in ['limit_train','limit_val','limit_test','limit_ood','limit_chapman']:assert args[key] is None,key
   assert m['split']['hrv_imputation_manifest']['schema']==SCHEMA
   for role in ['raw_npz','ood_npz','fitted_state']:
    e=m['artifacts'][role];f=d/e['filename'];assert f.stat().st_size==e['bytes'] and sha256(f)==e['sha256'],role
   raw=np.load(d/m['artifacts']['raw_npz']['filename'],allow_pickle=False)
   for split in ['val','test']:
    assert len(raw[split+'_record_id'])==len(raw[split+'_y'])==len(raw[split+'_prob'])
    assert len(set(raw[split+'_record_id']))==len(raw[split+'_record_id'])
    prob=raw[split+'_prob'];assert prob.ndim==2 and np.isfinite(prob).all()
    assert np.allclose(prob.sum(1),1,atol=1e-5) and (prob>=0).all()
    labels=raw[split+'_y'];assert (labels>=0).all() and (labels<prob.shape[1]).all()
   assert not set(raw['train_record_id'])&set(raw['val_record_id'])
   assert not set(raw['train_record_id'])&set(raw['test_record_id'])
   assert not set(raw['val_record_id'])&set(raw['test_record_id'])
   assert not set(raw['val_patient'])&set(raw['test_patient'])
   ood=np.load(d/m['artifacts']['ood_npz']['filename'],allow_pickle=False)
   assert np.array_equal(raw['test_record_id'],ood['id_record_ids'])
   assert np.array_equal(raw['val_record_id'],ood['validation_record_ids'])
   for key in ood.files:
    if '__' in key:
     split=key.rsplit('__',1)[1]
     assert len(ood[key])==len(ood[split+'_record_ids']),key
     assert np.isfinite(ood[key]).all(),key
   count+=1
  except Exception as e:failures.append({'path':str(path),'error':repr(e)})
 print(json.dumps({'verified':count,'failures':failures,'pending_count':len(pending),'complete':not failures and not pending},indent=2))
 if failures:raise SystemExit(2)
if __name__=='__main__':main()
