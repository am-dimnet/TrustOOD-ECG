#!/usr/bin/env python3
"""Run the preserved postprocessor with explicit local historical path mapping.

Default: show the plan. --prepare-only audits the independent historical inputs
without computing new metrics. --execute requires the complete 433-run local
origin report and the complete 212-run formal view before any statistics.
"""
from pathlib import Path
import argparse
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'code'))
import postprocess_promised_metrics as P
from audit_revision2_provenance import atomic_json, digest, require
from audit_revision2_extensions import verify_origin_report, verify_record_files


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--historical-root', type=Path, required=True)
    p.add_argument('--ptb-root', type=Path)
    p.add_argument('--origin-report', type=Path)
    p.add_argument('--output', type=Path, required=True)
    modes = p.add_mutually_exclusive_group()
    modes.add_argument('--prepare-only', action='store_true')
    modes.add_argument('--execute', action='store_true')
    a = p.parse_args()
    old, output = a.historical_root.resolve(), a.output.resolve()
    roots = {name: old / 'results/formal' / name for name in ['noise_sqi', 'wearables']}
    if not (a.prepare_only or a.execute):
        print(json.dumps({'execute': False, 'required_origins': 433, 'required_formal_runs': 212,
                          'bootstrap': 2000, 'historical_roots': {k: str(v) for k, v in roots.items()},
                          'output': str(output)}, indent=2))
        return
    require(not output.exists(), 'Use a fresh output directory; preserve previous attempts')
    require(not output.is_relative_to(old), 'Never write into the historical archive')
    ledger = {}

    def resolve_declared(path_text, json_path):
        declared = Path(str(path_text))
        matched = [(name, root) for name, root in roots.items() if json_path.resolve().is_relative_to(root)]
        require(len(matched) == 1, 'Declared path is outside approved historical input roots')
        name, root = matched[0]
        if declared.is_absolute():
            original_root = Path('/root/Paper46_revision/results_final') / name
            require(declared.is_relative_to(original_root), 'Unexpected original artifact prefix')
            local = root / declared.relative_to(original_root)
        else:
            local = json_path.parent / declared
        local = local.resolve()
        require(local.is_relative_to(root) and local.parent == json_path.resolve().parent,
                'Historical artifact resolves outside its own run directory')
        payload = json.loads(json_path.read_text())
        record = payload['raw_npz' if name == 'noise_sqi' else 'prediction_file']
        require(str(record['path']) == str(path_text), 'Declared artifact differs from source JSON')
        require(local.is_file() and digest(local) == record['sha256'], 'Mapped historical artifact checksum differs')
        ledger[str(json_path.resolve())] = {
            'source_json_sha256': digest(json_path), 'original_path': str(declared),
            'local_path': str(local), 'sha256': record['sha256'], 'bytes': local.stat().st_size,
        }
        return local

    # Only path lookup is adapted. Every original data and mathematical check
    # still executes and original result JSON files remain byte-identical.
    P.resolve_declared = resolve_declared
    auxiliary, inputs = P.audit_auxiliary_roots(roots['noise_sqi'], roots['wearables'])
    output.mkdir(parents=True)
    atomic_json(output / 'historical_path_audit.json', {
        'complete': auxiliary['complete'], 'audit': auxiliary, 'path_map': ledger,
        'input_files': inputs, 'original_result_json_modified': False,
        'postprocessor_sha256': digest(HERE / 'code/postprocess_promised_metrics.py'),
    })
    require(auxiliary['complete'] and len(ledger) == 348, 'Historical 3 noise + 345 wearable inputs failed audit')
    if a.prepare_only:
        print(json.dumps({'mode': 'preparation', 'noise': 3, 'wearable': 345,
                          'complete_input_audit': True, 'statistics_computed': False}, indent=2))
        return
    require(a.ptb_root is not None and a.origin_report is not None, 'Execution requires formal view and full origin report')
    report = verify_origin_report(a.origin_report.resolve(), available_only=False)
    formal = [r for r in report['records'] if r['job']['family'] == 'formal']
    require(len(formal) == 212, 'Formal source count differs')
    for row in formal:
        verify_record_files(row)
    expected_jsons = {Path(r['json_path']).resolve() for r in formal}
    observed_jsons = {x.resolve() for x in a.ptb_root.rglob('seed_*.json')}
    require(observed_jsons == expected_jsons, 'Formal view does not match audited current and allowed historical origins')
    _, formal_audit, _ = P.audit_ptb(a.ptb_root.resolve())
    require(formal_audit['complete'], 'Formal mathematical input audit failed')
    atomic_json(output / 'origin_link.json', {'origin_report': str(a.origin_report.resolve()),
                                            'sha256': digest(a.origin_report), 'bootstrap': 2000})
    rc = P.main(['--ptb-root', str(a.ptb_root.resolve()), '--noise-root', str(roots['noise_sqi']),
                 '--wearables-root', str(roots['wearables']), '--output-dir', str(output / 'metrics'),
                 '--bootstrap', '2000', '--target-sensitivity', '0.95', '--fail-on-incomplete'])
    raise SystemExit(rc)


if __name__ == '__main__':
    main()
