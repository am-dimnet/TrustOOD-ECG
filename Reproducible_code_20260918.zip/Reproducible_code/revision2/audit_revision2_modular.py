#!/usr/bin/env python3
"""Audit corrected PTB and unchanged noise modular results under separate origins.

No training or inference is performed. The original independent mathematical
checker is reused; every upstream file is checked against its recorded hash.
Noise-only mode validates preparation but cannot publish a combined summary.
"""
from pathlib import Path
import argparse
import csv
import datetime
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'code'))
import audit_modular_pipeline as A
from audit_revision2_provenance import digest, require


def checked_file(path, entry):
    require(path.is_file() and path.stat().st_size == entry['bytes'] and
            digest(path) == entry['sha256'], 'Upstream checksum mismatch: ' + str(path))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--backup-root', type=Path, required=True)
    p.add_argument('--historical-root', type=Path, required=True)
    p.add_argument('--ptb-output', type=Path)
    p.add_argument('--origin-report', type=Path)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--noise-only', action='store_true')
    a = p.parse_args()
    backup, old, output = a.backup_root.resolve(), a.historical_root.resolve(), a.output.resolve()
    require(not output.exists(), 'Use a fresh audit output directory')
    if not a.noise_only:
        require(a.origin_report is not None and a.ptb_output is not None, 'Full mode requires PTB results and origin report')
        require(a.ptb_output.resolve().is_relative_to(backup), 'Use the verified local server-output backup')
        origin = json.loads(a.origin_report.read_text())
        require(origin['complete'] and not origin['failures'] and len(origin['records']) == 433,
                'Full 433-run origin audit is required')
        require(Path(origin['root']).resolve() == backup, 'Use the local origin audit matching this backup')
        require(origin['origin_counts'] == {'corrected_training_only_hrv_attempt2': 415,
                                           'historical_ecg_only_unchanged': 18}, 'Wrong origin totals')
        # Ensure the formal softmax inputs in this full audit have not changed.
        relevant = [r for r in origin['records'] if r['job']['family'] == 'formal' and
                    r['job']['model'] == 'softmax_modular' and r['job']['tau'] == 80]
        require(len(relevant) == 10 and all(r['origin'] == 'corrected_training_only_hrv_attempt2' for r in relevant),
                'Expected ten corrected softmax inputs')
        for row in relevant:
            for entry in row['files']:
                checked_file(Path(entry['path']), entry)
    old_results = old / 'results/extensions/modular_pipeline'
    inventory_path = old / 'inventories/modular_pipeline_results_bundle_sha256.tsv'
    with inventory_path.open() as f:
        inventory = {r['relative_path']: {'bytes': int(r['bytes']), 'sha256': r['sha256']}
                     for r in csv.DictReader(f, delimiter='\t')}
    noise_files, historical_cache = [], {}
    for seed in A.NOISE_SEEDS:
        for suffix in ('.json', '_arrays.npz'):
            rel = f'noise/seed_{seed}{suffix}'
            checked_file(old_results / rel, inventory[rel])
            noise_files.append({'relative_path': rel, **inventory[rel]})
        require((old / f'logs/modular_pipeline/noise_seed{seed}.exit').read_text().strip() == '0',
                'Historical noise task did not finish successfully')
        payload = json.loads((old_results / f'noise/seed_{seed}.json').read_text())
        for item in payload['run_definition']['input_artifacts']:
            if item['root_kind'] != 'cache':
                continue
            rel = Path(item['relative_path'])
            require(rel.name == str(rel), 'Unexpected nested historical cache input')
            path = old / 'configs/cache_manifests' / rel if rel.suffix == '.json' else backup / 'source_sidecars' / rel
            checked_file(path, item)
            historical_cache[str(rel)] = path
    output.mkdir(parents=True)
    # Small byte-identical copies keep the strict checker's root containment rule.
    # Historical manifest JSON stays unchanged rather than using new manifests.
    cache_view = output / 'historical_cache_inputs'
    cache_view.mkdir()
    for name, path in historical_cache.items():
        shutil.copy2(path, cache_view / name)
    roots = {
        'noise': {'code': old / 'code', 'cache': cache_view,
                  'noise_results': old / 'results/formal/noise_sqi',
                  'noise_checkpoints': old / 'checkpoints/noise_sqi',
                  'trustfed_cache': backup / 'wave_cache'},
        'ptb': {'code': backup / 'server_preparation/code', 'cache': backup / 'cache',
                'cache_provenance': backup, 'ptb_results': backup / 'results/formal',
                'trustfed_cache': backup / 'wave_cache'},
    }
    errors, payloads, audited = [], {'ptb': [], 'noise': []}, {'ptb': 0, 'noise': 0}
    domains = [('noise', A.NOISE_SEEDS, old_results)]
    if not a.noise_only:
        domains.insert(0, ('ptb', A.PTB_SEEDS, a.ptb_output.resolve()))
    for domain, seeds, result_root in domains:
        for seed in seeds:
            before = len(errors)
            payload, arrays = A.load_result_pair(result_root, domain, seed, roots[domain], errors)
            if payload is not None and arrays is not None:
                (A.audit_ptb_seed if domain == 'ptb' else A.audit_noise_seed)(payload, arrays, seed, errors)
                payloads[domain].append(payload)
                if len(errors) == before:
                    audited[domain] += 1
    generated_outputs = []
    ptb_output_files = []
    if not errors and not a.noise_only:
        require(audited == {'ptb': 5, 'noise': 3}, 'Canonical modular matrix incomplete')
        combined = output / 'combined'
        entries = []
        for domain, seeds, result_root in domains:
            (combined / domain).mkdir(parents=True)
            for seed in seeds:
                for suffix, role in (('.json', 'json'), ('_arrays.npz', 'arrays_npz')):
                    rel = f'{domain}/seed_{seed}{suffix}'
                    path = combined / rel
                    shutil.copy2(result_root / rel, path)
                    entries.append({'domain': domain, 'seed': seed, 'role': role,
                                    'relative_path': rel, 'bytes': path.stat().st_size, 'sha256': digest(path)})
        summary = combined / 'summary.json'
        A.atomic_json(summary, A.aggregate_scientific_results(payloads))
        entries.append({'domain': 'aggregate', 'seed': 0, 'role': 'summary_json',
                        'relative_path': 'summary.json', 'bytes': summary.stat().st_size, 'sha256': digest(summary)})
        definition = {'schema': A.MANIFEST_SCHEMA, 'script_version': 'revision2-mixed-origin-finalizer-v1',
                      'expected': {'ptb_seeds': A.PTB_SEEDS, 'noise_seeds': A.NOISE_SEEDS}, 'inventory': entries}
        A.atomic_json(combined / 'manifest.json', {
            'schema': A.MANIFEST_SCHEMA, 'status': 'complete', 'definition': definition,
            'fingerprint': A.canonical_hash(definition),
            'counts': {'ptb_results': 5, 'noise_results': 3, 'summary_files': 1, 'files': 17},
            'origin_policy': {'ptb': 'corrected_training_only_hrv_attempt2', 'noise': 'unchanged_historical_independent_noise'},
        })
        A.audit_manifest(combined, errors)
        A.compare(A.aggregate_scientific_results(payloads), json.loads(summary.read_text()), 'combined_summary', errors)
        if not errors:
            generated_outputs = [{'relative_path': str(f.relative_to(output)), 'bytes': f.stat().st_size,
                                  'sha256': digest(f)} for f in sorted(combined.rglob('*')) if f.is_file()]
            for seed in A.PTB_SEEDS:
                for suffix in ('.json', '_arrays.npz'):
                    f = a.ptb_output.resolve() / 'ptb' / f'seed_{seed}{suffix}'
                    ptb_output_files.append({'relative_to_backup': str(f.relative_to(backup)),
                                             'bytes': f.stat().st_size, 'sha256': digest(f)})
    report = {
        'schema': 'paper46-revision2-modular-mixed-origin-audit-v1',
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'failed' if errors else ('noise_preparation_verified' if a.noise_only else 'complete'),
        'complete': not errors and not a.noise_only, 'noise_only': a.noise_only,
        'audited': audited, 'errors': errors,
        'historical_noise_files': noise_files, 'historical_inventory_sha256': digest(inventory_path),
        'origin_report': None if a.noise_only else str(a.origin_report.resolve()),
        'origin_report_sha256': None if a.noise_only else digest(a.origin_report),
        'ptb_output_files': ptb_output_files,
        'generated_output_root': str(output), 'generated_outputs': generated_outputs,
        'mathematical_checker_sha256': digest(HERE / 'code/audit_modular_pipeline.py'),
        'adapter_sha256': digest(Path(__file__).resolve()),
        'roots_by_domain': {k: {n: str(v) for n, v in values.items()} for k, values in roots.items()},
        'checks': ['separate immutable code/input origins', 'upstream and output SHA-256',
                   'canonical fingerprints and seeds', 'safe NPZ dtypes/shapes',
                   'fold-9 threshold reconstruction', 'all diagnosis/selective/OOD metrics'],
        'neural_training_or_inference_performed': False,
    }
    A.atomic_json(output / 'audit.json', report)
    print(json.dumps({k: report[k] for k in ['status', 'complete', 'audited', 'errors']}, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
