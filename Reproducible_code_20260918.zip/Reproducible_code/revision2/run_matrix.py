#!/usr/bin/env python3
"""Print the corrected experiment matrix by default. Execution is explicitly gated."""
from pathlib import Path
import argparse,json,os,subprocess,sys,shlex,hashlib,shutil
HERE=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--stage',choices=['primary','remaining','all'],default='primary')
 p.add_argument('--cache-root',type=Path,required=True);p.add_argument('--trustfed-cache',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True);p.add_argument('--python',default=sys.executable)
 p.add_argument('--execute',action='store_true');p.add_argument('--only-model');p.add_argument('--only-seed',type=int)
 a=p.parse_args();jobs=json.loads((HERE/'configs/jobs.json').read_text())
 selected=[j for j in jobs if j['action']=='retrain' and (a.stage=='all' or (j['priority']==1)==(a.stage=='primary')) and (not a.only_model or a.only_model==j['model']) and (a.only_seed is None or a.only_seed==j['seed'])]
 print(f'{len(selected)} jobs; execute={a.execute}',flush=True)
 if a.execute:
  if os.environ.get('PAPER46_SERVER_READY')!='YES':raise SystemExit('Set PAPER46_SERVER_READY=YES after server authorization.')
  for forbidden in ['results_final','reproducibility_bundle','Reproducible_code/reference_outputs']:
   if forbidden in str(a.output.resolve()):raise SystemExit('Choose a new corrected-results directory, never an archive.')
  a.output.mkdir(parents=True,exist_ok=True)
  shutil.copy2(HERE/'configs/jobs.json',a.output/'planned_jobs.json')
 for job in selected:
  prot='closed' if job['protocol']=='closed' else f"strict_tau{job['tau']}"
  script='run_ptbxl_revision.py' if job['family']=='formal' else 'run_ptbxl_missing_extensions.py'
  cmd=[a.python,str(HERE/'code'/script),'--protocol',job['protocol'],'--models',job['model'],'--seed',str(job['seed']),
       '--tau',str(job['tau']),'--epochs','40','--batch-size','256','--eval-batch-size','512','--learning-rate','0.001',
       '--ensemble-members','5','--rare-threshold','50','--bootstrap','0','--device','cuda',
       '--cache-dir',str(a.cache_root/prot),'--trustfed-cache',str(a.trustfed_cache),'--results-dir',str(a.output/job['family'])]
  if job['protocol']=='closed':cmd.append('--cross-dataset')
  print(shlex.join(cmd),flush=True)
  if not a.execute:continue
  logdir=a.output/'logs'/job['family'];logdir.mkdir(parents=True,exist_ok=True)
  stem=f"{prot}_{job['model']}_seed{job['seed']}"
  (logdir/f'{stem}.command.json').write_text(json.dumps(cmd))
  env={**os.environ,'CUBLAS_WORKSPACE_CONFIG':':4096:8','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}
  with (logdir/f'{stem}.log').open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  (logdir/f'{stem}.exit').write_text(str(result.returncode))
  if result.returncode:raise SystemExit(f'Job failed ({result.returncode}); inspect {logdir/stem}.log')
if __name__=='__main__':main()
