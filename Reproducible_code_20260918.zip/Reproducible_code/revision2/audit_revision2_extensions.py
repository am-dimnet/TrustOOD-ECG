#!/usr/bin/env python3
"""Revision2 origin adapter for the unchanged extension mathematical audit.

The original checker remains the authority for the 49 groups, 221 runs, model
contracts, training histories, metric calculations and 1,400 representation
diagnostic rows. This adapter replaces only its historical deployment paths,
two-artifact assumption and launcher/code-origin checks with a verified
Revision2 provenance report. Partial checks never emit statistical summaries.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "code"))
import audit_promised_extensions as A
from audit_revision2_provenance import REMOTE, digest, require, relative_json


def verify_origin_report(report_path, available_only):
    report = json.loads(report_path.read_text())
    require(report["schema"] == "paper46-revision2-origin-audit-v1", "Wrong origin report schema")
    require(not report["failures"], "Origin report has failures")
    require(report["verified"] == len(report["records"]), "Origin report record count")
    if not available_only:
        require(report["complete"] and not report["available_only"] and len(report["records"]) == 433,
                "A complete 433-run origin audit is required before aggregation")
        require(report["origin_counts"] == {"corrected_training_only_hrv_attempt2": 415,
                                            "historical_ecg_only_unchanged": 18}, "Origin totals")
    root = Path(report["root"])
    require(digest(root / "environment/deployed_code_attempt2.json") == report["pinned_code_manifest_sha256"], "Pinned manifest changed")
    require(digest(root / "reused_ecg_only/reuse_manifest.json") == report["reuse_manifest_sha256"], "Reuse manifest changed")
    return report


def verify_record_files(row):
    """Detect any artifact replacement between provenance and mathematical audit."""
    for entry in row["files"]:
        p = Path(entry["path"])
        require(p.stat().st_size == entry["bytes"] and digest(p) == entry["sha256"], "Artifact changed after origin audit: " + str(p))


def check_common(payload, protocol, tag, seed, path, row, issues, adaptations):
    collected = []
    A.check_common_configuration(payload, protocol, tag, seed, path, collected)
    new = row["origin"] == "corrected_training_only_hrv_attempt2"
    cache = "closed" if protocol == "closed" else "strict_tau80"
    current_paths = {"environment.arguments.cache_dir": str(REMOTE / "cache" / cache),
                     "environment.arguments.trustfed_cache": str(REMOTE / "wave_cache")}
    for issue in collected:
        # Accept only these exact new paths, already tied to checked input hashes.
        field = issue.get("field")
        if new and issue["code"] == "configuration_mismatch" and field in current_paths and issue["actual"] == current_paths[field]:
            adaptations.append({"path": str(path), "kind": "verified_current_input_path", "field": field, "value": issue["actual"]})
        else:
            issues.append(issue)


def check_artifacts(payload, paths, row, issues, adaptations):
    collected = []
    A.check_artifact_manifest(payload, paths, collected)
    roles = {"raw_npz", "ood_npz", "fitted_state"}
    for issue in collected:
        if (row["origin"] == "corrected_training_only_hrv_attempt2"
                and issue["code"] == "artifact_manifest_roles_mismatch"
                and set(payload["artifacts"]) == roles):
            adaptations.append({"path": str(paths["json"]), "kind": "additional_verified_fitted_state", "sha256": payload["artifacts"]["fitted_state"]["sha256"]})
        else:
            issues.append(issue)


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    A.atomic_csv(path, rows, fields)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--origin-report", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--available-only", action="store_true")
    args = p.parse_args()
    report = verify_origin_report(args.origin_report, args.available_only)
    root = Path(report["root"])
    require(not args.output.resolve().is_relative_to(root / "results"), "Audit output must be separate from results")
    require(not args.output.resolve().is_relative_to(root / "reused_ecg_only"), "Audit output must be separate from reuse")
    config = A.build_expected_config()
    expected = A.expected_groups_by_identity(config)
    origins = {}
    for row in report["records"]:
        job = row["job"]
        if job["family"] != "extensions":
            continue
        key = ("closed" if job["protocol"] == "closed" else f"strict:tau{job['tau']}", job["model"], job["seed"])
        require(key in expected and key not in origins, "Unexpected or duplicate extension identity")
        verify_record_files(row)
        origins[key] = row
    # Reference arrays must be from audited corrected runs, never old HRV runs.
    for protocol in ["closed", "strict"]:
        refs = [r for r in report["records"] if r["job"]["family"] == "formal" and r["job"]["protocol"] == protocol
                and r["job"]["model"] == "trust_full" and r["job"]["seed"] == 7 and r["job"]["tau"] == 80]
        require(len(refs) == 1 and refs[0]["origin"] == "corrected_training_only_hrv_attempt2", "Audited corrected reference absent")
        verify_record_files(refs[0])
    issues, adaptations, records, feature_rows, weight_rows = [], [], [], [], []
    references = A.load_references(root / "results/formal", issues)
    for key, row in sorted(origins.items()):
        protocol, tag, seed = key
        group = expected[key]
        paths = {f["role"]: Path(f["path"]) for f in row["files"]}
        before = len(issues)
        payload = A.load_json(paths["json"], issues)
        raw = A.load_npz(paths["raw_npz"], issues)
        ood = A.load_npz(paths["ood_npz"], issues)
        if payload is None or raw is None or ood is None:
            continue
        check_common(payload, protocol, tag, seed, paths["json"], row, issues, adaptations)
        A.check_model_contract(payload, group, paths["json"], issues)
        A.check_fingerprint(payload, paths["json"], issues)
        A.check_training(payload, group, paths["json"], issues)
        diagnostics = A.check_representation_diagnostics(payload, group, protocol, paths["json"], issues)
        feature_rows.extend({"protocol": protocol, "tag": tag, "seed": seed, **r} for r in diagnostics)
        metrics = A.check_json_metrics(payload, protocol, paths["json"], issues)
        check_artifacts(payload, paths, row, issues, adaptations)
        weights = A.check_raw_npz(raw, protocol, group, payload, paths["raw_npz"], issues)
        A.check_ood_npz(ood, protocol, group, paths["ood_npz"], issues)
        reference = references.get(protocol)
        if row["origin"] == "historical_ecg_only_unchanged" and reference is not None:
            # ECG-only rows do not consume HRV. All non-HRV split fields and
            # every ordered label/patient/class/rare array still must match.
            reference = copy.deepcopy(reference)
            reference["split"].pop("hrv_imputation_manifest", None)
            require("hrv_imputation_manifest" not in payload["split"], "Unexpected changed historical split")
            adaptations.append({"path": str(paths["json"]), "kind": "ECG_only_split_no_HRV_dependency"})
        A.check_reference_alignment(payload, raw, protocol, reference, paths["json"], paths["raw_npz"], issues)
        weight_rows.append({"protocol": protocol, "tag": tag, "seed": seed,
                            **{k: json.dumps(v, separators=(",", ":")) if isinstance(v, list) else v for k, v in weights.items()}})
        records.append({"protocol": protocol, "tag": tag, "seed": seed, "family": group["family"],
                        "source_count": group["model"]["source_count"], "origin": row["origin"],
                        "json_path": str(paths["json"]), "raw_npz_path": str(paths["raw_npz"]), "ood_npz_path": str(paths["ood_npz"]),
                        "run_fingerprint": payload["run_fingerprint"], "parameter_total": payload["parameter_count"]["total"],
                        "parameter_trainable": payload["parameter_count"]["trainable"], "metrics": metrics, "complete": len(issues) == before})

    if not args.available_only:
        for label, actual, wanted in [("runs", len(records), 221), ("feature_rows", len(feature_rows), 1400),
                                       ("weight_rows", len(weight_rows), 221), ("groups", len({(r["protocol"], r["tag"]) for r in records}), 49)]:
            if actual != wanted:
                A.add_issue(issues, "full_matrix_cardinality", field=label, expected=wanted, actual=actual)
        allowed = {Path(f["path"]).resolve() for r in origins.values() for f in r["files"]}
        for prefix in [root / "results/extensions", root / "reused_ecg_only/extensions"]:
            for path in prefix.rglob("*"):
                if path.is_file() and path.suffix in [".json", ".npz", ".pt"] and path.resolve() not in allowed:
                    A.add_issue(issues, "unexpected_extension_artifact", path)

    complete = not args.available_only and not issues and len(records) == 221
    manifest = {"schema": "paper46-revision2-extensions-audit-v1", "complete": complete,
                "available_only": args.available_only, "loaded_record_count": len(records), "expected_record_count": 221,
                "representation_diagnostic_row_count": len(feature_rows), "source_weight_diagnostic_row_count": len(weight_rows),
                "origin_counts": dict(Counter(r["origin"] for r in records)), "issue_count": len(issues), "issues": issues,
                "origin_report": str(args.origin_report.resolve()), "origin_report_sha256": digest(args.origin_report),
                "mathematical_auditor_sha256": digest(Path(A.__file__)), "adapter_sha256": digest(Path(__file__)),
                "adaptations": adaptations, "interpretation_constraints": config["interpretation_constraints"],
                "remaining": [list(k) for k in expected if k not in origins]}
    A.atomic_json(args.output / "audit_manifest.json", manifest)
    # No publication summaries are emitted from partial or failed audits.
    if complete:
        summary_rows, summary = A.aggregate_records(records)
        pair_rows, pairs = A.paired_effects(records)
        feature_summary_rows, feature_summary = A.aggregate_feature_diagnostics(feature_rows)
        weight_summary = A.aggregate_weight_diagnostics(weight_rows)
        for name, value in [("expected_config.json", config), ("summary.json", summary), ("paired_effects.json", pairs),
                            ("representation_diagnostics_summary.json", feature_summary),
                            ("input_files.json", [f for r in origins.values() for f in r["files"]]),
                            ("task_logs.json", [{"job": r["job"], "origin": r["origin"], "commands": r["successful_queue_commands"]} for r in origins.values()]),
                            ("code_manifest.json", [{"job": r["job"], "origin": r["origin"], "code_sha256": r["code_sha256"]} for r in origins.values()])]:
            A.atomic_json(args.output / name, value)
        flat_records = [{**{k: v for k, v in r.items() if k != "metrics"}, **r["metrics"]} for r in records]
        for name, rows in [("records.csv", flat_records), ("summary.csv", summary_rows), ("paired_effects.csv", pair_rows),
                           ("representation_diagnostics.csv", feature_rows), ("representation_diagnostics_summary.csv", feature_summary_rows),
                           ("source_weight_diagnostics.csv", weight_rows), ("source_weight_diagnostics_summary.csv", weight_summary)]:
            write_csv(args.output / name, rows)
        manifest["generated_outputs"] = [
            {"path": str(f.resolve()), "relative_path": f.name, "bytes": f.stat().st_size, "sha256": digest(f)}
            for f in sorted(args.output.iterdir()) if f.is_file() and f.name != "audit_manifest.json"
        ]
        A.atomic_json(args.output / "audit_manifest.json", manifest)
    print(json.dumps({k: manifest[k] for k in ["complete", "loaded_record_count", "origin_counts", "issue_count", "issues"]}, indent=2))
    return 2 if issues or (not args.available_only and not complete) else 0


if __name__ == "__main__":
    raise SystemExit(main())
