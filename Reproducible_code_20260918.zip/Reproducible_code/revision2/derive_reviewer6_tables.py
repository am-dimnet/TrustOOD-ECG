#!/usr/bin/env python3
"""Derive fixed-risk coverage and hypothetical alert burden from verified new outputs.
No training/inference. Do not substitute historical HRV-affected arrays.
"""
from pathlib import Path
import argparse,json,sys,csv
sys.path.insert(0,str(Path(__file__).resolve().parent/'code'))
def main():
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 import numpy as np
 from scipy.stats import t as student_t, spearmanr
 from sklearn.metrics import roc_curve
 from revision2_provenance import SCHEMA,sha256
 rows=[];alerts=[];gates=[];provenance=[]
 for seed in [7,13,42,99,2026]:
  d=a.results/'formal/closed/trust_full';j=d/f'seed_{seed}.json';m=json.loads(j.read_text())
  assert m['status']=='complete' and m['split']['hrv_imputation_manifest']['schema']==SCHEMA
  for role in ['raw_npz','ood_npz']:
   e=m['artifacts'][role];assert sha256(d/e['filename'])==e['sha256']
  z=np.load(d/m['artifacts']['raw_npz']['filename'],allow_pickle=False)
  y=z['test_y'];prob=z['test_prob'];u=z['test_u'].reshape(-1)
  ids=z['test_record_id'];assert len(set(ids))==len(y)
  # Stable original-order tie handling matches the declared runner convention.
  order=np.argsort(u,kind='mergesort');correct=prob.argmax(1)==y
  risk=np.cumsum(~correct[order])/np.arange(1,len(y)+1);rare=np.isin(y,z['rare_ids'])
  for target in [.01,.05,.10]:
   possible=np.flatnonzero(risk<=target);n=int(possible[-1]+1) if len(possible) else 0
   rejected=np.ones(len(y),bool);rejected[order[:n]]=False
   rows.append(dict(seed=seed,target_risk=target,coverage=n/len(y),n_accepted=n,achieved_risk=float(risk[n-1]) if n else None,
                    rare_rejection=float(rejected[rare].mean()),frequent_rejection=float(rejected[~rare].mean())))
  o=np.load(d/m['artifacts']['ood_npz']['filename'],allow_pickle=False)
  assert np.array_equal(ids,o['id_record_ids'])
  inside=o['composite__id'];outside=o['composite__chapman']
  fpr,tpr,threshold=roc_curve(np.r_[np.zeros(len(inside)),np.ones(len(outside))],np.r_[inside,outside])
  pos=np.flatnonzero(tpr>=.95)[0];f=float(fpr[pos]);sens=float(tpr[pos])
  fixed=m['ood']['composite']['operating_point']
  for pi in [.001,.005,.01,.05,.10]:
   alerts.append(dict(seed=seed,prevalence=pi,retrospective_tpr=sens,retrospective_fpr=f,retrospective_threshold=float(threshold[pos]),
      ppv=pi*sens/(pi*sens+(1-pi)*f),false_alerts_per_1000=1000*(1-pi)*f,
      validation_fixed_tpr=fixed['ood_test_true_positive_rate'],validation_fixed_fpr=fixed['id_test_false_positive_rate']))
  w=z['test_source_w'];source=z['test_source_prob'];q=z['test_source_q'];names=z['source_names']
  gates.append(dict(seed=seed,source='mean',target='fused_correctness',spearman=float(spearmanr(w.mean(1),correct).statistic)))
  for k,name in enumerate(names):
   for target,value in [('own_correctness',source[:,k].argmax(1)==y),('shared_quality',q[:,k].reshape(-1))]:
    val=float(spearmanr(w[:,k],value).statistic)
    gates.append(dict(seed=seed,source=str(name),target=target,spearman=val if np.isfinite(val) else None))
  provenance.append({'path':str(j.resolve()),'sha256':sha256(j),'imputation':m['split']['hrv_imputation_manifest']})
 a.output.mkdir(parents=True,exist_ok=True)
 def write(name,data):
  with (a.output/name).open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 write('low_risk_per_seed.csv',rows);write('chapman_alert_burden_per_seed.csv',alerts);write('gate_correlations_per_seed.csv',gates)
 summary=[]
 for name,data,group,metrics in [('low_risk',rows,'target_risk',['coverage','n_accepted','achieved_risk','rare_rejection']),('alerts',alerts,'prevalence',['ppv','false_alerts_per_1000','retrospective_tpr','retrospective_fpr'])]:
  for value in sorted({r[group] for r in data}):
   for metric in metrics:
    x=np.array([r[metric] for r in data if r[group]==value and r[metric] is not None]);x=x[np.isfinite(x)]
    mean=float(x.mean()) if len(x) else None;sd=float(x.std(ddof=1)) if len(x)>1 else None
    half=float(student_t.ppf(.975,len(x)-1)*sd/np.sqrt(len(x))) if sd is not None else None
    summary.append(dict(analysis=name,setting=value,metric=metric,n_finite=len(x),mean=mean,sd=sd,ci_lower=mean-half if half is not None else None,ci_upper=mean+half if half is not None else None))
 write('reviewer6_seed_summary.csv',summary)
 (a.output/'provenance.json').write_text(json.dumps({'sources':provenance,'tie_rule':'stable source row order; largest prefix with empirical risk <= target','uncertainty':'seed Student-t; not patient-cluster uncertainty','alarm_rule':'actual achieved TPR at first ROC point with TPR >= .95; nonlinear PPV computed within seed'},indent=2))
if __name__=='__main__':main()
