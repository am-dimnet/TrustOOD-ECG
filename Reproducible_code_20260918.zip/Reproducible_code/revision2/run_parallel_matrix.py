#!/usr/bin/env python3
"""GPU-bound queue; unchanged scientific commands, durable status and fail-stop."""
from pathlib import Path
import argparse, collections, datetime, fcntl, json, os, shutil, subprocess, sys, time

HERE = Path(__file__).resolve().parent

def command(job, a):
    protocol = 'closed' if job['protocol'] == 'closed' else f"strict_tau{job['tau']}"
    script = 'run_ptbxl_revision.py' if job['family'] == 'formal' else 'run_ptbxl_missing_extensions.py'
    cmd = [a.python, '-u', str(HERE/'code'/script), '--protocol', job['protocol'],
           '--models', job['model'], '--seed', str(job['seed']), '--tau', str(job['tau']),
           '--epochs', '40', '--batch-size', '256', '--eval-batch-size', '512',
           '--learning-rate', '0.001', '--ensemble-members', '5', '--rare-threshold', '50',
           '--bootstrap', '0', '--device', 'cuda', '--cache-dir', str(a.cache_root/protocol),
           '--trustfed-cache', str(a.trustfed_cache), '--results-dir', str(a.output/job['family'])]
    if job['protocol'] == 'closed': cmd.append('--cross-dataset')
    return cmd

def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2))
    os.replace(temp, path)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage', choices=['primary', 'remaining', 'all'], default='primary')
    p.add_argument('--cache-root', type=Path, required=True)
    p.add_argument('--trustfed-cache', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--python', default=sys.executable)
    p.add_argument('--gpus', default='0,1')
    p.add_argument('--workers-per-gpu', type=int, default=1)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--only-protocol',choices=['closed','strict'])
    p.add_argument('--queue-name', choices=['default','remaining'], default='default',
                   help='Disjoint remaining phase may use separate control/status under guarded handoff')
    p.add_argument('--external-status', type=Path,
                   help='Read-only active primary jobs counted against the same GPU slot budget')
    a = p.parse_args()
    gpus = a.gpus.split(',')
    if a.workers_per_gpu < 1 or len(set(gpus)) != len(gpus): p.error('Invalid GPU slots')
    jobs = json.loads((HERE/'configs/jobs.json').read_text())
    jobs = [j for j in jobs if j['action']=='retrain' and
            (a.stage=='all' or (j['priority']==1)==(a.stage=='primary')) and
            (a.only_protocol is None or j['protocol']==a.only_protocol)]
    # Complete the priority-1 stage before opening the extension stage.
    seed_order={value:index for index,value in enumerate([7,13,42,99,2026])}
    # Different methods have different CPU/GPU phases; interleave them within each seed.
    # Model construction and training reset the seed, so queue order changes no protocol.
    jobs.sort(key=lambda j:(j['priority'],seed_order[j['seed']]))
    if not a.execute:
        print(json.dumps({'jobs':len(jobs),'gpus':gpus,'workers_per_gpu':a.workers_per_gpu,
                          'commands':[command(j,a) for j in jobs]},indent=2));return
    if os.environ.get('PAPER46_SERVER_READY') != 'YES':
        raise SystemExit('Server authorization flag is required')
    if any(s in str(a.output.resolve()) for s in ['results_final','reproducibility_bundle','reference_outputs']):
        raise SystemExit('A new result directory is required')
    a.output.mkdir(parents=True,exist_ok=True)
    prefix = '' if a.queue_name == 'default' else a.queue_name + '_'
    if a.queue_name == 'remaining' and (a.stage != 'remaining' or a.external_status is None):
        raise SystemExit('Named remaining queue requires a disjoint stage and primary status')
    lock = (a.output/(prefix+'queue.lock')).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    logroot = a.output/'queue_logs'/stamp
    logroot.mkdir(parents=True)
    shutil.copy2(HERE/'configs/jobs.json',a.output/'planned_jobs.json')
    pending = collections.deque(jobs);running=[];completed=[];failures=[]
    control = a.output/(prefix+'queue_control.json')
    if not control.exists():atomic_json(control,{'workers_per_gpu':a.workers_per_gpu,'pause_new_jobs':False})
    def status():
        atomic_json(a.output/(prefix+'queue_status.json'),{
            'updated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'queue_pid':os.getpid(),'stage':a.stage,'planned':len(jobs),
            'pending':len(pending),'completed':completed,'failures':failures,
            'running':[{k:v for k,v in r.items() if k not in ['process','handle']} for r in running],
            'state':'failed' if failures else ('complete' if not pending and not running else 'running')})
    while pending or running:
        for r in list(running):
            result = r['process'].poll()
            if result is None:continue
            r['handle'].close()
            elapsed=time.time()-r['started_unix']
            record={'job':r['job'],'gpu':r['gpu'],'seconds':elapsed,'exit_code':result,'log':r['log']}
            Path(r['log']+'.exit').write_text(str(result)+'\n')
            (completed if result==0 else failures).append(record)
            running.remove(r)
            print(json.dumps({'finished':record}),flush=True)
        settings=json.loads(control.read_text())
        slots=int(settings.get('workers_per_gpu',a.workers_per_gpu))
        if not 1 <= slots <= 8:raise ValueError('workers_per_gpu must be 1..8')
        external=[]
        if a.external_status is not None:
            source=json.loads(a.external_status.read_text())
            external=source['running']
            if source['failures']:
                settings['pause_new_jobs']=True
            if any(r['job']['priority']!=1 for r in external):
                raise ValueError('External phase is not restricted to disjoint primary jobs')
        if not failures and not settings.get('pause_new_jobs',False):
            for gpu in gpus:
                while pending and sum(r['gpu']==gpu for r in running)+sum(r['gpu']==gpu for r in external)<slots:
                    if running and pending[0]['priority']>min(r['job']['priority'] for r in running):break
                    job=pending.popleft();cmd=command(job,a)
                    stem=f"{job['family']}_{job['protocol']}_tau{job['tau']}_{job['model']}_seed{job['seed']}"
                    log=logroot/f'{stem}.log';handle=log.open('w')
                    env={**os.environ,'CUDA_VISIBLE_DEVICES':gpu,'CUBLAS_WORKSPACE_CONFIG':':4096:8',
                         'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1',
                         'NUMEXPR_NUM_THREADS':'1','PYTHONUNBUFFERED':'1'}
                    atomic_json(log.with_suffix('.command.json'),{'command':cmd,'gpu':gpu,'job':job})
                    proc=subprocess.Popen(cmd,stdout=handle,stderr=subprocess.STDOUT,env=env)
                    r={'job':job,'gpu':gpu,'pid':proc.pid,'started_unix':time.time(),
                       'log':str(log),'process':proc,'handle':handle}
                    running.append(r);print(json.dumps({'started':job,'gpu':gpu,'pid':proc.pid}),flush=True)
        status()
        if failures and not running:break
        if pending or running:time.sleep(5)
    status()
    if failures:raise SystemExit(2)

if __name__=='__main__':main()
