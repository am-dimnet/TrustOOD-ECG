#!/usr/bin/env python3
"""Leakage-free PTB-XL revision experiments for Paper46.

This runner is deliberately separate from the initially submitted code.  It
uses the zero-copy sidecars produced by :mod:`data_adapter`, freezes every
fit/selection decision on folds 1--8 / fold 9, and writes compact, resumable
JSON/NPZ artefacts rather than large checkpoints.

Examples
--------
Smoke test one model::

    python run_ptbxl_revision.py --protocol closed --models trust_full \
        --seed 7 --epochs 1 --limit-train 1024 --limit-val 512 --limit-test 512

Canonical closed-set comparison::

    python run_ptbxl_revision.py --protocol closed --models main --seed 7

Strict original-multilabel held-out-code OOD comparison::

    python run_ptbxl_revision.py --protocol strict --tau 80 --models main --seed 7

All OOD scores use one convention: larger means more OOD.  No Chapman or
fold-10 sample is used to fit a model, standardizer, covariance, temperature,
coefficient, or operating threshold.
"""

from __future__ import annotations

import argparse
import copy
import gc
import hashlib
import json
import math
import os
import platform
import random
import sys
import time
from collections import OrderedDict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import scipy
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.special import logsumexp
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    precision_recall_fscore_support,
    recall_score,
    roc_auc_score,
)

import data_adapter as D
import revision2_provenance as V2
_REVISION2_FITTED_STATES = {}
import revisionlib as R


SCRIPT_VERSION = "paper46-ptbxl-revision-v1"
RUN_FINGERPRINT_SCHEMA = "paper46-ptbxl-run-fingerprint-v1"
DEFAULT_SEEDS = (7, 13, 42, 99, 2026)
MAIN_MODELS = (
    "trust_full",
    "softmax_modular",
    "concat_matched",
    "deep_ensemble",
    "tmc",
    "tmdf",
    "pool_only",
    "fuse_only",
)
ABLATION_MODELS = (
    "trust_normalized",
    "trust_mean",
    "gate_uncertainty",
    "gate_sqi",
    "no_gate",
    "no_sqi_source",
    "no_sqi_source_gate_uncertainty",
    "comp_0",
    "comp_0.01",
    "comp_0.05",
    "comp_0.2",
    "comp_squared",
    "comp_crosscov",
)
SOURCE_COUNT_MODELS = tuple(
    f"{pooling}_s{count}"
    for pooling in ("cumulative", "normalized", "mean")
    for count in (1, 2, 3, 4)
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = False


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if hasattr(value, "__dataclass_fields__"):
        return jsonable(asdict(value))
    return value


def atomic_json(payload: Any, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(jsonable(payload), handle, indent=2, sort_keys=True, ensure_ascii=False,
                      allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_npz(target: Path, **arrays: np.ndarray) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("wb") as handle:
            np.savez_compressed(handle, **arrays)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_object(value: Any) -> str:
    encoded = json.dumps(
        jsonable(value), sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def source_specs(count: int = 4) -> OrderedDict[str, dict[str, Any]]:
    if count not in (1, 2, 3, 4):
        raise ValueError("source count must be 1, 2, 3, or 4")
    # All four PTB sources derive from the same acquisition, so the measured ECG
    # quality is explicitly shared rather than silently replaced by q=1.
    all_specs: OrderedDict[str, dict[str, Any]] = OrderedDict(
        (
            ("ecg", {"type": "wave", "in": 12, "quality_key": "ecg_q"}),
            ("hrv", {"type": "vec", "in": 8, "quality_key": "ecg_q"}),
            ("spec", {"type": "vec", "in": 36, "quality_key": "ecg_q"}),
            ("sqi", {"type": "vec", "in": 6, "quality_key": "ecg_q"}),
        )
    )
    return OrderedDict(list(all_specs.items())[:count])


class MatchedConcatClassifier(R.SharedBackboneClassifier):
    """Concat control whose 384-unit head matches the full model within 1%."""

    def __init__(self, sources: Mapping[str, Mapping[str, Any]], n_classes: int,
                 feat_dim: int = 128, drop: float = 0.2, hidden: int = 384):
        super().__init__(sources, n_classes, feat_dim=feat_dim, drop=drop)
        self.head = nn.Sequential(
            nn.Linear(self.feature_dim, hidden),
            nn.ReLU(),
            nn.Dropout(drop),
            nn.Linear(hidden, n_classes),
        )


@dataclass(frozen=True)
class ModelPlan:
    tag: str
    family: str
    pooling: str = "cumulative"
    branch: str = "both"
    gate_mode: str = "both"
    sqi_source: bool = True
    source_count: int = 4
    complementarity_weight: float = 0.1
    complementarity_mode: str = "absolute_cosine"


def parse_model_plan(tag: str) -> ModelPlan:
    fixed = {
        "trust_full": ModelPlan(tag, "trust"),
        "softmax_modular": ModelPlan(tag, "softmax", complementarity_weight=0.0),
        "concat_matched": ModelPlan(tag, "matched_concat", complementarity_weight=0.0),
        "deep_ensemble": ModelPlan(tag, "ensemble", complementarity_weight=0.0),
        "tmc": ModelPlan(tag, "tmc", complementarity_weight=0.0),
        "tmdf": ModelPlan(tag, "tmdf", complementarity_weight=0.0),
        "pool_only": ModelPlan(tag, "trust", branch="pooling_only"),
        "fuse_only": ModelPlan(tag, "trust", branch="fuse_only"),
        "trust_normalized": ModelPlan(tag, "trust", pooling="normalized"),
        "trust_mean": ModelPlan(tag, "trust", pooling="mean"),
        "gate_uncertainty": ModelPlan(tag, "trust", gate_mode="uncertainty_only"),
        "gate_sqi": ModelPlan(tag, "trust", gate_mode="sqi_only"),
        "no_gate": ModelPlan(tag, "trust", gate_mode="none"),
        "no_sqi_source": ModelPlan(tag, "trust", sqi_source=False),
        "no_sqi_source_gate_uncertainty": ModelPlan(
            tag, "trust", gate_mode="uncertainty_only", sqi_source=False
        ),
        "comp_squared": ModelPlan(tag, "trust", complementarity_mode="squared_cosine"),
        "comp_crosscov": ModelPlan(tag, "trust", complementarity_mode="cross_covariance"),
    }
    if tag in fixed:
        return fixed[tag]
    if tag.startswith("comp_"):
        return ModelPlan(tag, "trust", complementarity_weight=float(tag.split("_", 1)[1]))
    for pooling in ("cumulative", "normalized", "mean"):
        prefix = f"{pooling}_s"
        if tag.startswith(prefix):
            return ModelPlan(tag, "trust", pooling=pooling,
                             source_count=int(tag[len(prefix):]))
    raise ValueError(f"unknown model tag {tag!r}")


def build_model(plan: ModelPlan, n_classes: int) -> nn.Module:
    specs = source_specs(plan.source_count)
    if plan.family == "trust":
        return R.RevisionTrustModel(
            specs,
            n_classes,
            pooling=plan.pooling,
            branch=plan.branch,
            gate_mode=plan.gate_mode,
            sqi_source=plan.sqi_source,
            missing_quality="error" if plan.gate_mode in ("both", "sqi_only") else "ones",
        )
    if plan.family == "softmax":
        return R.SharedBackboneClassifier(specs, n_classes)
    if plan.family == "matched_concat":
        return MatchedConcatClassifier(specs, n_classes)
    if plan.family == "ensemble":
        # ``run_one`` expands this marker into five independently fitted
        # SharedBackboneClassifier members.
        return R.SharedBackboneClassifier(specs, n_classes)
    if plan.family == "tmc":
        return R.TMCAdapter(specs, n_classes)
    if plan.family == "tmdf":
        return R.TMDFAdapter(specs, n_classes)
    raise ValueError(plan.family)


def input_keys(model: nn.Module, arrays: Mapping[str, np.ndarray]) -> tuple[str, ...]:
    names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    keys = list(names)
    specs = getattr(model, "source_specs", {})
    for name in names:
        quality_key = str(specs.get(name, {}).get("quality_key", f"{name}_q"))
        if quality_key in arrays and quality_key not in keys:
            keys.append(quality_key)
    return tuple(keys)


def tensor_batch(arrays: Mapping[str, np.ndarray], indices: np.ndarray,
                 keys: Sequence[str], device: torch.device) -> dict[str, torch.Tensor]:
    result: dict[str, torch.Tensor] = {}
    for key in keys:
        value = torch.as_tensor(np.ascontiguousarray(arrays[key][indices]), device=device)
        if value.is_floating_point():
            value = value.float()
        result[key] = value
    return result


def softmax_numpy(logits: np.ndarray) -> np.ndarray:
    z = np.asarray(logits, dtype=np.float64)
    z = z - z.max(axis=1, keepdims=True)
    exp = np.exp(z)
    return exp / exp.sum(axis=1, keepdims=True)


@torch.no_grad()
def predict_softmax(model: nn.Module, arrays: Mapping[str, np.ndarray], batch_size: int,
                    device: torch.device) -> dict[str, np.ndarray]:
    model.eval()
    keys = input_keys(model, arrays)
    n = len(arrays[keys[0]])
    logits = []
    for start in range(0, n, batch_size):
        idx = np.arange(start, min(start + batch_size, n))
        logits.append(model(tensor_batch(arrays, idx, keys, device)).cpu().numpy())
    logit = np.concatenate(logits)
    prob = softmax_numpy(logit)
    return {
        "logits": logit,
        "prob": prob,
        "pred": prob.argmax(axis=1),
        "conf": prob.max(axis=1),
    }


def predict_any(model: nn.Module, plan: ModelPlan, arrays: Mapping[str, np.ndarray],
                batch_size: int, device: torch.device) -> dict[str, np.ndarray]:
    if plan.family in ("softmax", "matched_concat", "ensemble"):
        return predict_softmax(model, arrays, batch_size, device)
    return R.predict_revision(model, arrays, batch_size=batch_size, device=device)


def macro_auc(probs: np.ndarray, labels: np.ndarray,
              class_ids: Iterable[int] | None = None) -> float:
    ids = list(range(probs.shape[1])) if class_ids is None else list(class_ids)
    values = []
    for class_id in ids:
        truth = labels == class_id
        if truth.any() and (~truth).any():
            values.append(roc_auc_score(truth, probs[:, class_id]))
    return float(np.mean(values)) if values else float("nan")


def macro_auprc(probs: np.ndarray, labels: np.ndarray,
                class_ids: Iterable[int] | None = None) -> float:
    ids = list(range(probs.shape[1])) if class_ids is None else list(class_ids)
    values = []
    for class_id in ids:
        truth = labels == class_id
        if truth.any():
            values.append(average_precision_score(truth, probs[:, class_id]))
    return float(np.mean(values)) if values else float("nan")


def classwise_report(probs: np.ndarray, labels: np.ndarray, class_names: Sequence[str],
                     supports: Mapping[str, np.ndarray]) -> list[dict[str, Any]]:
    predictions = probs.argmax(axis=1)
    precision, recall, f1, test_support = precision_recall_fscore_support(
        labels, predictions, labels=np.arange(probs.shape[1]), zero_division=0
    )
    rows = []
    for class_id, name in enumerate(class_names):
        truth = labels == class_id
        auc = roc_auc_score(truth, probs[:, class_id]) if truth.any() and (~truth).any() else None
        auprc = average_precision_score(truth, probs[:, class_id]) if truth.any() else None
        rows.append(
            {
                "class_id": class_id,
                "class_name": name,
                "train_records": int(supports["train_records"][class_id]),
                "val_records": int(supports["val_records"][class_id]),
                "test_records": int(supports["test_records"][class_id]),
                "train_patients": int(supports["train_patients"][class_id]),
                "val_patients": int(supports["val_patients"][class_id]),
                "test_patients": int(supports["test_patients"][class_id]),
                "precision": float(precision[class_id]),
                "recall": float(recall[class_id]),
                "f1": float(f1[class_id]),
                "auroc": None if auc is None else float(auc),
                "auprc": None if auprc is None else float(auprc),
                "estimable_ranking": bool(truth.any() and (~truth).any()),
            }
        )
    return rows


def support_arrays(labels: np.ndarray, patient: np.ndarray, split_indices: Mapping[str, np.ndarray],
                   n_classes: int) -> dict[str, np.ndarray]:
    result: dict[str, np.ndarray] = {}
    for split, indices in split_indices.items():
        result[f"{split}_records"] = np.bincount(labels[indices], minlength=n_classes)
        result[f"{split}_patients"] = np.asarray(
            [len(np.unique(patient[indices][labels[indices] == class_id]))
             for class_id in range(n_classes)],
            dtype=np.int64,
        )
    return result


def selective_operating_report(probs: np.ndarray, labels: np.ndarray, confidence: np.ndarray,
                               rare_ids: np.ndarray) -> dict[str, Any]:
    base = R.selective_metrics(probs, labels, confidence=confidence)
    order = np.argsort(-confidence, kind="mergesort")
    predictions = probs.argmax(axis=1)
    fixed = {}
    rare_mask = np.isin(labels, rare_ids)
    for coverage in (1.0, 0.9, 0.8, 0.5):
        count = max(1, int(np.ceil(coverage * len(labels))))
        accepted = order[:count]
        rejected_mask = np.ones(len(labels), dtype=bool)
        rejected_mask[accepted] = False
        fixed[f"{coverage:.6g}"] = {
            "coverage": float(count / len(labels)),
            "balanced_accuracy": float(balanced_accuracy_score(labels[accepted], predictions[accepted])),
            "macro_f1": float(f1_score(labels[accepted], predictions[accepted], average="macro",
                                        labels=np.arange(probs.shape[1]), zero_division=0)),
            "rare_rejection_rate": float(rejected_mask[rare_mask].mean()) if rare_mask.any() else None,
            "frequent_rejection_rate": float(rejected_mask[~rare_mask].mean()) if (~rare_mask).any() else None,
        }
    return {
        "aurc": base["aurc"],
        "eaurc": base["eaurc"],
        "fixed_coverage": fixed,
        "coverage_at_fixed_risk": base["fixed_risk"],
    }


def diagnosis_report(raw: Mapping[str, np.ndarray], labels: np.ndarray,
                     val_raw: Mapping[str, np.ndarray], val_labels: np.ndarray,
                     class_names: Sequence[str], rare_ids: np.ndarray,
                     supports: Mapping[str, np.ndarray]) -> dict[str, Any]:
    probs = np.asarray(raw["prob"])
    predictions = probs.argmax(axis=1)
    logits = np.asarray(raw["logits"])
    val_logits = np.asarray(val_raw["logits"])
    calibration = R.calibration_report(logits, labels, val_logits, val_labels)
    scaler = R.TemperatureScaler(calibration["temperature"])
    scaled_probs = scaler.predict_proba(logits)
    selection_confidence = -np.asarray(raw["u"]) if "u" in raw else probs.max(axis=1)
    rare_evaluable = np.asarray(
        [class_id for class_id in rare_ids if np.any(labels == class_id)], dtype=np.int64
    )
    return {
        "accuracy": float(accuracy_score(labels, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "macro_f1": float(f1_score(labels, predictions, average="macro",
                                   labels=np.arange(probs.shape[1]), zero_division=0)),
        "weighted_f1": float(f1_score(labels, predictions, average="weighted", zero_division=0)),
        "macro_auroc": macro_auc(probs, labels),
        "macro_auprc": macro_auprc(probs, labels),
        "rare_n_defined": int(len(rare_ids)),
        "rare_n_evaluable": int(len(rare_evaluable)),
        "rare_macro_auroc": macro_auc(probs, labels, rare_evaluable),
        "rare_macro_auprc": macro_auprc(probs, labels, rare_evaluable),
        "rare_macro_recall": float(recall_score(labels, predictions, labels=rare_ids,
                                                average="macro", zero_division=0)),
        "rare_macro_f1": float(f1_score(labels, predictions, labels=rare_ids,
                                        average="macro", zero_division=0)),
        "calibration": calibration,
        "temperature_scaled_diagnosis": {
            "accuracy": float(accuracy_score(labels, scaled_probs.argmax(axis=1))),
            "macro_f1": float(f1_score(labels, scaled_probs.argmax(axis=1), average="macro",
                                       labels=np.arange(probs.shape[1]), zero_division=0)),
        },
        "selective_primary": selective_operating_report(probs, labels, selection_confidence, rare_ids),
        "selective_max_probability": selective_operating_report(probs, labels, probs.max(axis=1), rare_ids),
        "classwise": classwise_report(probs, labels, class_names, supports),
    }


def patient_bootstrap_report(raw: Mapping[str, np.ndarray], labels: np.ndarray,
                             patient_ids: np.ndarray, rare_ids: np.ndarray,
                             n_bootstrap: int, seed: int) -> dict[str, Any]:
    if n_bootstrap <= 0:
        return {}
    probs = np.asarray(raw["prob"])
    pred = probs.argmax(axis=1)
    statistics: dict[str, Callable[[np.ndarray], float]] = {
        "accuracy": lambda ix: accuracy_score(labels[ix], pred[ix]),
        "balanced_accuracy": lambda ix: balanced_accuracy_score(labels[ix], pred[ix]),
        "macro_f1": lambda ix: f1_score(labels[ix], pred[ix], average="macro",
                                        labels=np.arange(probs.shape[1]), zero_division=0),
        "rare_macro_f1": lambda ix: f1_score(labels[ix], pred[ix], average="macro",
                                             labels=rare_ids, zero_division=0),
    }
    report = {}
    for offset, (name, statistic) in enumerate(statistics.items()):
        result = R.patient_bootstrap(patient_ids, statistic, n_bootstrap=n_bootstrap,
                                     seed=seed + offset)
        report[name] = {
            "observed": result.observed,
            "ci95": [result.lower, result.upper],
            "n_bootstrap": result.n_bootstrap,
            "n_patients": result.n_patients,
        }
    return report


def class_weights(labels: np.ndarray, n_classes: int) -> np.ndarray:
    counts = np.bincount(labels, minlength=n_classes).astype(np.float64)
    weights = 1.0 / np.sqrt(counts + 1.0)
    return (weights / weights.mean()).astype(np.float32)


def alternative_complementarity_loss(projections: Sequence[torch.Tensor], mode: str) -> torch.Tensor:
    """Prespecified alternatives to the manuscript's absolute-cosine penalty."""

    if len(projections) < 2:
        return projections[0].new_zeros(()) if projections else torch.tensor(0.0)
    terms = []
    for left_index in range(len(projections)):
        for right_index in range(left_index + 1, len(projections)):
            left = projections[left_index]
            right = projections[right_index]
            if mode == "squared_cosine":
                terms.append(((left * right).sum(dim=-1) ** 2).mean())
            elif mode == "cross_covariance":
                left_centered = left - left.mean(dim=0, keepdim=True)
                right_centered = right - right.mean(dim=0, keepdim=True)
                covariance = left_centered.T @ right_centered / max(left.shape[0] - 1, 1)
                terms.append(covariance.square().mean())
            else:
                raise ValueError(f"unknown complementarity mode {mode!r}")
    return torch.stack(terms).mean()


def training_loss(model: nn.Module, plan: ModelPlan, output: Any, targets: torch.Tensor,
                  epoch: int, class_weight: torch.Tensor) -> torch.Tensor:
    if plan.family in ("softmax", "matched_concat", "ensemble"):
        return F.cross_entropy(output, targets, weight=class_weight)
    kl_weight = 0.05 * min(1.0, (epoch + 1) / 10.0)
    if plan.family in ("tmc", "tmdf"):
        return R.tmc_training_loss(output, targets, kl_weight=kl_weight,
                                   class_weights=class_weight)
    built_in_weight = (
        plan.complementarity_weight
        if plan.complementarity_mode == "absolute_cosine"
        else 0.0
    )
    loss = R.revision_training_loss(
        output,
        targets,
        kl_weight=kl_weight,
        ce_weight=0.5,
        deep_supervision_weight=0.3,
        complementarity_weight=built_in_weight,
        class_weights=class_weight,
    )
    if plan.complementarity_weight > 0 and plan.complementarity_mode != "absolute_cosine":
        loss = loss + plan.complementarity_weight * alternative_complementarity_loss(
            output["projs"], plan.complementarity_mode
        )
    return loss


def train_model(model: nn.Module, plan: ModelPlan, train: Mapping[str, np.ndarray],
                validation: Mapping[str, np.ndarray], n_classes: int, epochs: int,
                batch_size: int, learning_rate: float, seed: int, device: torch.device) -> tuple[nn.Module, dict[str, Any]]:
    set_seed(seed)
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs, 1))
    weight = torch.as_tensor(class_weights(train["y"], n_classes), device=device)
    keys = input_keys(model, train)
    best_score = -float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    history = []
    started = time.time()
    for epoch in range(epochs):
        model.train()
        permutation = np.random.permutation(len(train["y"]))
        total_loss = 0.0
        batches = 0
        for start in range(0, len(permutation), batch_size):
            indices = permutation[start:start + batch_size]
            batch = tensor_batch(train, indices, keys, device)
            targets = torch.as_tensor(train["y"][indices], dtype=torch.long, device=device)
            output = model(batch)
            loss = training_loss(model, plan, output, targets, epoch, weight)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total_loss += float(loss.detach().cpu())
            batches += 1
        scheduler.step()
        val_raw = predict_any(model, plan, validation, batch_size=max(batch_size, 512), device=device)
        score = macro_auc(val_raw["prob"], validation["y"])
        if not math.isfinite(score):
            score = float(accuracy_score(validation["y"], val_raw["pred"]))
        if score > best_score:
            best_score = score
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
        record = {
            "epoch": epoch + 1,
            "loss": total_loss / max(batches, 1),
            "val_macro_auroc": score,
            "val_accuracy": float(accuracy_score(validation["y"], val_raw["pred"])),
            "elapsed_seconds": time.time() - started,
        }
        history.append(record)
        print(
            f"[{plan.tag} seed={seed}] epoch {epoch + 1:02d}/{epochs} "
            f"loss={record['loss']:.4f} val_auc={score:.4f} "
            f"val_acc={record['val_accuracy']:.4f}",
            flush=True,
        )
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {
        "best_val_macro_auroc": best_score,
        "history": history,
        "train_seconds": time.time() - started,
        "selection": "maximum fold-9 macro-AUROC; no fold-10 or OOD data",
    }


def parameter_count(model: nn.Module) -> dict[str, int]:
    return {
        "total": int(sum(parameter.numel() for parameter in model.parameters())),
        "trainable": int(sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)),
    }


def profile_inference(model: nn.Module, arrays: Mapping[str, np.ndarray], batch_size: int,
                      device: torch.device) -> dict[str, Any]:
    n = min(batch_size, len(next(iter(arrays.values()))))
    indices = np.arange(n)
    keys = input_keys(model, arrays)
    batch = tensor_batch(arrays, indices, keys, device)
    model.eval()
    if device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
    with torch.no_grad():
        for _ in range(5):
            model(batch)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        durations = []
        for _ in range(20):
            start = time.perf_counter()
            model(batch)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            durations.append(time.perf_counter() - start)
    return {
        "batch_size": n,
        "median_batch_ms": float(np.median(durations) * 1000),
        "median_ms_per_record": float(np.median(durations) * 1000 / n),
        "peak_gpu_memory_bytes": int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else None,
    }


def materialize(adapter: D.DatasetAdapter, indices: np.ndarray, labels: np.ndarray | None,
                label_map: Mapping[int, int] | None = None) -> dict[str, np.ndarray]:
    if any(value is None for value in (adapter.hrv8, adapter.spec36, adapter.sqi6, adapter.quality)):
        raise RuntimeError(f"{adapter.name} derived feature sidecars have not been prepared")
    arrays = {
        "ecg": adapter.signals[indices],
        "hrv": np.asarray(adapter.hrv8[indices], dtype=np.float32),
        "spec": np.asarray(adapter.spec36[indices], dtype=np.float32),
        "sqi": np.asarray(adapter.sqi6[indices], dtype=np.float32),
        "ecg_q": np.asarray(adapter.quality[indices], dtype=np.float32),
    }
    if labels is not None:
        selected = np.asarray(labels[indices], dtype=np.int64)
        if label_map is not None:
            try:
                selected = np.asarray([label_map[int(value)] for value in selected], dtype=np.int64)
            except KeyError as exc:
                raise RuntimeError(f"unmapped label in an ID split: {exc}") from exc
        arrays["y"] = selected
    return arrays


def deterministic_limit(indices: np.ndarray, limit: int | None, seed: int) -> np.ndarray:
    if limit is None or limit <= 0 or len(indices) <= limit:
        return indices
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(indices, size=limit, replace=False))


def deterministic_stratified_limit(indices: np.ndarray, labels: np.ndarray,
                                   limit: int | None, seed: int) -> np.ndarray:
    """Limit a training split while retaining at least one record per class.

    This path is used only by remote smoke tests.  Canonical runs never set a
    training limit and therefore always use the complete official split.
    """

    if limit is None or limit <= 0 or len(indices) <= limit:
        return indices
    present = np.unique(labels[indices])
    if limit < len(present):
        raise ValueError(f"training limit {limit} is smaller than {len(present)} classes")
    rng = np.random.default_rng(seed)
    mandatory = np.asarray(
        [rng.choice(indices[labels[indices] == class_id]) for class_id in present],
        dtype=np.int64,
    )
    remaining = np.setdiff1d(indices, mandatory, assume_unique=False)
    additional = rng.choice(remaining, size=limit - len(mandatory), replace=False)
    return np.sort(np.r_[mandatory, additional])


def load_protocol(args: argparse.Namespace) -> dict[str, Any]:
    adapter = D.open_dataset("ptbxl", args.trustfed_cache, args.cache_dir)
    if adapter.y_trainfreq is None or adapter.label_names is None:
        raise RuntimeError("PTB label sidecars are missing; run data_adapter.py --prepare-metadata")
    metadata = adapter.metadata
    folds = pd.to_numeric(metadata["strat_fold"], errors="raise").to_numpy(dtype=np.int64)
    patient = metadata["patient_id"].astype(str).to_numpy()
    valid = adapter.valid
    labels = np.asarray(adapter.y_trainfreq, dtype=np.int64)
    full_names = list(adapter.label_names)
    if args.protocol == "closed":
        train_index = np.flatnonzero(valid & (folds <= 8))
        val_index = np.flatnonzero(valid & (folds == 9))
        test_index = np.flatnonzero(valid & (folds == 10))
        label_map = None
        class_names = full_names
        ood_indices: dict[str, np.ndarray] = {}
        split_manifest = {
            "protocol": "closed",
            "train": len(train_index), "validation": len(val_index), "test": len(test_index),
        }
    else:
        split_path = Path(args.cache_dir) / f"ptbxl_strict_ood_tau{args.tau}.npz"
        if not split_path.is_file():
            raise FileNotFoundError(split_path)
        split = np.load(split_path, allow_pickle=False)
        train_index = split["train_id"]
        val_index = split["val_id"]
        test_index = split["test_id"]
        ood_indices = {
            "all": split["test_ood"],
            "pure": split["test_ood_pure"],
            "mixed": split["test_ood_mixed"],
        }
        label_payload = json.loads((Path(args.cache_dir) / "ptbxl_labels.json").read_text())
        heldout = set(label_payload["strict_ood"][str(args.tau)]["heldout_codes"])
        known_original = [index for index, name in enumerate(full_names) if name not in heldout]
        label_map = {old: new for new, old in enumerate(known_original)}
        class_names = [full_names[index] for index in known_original]
        split_manifest = label_payload["strict_ood"][str(args.tau)]
    imputation_manifest = V2.validate_imputation(args, adapter, train_index)
    split_manifest = {**split_manifest, "hrv_imputation_manifest": imputation_manifest}
    train_index = deterministic_stratified_limit(
        train_index, labels, args.limit_train, args.seed + 1
    )
    val_index = deterministic_limit(val_index, args.limit_val, args.seed + 2)
    test_index = deterministic_limit(test_index, args.limit_test, args.seed + 3)
    if args.protocol == "strict" and args.limit_ood:
        ood_indices = {
            name: deterministic_limit(index, args.limit_ood, args.seed + 10 + offset)
            for offset, (name, index) in enumerate(ood_indices.items())
        }
    return {
        "adapter": adapter,
        "labels": labels,
        "patient": patient,
        "train_index": train_index,
        "val_index": val_index,
        "test_index": test_index,
        "ood_indices": ood_indices,
        "label_map": label_map,
        "class_names": class_names,
        "split_manifest": split_manifest,
    }


@torch.no_grad()
def source_features(model: nn.Module, arrays: Mapping[str, np.ndarray], batch_size: int,
                    device: torch.device) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    model.eval()
    keys = input_keys(model, arrays)
    names = tuple(getattr(model, "source_names", getattr(model, "src_names", ())))
    features = {name: [] for name in names}
    aux: dict[str, list[np.ndarray]] = {"u": [], "source_w": []}
    n = len(arrays[names[0]])
    for start in range(0, n, batch_size):
        indices = np.arange(start, min(start + batch_size, n))
        output = model(tensor_batch(arrays, indices, keys, device))
        for name in names:
            features[name].append(output["per"][name]["h"].cpu().numpy())
        aux["u"].append(output["u"].cpu().numpy().reshape(-1))
        aux["source_w"].append(output["source_w"].cpu().numpy())
    return (
        {name: np.concatenate(parts) for name, parts in features.items()},
        {name: np.concatenate(parts) for name, parts in aux.items()},
    )


def fit_source_density(model: nn.Module, train: Mapping[str, np.ndarray], validation: Mapping[str, np.ndarray],
                       n_classes: int, batch_size: int, device: torch.device) -> dict[str, Any]:
    train_features, _ = source_features(model, train, batch_size, device)
    val_features, val_aux = source_features(model, validation, batch_size, device)
    states = {}
    val_scores = {}
    for name in train_features:
        state = R.fit_mahalanobis(train_features[name], train["y"], n_classes=n_classes,
                                  covariance="ledoit_wolf", ridge=1e-3, standardize=True)
        states[name] = state
        val_scores[name] = R.mahalanobis_ood_score(val_features[name], state)
    density_val = R.combine_source_ood_scores(
        val_scores, list(train_features), weights=val_aux["source_w"],
        reference_scores=val_scores, normalize_weights=True,
    )
    return {
        "states": states,
        "reference_scores": val_scores,
        "vacuity_mean": float(val_aux["u"].mean()),
        "vacuity_std": float(val_aux["u"].std() + 1e-8),
        "vacuity_median": float(np.median(val_aux["u"])),
        "vacuity_mad": float(np.median(np.abs(val_aux["u"] - np.median(val_aux["u"]))) + 1e-8),
        "density_val": density_val,
        "source_names": list(train_features),
    }


def source_density_scores(model: nn.Module, arrays: Mapping[str, np.ndarray], state: Mapping[str, Any],
                          batch_size: int, device: torch.device) -> dict[str, np.ndarray]:
    features, aux = source_features(model, arrays, batch_size, device)
    per_source = {
        name: R.mahalanobis_ood_score(features[name], state["states"][name])
        for name in state["source_names"]
    }
    density = R.combine_source_ood_scores(
        per_source, state["source_names"], weights=aux["source_w"],
        reference_scores=state["reference_scores"], normalize_weights=True,
    )
    vacuity_z = (aux["u"] - state["vacuity_mean"]) / state["vacuity_std"]
    vacuity_robust = (aux["u"] - state["vacuity_median"]) / (1.4826 * state["vacuity_mad"])
    return {
        "vacuity": aux["u"],
        "density": density,
        "composite": vacuity_z + density,
        "composite_robust": vacuity_robust + density,
        "source_w": aux["source_w"],
        **{f"density_{name}": score for name, score in per_source.items()},
    }


def threshold_report(validation_score: np.ndarray, id_score: np.ndarray,
                     ood_score: np.ndarray, quantile: float = 0.95) -> dict[str, Any]:
    threshold = float(np.quantile(validation_score, quantile))
    return {
        "validation_quantile": quantile,
        "threshold": threshold,
        "id_test_false_positive_rate": float(np.mean(id_score > threshold)),
        "ood_test_true_positive_rate": float(np.mean(ood_score > threshold)),
    }


@torch.no_grad()
def gpu_knn_scores(train_features: np.ndarray, query_features: np.ndarray, k: int,
                   device: torch.device, chunk_size: int = 512) -> np.ndarray:
    """Official normalized-feature kNN score, evaluated by chunked GPU matmul."""

    train = torch.as_tensor(train_features, dtype=torch.float32, device=device)
    train = F.normalize(train, dim=1)
    outputs = []
    for start in range(0, len(query_features), chunk_size):
        query = torch.as_tensor(query_features[start:start + chunk_size], dtype=torch.float32,
                                device=device)
        query = F.normalize(query, dim=1)
        similarity = query @ train.T
        kth_similarity = torch.topk(similarity, k=k, dim=1, largest=True).values[:, -1]
        outputs.append(torch.sqrt(torch.clamp(2.0 - 2.0 * kth_similarity, min=0.0)).cpu().numpy())
    del train
    return np.concatenate(outputs)


def posthoc_softmax_ood(model: R.SharedBackboneClassifier, train: Mapping[str, np.ndarray],
                        validation: Mapping[str, np.ndarray], id_test: Mapping[str, np.ndarray],
                        ood_sets: Mapping[str, Mapping[str, np.ndarray]], n_classes: int,
                        batch_size: int, device: torch.device) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    f_train, z_train = R.extract_features_logits(model, train, batch_size, device)
    f_val, z_val = R.extract_features_logits(model, validation, batch_size, device)
    f_id, z_id = R.extract_features_logits(model, id_test, batch_size, device)
    extracted = {
        name: R.extract_features_logits(model, arrays, batch_size, device)
        for name, arrays in ood_sets.items()
    }
    p_val, p_id = softmax_numpy(z_val), softmax_numpy(z_id)
    weight = model.head.weight.detach().cpu().numpy()
    bias = model.head.bias.detach().cpu().numpy()

    maha_states = {
        "empirical_r1e-5": R.fit_mahalanobis(f_train, train["y"], n_classes, "empirical",
                                             ridge=1e-5, standardize=True),
        "empirical_r1e-3": R.fit_mahalanobis(f_train, train["y"], n_classes, "empirical",
                                             ridge=1e-3, standardize=True),
        "empirical_r1e-1": R.fit_mahalanobis(f_train, train["y"], n_classes, "empirical",
                                             ridge=1e-1, standardize=True),
        "empirical_shrink0.1": R.fit_mahalanobis(
            f_train, train["y"], n_classes, "empirical", shrinkage=0.1,
            ridge=1e-3, standardize=True
        ),
        "ledoit_wolf": R.fit_mahalanobis(f_train, train["y"], n_classes, "ledoit_wolf",
                                         ridge=1e-3, standardize=True),
        "oas": R.fit_mahalanobis(f_train, train["y"], n_classes, "oas",
                                 ridge=1e-3, standardize=True),
    }
    vim_state = R.fit_vim(f_train, z_train, weight, bias, principal_dim=f_train.shape[1] // 2)
    dice_state = R.fit_dice(f_train, weight, bias, keep_ratio=0.1)
    _REVISION2_FITTED_STATES["posthoc"] = {
        "mahalanobis": maha_states, "vim": vim_state, "dice": dice_state,
        "knn_training_features": f_train, "training_labels": train["y"],
    }
    scores: dict[str, dict[str, np.ndarray]] = {
        "MSP": {"validation": R.msp_ood_score(p_val), "id": R.msp_ood_score(p_id)},
        "Energy": {"validation": R.energy_ood_score(z_val), "id": R.energy_ood_score(z_id)},
        "GEN": {"validation": R.gen_ood_score(logits=z_val, gamma=0.1, top_m=min(100, n_classes)),
                "id": R.gen_ood_score(logits=z_id, gamma=0.1, top_m=min(100, n_classes))},
        "ViM": {"validation": R.vim_ood_score(f_val, z_val, vim_state),
                "id": R.vim_ood_score(f_id, z_id, vim_state)},
        "DICE": {"validation": R.dice_ood_score(f_val, dice_state),
                 "id": R.dice_ood_score(f_id, dice_state)},
        "deep-kNN": {"validation": gpu_knn_scores(f_train, f_val, 50, device),
                     "id": gpu_knn_scores(f_train, f_id, 50, device)},
    }
    for name, state in maha_states.items():
        scores[f"Mahalanobis:{name}"] = {
            "validation": R.mahalanobis_ood_score(f_val, state),
            "id": R.mahalanobis_ood_score(f_id, state),
        }
    odin_val = R.odin_ood_score(model, validation, wave_keys=("ecg",), batch_size=batch_size,
                                device=device)
    odin_id = R.odin_ood_score(model, id_test, wave_keys=("ecg",), batch_size=batch_size,
                               device=device)
    scores["ODIN"] = {"validation": odin_val["score"], "id": odin_id["score"]}

    for set_name, arrays in ood_sets.items():
        features, logits = extracted[set_name]
        probs = softmax_numpy(logits)
        scores["MSP"][set_name] = R.msp_ood_score(probs)
        scores["Energy"][set_name] = R.energy_ood_score(logits)
        scores["GEN"][set_name] = R.gen_ood_score(logits=logits, gamma=0.1,
                                                  top_m=min(100, n_classes))
        scores["ViM"][set_name] = R.vim_ood_score(features, logits, vim_state)
        scores["DICE"][set_name] = R.dice_ood_score(features, dice_state)
        scores["deep-kNN"][set_name] = gpu_knn_scores(f_train, features, 50, device)
        for name, state in maha_states.items():
            scores[f"Mahalanobis:{name}"][set_name] = R.mahalanobis_ood_score(features, state)
        scores["ODIN"][set_name] = R.odin_ood_score(
            model, arrays, wave_keys=("ecg",), batch_size=batch_size, device=device
        )["score"]

    report: dict[str, Any] = {}
    primary_ood_name = "all" if "all" in ood_sets else next(iter(ood_sets))
    for method, values in scores.items():
        report[method] = {
            "primary": R.ood_metrics(values["id"], values[primary_ood_name]),
            "operating_point": threshold_report(values["validation"], values["id"],
                                                 values[primary_ood_name]),
            "strata": {
                name: R.ood_metrics(values["id"], values[name]) for name in ood_sets
            },
        }
    flat_scores = {
        f"{method}__{split}": np.asarray(value)
        for method, splits in scores.items() for split, value in splits.items()
    }
    return report, flat_scores


def basic_softmax_ood(model: nn.Module, validation: Mapping[str, np.ndarray],
                      id_test: Mapping[str, np.ndarray],
                      ood_sets: Mapping[str, Mapping[str, np.ndarray]], batch_size: int,
                      device: torch.device) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    """Output-space OOD controls for the nonlinear parameter-matched concat head."""

    raw = {
        "validation": predict_softmax(model, validation, batch_size, device),
        "id": predict_softmax(model, id_test, batch_size, device),
        **{
            name: predict_softmax(model, arrays, batch_size, device)
            for name, arrays in ood_sets.items()
        },
    }
    scores = {
        "MSP": {name: R.msp_ood_score(value["prob"]) for name, value in raw.items()},
        "Energy": {name: R.energy_ood_score(value["logits"]) for name, value in raw.items()},
        "GEN": {
            name: R.gen_ood_score(logits=value["logits"], gamma=0.1,
                                  top_m=min(100, value["prob"].shape[1]))
            for name, value in raw.items()
        },
    }
    scores["ODIN"] = {
        "validation": R.odin_ood_score(model, validation, wave_keys=("ecg",),
                                        batch_size=batch_size, device=device)["score"],
        "id": R.odin_ood_score(model, id_test, wave_keys=("ecg",),
                                batch_size=batch_size, device=device)["score"],
        **{
            name: R.odin_ood_score(model, arrays, wave_keys=("ecg",),
                                   batch_size=batch_size, device=device)["score"]
            for name, arrays in ood_sets.items()
        },
    }
    primary = "all" if "all" in ood_sets else next(iter(ood_sets))
    report = {
        method: {
            "primary": R.ood_metrics(values["id"], values[primary]),
            "operating_point": threshold_report(
                values["validation"], values["id"], values[primary]
            ),
            "strata": {
                name: R.ood_metrics(values["id"], values[name]) for name in ood_sets
            },
        }
        for method, values in scores.items()
    }
    flat = {
        f"{method}__{split}": np.asarray(value)
        for method, values in scores.items() for split, value in values.items()
    }
    return report, flat


def evidence_ood_report(model: nn.Module, train: Mapping[str, np.ndarray],
                        validation: Mapping[str, np.ndarray], id_test: Mapping[str, np.ndarray],
                        ood_sets: Mapping[str, Mapping[str, np.ndarray]], n_classes: int,
                        batch_size: int, device: torch.device) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    density_state = fit_source_density(model, train, validation, n_classes, batch_size, device)
    _REVISION2_FITTED_STATES["source_density"] = density_state
    val_scores = source_density_scores(model, validation, density_state, batch_size, device)
    id_scores = source_density_scores(model, id_test, density_state, batch_size, device)
    out_scores = {
        name: source_density_scores(model, arrays, density_state, batch_size, device)
        for name, arrays in ood_sets.items()
    }
    methods = ("vacuity", "density", "composite", "composite_robust")
    primary = "all" if "all" in ood_sets else next(iter(ood_sets))
    report = {}
    for method in methods:
        report[method] = {
            "primary": R.ood_metrics(id_scores[method], out_scores[primary][method]),
            "operating_point": threshold_report(val_scores[method], id_scores[method],
                                                 out_scores[primary][method]),
            "strata": {
                name: R.ood_metrics(id_scores[method], scores[method])
                for name, scores in out_scores.items()
            },
        }
    # Fixed coefficient sensitivity; all component normalizers remain fold-9-only.
    report["coefficient_sensitivity"] = {}
    for coefficient in (0.0, 0.5, 1.0, 2.0):
        val = ((val_scores["vacuity"] - density_state["vacuity_mean"])
               / density_state["vacuity_std"] + coefficient * val_scores["density"])
        ids = ((id_scores["vacuity"] - density_state["vacuity_mean"])
               / density_state["vacuity_std"] + coefficient * id_scores["density"])
        outs = ((out_scores[primary]["vacuity"] - density_state["vacuity_mean"])
                / density_state["vacuity_std"] + coefficient * out_scores[primary]["density"])
        report["coefficient_sensitivity"][str(coefficient)] = {
            "metrics": R.ood_metrics(ids, outs),
            "operating_point": threshold_report(val, ids, outs),
        }
    flat = {}
    for split, scores in {"validation": val_scores, "id": id_scores, **out_scores}.items():
        for method, values in scores.items():
            flat[f"{method}__{split}"] = np.asarray(values)
    return report, flat


def predict_ensemble(models: Sequence[nn.Module], arrays: Mapping[str, np.ndarray],
                     batch_size: int, device: torch.device) -> dict[str, np.ndarray]:
    """Five-member probability ensemble plus epistemic mutual information."""

    member_probabilities = np.stack(
        [predict_softmax(model, arrays, batch_size, device)["prob"] for model in models],
        axis=0,
    )
    probability = member_probabilities.mean(axis=0)
    predictive_entropy = -(probability * np.log(np.clip(probability, 1e-12, 1.0))).sum(axis=1)
    member_entropy = -(
        member_probabilities * np.log(np.clip(member_probabilities, 1e-12, 1.0))
    ).sum(axis=2).mean(axis=0)
    return {
        "prob": probability,
        "logits": np.log(np.clip(probability, 1e-12, 1.0)),
        "pred": probability.argmax(axis=1),
        "conf": probability.max(axis=1),
        "predictive_entropy": predictive_entropy,
        "mutual_information": predictive_entropy - member_entropy,
    }


def ensemble_ood_report(models: Sequence[nn.Module], validation: Mapping[str, np.ndarray],
                        id_test: Mapping[str, np.ndarray],
                        ood_sets: Mapping[str, Mapping[str, np.ndarray]], batch_size: int,
                        device: torch.device) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    raw = {
        "validation": predict_ensemble(models, validation, batch_size, device),
        "id": predict_ensemble(models, id_test, batch_size, device),
        **{
            name: predict_ensemble(models, arrays, batch_size, device)
            for name, arrays in ood_sets.items()
        },
    }
    scores = {
        "Ensemble-MSP": {
            split: R.msp_ood_score(value["prob"]) for split, value in raw.items()
        },
        "Ensemble-predictive-entropy": {
            split: value["predictive_entropy"] for split, value in raw.items()
        },
        "Ensemble-mutual-information": {
            split: value["mutual_information"] for split, value in raw.items()
        },
    }
    primary = "all" if "all" in ood_sets else next(iter(ood_sets))
    report = {}
    for method, values in scores.items():
        report[method] = {
            "primary": R.ood_metrics(values["id"], values[primary]),
            "operating_point": threshold_report(
                values["validation"], values["id"], values[primary]
            ),
            "strata": {
                name: R.ood_metrics(values["id"], values[name]) for name in ood_sets
            },
        }
    flat = {
        f"{method}__{split}": np.asarray(value)
        for method, values in scores.items() for split, value in values.items()
    }
    return report, flat


def profile_ensemble(models: Sequence[nn.Module], arrays: Mapping[str, np.ndarray],
                     batch_size: int, device: torch.device) -> dict[str, Any]:
    profiles = [profile_inference(model, arrays, batch_size, device) for model in models]
    return {
        "members": len(models),
        "batch_size": profiles[0]["batch_size"],
        "median_batch_ms_sum_members": float(
            sum(profile["median_batch_ms"] for profile in profiles)
        ),
        "median_ms_per_record_sum_members": float(
            sum(profile["median_ms_per_record"] for profile in profiles)
        ),
        "peak_gpu_memory_bytes_sequential": max(
            profile["peak_gpu_memory_bytes"] or 0 for profile in profiles
        ),
    }


def load_chapman(args: argparse.Namespace, limit: int | None, seed: int) -> tuple[dict[str, np.ndarray], np.ndarray]:
    adapter = D.open_dataset("chapman", args.trustfed_cache, args.cache_dir)
    indices = np.flatnonzero(adapter.valid)
    indices = deterministic_limit(indices, limit, seed)
    return materialize(adapter, indices, labels=None), indices


def current_code_hashes() -> dict[str, str]:
    return {
        "run_ptbxl_revision.py": sha256_file(Path(__file__).resolve()),
        "revisionlib.py": sha256_file(Path(R.__file__).resolve()),
        "data_adapter.py": sha256_file(Path(D.__file__).resolve()),
    }


def environment_manifest(args: argparse.Namespace, device: torch.device) -> dict[str, Any]:
    code_hashes = current_code_hashes()
    return {
        "script_version": SCRIPT_VERSION,
        "script_sha256": code_hashes["run_ptbxl_revision.py"],
        "revisionlib_sha256": code_hashes["revisionlib.py"],
        "data_adapter_sha256": code_hashes["data_adapter.py"],
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pandas": pd.__version__,
        "sklearn": sklearn.__version__,
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "device": str(device),
        "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "arguments": vars(args),
        "score_direction": "higher means more OOD for every OOD score",
    }


def make_run_definition(
    args: argparse.Namespace, plan: ModelPlan, protocol: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "script_version": SCRIPT_VERSION,
        "code_sha256": current_code_hashes(),
        "arguments": vars(args),
        "model": asdict(plan),
        "seed": args.seed,
        "protocol": args.protocol,
        "tau": args.tau if args.protocol == "strict" else None,
        "split": protocol["split_manifest"],
        "n_classes": len(protocol["class_names"]),
        "class_names": protocol["class_names"],
    }


def artifact_manifest_entry(path: Path) -> dict[str, Any]:
    return {
        "filename": path.name,
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def existing_run_status(
    json_path: Path,
    raw_path: Path,
    ood_path: Path,
    expected_fingerprint: str,
    expect_ood: bool,
) -> tuple[bool, bool, str]:
    """Return ``(same_definition, complete, reason)`` for resumable output."""

    if not json_path.is_file():
        return False, False, "result JSON is absent"
    try:
        payload = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, False, f"result JSON is unreadable: {type(exc).__name__}"
    if payload.get("fingerprint_schema") != RUN_FINGERPRINT_SCHEMA:
        return False, False, "fingerprint schema is missing or stale"
    if payload.get("run_fingerprint") != expected_fingerprint:
        return False, False, "run fingerprint differs from the requested run"
    definition = payload.get("run_definition")
    if not isinstance(definition, Mapping) or sha256_object(definition) != expected_fingerprint:
        return False, False, "stored run definition does not match its fingerprint"
    if payload.get("status") != "complete":
        return True, False, "status is not complete"
    artifacts = payload.get("artifacts")
    if not isinstance(artifacts, Mapping):
        return True, False, "artifact checksum manifest is absent"
    required_paths = [("raw_npz", raw_path), ("fitted_state", json_path.with_name(json_path.stem + "_fitted_state.pt"))]
    if expect_ood:
        required_paths.append(("ood_npz", ood_path))
    for role, path in required_paths:
        declared = artifacts.get(role)
        if not isinstance(declared, Mapping):
            return True, False, f"{role} checksum manifest is absent"
        if not path.is_file():
            return True, False, f"{role} file is absent"
        if declared.get("filename") != path.name:
            return True, False, f"{role} filename differs"
        if declared.get("bytes") != int(path.stat().st_size):
            return True, False, f"{role} byte count differs"
        if declared.get("sha256") != sha256_file(path):
            return True, False, f"{role} checksum differs"
    return True, True, "complete fingerprinted result"


def run_one(args: argparse.Namespace, tag: str, protocol: Mapping[str, Any],
            device: torch.device) -> None:
    _REVISION2_FITTED_STATES.clear()
    plan = parse_model_plan(tag)
    result_dir = Path(args.results_dir) / args.protocol
    if args.protocol == "strict":
        result_dir = result_dir / f"tau{args.tau}"
    result_dir = result_dir / tag
    json_path = result_dir / f"seed_{args.seed}.json"
    raw_path = result_dir / f"seed_{args.seed}_raw.npz"
    ood_path = result_dir / f"seed_{args.seed}_ood_scores.npz"
    expect_ood = args.protocol == "strict" or args.cross_dataset
    run_definition = make_run_definition(args, plan, protocol)
    run_fingerprint = sha256_object(run_definition)
    if not args.force and any(path.is_file() for path in (json_path, raw_path, ood_path)):
        same_definition, complete, reason = existing_run_status(
            json_path, raw_path, ood_path, run_fingerprint, expect_ood,
        )
        if complete:
            print(
                f"[resume] {tag} seed={args.seed} complete; fingerprint and artefacts verified",
                flush=True,
            )
            return
        if json_path.is_file() and not same_definition:
            raise RuntimeError(
                f"refusing to mix an existing incompatible result at {json_path}: {reason}; "
                "use a new results directory or explicitly pass --force"
            )
        print(f"[recover] {tag} seed={args.seed}: {reason}; recomputing", flush=True)

    adapter: D.DatasetAdapter = protocol["adapter"]
    labels = protocol["labels"]
    label_map = protocol["label_map"]
    train = materialize(adapter, protocol["train_index"], labels, label_map)
    validation = materialize(adapter, protocol["val_index"], labels, label_map)
    test = materialize(adapter, protocol["test_index"], labels, label_map)
    class_names = protocol["class_names"]
    n_classes = len(class_names)
    if set(np.unique(train["y"])) != set(range(n_classes)):
        missing = sorted(set(range(n_classes)) - set(np.unique(train["y"])))
        raise RuntimeError(f"training split has no records for model classes {missing}")
    # Reset before construction as well as training so a model's initialization
    # never depends on which other tags happened to run earlier in a process.
    set_seed(args.seed)
    models: list[nn.Module] = []
    if plan.family == "ensemble":
        member_training = []
        for member in range(args.ensemble_members):
            member_seed = args.seed * 100 + member
            set_seed(member_seed)
            member_model = build_model(plan, n_classes)
            print(
                f"\n=== {args.protocol} {tag} seed={args.seed} "
                f"member={member + 1}/{args.ensemble_members} ===",
                flush=True,
            )
            member_model, member_history = train_model(
                member_model, plan, train, validation, n_classes, args.epochs,
                args.batch_size, args.learning_rate, member_seed, device,
            )
            models.append(member_model)
            member_training.append({"member": member, "seed": member_seed, **member_history})
        per_member_count = parameter_count(models[0])
        counts = {
            "per_member_total": per_member_count["total"],
            "per_member_trainable": per_member_count["trainable"],
            "members": args.ensemble_members,
            "total": per_member_count["total"] * args.ensemble_members,
            "trainable": per_member_count["trainable"] * args.ensemble_members,
        }
        training = {
            "members": member_training,
            "train_seconds": float(sum(item["train_seconds"] for item in member_training)),
            "selection": "each member independently selected by fold-9 macro-AUROC",
        }
        val_raw = predict_ensemble(models, validation, args.eval_batch_size, device)
        test_raw = predict_ensemble(models, test, args.eval_batch_size, device)
        model: nn.Module | None = None
    else:
        model = build_model(plan, n_classes)
        counts = parameter_count(model)
        print(
            f"\n=== {args.protocol} {tag} seed={args.seed} params={counts['total']:,} ===",
            flush=True,
        )
        model, training = train_model(
            model, plan, train, validation, n_classes, args.epochs, args.batch_size,
            args.learning_rate, args.seed, device,
        )
        val_raw = predict_any(model, plan, validation, args.eval_batch_size, device)
        test_raw = predict_any(model, plan, test, args.eval_batch_size, device)

    train_global_labels = labels[protocol["train_index"]]
    if label_map is not None:
        train_global_labels = np.asarray([label_map[int(value)] for value in train_global_labels])
    rare_ids = np.flatnonzero(np.bincount(train_global_labels, minlength=n_classes) < args.rare_threshold)
    patient = protocol["patient"]
    split_for_support = {
        "train": protocol["train_index"],
        "val": protocol["val_index"],
        "test": protocol["test_index"],
    }
    if label_map is None:
        support_label_vector = labels
        support_patient = patient
    else:
        # Supports are computed only on ID records, so create a safe remapped vector.
        support_label_vector = np.full_like(labels, -1)
        for old, new in label_map.items():
            support_label_vector[labels == old] = new
        support_patient = patient
    supports = support_arrays(support_label_vector, support_patient, split_for_support, n_classes)
    diagnosis = diagnosis_report(test_raw, test["y"], val_raw, validation["y"],
                                 class_names, rare_ids, supports)
    bootstrap = patient_bootstrap_report(
        test_raw, test["y"], patient[protocol["test_index"]], rare_ids,
        args.bootstrap, args.seed,
    )
    if args.profile and plan.family == "ensemble":
        profiling = profile_ensemble(models, test, args.eval_batch_size, device)
    elif args.profile:
        assert model is not None
        profiling = profile_inference(model, test, args.eval_batch_size, device)
    else:
        profiling = {}

    ood_report: dict[str, Any] = {}
    ood_scores: dict[str, np.ndarray] = {}
    if args.protocol == "strict":
        ood_sets = {
            name: materialize(adapter, indices, labels=None)
            for name, indices in protocol["ood_indices"].items()
        }
        if plan.family == "ensemble":
            ood_report, ood_scores = ensemble_ood_report(
                models, validation, test, ood_sets, args.eval_batch_size, device
            )
        elif plan.family == "softmax":
            assert model is not None
            ood_report, ood_scores = posthoc_softmax_ood(
                model, train, validation, test, ood_sets, n_classes,
                args.eval_batch_size, device,
            )
        elif plan.family == "matched_concat":
            assert model is not None
            ood_report, ood_scores = basic_softmax_ood(
                model, validation, test, ood_sets, args.eval_batch_size, device
            )
        elif plan.family not in ("matched_concat",):
            assert model is not None
            ood_report, ood_scores = evidence_ood_report(
                model, train, validation, test, ood_sets, n_classes,
                args.eval_batch_size, device,
            )
    elif args.cross_dataset:
        chapman, chapman_indices = load_chapman(args, args.limit_chapman, args.seed + 50)
        ood_sets = {"chapman": chapman}
        if plan.family == "ensemble":
            ood_report, ood_scores = ensemble_ood_report(
                models, validation, test, ood_sets, args.eval_batch_size, device
            )
        elif plan.family == "softmax":
            assert model is not None
            ood_report, ood_scores = posthoc_softmax_ood(
                model, train, validation, test, ood_sets, n_classes,
                args.eval_batch_size, device,
            )
        elif plan.family == "matched_concat":
            assert model is not None
            ood_report, ood_scores = basic_softmax_ood(
                model, validation, test, ood_sets, args.eval_batch_size, device
            )
        elif plan.family not in ("matched_concat",):
            assert model is not None
            ood_report, ood_scores = evidence_ood_report(
                model, train, validation, test, ood_sets, n_classes,
                args.eval_batch_size, device,
            )
        ood_report["chapman_n"] = int(len(chapman_indices))

    if expect_ood and not ood_scores:
        raise RuntimeError(
            f"{args.protocol}/{tag}/seed={args.seed} requires OOD output but produced no scores"
        )

    environment = environment_manifest(args, device)

    payload = {
        "status": "complete",
        "fingerprint_schema": RUN_FINGERPRINT_SCHEMA,
        "run_definition": run_definition,
        "run_fingerprint": run_fingerprint,
        "model": asdict(plan),
        "seed": args.seed,
        "protocol": args.protocol,
        "tau": args.tau if args.protocol == "strict" else None,
        "split": protocol["split_manifest"],
        "n_classes": n_classes,
        "class_names": class_names,
        "rare_definition": f"folds 1-8 model-label record count < {args.rare_threshold}",
        "rare_ids": rare_ids,
        "rare_names": [class_names[index] for index in rare_ids],
        "parameter_count": counts,
        "training": training,
        "diagnosis": diagnosis,
        "patient_cluster_bootstrap": bootstrap,
        "profiling": profiling,
        "ood": ood_report,
        "environment": environment,
        "created_at_unix": time.time(),
    }
    raw_arrays = {
        "val_prob": val_raw["prob"], "val_logits": val_raw["logits"], "val_y": validation["y"],
        "test_prob": test_raw["prob"], "test_logits": test_raw["logits"], "test_y": test["y"],
        "test_patient": patient[protocol["test_index"]].astype(str),
        "val_patient": patient[protocol["val_index"]].astype(str),
        "train_record_id": V2.record_ids(adapter, protocol["train_index"]),
        "val_record_id": V2.record_ids(adapter, protocol["val_index"]),
        "test_record_id": V2.record_ids(adapter, protocol["test_index"]),
        "rare_ids": rare_ids,
        "class_names": np.asarray(class_names, dtype=str),
    }
    for prefix, raw in (("val", val_raw), ("test", test_raw)):
        for name in ("u", "u_pool", "source_u", "source_q", "source_w", "q_observed", "source_prob", "evidence", "pool_evidence"):
            if name in raw:
                raw_arrays[f"{prefix}_{name}"] = raw[name]
    if plan.family not in ("softmax", "matched_concat", "ensemble"):
        raw_arrays["source_names"] = np.asarray(model.source_names, dtype=str)
    if ood_scores:
        ood_scores["validation_record_ids"] = V2.record_ids(adapter, protocol["val_index"])
        ood_scores["id_record_ids"] = V2.record_ids(adapter, protocol["test_index"])
        if args.protocol == "strict":
            for subset, indices in protocol["ood_indices"].items():
                ood_scores[f"{subset}_record_ids"] = V2.record_ids(adapter, indices)
        else:
            ca = D.open_dataset("chapman", args.trustfed_cache, args.cache_dir)
            ood_scores["chapman_record_ids"] = V2.record_ids(ca, chapman_indices)
    state_path = result_dir / f"seed_{args.seed}_fitted_state.pt"
    V2.save_fitted_state(state_path, model, models, plan, protocol, diagnosis,
                         _REVISION2_FITTED_STATES, run_definition)
    atomic_npz(raw_path, **raw_arrays)
    if ood_scores:
        atomic_npz(ood_path, **ood_scores)
    payload["artifacts"] = {
        "fitted_state": artifact_manifest_entry(state_path),
        "raw_npz": artifact_manifest_entry(raw_path),
        **(
            {"ood_npz": artifact_manifest_entry(ood_path)}
            if expect_ood else {}
        ),
    }
    atomic_json(payload, json_path)
    print(f"[saved] {json_path}", flush=True)
    del models, train, validation, test, val_raw, test_raw
    if model is not None:
        del model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def expand_models(value: str) -> list[str]:
    tokens = [token.strip() for token in value.split(",") if token.strip()]
    expanded = []
    for token in tokens:
        if token == "main":
            expanded.extend(MAIN_MODELS)
        elif token == "ablations":
            expanded.extend(ABLATION_MODELS)
        elif token == "source_count":
            expanded.extend(SOURCE_COUNT_MODELS)
        elif token == "all":
            expanded.extend(MAIN_MODELS + ABLATION_MODELS + SOURCE_COUNT_MODELS)
        else:
            expanded.append(token)
    unique = []
    for token in expanded:
        parse_model_plan(token)
        if token not in unique:
            unique.append(token)
    if not unique:
        raise argparse.ArgumentTypeError("at least one model is required")
    return unique


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--protocol", choices=("closed", "strict"), required=True)
    parser.add_argument("--models", default="main", help="comma list, or main/ablations/source_count/all")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--tau", type=int, default=80)
    parser.add_argument("--rare-threshold", type=int, default=50)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--eval-batch-size", type=int, default=512)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--ensemble-members", type=int, default=5)
    parser.add_argument("--bootstrap", type=int, default=0,
                        help="patient-cluster bootstrap replicates; aggregate stage can also do this")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--cross-dataset", action="store_true",
                        help="for closed protocol, evaluate all valid Chapman records as domain-shift OOD")
    parser.add_argument("--limit-train", type=int)
    parser.add_argument("--limit-val", type=int)
    parser.add_argument("--limit-test", type=int)
    parser.add_argument("--limit-ood", type=int)
    parser.add_argument("--limit-chapman", type=int)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--trustfed-cache", default=str(D.DEFAULT_TRUSTFED_CACHE))
    parser.add_argument("--cache-dir", default="/root/Paper46_revision/cache")
    parser.add_argument("--results-dir", default="/root/Paper46_revision/results")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if (args.epochs < 1 or args.batch_size < 1 or args.eval_batch_size < 1
            or args.ensemble_members < 2):
        raise SystemExit("epochs and batch sizes must be positive")
    if args.protocol == "strict" and args.cross_dataset:
        raise SystemExit("--cross-dataset is only valid with --protocol closed")
    args.models = expand_models(args.models)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA requested but unavailable")
    set_seed(args.seed)
    protocol = load_protocol(args)
    print(json.dumps(jsonable({
        "protocol": args.protocol,
        "models": args.models,
        "seed": args.seed,
        "train": len(protocol["train_index"]),
        "validation": len(protocol["val_index"]),
        "test": len(protocol["test_index"]),
        "ood": {name: len(index) for name, index in protocol["ood_indices"].items()},
        "n_classes": len(protocol["class_names"]),
        "device": str(device),
    }), indent=2), flush=True)
    for tag in args.models:
        run_one(args, tag, protocol, device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
