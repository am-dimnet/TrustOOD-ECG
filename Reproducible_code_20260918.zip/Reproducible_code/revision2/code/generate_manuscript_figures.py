#!/usr/bin/env python3
"""Generate the eleven quantitative figures used by the revised manuscript.

The five structural figures are maintained separately because they are diagrams,
not data plots. This script reads only independently audited aggregate outputs;
it never reads waveforms, identifiers, checkpoints, or raw predictions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd


BLUE = "#4477AA"
CYAN = "#66CCEE"
GREEN = "#228833"
YELLOW = "#CCBB44"
RED = "#CC6677"
PURPLE = "#AA3377"
GREY = "#777777"
BLACK = "#222222"
LIGHT = "#E9EEF4"
INPUT_FILES: dict[str, dict] = {}
AXIS_REPORT: list[dict] = []

METHOD_COLORS = {
    "TrustOOD-ECG": RED,
    "Softmax": BLUE,
    "Matched concat.": CYAN,
    "Deep ensemble": GREEN,
    "Pool only": YELLOW,
    "Gated Fuse only": PURPLE,
    "TMC": GREY,
    "TMDF/ETMC": BLACK,
}

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["DejaVu Serif"],
        "mathtext.fontset": "dejavuserif",
        "font.size": 8.2,
        "axes.titlesize": 9.0,
        "axes.labelsize": 8.4,
        "legend.fontsize": 7.0,
        "xtick.labelsize": 7.4,
        "ytick.labelsize": 7.4,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.20,
        "grid.linewidth": 0.55,
        "axes.axisbelow": True,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.035,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)


def parse_args() -> argparse.Namespace:
    here = Path(__file__).resolve()
    package = here.parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reference-root",
        type=Path,
        default=package / "reference_outputs",
        help="Root containing aggregates/ and manuscript_tables/.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--origin-report", type=Path, required=True,
                        help="Complete 433-run Revision2 origin report linked by the aggregate audits")
    parser.add_argument("--historical-root", type=Path, required=True,
                        help="Immutable Revision1 Submission_Supplement/reference_outputs tree for independent tables")
    return parser.parse_args()


def verify_reference_tree(root: Path, origin_path: Path, historical: Path) -> dict:
    """Reject incomplete or historical-HRV aggregate inputs before drawing."""
    def require(ok, message):
        if not ok:
            raise ValueError(message)

    def load(path):
        value = json.loads(path.read_text())
        INPUT_FILES[str(path.resolve())] = {"path": str(path.resolve()), "bytes": path.stat().st_size,
                                          "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        return value

    def check_output(path, entries):
        matching = [x for x in entries if Path(x.get("relative_path", x.get("path", ""))).name == path.name]
        require(len(matching) == 1, "Missing or duplicate aggregate output declaration: " + str(path))
        e = matching[0]
        require(path.is_file() and path.stat().st_size == e["bytes"] and
                hashlib.sha256(path.read_bytes()).hexdigest() == e["sha256"], "Aggregate output checksum mismatch: " + str(path))

    origin = load(origin_path)
    require(origin.get("schema") == "paper46-revision2-origin-audit-v1" and
            origin.get("complete") and not origin.get("available_only") and not origin.get("failures") and
            len(origin.get("records", [])) == 433, "Complete 433-run Revision2 origin audit required before drawing")
    require(origin["origin_counts"] == {"corrected_training_only_hrv_attempt2": 415,
                                        "historical_ecg_only_unchanged": 18}, "Incorrect result origins")
    expected = {f["sha256"] for row in origin["records"] if row["job"]["family"] == "formal"
                for f in row["files"] if f["role"] == "json"}
    require(len(expected) == 212, "Expected 212 formal source JSON hashes")
    agg = root / "aggregates"
    formal = load(agg / "ptbxl/result_manifest.json")
    require(formal["summary"]["complete"] and formal["summary"]["n_records"] == 212,
            "Formal aggregate is incomplete")
    actual = [x["sha256"] for x in formal["files"] if x.get("role") == "result_json"]
    require(len(actual) == 212 and set(actual) == expected, "Formal aggregates use different or historical HRV results")
    for name in ["seed_summary.csv", "ood_summary.csv", "calibration_summary.csv", "classwise_summary.csv"]:
        check_output(agg / "ptbxl" / name, formal["generated_outputs"])
    extension = load(agg / "promised_extensions/audit_manifest.json")
    require(extension.get("schema") == "paper46-revision2-extensions-audit-v1" and extension["complete"] and
            extension["loaded_record_count"] == 221 and not extension["issues"], "Extensions audit is incomplete or from old HRV inputs")
    require(extension["origin_report_sha256"] == hashlib.sha256(origin_path.read_bytes()).hexdigest(),
            "Extension audit is not linked to the supplied origin report")
    check_output(agg / "promised_extensions/summary.csv", extension["generated_outputs"])
    promised = load(agg / "promised_postprocess/manifest.json")
    completion_path = agg / "promised_postprocess/completion_matrix.json"
    check_output(completion_path, promised["outputs"])
    require(load(completion_path)["complete"], "Promised-metric postprocessing is incomplete")
    actual = [x["sha256"] for x in promised["inputs"] if x.get("role") == "ptb_json"]
    require(len(actual) == 212 and set(actual) == expected, "Postprocessing uses different PTB inputs")
    for name in ["ood_paired_seed.csv", "selective_seed_summary.csv", "ood_alert_seed_summary.csv"]:
        check_output(agg / "promised_postprocess" / name, promised["outputs"])
    historical_files = ["aggregates/auxiliary/noise_summary.csv", "aggregates/auxiliary/wearable_summary.csv",
                        "aggregates/noise_gate_extensions/summary_aggregate.csv",
                        "aggregates/noise_shift_calibration_audit/calibration_metrics.csv",
                        "manuscript_tables/Supplementary_Class_Distributions.csv"]
    for rel in historical_files:
        candidate, original = root / rel, historical / rel
        require(candidate.is_file() and original.is_file() and
                hashlib.sha256(candidate.read_bytes()).hexdigest() == hashlib.sha256(original.read_bytes()).hexdigest(),
                "Independent historical source differs: " + rel)
    return {"complete": True, "formal_new": 203, "formal_historical_ECG_only": 9,
            "extensions_new": 212, "extensions_historical_ECG_only": 9,
            "independent_historical_tables": historical_files}


def read_csv(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    INPUT_FILES[str(path.resolve())] = {
        "path": str(path.resolve()), "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    return pd.read_csv(path)


def one(df: pd.DataFrame, **filters) -> pd.Series:
    out = df
    for key, value in filters.items():
        if value is None:
            out = out[out[key].isna()]
        else:
            out = out[out[key] == value]
    if len(out) != 1:
        raise RuntimeError(f"Expected one row for {filters}, found {len(out)}")
    return out.iloc[0]


def require_n(rows: list[pd.Series], expected: int, context: str,
              column: str = "n") -> None:
    observed = [int(row[column]) for row in rows]
    if any(value != expected for value in observed):
        raise RuntimeError(f"{context}: expected {column}={expected}, found {observed}")


def require_seed_rows(df: pd.DataFrame, expected: set[int], context: str) -> None:
    observed = {int(seed) for seed in df["seed"].unique()}
    if observed != expected:
        raise RuntimeError(f"{context}: expected seeds {sorted(expected)}, found {sorted(observed)}")


def finish(fig: plt.Figure, output: Path) -> None:
    AXIS_REPORT.append({"figure": output.name, "axes": [
        {"title": ax.get_title(), "xlim": list(ax.get_xlim()), "ylim": list(ax.get_ylim()),
         "data_x": list(ax.dataLim.intervalx), "data_y": list(ax.dataLim.intervaly)}
        for ax in fig.axes]})
    fig.savefig(
        output,
        metadata={"Creator": "generate_manuscript_figures.py", "CreationDate": None},
    )
    fig.savefig(output.with_suffix(".png"), dpi=300)
    plt.close(fig)


def data_limits(axes, axis: str, *, include=(), zero_baseline: bool = False) -> tuple[float, float]:
    """Use all plotted values and error endpoints; never reuse old-result limits."""
    axes = list(np.asarray(axes, dtype=object).reshape(-1))
    values = list(include)
    for ax in axes:
        interval = ax.dataLim.intervalx if axis == "x" else ax.dataLim.intervaly
        values.extend(float(v) for v in interval if np.isfinite(v))
    if axis not in {"x", "y"} or not values:
        raise ValueError("Cannot determine data limits for empty or invalid axis")
    low, high = min(values), max(values)
    if zero_baseline:
        low, high = min(low, 0.0), max(high, 0.0)
    span = high - low
    pad = 0.07 * (span if span > 0 else max(abs(low), 0.1))
    bounds = (0.0 if zero_baseline and low == 0.0 else low - pad, high + pad)
    for ax in axes:
        (ax.set_xlim if axis == "x" else ax.set_ylim)(*bounds)
    return bounds


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.13, 1.06, label, transform=ax.transAxes, fontweight="bold", va="top")


def horizontal_metric(
    ax: plt.Axes,
    labels: list[str],
    means: list[float],
    sds: list[float],
    title: str,
    higher_better: bool,
    show_labels: bool,
) -> None:
    y = np.arange(len(labels))
    for yi, label, mean, sd in zip(y, labels, means, sds):
        color = METHOD_COLORS[label]
        ax.errorbar(mean, yi, xerr=sd, fmt="o", ms=4.2, lw=1.0, capsize=2.0,
                    color=color, ecolor=color)
    ax.set_yticks(y)
    ax.set_yticklabels(labels if show_labels else [""] * len(labels))
    ax.invert_yaxis()
    data_limits(ax, "x")
    arrow = r"$\uparrow$" if higher_better else r"$\downarrow$"
    ax.set_title(f"{title} {arrow}")
    ax.xaxis.set_major_locator(MaxNLocator(4))


def fig_main_compare(seed: pd.DataFrame, out: Path) -> None:
    specs = [
        ("TrustOOD-ECG", "trust_full"),
        ("Softmax", "softmax_modular"),
        ("Matched concat.", "concat_matched"),
        ("Deep ensemble", "deep_ensemble"),
        ("Pool only", "pool_only"),
        ("Gated Fuse only", "fuse_only"),
        ("TMC", "tmc"),
        ("TMDF/ETMC", "tmdf"),
    ]
    metrics = [
        ("diagnosis.macro_auroc", "Macro-AUROC", True),
        ("diagnosis.rare_macro_auroc", "Rare AUROC", True),
        ("diagnosis.calibration.raw.ece_fixed", "Raw ECE", False),
        ("diagnosis.selective_primary.aurc", "AURC", False),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.35), sharey=False)
    labels = [s[0] for s in specs]
    for idx, (ax, (metric, title, higher)) in enumerate(zip(axes.flat, metrics)):
        rows = [one(seed, method=m, protocol="closed", metric=metric) for _, m in specs]
        require_n(rows, 5, f"main comparison: {metric}")
        horizontal_metric(ax, labels, [r["mean"] for r in rows], [r["sd"] for r in rows],
                          title, higher, idx % 2 == 0)
        panel_label(ax, f"({chr(97 + idx)})")
    fig.subplots_adjust(left=0.19, right=0.99, top=0.90, bottom=0.10, wspace=0.14, hspace=0.32)
    finish(fig, out / "fig_main_compare.pdf")


def fig_rare_scatter(classwise: pd.DataFrame, dist: pd.DataFrame, out: Path) -> None:
    base = classwise[(classwise.method == "trust_full") &
                     (classwise.protocol == "closed") &
                     (classwise.dataset == "ptbxl") &
                     (classwise.split == "test")]
    auc = base[base.metric == "auroc"][["class_id", "mean", "sd"]].rename(
        columns={"mean": "auroc", "sd": "auroc_sd"})
    ap = base[base.metric == "auprc"][["class_id", "mean", "sd"]].rename(
        columns={"mean": "auprc", "sd": "auprc_sd"})
    d = dist.merge(auc, on="class_id").merge(ap, on="class_id")
    require_n([row for _, row in base.iterrows()], 5, "classwise metrics")
    fig, axes = plt.subplots(
        1, 2, figsize=(7.25, 2.95), sharex=True, sharey=True
    )
    for ax, metric, sd_col, title in [
        (axes[0], "auroc", "auroc_sd", "Per-class AUROC"),
        (axes[1], "auprc", "auprc_sd", "Per-class AUPRC"),
    ]:
        for rare, color, marker, label in [
            (False, BLUE, "o", "Frequent (train support >= 50)"),
            (True, RED, "^", "Rare (train support < 50)"),
        ]:
            q = d[d.is_rare == rare]
            ax.errorbar(q.train_records, q[metric], yerr=q[sd_col], fmt=marker, ms=3.2,
                        capsize=1.3, lw=0.55, alpha=0.82, color=color, label=label)
        ax.set_title(title, pad=3.5)
        ax.set_xscale("log")
        ax.set_xlim(6, 7500)
        ax.axvline(50, color=BLACK, lw=0.8, ls="--")
    axes[0].axhline(0.5, color=GREY, lw=0.7, ls=":")
    data_limits(axes, "y", include=(0.0, 1.0))
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.995),
        ncol=2, frameon=True, columnspacing=1.35, handletextpad=0.45,
        borderpad=0.35,
    )
    fig.supylabel("Per-class score", x=0.015)
    fig.supxlabel("Folds 1-8 training records (log scale)", x=0.54, y=0.025)
    for ax, label in zip(axes, ["(a)", "(b)"]):
        ax.text(-0.10, 1.06, label, transform=ax.transAxes,
                fontweight="bold", va="top")
    fig.subplots_adjust(left=0.095, right=0.99, top=0.76, bottom=0.22,
                        wspace=0.12)
    finish(fig, out / "fig_rare_scatter.pdf")


def fig_ablation(seed: pd.DataFrame, ext: pd.DataFrame, out: Path) -> None:
    methods = [
        ("Pool", "pool_only"), ("Gated Fuse only", "fuse_only"),
        ("Pool+Fuse", "trust_full"),
        ("Concat.", "concat_matched"), ("TMC", "tmc"), ("TMDF/ETMC", "tmdf"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.20))
    x = np.arange(len(methods))
    for metric, label, color, offset in [
        ("diagnosis.macro_auroc", "Macro-AUROC", BLUE, -0.09),
        ("diagnosis.selective_primary.aurc", "AURC (lower is better)", RED, 0.09),
    ]:
        rows = [one(seed, method=m, protocol="closed", metric=metric) for _, m in methods]
        require_n(rows, 5, f"fusion controls: {metric}")
        axes[0].errorbar(x + offset, [r["mean"] for r in rows],
                         yerr=[r["sd"] for r in rows], fmt="o-", ms=3.8,
                         lw=1.0, capsize=2, label=label, color=color)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([a for a, _ in methods], rotation=24, ha="right")
    axes[0].set_xlim(-0.35, 5.35)
    data_limits(axes[0], "y")
    axes[0].set_ylabel("Metric value")
    axes[0].set_xlabel("Fusion/control method", labelpad=3)

    etas = [0, 0.01, 0.03, 0.1, 0.3, 1.0]
    tags = [f"pareto_eta_{e:g}_aux_0.3" for e in etas]
    for metric, label, color in [
        ("diagnosis.macro_auroc", "Closed macro-AUROC", BLUE),
        ("ood.composite.primary.auroc", "Chapman-Ningbo OOD AUROC", RED),
    ]:
        rows = [one(ext, protocol="closed", tag=t, metric=metric) for t in tags]
        require_n(rows, 5, f"redundancy sensitivity: {metric}")
        axes[1].errorbar(np.arange(len(etas)), [r["mean"] for r in rows],
                         yerr=[r["sd"] for r in rows], marker="o", lw=1.1,
                         capsize=2, label=label, color=color)
    axes[1].axvline(3, color=GREY, ls="--", lw=0.8,
                    label=r"Default $\eta=0.1$")
    axes[1].set_xticks(np.arange(len(etas)))
    axes[1].set_xticklabels([f"{e:g}" for e in etas])
    axes[1].set_xlim(-0.25, 5.25)
    axes[1].set_xlabel(
        "Redundancy coefficient $\\eta$\n(auxiliary loss weight = 0.3)",
        labelpad=3,
    )
    data_limits(axes[1], "y")
    axes[1].set_ylabel("AUROC")
    handles0, labels0 = axes[0].get_legend_handles_labels()
    handles1, labels1 = axes[1].get_legend_handles_labels()
    lookup = dict(zip(labels0 + labels1, handles0 + handles1))
    legend_specs = [
        ("Macro-AUROC", "(a) Macro-AUROC"),
        ("AURC (lower is better)", "(a) AURC (lower is better)"),
        ("Closed macro-AUROC", "(b) Closed macro-AUROC"),
        ("Chapman-Ningbo OOD AUROC", "(b) Chapman-Ningbo OOD AUROC"),
        (r"Default $\eta=0.1$", r"(b) Default $\eta=0.1$"),
    ]
    fig.legend(
        [lookup[key] for key, _ in legend_specs],
        [display for _, display in legend_specs],
        loc="upper center", bbox_to_anchor=(0.5, 0.995), ncol=3,
        frameon=True, columnspacing=0.9, handletextpad=0.4,
        borderpad=0.35, labelspacing=0.35,
    )
    for ax, label in zip(axes, ["(a)", "(b)"]):
        ax.text(-0.12, 1.03, label, transform=ax.transAxes,
                fontweight="bold", va="bottom")
    fig.subplots_adjust(left=0.085, right=0.995, top=0.78, bottom=0.27,
                        wspace=0.22)
    finish(fig, out / "fig_ablation.pdf")


OOD_METHODS = [
    ("Trust composite", "trust_full", "composite"),
    ("TMDF/ETMC", "tmdf", "composite"),
    ("ViM", "softmax_modular", "ViM"),
    ("Mahalanobis-LW", "softmax_modular", "Mahalanobis:ledoit_wolf"),
    ("deep-kNN", "softmax_modular", "deep-kNN"),
    ("Energy", "softmax_modular", "Energy"),
    ("ODIN", "softmax_modular", "ODIN"),
    ("DICE", "softmax_modular", "DICE"),
    ("GEN", "softmax_modular", "GEN"),
]


def ood_rows(df: pd.DataFrame, protocol: str, scenario: str, category: str,
             metric: str) -> list[pd.Series]:
    return [one(df, method=m, protocol=protocol, detector=det, scenario=scenario,
                ood_category=category, metric=metric) for _, m, det in OOD_METHODS]


def fig_ood_openset(ood: pd.DataFrame, out: Path) -> None:
    scenarios = [
        ("strict:tau80", "all", "aggregate", r"Strict $\tau=80$ held-out codes"),
        ("closed", "chapman", "cross", "PTB-XL to Chapman-Ningbo"),
    ]
    labels = [a for a, _, _ in OOD_METHODS]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.75), sharey=False)
    for col, (protocol, scenario, cat, title) in enumerate(scenarios):
        for row_idx, (metric, mtitle, higher) in enumerate([
            ("auroc", "AUROC", True),
            ("fpr95", "Retrospective FPR95", False),
        ]):
            ax = axes[row_idx, col]
            rows = ood_rows(ood, protocol, scenario, cat, metric)
            require_n(rows, 5, f"OOD comparison: {protocol}/{scenario}/{metric}")
            y = np.arange(len(labels))
            for yi, label, r in zip(y, labels, rows):
                color = RED if label == "Trust composite" else BLUE
                ax.errorbar(r["mean"], yi, xerr=r["sd"], fmt="o", ms=3.8,
                            capsize=1.8, color=color, ecolor=color)
            ax.set_yticks(y)
            ax.set_yticklabels(labels if col == 0 else [""] * len(labels))
            ax.invert_yaxis()
            arrow = r"$\uparrow$" if higher else r"$\downarrow$"
            ax.set_title(f"{title}\n{mtitle} {arrow}")
            panel_label(ax, f"({chr(97 + row_idx * 2 + col)})")
    for row_axes in axes:
        data_limits(row_axes, "x")
    fig.subplots_adjust(left=0.20, right=0.99, top=0.88, bottom=0.08, wspace=0.15, hspace=0.34)
    finish(fig, out / "fig_ood_openset.pdf")


def fig_ood_effects(paired: pd.DataFrame, out: Path) -> None:
    comparisons = [
        ("TMDF/ETMC", "tmdf", "composite"),
        ("ViM", "softmax_modular", "ViM"),
        ("Mahalanobis-LW", "softmax_modular", "Mahalanobis:ledoit_wolf"),
        ("deep-kNN", "softmax_modular", "deep-kNN"),
        ("Energy", "softmax_modular", "Energy"),
        ("ODIN", "softmax_modular", "ODIN"),
        ("DICE", "softmax_modular", "DICE"),
        ("GEN", "softmax_modular", "GEN"),
    ]
    scenarios = [
        ("strict:tau80", "all", r"Strict $\tau=80$"),
        ("closed", "chapman", "Chapman-Ningbo shift"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.05), sharey=True)
    for idx, (ax, (protocol, scenario, title)) in enumerate(zip(axes, scenarios)):
        rows = []
        for label, method_b, detector_b in comparisons:
            r = one(paired, protocol=protocol, scenario=scenario,
                    method_a="trust_full", detector_a="composite",
                    method_b=method_b, detector_b=detector_b, metric="auroc")
            rows.append((label, r))
        require_n([row for _, row in rows], 5, f"paired OOD effects: {protocol}/{scenario}")
        if any(int(row["holm_family_size"]) != 59 for _, row in rows):
            raise RuntimeError("Paired OOD effects must use the prespecified 59-comparison Holm family")
        y = np.arange(len(rows))
        for yi, (label, r) in zip(y, rows):
            significant = float(r["pvalue_holm"]) < 0.05
            color = RED if significant else BLUE
            ax.errorbar(r["mean"], yi,
                        xerr=[[r["mean"] - r["ci_low"]], [r["ci_high"] - r["mean"]]],
                        fmt="o", ms=4.0, mfc=color if significant else "white",
                        mec=color, ecolor=color, capsize=2, lw=1.0)
        ax.axvline(0, color=BLACK, lw=0.8, ls="--")
        ax.set_yticks(y)
        if idx == 0:
            ax.set_yticklabels([x[0] for x in rows])
        else:
            ax.tick_params(axis="y", left=False, labelleft=False)
        ax.set_title(title)
    axes[0].invert_yaxis()
    data_limits(axes, "x", include=(0.0,))
    for ax in axes:
        ax.xaxis.set_major_locator(MaxNLocator(5))
    fig.supxlabel("Paired AUROC difference: Trust composite - comparator",
                  x=0.56, y=0.025)
    for ax, label in zip(axes, ["(a)", "(b)"]):
        ax.text(-0.12, 1.04, label, transform=ax.transAxes,
                fontweight="bold", va="bottom")
    fig.subplots_adjust(left=0.17, right=0.995, top=0.82, bottom=0.20,
                        wspace=0.10)
    finish(fig, out / "fig_ood_hist.pdf")


def fig_calibration(cal: pd.DataFrame, out: Path) -> None:
    methods = [("TrustOOD-ECG", "trust_full"), ("Softmax", "softmax_modular"),
               ("Deep ensemble", "deep_ensemble")]
    metrics = [("ece_fixed", "ECE"), ("nll", "NLL"), ("brier", "Brier score")]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.75))
    x = np.arange(len(methods))
    w = 0.34
    for idx, (ax, (metric, title)) in enumerate(zip(axes, metrics)):
        for j, (variant, label, color) in enumerate([
            ("raw", "Raw", BLUE), ("TS", "Temperature-scaled", RED)
        ]):
            rows = [one(cal, method=m, protocol="closed", dataset="ptbxl", split="test",
                        calibration_variant=variant, metric=metric) for _, m in methods]
            require_n(rows, 5, f"calibration: {variant}/{metric}")
            ax.bar(x + (j - 0.5) * w, [r["mean"] for r in rows], width=w,
                   yerr=[r["sd"] for r in rows], capsize=2, color=color,
                   alpha=0.88, label=label)
        ax.set_xticks(x)
        ax.set_xticklabels([a for a, _ in methods], rotation=22, ha="right")
        data_limits(ax, "y", zero_baseline=True)
        ax.set_title(f"{title} " + r"$\downarrow$")
        panel_label(ax, f"({chr(97 + idx)})")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.52, 1.02),
               ncol=2, frameon=True)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.77, bottom=0.25, wspace=0.28)
    finish(fig, out / "fig_calibration.pdf")


def fig_risk_coverage(sel: pd.DataFrame, out: Path) -> None:
    methods = [("TrustOOD-ECG", "trust_full", RED),
               ("Softmax", "softmax_modular", BLUE),
               ("Deep ensemble", "deep_ensemble", GREEN)]
    coverages = [0.50, 0.70, 0.80, 0.90, 0.95, 1.00]
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.05), sharex=True, sharey=False)
    for label, method, color in methods:
        q = sel[(sel.protocol == "closed") & (sel.method == method)]
        for ax, metric in [(axes[0], "risk"), (axes[1], "rare_rejection_rate")]:
            rows = [one(q, target_coverage=c, metric=metric) for c in coverages]
            require_n(rows, 5, f"selective summaries: {method}/{metric}")
            y = np.asarray([r["mean"] for r in rows])
            sd = np.asarray([r["sd"] for r in rows])
            axes_y = np.asarray(coverages)
            ax.plot(axes_y, y, marker="o", ms=3.2, lw=1.2, color=color, label=label)
            ax.fill_between(axes_y, y - sd, y + sd,
                            color=color, alpha=0.13, linewidth=0)
    axes[0].set_ylabel("Selective risk")
    axes[0].set_title("Risk-coverage summaries")
    nominal_rejection = 1.0 - np.asarray(coverages)
    axes[1].plot(coverages, nominal_rejection, color=BLACK, ls="--", lw=1.0,
                 label="Nominal overall rejection (1 - coverage)")
    axes[1].set_ylabel("Rare-class rejection rate")
    axes[1].set_title("Rare-class rejection")
    data_limits(axes[0], "y")
    data_limits(axes[1], "y", include=(0.0,))
    for ax in axes:
        ax.set_xlim(0.48, 1.02)
        ax.set_xticks([0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    fig.supxlabel("Coverage", x=0.53, y=0.025)

    handle_by_label: dict[str, object] = {}
    for ax in axes:
        handles, labels = ax.get_legend_handles_labels()
        handle_by_label.update(zip(labels, handles))
    legend_labels = [
        "TrustOOD-ECG",
        "Softmax",
        "Deep ensemble",
        "Nominal overall rejection (1 - coverage)",
    ]
    fig.legend(
        [handle_by_label[label] for label in legend_labels],
        legend_labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        ncol=4,
        frameon=True,
        fontsize=6.4,
        columnspacing=0.8,
        handlelength=2.0,
        handletextpad=0.4,
        borderpad=0.35,
    )
    for ax, label in zip(axes, ["(a)", "(b)"]):
        ax.text(-0.11, 1.04, label, transform=ax.transAxes,
                fontweight="bold", va="bottom")
    fig.subplots_adjust(left=0.085, right=0.995, top=0.73, bottom=0.19, wspace=0.28)
    finish(fig, out / "fig_risk_coverage.pdf")


SNR_ORDER = ["clean", "24dB", "18dB", "12dB", "6dB", "0dB", "-6dB"]
SNR_LABELS = ["clean", "24", "18", "12", "6", "0", "-6"]


def fig_noise(noise: pd.DataFrame, cal_noise: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.75))
    x = np.arange(len(SNR_ORDER))
    for label, variant, color in [("TrustOOD-ECG", "trust_full", RED),
                                  ("Softmax", "softmax_modular", BLUE)]:
        q = noise[(noise.category == "model") & (noise.variant == variant) &
                  (noise.metric == "diagnosis.accuracy")]
        rows = [one(q, context=s) for s in SNR_ORDER]
        require_n(rows, 3, f"noise diagnosis: {variant}")
        axes[0].errorbar(x, [r["mean"] for r in rows], yerr=[r["sd"] for r in rows],
                         marker="o", ms=3.1, lw=1.1, capsize=1.8, color=color, label=label)
    axes[0].set_ylabel("Accuracy")
    axes[0].set_title("Diagnosis under paired noise")
    axes[0].legend(loc="lower left")

    q = cal_noise[(cal_noise.split == "test") & (cal_noise.stratum == "all")]
    require_seed_rows(q, {7, 13, 42}, "noise calibration")
    for variant, label, color in [("raw", "Raw ECE", BLUE),
                                  ("temperature_scaled", "Frozen-TS ECE", RED)]:
        values, errors = [], []
        for s in SNR_ORDER:
            z = q[(q.snr_label == s) & (q.calibration_variant == variant)]
            values.append(z.ece_equal_width.mean())
            errors.append(z.ece_equal_width.std(ddof=1))
        axes[1].errorbar(x, values, yerr=errors, marker="o", ms=3.1,
                         capsize=1.8, lw=1.1, color=color, label=label)
    axes[1].set_ylabel("TrustOOD-ECG ECE")
    axes[1].set_title("TrustOOD-ECG calibration transfer")
    axes[1].legend(loc="center left")

    for variant, label, color in [("composite", "Composite", RED),
                                  ("sqi_only", "SQI only", GREEN),
                                  ("sqi_plus_composite", "SQI + composite", PURPLE)]:
        q = noise[(noise.category == "corruption_detector") &
                  (noise.variant == variant) & (noise.metric == "auroc")]
        rows = [one(q, context=s) for s in SNR_ORDER[1:]]
        require_n(rows, 3, f"corruption detection: {variant}")
        axes[2].errorbar(x[1:], [r["mean"] for r in rows], yerr=[r["sd"] for r in rows],
                         marker="o", ms=3.1, capsize=1.8, lw=1.1, color=color, label=label)
    axes[2].set_ylabel("Corruption AUROC")
    axes[2].set_ylim(0.41, 1.02)
    axes[2].set_title("Synthetic corruption detection")
    axes[2].legend(loc="upper left")
    for idx, ax in enumerate(axes):
        ax.set_xticks(x)
        ax.set_xticklabels(SNR_LABELS)
        ax.set_xlabel("SNR (dB)")
        # Place panel markers above and left of the top y tick and title.
        ax.text(-0.18, 1.13, f"({chr(97 + idx)})", transform=ax.transAxes,
                fontweight="bold", va="bottom")
    fig.subplots_adjust(left=0.085, right=0.99, top=0.77, bottom=0.20, wspace=0.30)
    finish(fig, out / "fig_noise.pdf")


def fig_source_weights(gate: pd.DataFrame, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(3.55, 2.85))
    x = np.arange(len(SNR_ORDER))
    for source, label, color, marker in [
        ("ecg", "ECG", RED, "o"), ("hrv", "HRV", BLUE, "s"),
        ("spec", "Spectrum", GREEN, "^"), ("sqi", "SQI", PURPLE, "D"),
    ]:
        q = gate[(gate.gate == "independent_sigmoid") &
                 (gate.metric == f"gate_{source}_mean")]
        rows = [one(q, snr_label=s) for s in SNR_ORDER]
        require_n(rows, 3, f"gate response: {source}", column="n_seed")
        y = np.asarray([r["mean"] for r in rows])
        sd = np.asarray([r["std"] for r in rows])
        ax.errorbar(x, y, yerr=sd, marker=marker, ms=3.0, capsize=1.6,
                    lw=1.0, color=color, label=label)
    ax.set_xticks(x)
    ax.set_xticklabels(SNR_LABELS)
    ax.set_xlabel("SNR (dB)")
    ax.set_ylabel("Mean gate coefficient")
    ax.set_ylim(0.08, 1.04)
    ax.legend(ncol=2, loc="center right")
    finish(fig, out / "fig_source_weights.pdf")


def fig_multimodal(wear: pd.DataFrame, out: Path) -> None:
    specs = [
        ("mhealth", [("ECG", "ecg_only"), ("Motion", "motion_only"),
                     ("Concat.", "concat_matched"), ("Trust", "trust_full")]),
        ("wesad", [("ECG", "ecg_only"), ("Motion", "motion_only"),
                   ("PPG", "ppg_only"), ("Concat.", "concat_matched"),
                   ("Trust", "trust_full")]),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for idx, (ax, (dataset, methods)) in enumerate(zip(axes, specs)):
        x = np.arange(len(methods))
        w = 0.36
        for j, (metric, label, color) in enumerate([
            ("macro_f1", "Macro-F1", BLUE), ("macro_auprc", "Macro-AUPRC", RED)
        ]):
            rows = [one(wear, dataset=dataset, model=m, section="diagnosis_raw",
                        metric=metric) for _, m in methods]
            require_n(rows, 3, f"wearable LOSO: {dataset}/{metric}")
            ax.bar(x + (j - 0.5) * w, [r["mean"] for r in rows], width=w,
                   yerr=[r["sd"] for r in rows], capsize=2, color=color,
                   alpha=0.88, label=label)
        ax.set_xticks(x)
        ax.set_xticklabels([a for a, _ in methods], rotation=22, ha="right")
        ax.set_ylim(0.0, 0.9)
        ax.set_title("MHEALTH activity" if dataset == "mhealth" else "WESAD affect")
        # Keep the panel marker clear of the top y tick at manuscript scale.
        ax.text(-0.115, 1.13, f"({chr(97 + idx)})", transform=ax.transAxes,
                fontweight="bold", va="top")
    axes[0].set_ylabel("Subject-wise LOSO score")
    axes[0].legend(loc="upper left")
    fig.subplots_adjust(left=0.09, right=0.99, top=0.80, bottom=0.25, wspace=0.22)
    finish(fig, out / "fig_multimodal.pdf")


def fig_generalization(ood: pd.DataFrame, alerts: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.15), sharex=False, sharey=False)
    taus = [40, 80, 160]
    for category, label, color, marker in [
        ("aggregate", "All OOD", RED, "o"), ("pure", "Pure OOD", BLUE, "s"),
        ("mixed", "Mixed OOD", GREEN, "^")
    ]:
        vals, sds = [], []
        for tau in taus:
            scenario = "all" if category == "aggregate" else category
            r = one(ood, method="trust_full", protocol=f"strict:tau{tau}",
                    detector="composite", scenario=scenario,
                    ood_category=category, metric="auroc")
            vals.append(r["mean"]); sds.append(r["sd"])
            require_n([r], 5 if tau == 80 else 3,
                      f"strict threshold sensitivity: tau={tau}/{category}")
        axes[0].errorbar(np.arange(3), vals, yerr=sds, marker=marker, ms=3.2,
                         capsize=2, lw=1.1, color=color, label=label)
    axes[0].set_xticks(np.arange(3))
    axes[0].set_xticklabels(["40\n34 OOD; 3 seeds", "80\n93 OOD; 5 seeds",
                             "160\n240 OOD; 3 seeds"])
    axes[0].set_xlabel(r"Held-out-code support threshold $\tau$")
    axes[0].set_ylabel("Composite AUROC")
    axes[0].set_xlim(-0.18, 2.18)
    data_limits(axes[0], "y")

    q = alerts[(alerts.protocol == "closed") & (alerts.scenario == "chapman") &
               (alerts.method == "trust_full") & (alerts.detector == "composite")]
    prevalence = [0.01, 0.05, 0.10]
    ppv = [one(q, prevalence=p, metric="ppv") for p in prevalence]
    fp = [one(q, prevalence=p, metric="false_alerts_per_1000") for p in prevalence]
    require_n(ppv + fp, 5, "Chapman-Ningbo prevalence projection")
    ax = axes[1]
    x = np.arange(3)
    ppv_line = ax.errorbar(
        x, [100 * r["mean"] for r in ppv], yerr=[100 * r["sd"] for r in ppv],
        marker="o", color=BLUE, capsize=2, lw=1.1, label="PPV (%)")
    ax.set_ylabel("PPV (%)", color=BLUE)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.set_xlim(-0.18, 2.18)
    data_limits(ax, "y", zero_baseline=True)
    ax.set_xticks(x)
    ax.set_xticklabels(["1%", "5%", "10%"])
    ax.set_xlabel("Assumed OOD prevalence")
    ax2 = ax.twinx()
    ax2.spines["top"].set_visible(False)
    fp_line = ax2.errorbar(
        x, [r["mean"] for r in fp], yerr=[r["sd"] for r in fp],
        marker="s", color=RED, capsize=2, lw=1.1,
        label="False alerts / 1,000")
    data_limits(ax2, "y", zero_baseline=True)
    ax2.set_ylabel("False alerts per 1,000", color=RED)
    ax2.tick_params(axis="y", labelcolor=RED)
    ood_handles, ood_labels = axes[0].get_legend_handles_labels()
    fig.legend(
        ood_handles + [ppv_line, fp_line],
        ood_labels + ["PPV (%)", "False alerts / 1,000"],
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        ncol=5,
        frameon=True,
        fontsize=6.4,
        columnspacing=0.8,
        handlelength=1.8,
        handletextpad=0.35,
        borderpad=0.35,
    )
    for panel_ax, label in zip(axes, ["(a)", "(b)"]):
        panel_ax.text(-0.12, 1.03, label, transform=panel_ax.transAxes,
                      fontweight="bold", va="bottom")
    fig.subplots_adjust(left=0.085, right=0.90, top=0.82, bottom=0.28, wspace=0.28)
    finish(fig, out / "fig_generalization.pdf")


def main() -> None:
    args = parse_args()
    root = args.reference_root.resolve()
    out = args.output_dir.resolve()
    provenance = verify_reference_tree(root, args.origin_report.resolve(), args.historical_root.resolve())
    if out.exists():
        raise ValueError("Use a fresh figure directory; previous figure attempts are preserved")
    out.mkdir(parents=True)
    agg = root / "aggregates"
    tables = root / "manuscript_tables"

    seed = read_csv(agg / "ptbxl" / "seed_summary.csv")
    ood = read_csv(agg / "ptbxl" / "ood_summary.csv")
    calibration = read_csv(agg / "ptbxl" / "calibration_summary.csv")
    classwise = read_csv(agg / "ptbxl" / "classwise_summary.csv")
    noise = read_csv(agg / "auxiliary" / "noise_summary.csv")
    wearable = read_csv(agg / "auxiliary" / "wearable_summary.csv")
    ext = read_csv(agg / "promised_extensions" / "summary.csv")
    paired = read_csv(agg / "promised_postprocess" / "ood_paired_seed.csv")
    selective = read_csv(agg / "promised_postprocess" / "selective_seed_summary.csv")
    alerts = read_csv(agg / "promised_postprocess" / "ood_alert_seed_summary.csv")
    gate = read_csv(agg / "noise_gate_extensions" / "summary_aggregate.csv")
    cal_noise = read_csv(agg / "noise_shift_calibration_audit" / "calibration_metrics.csv")
    distributions = read_csv(tables / "Supplementary_Class_Distributions.csv")

    fig_main_compare(seed, out)
    fig_rare_scatter(classwise, distributions, out)
    fig_ablation(seed, ext, out)
    fig_ood_openset(ood, out)
    fig_ood_effects(paired, out)
    fig_calibration(calibration, out)
    fig_risk_coverage(selective, out)
    fig_noise(noise, cal_noise, out)
    fig_source_weights(gate, out)
    fig_multimodal(wearable, out)
    fig_generalization(ood, alerts, out)

    quantitative_names = [
        "fig_main_compare.pdf",
        "fig_rare_scatter.pdf",
        "fig_ablation.pdf",
        "fig_ood_openset.pdf",
        "fig_ood_hist.pdf",
        "fig_calibration.pdf",
        "fig_risk_coverage.pdf",
        "fig_noise.pdf",
        "fig_source_weights.pdf",
        "fig_multimodal.pdf",
        "fig_generalization.pdf",
    ]
    files = [out / name for name in quantitative_names]
    if len(files) != 11:
        raise RuntimeError(f"Expected 11 quantitative PDFs, found {len(files)}")
    manifest = {
        "schema": "paper46-manuscript-quantitative-figures-v2",
        "axis_policy": "Affected result axes include every plotted mean, SD/CI endpoint; calibration bars start at zero; identical OOD metrics share ranges across scenarios.",
        "inputs": list(INPUT_FILES.values()),
        "axes": AXIS_REPORT,
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "revision2_input_audit": provenance,
        # Preserve the caller-provided path instead of leaking the machine-specific
        # absolute path produced by ``resolve()`` into the distributable manifest.
        "reference_root": str(args.reference_root),
        "figures": [
            {"name": p.name, "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in files
        ],
        "previews": [
            {"name": p.with_suffix(".png").name, "bytes": p.with_suffix(".png").stat().st_size,
             "sha256": hashlib.sha256(p.with_suffix(".png").read_bytes()).hexdigest()}
            for p in files
        ],
    }
    (out / "quantitative_figure_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"output_dir": str(out), "figure_count": len(files)}))


if __name__ == "__main__":
    main()
