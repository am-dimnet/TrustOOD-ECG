#!/usr/bin/env python3
"""Derive reviewer-promised metrics from completed Paper46 artefacts only.

The program never trains a model and never fabricates unavailable quantities.
It audits the exact 212-run PTB-XL matrix and the completed noise/wearable
artefacts, verifies every declared SHA-256, and then derives:

* rare-class sensitivity analyses at training-support thresholds 25/50/100;
* subject-cluster confidence intervals and paired subject-cluster contrasts;
* selective prediction at 50/70/80/90/95/100 percent coverage;
* paired-seed and paired-sample OOD contrasts with Holm adjustment;
* PPV and alert burden at 1/5/10 percent OOD prevalence and fixed sensitivity;
* an end-to-end modular-pipeline result only when all per-sample SQI,
  classifier and OOD arrays are aligned in the same Softmax run.

The submitted result schema does not contain SQI for validation and OOD
records.  In that normal case the modular analysis is explicitly emitted as
``available=false`` with the exact missing fields.  Noise or wearable arrays
from a different fitted model/dataset are never silently spliced into PTB-XL.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import scipy
from scipy import stats
import sklearn
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
    roc_curve,
)


SCRIPT_VERSION = "paper46-promised-postprocess-v1"
PTB_SCHEMA = "paper46-ptbxl-revision-v1"
FINGERPRINT_SCHEMA = "paper46-ptbxl-run-fingerprint-v1"
FIVE_SEEDS = (7, 13, 42, 99, 2026)
THREE_SEEDS = (7, 42, 2026)
RARE_THRESHOLDS = (25, 50, 100)
COVERAGES = (0.50, 0.70, 0.80, 0.90, 0.95, 1.00)
PREVALENCES = (0.01, 0.05, 0.10)

MAIN = (
    "trust_full", "softmax_modular", "concat_matched", "deep_ensemble",
    "tmc", "tmdf", "pool_only", "fuse_only",
)
BASELINES = tuple(value for value in MAIN if value != "trust_full")
ABLATIONS = (
    "trust_normalized", "trust_mean", "gate_uncertainty", "gate_sqi", "no_gate",
    "no_sqi_source", "no_sqi_source_gate_uncertainty", "comp_0", "comp_0.01",
    "comp_0.05", "comp_0.2", "comp_squared", "comp_crosscov",
)
SOURCE_COUNT = tuple(
    f"{pooling}_s{count}"
    for pooling in ("cumulative", "normalized", "mean")
    for count in (1, 2, 3, 4)
)
SENSITIVITY = ("trust_full", "softmax_modular", "concat_matched")


def expected_matrix() -> dict[tuple[str, str], tuple[int, ...]]:
    result: dict[tuple[str, str], tuple[int, ...]] = {}
    for protocol in ("closed", "strict:tau80"):
        result.update({(protocol, method): FIVE_SEEDS for method in MAIN})
        result.update({(protocol, method): THREE_SEEDS for method in ABLATIONS})
    result.update({("closed", method): THREE_SEEDS for method in SOURCE_COUNT})
    for protocol in ("strict:tau40", "strict:tau160"):
        result.update({(protocol, method): THREE_SEEDS for method in SENSITIVITY})
    if len(result) != 60 or sum(len(value) for value in result.values()) != 212:
        raise RuntimeError("internal 212-run matrix definition drift")
    return result


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def strict(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return strict(value.tolist())
    if isinstance(value, np.generic):
        return strict(value.item())
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): strict(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict(item) for item in value]
    return value


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(
        strict(value), sort_keys=True, separators=(",", ":"),
        ensure_ascii=True, allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def stable_seed(*parts: Any) -> int:
    text = "\x1f".join(str(part) for part in parts)
    return int.from_bytes(hashlib.sha256(text.encode("utf-8")).digest()[:8], "little")


def atomic_json(path: Path, value: Any, pretty: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        options: dict[str, Any] = {
            "sort_keys": True, "ensure_ascii": False, "allow_nan": False,
        }
        if pretty:
            options["indent"] = 2
        else:
            options["separators"] = (",", ":")
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(strict(value), handle, **options)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_csv(path: Path, rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: strict(row.get(key)) for key in fields})
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("top-level JSON is not an object")
    return value


def protocol_name(payload: Mapping[str, Any]) -> str:
    if payload.get("protocol") == "strict":
        return f"strict:tau{int(payload['tau'])}"
    return str(payload.get("protocol"))


def method_name(payload: Mapping[str, Any]) -> str:
    model = payload.get("model", {})
    return str(model.get("tag", model.get("name", "unknown"))) if isinstance(model, Mapping) else str(model)


@dataclass(frozen=True)
class Run:
    json_path: Path
    raw_path: Path
    ood_path: Path
    payload: dict[str, Any]
    protocol: str
    method: str
    seed: int

    @property
    def key(self) -> tuple[str, str, int]:
        return self.protocol, self.method, self.seed


@dataclass
class Raw:
    val_prob: np.ndarray
    val_y: np.ndarray
    test_prob: np.ndarray
    test_y: np.ndarray
    patient: np.ndarray
    confidence: np.ndarray
    confidence_kind: str
    class_names: np.ndarray


def validate_artifact(
    json_path: Path, payload: Mapping[str, Any], role: str, suffix: str,
    inputs: dict[str, dict[str, Any]], errors: list[str],
) -> Path:
    path = json_path.with_name(f"{json_path.stem}{suffix}").resolve()
    declared = payload.get("artifacts", {}).get(role, {})
    if not path.is_file():
        errors.append(f"missing {role}: {path}")
        return path
    actual_hash = sha256_file(path)
    actual_bytes = path.stat().st_size
    if declared.get("filename") != path.name:
        errors.append(f"{role} filename mismatch: {path}")
    if declared.get("bytes") != actual_bytes:
        errors.append(f"{role} byte count mismatch: {path}")
    if declared.get("sha256") != actual_hash:
        errors.append(f"{role} SHA-256 mismatch: {path}")
    inputs[str(path)] = {
        "role": role, "path": str(path), "bytes": actual_bytes, "sha256": actual_hash,
    }
    return path


def audit_ptb(root: Path) -> tuple[list[Run], dict[str, Any], dict[str, dict[str, Any]]]:
    expected = expected_matrix()
    inputs: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    records: list[Run] = []
    ood_arrays_skipped: list[dict[str, Any]] = []
    seen: dict[tuple[str, str, int], Path] = {}
    json_paths = sorted(root.rglob("seed_*.json"))
    for path in json_paths:
        try:
            payload = load_json(path)
            if "run_definition" not in payload or "model" not in payload:
                continue
            json_hash = sha256_file(path)
            inputs[str(path.resolve())] = {
                "role": "ptb_json", "path": str(path.resolve()),
                "bytes": path.stat().st_size, "sha256": json_hash,
            }
            protocol = protocol_name(payload)
            method = method_name(payload)
            seed = int(payload["seed"])
            key = (protocol, method, seed)
            if key in seen:
                errors.append(f"duplicate PTB cell {key}: {seen[key]} and {path}")
            seen[key] = path
            if payload.get("status") != "complete":
                errors.append(f"incomplete status: {path}")
            if payload.get("environment", {}).get("script_version") != PTB_SCHEMA:
                errors.append(f"script schema mismatch: {path}")
            if payload.get("fingerprint_schema") != FINGERPRINT_SCHEMA:
                errors.append(f"fingerprint schema mismatch: {path}")
            fingerprint = payload.get("run_fingerprint")
            if not isinstance(fingerprint, str) or re.fullmatch(r"[0-9a-f]{64}", fingerprint) is None:
                errors.append(f"malformed run fingerprint: {path}")
            elif canonical_hash(payload.get("run_definition")) != fingerprint:
                errors.append(f"run fingerprint mismatch: {path}")
            raw_path = validate_artifact(path, payload, "raw_npz", "_raw.npz", inputs, errors)
            ood_path = validate_artifact(path, payload, "ood_npz", "_ood_scores.npz", inputs, errors)
            if raw_path.is_file() and ood_path.is_file():
                try:
                    with np.load(raw_path, allow_pickle=False) as archive:
                        required = {"val_prob", "val_y", "test_prob", "test_y", "test_patient", "class_names"}
                        missing = required - set(archive.files)
                        if missing:
                            errors.append(f"raw keys missing {sorted(missing)}: {raw_path}")
                        else:
                            n = len(archive["test_y"])
                            if archive["test_prob"].ndim != 2 or archive["test_prob"].shape[0] != n:
                                errors.append(f"raw probability shape mismatch: {raw_path}")
                            if len(archive["test_patient"]) != n:
                                errors.append(f"raw patient shape mismatch: {raw_path}")
                    with np.load(ood_path, allow_pickle=False) as archive:
                        if not archive.files:
                            errors.append(f"empty OOD NPZ: {ood_path}")
                        for name in archive.files:
                            value = np.asarray(archive[name])
                            _, rejection = score_vector(value)
                            if rejection is not None:
                                parsed_name = split_score_key(name)
                                ood_arrays_skipped.append({
                                    "protocol": protocol, "method": method, "seed": seed,
                                    "path": str(ood_path), "array_key": name,
                                    "detector": parsed_name[0] if parsed_name else None,
                                    "scenario": parsed_name[1] if parsed_name else None,
                                    "shape": list(value.shape), "dtype": str(value.dtype),
                                    "reason": rejection, "action": "skipped; never flattened or column-selected",
                                })
                                if value.ndim == 1 and np.issubdtype(value.dtype, np.floating):
                                    if not len(value) or not np.isfinite(value).all():
                                        errors.append(f"invalid 1D floating OOD score {name}: {ood_path}")
                except Exception as exc:
                    errors.append(f"NPZ audit error {path}: {type(exc).__name__}: {exc}")
                records.append(Run(path.resolve(), raw_path, ood_path, payload, protocol, method, seed))
        except Exception as exc:
            errors.append(f"JSON audit error {path}: {type(exc).__name__}: {exc}")

    expected_cells = {(protocol, method, seed) for (protocol, method), seeds in expected.items() for seed in seeds}
    observed_cells = {record.key for record in records}
    missing = sorted(expected_cells - observed_cells)
    unexpected = sorted(observed_cells - expected_cells)
    if missing:
        errors.append(f"missing PTB cells: {missing}")
    if unexpected:
        errors.append(f"unexpected PTB cells: {unexpected}")
    if len(records) != 212:
        errors.append(f"expected 212 valid PTB records, observed {len(records)}")
    audit = {
        "expected_records": 212, "observed_records": len(records),
        "expected_groups": 60, "observed_groups": len({(item.protocol, item.method) for item in records}),
        "missing_cells": [list(value) for value in missing],
        "unexpected_cells": [list(value) for value in unexpected],
        "ood_arrays_skipped": ood_arrays_skipped,
        "ood_arrays_skipped_count": len(ood_arrays_skipped),
        "errors": errors, "complete": not errors,
    }
    return records, audit, inputs


def resolve_declared(path_text: Any, json_path: Path) -> Path:
    path = Path(str(path_text))
    return path if path.is_absolute() else (json_path.parent / path).resolve()


def audit_auxiliary_roots(
    noise_root: Path, wearables_root: Path,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    inputs: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    noise_count = 0
    for seed in (7, 13, 42):
        candidates = sorted(noise_root.rglob(f"seed_{seed}.json"))
        candidates = [path for path in candidates if path.parent.name == "canonical"]
        if len(candidates) != 1:
            errors.append(f"noise seed {seed}: expected one canonical JSON, found {len(candidates)}")
            continue
        path = candidates[0]
        payload = load_json(path)
        if payload.get("status") != "complete" or payload.get("canonical") is not True:
            errors.append(f"noise seed {seed}: incomplete/noncanonical")
            continue
        curves = resolve_declared(payload.get("raw_npz", {}).get("path"), path)
        if not curves.is_file():
            errors.append(f"noise seed {seed}: missing curves NPZ")
            continue
        actual = sha256_file(curves)
        if actual != payload.get("raw_npz", {}).get("sha256"):
            errors.append(f"noise seed {seed}: curves SHA mismatch")
        for role, item in (("noise_json", path), ("noise_curves", curves)):
            inputs[str(item.resolve())] = {
                "role": role, "path": str(item.resolve()), "bytes": item.stat().st_size,
                "sha256": sha256_file(item),
            }
        noise_count += 1

    wearable_json = []
    for path in sorted(wearables_root.rglob("seed_*.json")):
        payload = load_json(path)
        if payload.get("schema") != "paper46-wearable-loso-v1":
            continue
        wearable_json.append(path)
        prediction = resolve_declared(payload.get("prediction_file", {}).get("path"), path)
        if payload.get("status") != "complete" or not prediction.is_file():
            errors.append(f"wearable incomplete/missing prediction: {path}")
            continue
        actual = sha256_file(prediction)
        if actual != payload.get("prediction_file", {}).get("sha256"):
            errors.append(f"wearable prediction SHA mismatch: {prediction}")
        for role, item in (("wearable_json", path), ("wearable_prediction", prediction)):
            inputs[str(item.resolve())] = {
                "role": role, "path": str(item.resolve()), "bytes": item.stat().st_size,
                "sha256": sha256_file(item),
            }
    if noise_count != 3:
        errors.append(f"expected 3 valid noise results, observed {noise_count}")
    if len(wearable_json) != 345:
        errors.append(f"expected 345 wearable JSON files, observed {len(wearable_json)}")
    return {
        "noise_expected": 3, "noise_observed": noise_count,
        "wearable_expected": 345, "wearable_observed": len(wearable_json),
        "errors": errors, "complete": not errors,
    }, inputs


def load_raw(run: Run, cache: dict[Path, Raw]) -> Raw:
    if run.raw_path in cache:
        return cache[run.raw_path]
    with np.load(run.raw_path, allow_pickle=False) as archive:
        val_prob = np.asarray(archive["val_prob"], dtype=np.float64)
        test_prob = np.asarray(archive["test_prob"], dtype=np.float64)
        val_prob /= np.maximum(val_prob.sum(axis=1, keepdims=True), 1e-300)
        test_prob /= np.maximum(test_prob.sum(axis=1, keepdims=True), 1e-300)
        has_vacuity = "test_u" in archive.files
        confidence = (
            -np.asarray(archive["test_u"], dtype=np.float64).reshape(-1)
            if has_vacuity else test_prob.max(axis=1)
        )
        raw = Raw(
            val_prob=val_prob, val_y=np.asarray(archive["val_y"], dtype=np.int64),
            test_prob=test_prob, test_y=np.asarray(archive["test_y"], dtype=np.int64),
            patient=np.asarray(archive["test_patient"]).astype(str),
            confidence=confidence,
            confidence_kind="negative vacuity" if has_vacuity else "maximum probability",
            class_names=np.asarray(archive["class_names"]).astype(str),
        )
    if len(raw.test_y) != len(raw.patient) or len(raw.test_y) != len(raw.confidence):
        raise ValueError(f"raw alignment failure: {run.raw_path}")
    cache[run.raw_path] = raw
    return raw


def support_rows(run: Run, n_classes: int) -> list[dict[str, Any]]:
    rows = run.payload.get("diagnosis", {}).get("classwise", [])
    if not isinstance(rows, list) or len(rows) != n_classes:
        raise ValueError(f"classwise support absent/inconsistent: {run.json_path}")
    ordered = sorted(rows, key=lambda item: int(item["class_id"]))
    if [int(item["class_id"]) for item in ordered] != list(range(n_classes)):
        raise ValueError(f"classwise IDs inconsistent: {run.json_path}")
    return ordered


def ranking(values: np.ndarray, labels: np.ndarray, class_ids: Sequence[int], kind: str) -> float | None:
    scores = []
    for class_id in class_ids:
        truth = labels == int(class_id)
        if kind == "auroc" and truth.any() and (~truth).any():
            scores.append(float(roc_auc_score(truth, values[:, int(class_id)])))
        elif kind == "auprc" and truth.any():
            scores.append(float(average_precision_score(truth, values[:, int(class_id)])))
    return float(np.mean(scores)) if scores else None


def rare_analyses(
    records: Sequence[Run], raw_cache: dict[Path, Raw], bootstrap: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    classwise_output: list[dict[str, Any]] = []
    macro_output: list[dict[str, Any]] = []
    patient_ci: list[dict[str, Any]] = []
    for run in records:
        raw = load_raw(run, raw_cache)
        predictions = raw.test_prob.argmax(axis=1)
        supports = support_rows(run, raw.test_prob.shape[1])
        precision, recall, f1, test_count = precision_recall_fscore_support(
            raw.test_y, predictions, labels=np.arange(raw.test_prob.shape[1]), zero_division=0,
        )
        for threshold in RARE_THRESHOLDS:
            rare_ids = np.asarray(
                [index for index, item in enumerate(supports) if int(item["train_records"]) < threshold],
                dtype=np.int64,
            )
            evaluable_auc = [index for index in rare_ids if np.any(raw.test_y == index) and np.any(raw.test_y != index)]
            evaluable_pr = [index for index in rare_ids if np.any(raw.test_y == index)]
            class_rows = []
            for class_id, item in enumerate(supports):
                truth = raw.test_y == class_id
                row = {
                    "protocol": run.protocol, "method": run.method, "seed": run.seed,
                    "rare_threshold": threshold, "class_id": class_id,
                    "class_name": str(raw.class_names[class_id]),
                    "is_rare": bool(class_id in set(rare_ids.tolist())),
                    "train_records": int(item["train_records"]),
                    "validation_records": int(item["val_records"]),
                    "test_records": int(test_count[class_id]),
                    "train_patients": int(item["train_patients"]),
                    "validation_patients": int(item["val_patients"]),
                    "test_patients": int(len(np.unique(raw.patient[truth]))),
                    "precision": float(precision[class_id]), "recall": float(recall[class_id]),
                    "f1": float(f1[class_id]),
                    "auroc": float(roc_auc_score(truth, raw.test_prob[:, class_id]))
                    if truth.any() and (~truth).any() else None,
                    "auprc": float(average_precision_score(truth, raw.test_prob[:, class_id]))
                    if truth.any() else None,
                }
                classwise_output.append(row)
                class_rows.append(row)
            rare_rows = [row for row in class_rows if row["is_rare"]]
            macro = {
                "protocol": run.protocol, "method": run.method, "seed": run.seed,
                "rare_threshold": threshold, "n_classes_defined": len(rare_ids),
                "n_classes_auc_evaluable": len(evaluable_auc),
                "n_classes_auprc_evaluable": len(evaluable_pr),
                "train_records_sum": int(sum(row["train_records"] for row in rare_rows)),
                "test_records_sum": int(sum(row["test_records"] for row in rare_rows)),
                "macro_precision": float(np.mean([row["precision"] for row in rare_rows])) if rare_rows else None,
                "macro_recall": float(np.mean([row["recall"] for row in rare_rows])) if rare_rows else None,
                "macro_f1": float(np.mean([row["f1"] for row in rare_rows])) if rare_rows else None,
                "macro_auroc": ranking(raw.test_prob, raw.test_y, evaluable_auc, "auroc"),
                "macro_auprc": ranking(raw.test_prob, raw.test_y, evaluable_pr, "auprc"),
            }
            macro_output.append(macro)
            if run.method == "trust_full" and len(rare_ids):
                patient_ci.extend(
                    patient_bootstrap_single(run, raw, rare_ids, threshold, bootstrap)
                )
    return classwise_output, macro_output, patient_ci


def cluster_codes(patient: np.ndarray) -> tuple[np.ndarray, int]:
    _, inverse = np.unique(patient.astype(str), return_inverse=True)
    return inverse.astype(np.int64), int(inverse.max() + 1)


def confusion_metric(
    y: np.ndarray, prediction: np.ndarray, rare_ids: np.ndarray,
    record_weights: np.ndarray | None, metric: str, n_classes: int,
) -> float:
    encoded = y * n_classes + prediction
    matrix = np.bincount(
        encoded, weights=record_weights, minlength=n_classes * n_classes,
    ).reshape(n_classes, n_classes)
    tp = np.diag(matrix)
    actual = matrix.sum(axis=1)
    predicted = matrix.sum(axis=0)
    recall = np.divide(
        tp, actual, out=np.zeros(tp.shape, dtype=np.float64), where=actual > 0,
    )
    precision = np.divide(
        tp, predicted, out=np.zeros(tp.shape, dtype=np.float64), where=predicted > 0,
    )
    f1 = np.divide(2 * precision * recall, precision + recall,
                   out=np.zeros(tp.shape, dtype=np.float64),
                   where=(precision + recall) > 0)
    values = recall if metric == "rare_macro_recall" else f1
    return float(np.mean(values[rare_ids]))


def bootstrap_summary(samples: Sequence[float], observed: float, bootstrap: int) -> dict[str, Any]:
    values = np.asarray(samples, dtype=np.float64)
    finite = values[np.isfinite(values)]
    if not len(finite):
        return {"available": False, "reason": "no finite bootstrap replicates"}
    low, high = np.quantile(finite, (0.025, 0.975))
    return {
        "available": True, "observed": observed, "ci_low": float(low), "ci_high": float(high),
        "bootstrap_requested": bootstrap, "bootstrap_finite": len(finite),
    }


def patient_bootstrap_single(
    run: Run, raw: Raw, rare_ids: np.ndarray, threshold: int, bootstrap: int,
) -> list[dict[str, Any]]:
    prediction = raw.test_prob.argmax(axis=1)
    inverse, n_patients = cluster_codes(raw.patient)
    rng = np.random.default_rng(stable_seed("rare-single", run.protocol, run.method, run.seed, threshold))
    sample_lists = {"rare_macro_f1": [], "rare_macro_recall": []}
    for _ in range(bootstrap):
        counts = rng.multinomial(n_patients, np.full(n_patients, 1.0 / n_patients))
        weights = counts[inverse].astype(np.float64)
        for metric in sample_lists:
            sample_lists[metric].append(
                confusion_metric(raw.test_y, prediction, rare_ids, weights, metric, raw.test_prob.shape[1])
            )
    rows = []
    for metric, samples in sample_lists.items():
        observed = confusion_metric(
            raw.test_y, prediction, rare_ids, None, metric, raw.test_prob.shape[1]
        )
        rows.append({
            "protocol": run.protocol, "method": run.method, "seed": run.seed,
            "rare_threshold": threshold, "metric": metric, "n_patients": n_patients,
            **bootstrap_summary(samples, observed, bootstrap),
        })
    return rows


def align_raw(left: Raw, right: Raw) -> str | None:
    if left.test_prob.shape != right.test_prob.shape:
        return "test probability shapes differ"
    if not np.array_equal(left.class_names, right.class_names):
        return "class names/order differ"
    if len(left.test_y) != len(right.test_y):
        return "record counts differ"
    if not np.array_equal(left.test_y, right.test_y):
        return "test labels differ"
    if not np.array_equal(left.patient, right.patient):
        return "test patient ordering differs"
    return None


def paired_patient_rare(
    records: Sequence[Run], macro_rows: Sequence[Mapping[str, Any]],
    raw_cache: dict[Path, Raw], bootstrap: int,
) -> list[dict[str, Any]]:
    index = {run.key: run for run in records}
    rare_lookup = {
        (row["protocol"], row["method"], row["seed"], row["rare_threshold"]): row
        for row in macro_rows
    }
    output = []
    for protocol, method, seed in sorted(index):
        if method not in BASELINES or (protocol, "trust_full", seed) not in index:
            continue
        left_run, right_run = index[(protocol, "trust_full", seed)], index[(protocol, method, seed)]
        left, right = load_raw(left_run, raw_cache), load_raw(right_run, raw_cache)
        reason = align_raw(left, right)
        left_support: list[dict[str, Any]] = []
        if reason is None:
            left_support = support_rows(left_run, left.test_prob.shape[1])
            right_support = support_rows(right_run, right.test_prob.shape[1])
            if ([int(item["train_records"]) for item in left_support]
                    != [int(item["train_records"]) for item in right_support]):
                reason = "training-support vectors differ"
        for threshold in RARE_THRESHOLDS:
            common = {
                "protocol": protocol, "method_a": "trust_full", "method_b": method,
                "seed": seed, "rare_threshold": threshold,
                "difference_direction": "method_a_minus_method_b",
            }
            if reason:
                for metric in ("rare_macro_f1", "rare_macro_recall"):
                    output.append({**common, "metric": metric, "available": False, "reason": reason})
                continue
            support = left_support
            rare_ids = np.asarray(
                [class_id for class_id, item in enumerate(support) if int(item["train_records"]) < threshold],
                dtype=np.int64,
            )
            if not len(rare_ids):
                for metric in ("rare_macro_f1", "rare_macro_recall"):
                    output.append({
                        **common, "metric": metric, "available": False,
                        "reason": "no class meets this rare-support threshold",
                    })
                continue
            inverse, n_patients = cluster_codes(left.patient)
            left_pred, right_pred = left.test_prob.argmax(1), right.test_prob.argmax(1)
            rng = np.random.default_rng(stable_seed("rare-pair", protocol, method, seed, threshold))
            samples = {"rare_macro_f1": [], "rare_macro_recall": []}
            for _ in range(bootstrap):
                counts = rng.multinomial(n_patients, np.full(n_patients, 1.0 / n_patients))
                weights = counts[inverse].astype(np.float64)
                for metric in samples:
                    samples[metric].append(
                        confusion_metric(left.test_y, left_pred, rare_ids, weights, metric, left.test_prob.shape[1])
                        - confusion_metric(right.test_y, right_pred, rare_ids, weights, metric, right.test_prob.shape[1])
                    )
            for metric, values in samples.items():
                metric_name = "macro_f1" if metric.endswith("f1") else "macro_recall"
                observed = (
                    float(rare_lookup[(protocol, "trust_full", seed, threshold)][metric_name])
                    - float(rare_lookup[(protocol, method, seed, threshold)][metric_name])
                )
                finite = np.asarray(values, dtype=np.float64)
                low, high = np.quantile(finite, (0.025, 0.975))
                pvalue = min(1.0, 2.0 * min(float(np.mean(finite <= 0)), float(np.mean(finite >= 0))))
                output.append({
                    **common, "metric": metric, "available": True,
                    "observed_difference": observed, "ci_low": float(low), "ci_high": float(high),
                    "pvalue": pvalue, "n_patients": n_patients,
                    "bootstrap_requested": bootstrap, "bootstrap_finite": len(finite),
                })
    holm(output, ("protocol", "rare_threshold", "seed", "metric"), "pvalue")
    return output


def summary_stats(values: Sequence[float]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    if not len(array):
        return {"n": 0, "mean": None, "sd": None, "ci_low": None, "ci_high": None}
    mean = float(array.mean())
    if len(array) < 2:
        return {"n": 1, "mean": mean, "sd": None, "ci_low": None, "ci_high": None}
    sd = float(array.std(ddof=1))
    half = float(stats.t.ppf(0.975, len(array) - 1) * sd / math.sqrt(len(array)))
    return {"n": len(array), "mean": mean, "sd": sd, "ci_low": mean - half, "ci_high": mean + half}


def one_sample(values: Sequence[float]) -> dict[str, Any]:
    summary = summary_stats(values)
    if len(values) < 2:
        return {**summary, "t_statistic": None, "pvalue": None, "cohen_dz": None}
    sd = float(np.std(values, ddof=1))
    mean = float(np.mean(values))
    if sd == 0:
        return {
            **summary, "t_statistic": 0.0 if mean == 0 else math.copysign(math.inf, mean),
            "pvalue": 1.0 if mean == 0 else 0.0, "cohen_dz": None,
        }
    statistic = mean / (sd / math.sqrt(len(values)))
    return {
        **summary, "t_statistic": statistic,
        "pvalue": float(2 * stats.t.sf(abs(statistic), len(values) - 1)),
        "cohen_dz": mean / sd,
    }


def holm(rows: list[dict[str, Any]], family_keys: Sequence[str], pkey: str) -> None:
    groups: dict[tuple[Any, ...], list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        if row.get("available", True) and row.get(pkey) is not None:
            groups[tuple(row.get(key) for key in family_keys)].append(index)
    for indices in groups.values():
        ordered = sorted(indices, key=lambda index: float(rows[index][pkey]))
        running = 0.0
        for rank, index in enumerate(ordered):
            running = max(running, (len(ordered) - rank) * float(rows[index][pkey]))
            rows[index][f"{pkey}_holm"] = min(1.0, running)
            rows[index]["holm_family_size"] = len(ordered)


def seed_summaries(
    rows: Sequence[Mapping[str, Any]], group_keys: Sequence[str], metrics: Sequence[str],
) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row[key] for key in group_keys)].append(row)
    output = []
    for key, values in sorted(grouped.items(), key=lambda item: tuple(str(value) for value in item[0])):
        for metric in metrics:
            numeric = [float(row[metric]) for row in values if row.get(metric) is not None]
            output.append({
                **dict(zip(group_keys, key)), "metric": metric,
                **summary_stats(numeric), "seeds": sorted(int(row["seed"]) for row in values),
            })
    return output


def paired_seed_rows(
    rows: Sequence[Mapping[str, Any]], context_keys: Sequence[str], metrics: Sequence[str],
) -> list[dict[str, Any]]:
    index = {
        (*[row[key] for key in context_keys], row["method"], int(row["seed"])): row
        for row in rows
    }
    contexts = sorted({tuple(row[key] for key in context_keys) for row in rows}, key=str)
    output = []
    for context in contexts:
        methods = sorted({row["method"] for row in rows if tuple(row[key] for key in context_keys) == context})
        for baseline in (method for method in BASELINES if method in methods):
            for metric in metrics:
                pairs = []
                seeds = []
                for seed in FIVE_SEEDS:
                    left = index.get((*context, "trust_full", seed))
                    right = index.get((*context, baseline, seed))
                    if left and right and left.get(metric) is not None and right.get(metric) is not None:
                        pairs.append(float(left[metric]) - float(right[metric]))
                        seeds.append(seed)
                if pairs:
                    output.append({
                        **dict(zip(context_keys, context)), "method_a": "trust_full",
                        "method_b": baseline, "metric": metric,
                        "difference_direction": "method_a_minus_method_b", "paired_seeds": seeds,
                        "available": True, **one_sample(pairs),
                    })
    holm(output, tuple(context_keys) + ("metric",), "pvalue")
    return output


def selective_rows(records: Sequence[Run], raw_cache: dict[Path, Raw]) -> list[dict[str, Any]]:
    output = []
    for run in records:
        raw = load_raw(run, raw_cache)
        prediction = raw.test_prob.argmax(1)
        supports = support_rows(run, raw.test_prob.shape[1])
        rare_ids = np.asarray(
            [index for index, item in enumerate(supports) if int(item["train_records"]) < 50],
            dtype=np.int64,
        )
        rare = np.isin(raw.test_y, rare_ids)
        order = np.argsort(-raw.confidence, kind="mergesort")
        for target in COVERAGES:
            accepted_count = max(1, int(math.ceil(target * len(order))))
            accepted_indices = order[:accepted_count]
            accepted = np.zeros(len(order), dtype=bool)
            accepted[accepted_indices] = True
            rejected = ~accepted
            accuracy = float(np.mean(prediction[accepted] == raw.test_y[accepted]))
            output.append({
                "protocol": run.protocol, "method": run.method, "seed": run.seed,
                "target_coverage": target, "coverage": float(accepted.mean()),
                "accepted": int(accepted.sum()), "rejected": int(rejected.sum()),
                "risk": 1.0 - accuracy, "accuracy": accuracy,
                "balanced_accuracy": float(balanced_accuracy_score(raw.test_y[accepted], prediction[accepted])),
                "macro_f1": float(f1_score(
                    raw.test_y[accepted], prediction[accepted], labels=np.arange(raw.test_prob.shape[1]),
                    average="macro", zero_division=0,
                )),
                "rare_rejection_rate": float(rejected[rare].mean()) if rare.any() else None,
                "frequent_rejection_rate": float(rejected[~rare].mean()) if (~rare).any() else None,
                "rare_definition": "folds1-8 train records < 50",
                "confidence": raw.confidence_kind,
            })
    return output


def split_score_key(key: str) -> tuple[str, str] | None:
    if "__" not in key:
        return None
    detector, scenario = key.rsplit("__", 1)
    return detector, scenario


def score_vector(value: Any) -> tuple[np.ndarray | None, str | None]:
    """Accept only finite, nonempty, one-dimensional floating OOD scores."""

    array = np.asarray(value)
    if array.ndim != 1:
        return None, f"not a 1D score vector (shape={list(array.shape)})"
    if not np.issubdtype(array.dtype, np.floating):
        return None, f"score dtype is not floating ({array.dtype})"
    if len(array) == 0:
        return None, "empty score vector"
    if not np.isfinite(array).all():
        return None, "score vector contains non-finite values"
    return np.asarray(array, dtype=np.float64), None


def require_score_vector(value: Any, label: str) -> np.ndarray:
    vector, rejection = score_vector(value)
    if rejection is not None or vector is None:
        raise ValueError(f"{label}: {rejection}")
    return vector


def ood_metrics(id_score: np.ndarray, out_score: np.ndarray, sensitivity: float) -> dict[str, Any]:
    id_score = require_score_vector(id_score, "ID scores")
    out_score = require_score_vector(out_score, "OOD scores")
    labels = np.r_[np.zeros(len(id_score), dtype=np.int8), np.ones(len(out_score), dtype=np.int8)]
    scores = np.r_[id_score, out_score]
    fpr, tpr, thresholds = roc_curve(labels, scores)
    eligible = np.flatnonzero(tpr >= sensitivity)
    if not len(eligible):
        operating_index = len(tpr) - 1
    else:
        best_fpr = np.min(fpr[eligible])
        candidates = eligible[fpr[eligible] == best_fpr]
        operating_index = int(candidates[np.argmax(thresholds[candidates])])
    return {
        "auroc": float(roc_auc_score(labels, scores)),
        "aupr_out": float(average_precision_score(labels, scores)),
        "aupr_in": float(average_precision_score(1 - labels, -scores)),
        "target_sensitivity": sensitivity,
        "threshold_at_target_sensitivity": float(thresholds[operating_index]),
        "true_positive_rate": float(tpr[operating_index]),
        "false_positive_rate": float(fpr[operating_index]),
    }


def ood_point_and_alert_rows(
    records: Sequence[Run], sensitivity: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    point_rows = []
    alert_rows = []
    skipped_rows = []
    for run in records:
        with np.load(run.ood_path, allow_pickle=False) as archive:
            parsed: dict[str, dict[str, np.ndarray]] = defaultdict(dict)
            for key in archive.files:
                result = split_score_key(key)
                if not result:
                    skipped_rows.append({
                        "protocol": run.protocol, "method": run.method, "seed": run.seed,
                        "path": str(run.ood_path), "array_key": key, "detector": None,
                        "scenario": None, "shape": list(np.asarray(archive[key]).shape),
                        "dtype": str(np.asarray(archive[key]).dtype),
                        "reason": "array key has no detector__scenario suffix",
                        "action": "skipped; never flattened or column-selected",
                    })
                    continue
                detector, scenario = result
                raw_value = np.asarray(archive[key])
                vector, rejection = score_vector(raw_value)
                if rejection is not None or vector is None:
                    skipped_rows.append({
                        "protocol": run.protocol, "method": run.method, "seed": run.seed,
                        "path": str(run.ood_path), "array_key": key,
                        "detector": detector, "scenario": scenario,
                        "shape": list(raw_value.shape), "dtype": str(raw_value.dtype),
                        "reason": rejection,
                        "action": "skipped; never flattened or column-selected",
                    })
                    continue
                parsed[detector][scenario] = vector
            for detector, scenarios in parsed.items():
                if "id" not in scenarios:
                    for scenario in scenarios:
                        skipped_rows.append({
                            "protocol": run.protocol, "method": run.method, "seed": run.seed,
                            "path": str(run.ood_path),
                            "array_key": f"{detector}__{scenario}",
                            "detector": detector, "scenario": scenario,
                            "shape": list(scenarios[scenario].shape),
                            "dtype": str(scenarios[scenario].dtype),
                            "reason": "no matching valid detector__id 1D floating vector",
                            "action": "skipped; no unpaired OOD metric computed",
                        })
                    continue
                for scenario, out_score in scenarios.items():
                    if scenario in ("id", "validation"):
                        continue
                    metrics = ood_metrics(scenarios["id"], out_score, sensitivity)
                    base = {
                        "protocol": run.protocol, "method": run.method, "seed": run.seed,
                        "detector": detector, "scenario": scenario,
                        "n_id": len(scenarios["id"]), "n_ood": len(out_score),
                        **metrics,
                    }
                    point_rows.append(base)
                    for prevalence in PREVALENCES:
                        tpr = metrics["true_positive_rate"]
                        fpr = metrics["false_positive_rate"]
                        denominator = prevalence * tpr + (1.0 - prevalence) * fpr
                        alert_rows.append({
                            **base, "prevalence": prevalence,
                            "ppv": prevalence * tpr / denominator if denominator > 0 else None,
                            "true_alerts_per_1000": 1000.0 * prevalence * tpr,
                            "false_alerts_per_1000": 1000.0 * (1.0 - prevalence) * fpr,
                            "total_alerts_per_1000": 1000.0 * denominator,
                            "threshold_selection": "retrospective test OOD ROC at fixed sensitivity; not a deployment threshold",
                        })
    return point_rows, alert_rows, skipped_rows


def paired_ood_seed(point_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    index = {
        (row["protocol"], row["method"], row["detector"], row["scenario"], row["seed"]): row
        for row in point_rows
    }
    comparator_pairs = sorted({
        (row["protocol"], row["method"], row["detector"], row["scenario"])
        for row in point_rows
        if row["method"] in MAIN
    })
    output = []
    for protocol, method, detector, scenario in comparator_pairs:
        if method == "trust_full" and detector == "composite":
            continue
        for metric in ("auroc", "aupr_out", "aupr_in", "false_positive_rate"):
            differences, seeds = [], []
            for seed in FIVE_SEEDS:
                left = index.get((protocol, "trust_full", "composite", scenario, seed))
                right = index.get((protocol, method, detector, scenario, seed))
                if left and right:
                    differences.append(float(left[metric]) - float(right[metric]))
                    seeds.append(seed)
            if differences:
                output.append({
                    "protocol": protocol, "scenario": scenario,
                    "method_a": "trust_full", "detector_a": "composite",
                    "method_b": method, "detector_b": detector, "metric": metric,
                    "difference_direction": "A_minus_B", "paired_seeds": seeds,
                    "available": True, **one_sample(differences),
                })
    holm(output, ("protocol", "scenario", "metric"), "pvalue")
    return output


def compute_midrank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_values = values[order]
    result = np.empty(len(values), dtype=np.float64)
    start = 0
    while start < len(values):
        end = start
        while end < len(values) and sorted_values[end] == sorted_values[start]:
            end += 1
        result[start:end] = 0.5 * (start + end - 1) + 1.0
        start = end
    inverse = np.empty(len(values), dtype=np.int64)
    inverse[order] = np.arange(len(values))
    return result[inverse]


def fast_delong(predictions: np.ndarray, positive_count: int) -> tuple[np.ndarray, np.ndarray]:
    classifiers, total = predictions.shape
    negative_count = total - positive_count
    positive = predictions[:, :positive_count]
    negative = predictions[:, positive_count:]
    tx = np.empty((classifiers, positive_count))
    ty = np.empty((classifiers, negative_count))
    tz = np.empty((classifiers, total))
    for index in range(classifiers):
        tx[index] = compute_midrank(positive[index])
        ty[index] = compute_midrank(negative[index])
        tz[index] = compute_midrank(predictions[index])
    aucs = tz[:, :positive_count].sum(axis=1) / positive_count / negative_count
    aucs -= (positive_count + 1.0) / (2.0 * negative_count)
    v01 = (tz[:, :positive_count] - tx) / negative_count
    v10 = 1.0 - (tz[:, positive_count:] - ty) / positive_count
    covariance = np.cov(v01) / positive_count + np.cov(v10) / negative_count
    return aucs, np.atleast_2d(covariance)


def paired_delong(left_id: np.ndarray, left_out: np.ndarray,
                  right_id: np.ndarray, right_out: np.ndarray) -> dict[str, Any]:
    try:
        left_id = require_score_vector(left_id, "method A ID scores")
        left_out = require_score_vector(left_out, "method A OOD scores")
        right_id = require_score_vector(right_id, "method B ID scores")
        right_out = require_score_vector(right_out, "method B OOD scores")
    except ValueError as exc:
        return {"available": False, "reason": str(exc)}
    if len(left_id) != len(right_id) or len(left_out) != len(right_out):
        return {"available": False, "reason": "paired score lengths differ"}
    predictions = np.vstack((
        np.r_[left_out, left_id], np.r_[right_out, right_id],
    ))
    aucs, covariance = fast_delong(predictions, len(left_out))
    contrast = np.asarray((1.0, -1.0))
    variance = float(contrast @ covariance @ contrast)
    difference = float(aucs[0] - aucs[1])
    if variance <= 0:
        pvalue = 1.0 if difference == 0 else 0.0
        half = 0.0
    else:
        standard_error = math.sqrt(variance)
        pvalue = float(2 * stats.norm.sf(abs(difference / standard_error)))
        half = 1.959963984540054 * standard_error
    return {
        "available": True, "auc_a": float(aucs[0]), "auc_b": float(aucs[1]),
        "difference": difference, "ci_low": difference - half, "ci_high": difference + half,
        "pvalue": pvalue, "n_id": len(left_id), "n_ood": len(left_out),
        "test": "paired DeLong",
    }


def load_detector(run: Run, detector: str, scenario: str) -> tuple[np.ndarray, np.ndarray]:
    with np.load(run.ood_path, allow_pickle=False) as archive:
        return (
            require_score_vector(archive[f"{detector}__id"], f"{detector}__id"),
            require_score_vector(
                archive[f"{detector}__{scenario}"], f"{detector}__{scenario}",
            ),
        )


def verify_ood_record_alignment(left_path: Path, right_path: Path, scenario: str) -> None:
    """Require saved unique record IDs before claiming paired OOD observations."""
    with np.load(left_path, allow_pickle=False) as left, np.load(right_path, allow_pickle=False) as right:
        for split in ("id", scenario):
            name = f"{split}_record_ids"
            if name not in left.files or name not in right.files:
                raise ValueError(f"saved record IDs absent for paired OOD split {split}")
            a, b = np.asarray(left[name]), np.asarray(right[name])
            if a.ndim != 1 or b.ndim != 1 or not len(a):
                raise ValueError(f"invalid paired record IDs: {split}")
            if len(np.unique(a)) != len(a) or len(np.unique(b)) != len(b):
                raise ValueError(f"duplicate paired record IDs: {split}")
            if not np.array_equal(a, b):
                raise ValueError(f"ordered paired record IDs differ: {split}")


def paired_ood_samples(records: Sequence[Run], point_rows: Sequence[Mapping[str, Any]],
                       raw_cache: dict[Path, Raw]) -> list[dict[str, Any]]:
    run_index = {run.key: run for run in records}
    candidates = sorted({
        (row["protocol"], row["method"], row["detector"], row["scenario"], int(row["seed"]))
        for row in point_rows if row["method"] in MAIN
    })
    output = []
    for protocol, method, detector, scenario, seed in candidates:
        if method == "trust_full" and detector == "composite":
            continue
        left_run = run_index.get((protocol, "trust_full", seed))
        right_run = run_index.get((protocol, method, seed))
        common = {
            "protocol": protocol, "scenario": scenario, "seed": seed,
            "method_a": "trust_full", "detector_a": "composite",
            "method_b": method, "detector_b": detector, "metric": "auroc",
            "difference_direction": "A_minus_B",
        }
        if not left_run or not right_run:
            output.append({**common, "available": False, "reason": "missing matched run"})
            continue
        alignment = align_raw(load_raw(left_run, raw_cache), load_raw(right_run, raw_cache))
        if alignment:
            output.append({**common, "available": False, "reason": alignment})
            continue
        try:
            verify_ood_record_alignment(left_run.ood_path, right_run.ood_path, scenario)
            left_id, left_out = load_detector(left_run, "composite", scenario)
            right_id, right_out = load_detector(right_run, detector, scenario)
            output.append({
                **common,
                "alignment_basis": (
                    "identical ordered ID labels/patients and explicitly verified unique "
                    "record IDs for both the ID and OOD arrays, within matched protocol and seed"
                ),
                **paired_delong(left_id, left_out, right_id, right_out),
            })
        except Exception as exc:
            output.append({**common, "available": False, "reason": f"{type(exc).__name__}: {exc}"})
    holm(output, ("protocol", "scenario", "seed", "metric"), "pvalue")
    return output


def find_quality_key(files: Iterable[str], split: str) -> str | None:
    available = set(files)
    for candidate in (
        f"quality__{split}", f"{split}_quality", f"sqi_quality__{split}",
        f"{split}_sqi_quality", f"ecg_quality__{split}",
    ):
        if candidate in available:
            return candidate
    return None


def modular_pipeline(records: Sequence[Run], noise_root: Path, wearables_root: Path,
                     raw_cache: dict[Path, Raw]) -> list[dict[str, Any]]:
    output = []
    noise_keys: list[str] = []
    noise_files = sorted((noise_root / "canonical").glob("seed_*_curves.npz"))
    if noise_files:
        with np.load(noise_files[0], allow_pickle=False) as archive:
            noise_keys = sorted(archive.files)
    for run in records:
        if run.method != "softmax_modular":
            continue
        primary = "chapman" if run.protocol == "closed" else "all"
        with np.load(run.ood_path, allow_pickle=False) as archive:
            files = list(archive.files)
            detector = "Mahalanobis:oas"
            score_keys = {
                split: f"{detector}__{split}" for split in ("validation", "id", primary)
            }
            quality_keys = {
                split: find_quality_key(files, split) for split in ("validation", "id", primary)
            }
            missing = [value for value in score_keys.values() if value not in files]
            missing.extend(
                f"aligned per-sample SQI/quality for {split} (accepted aliases: quality__{split}, {split}_quality, sqi_quality__{split})"
                for split, value in quality_keys.items() if value is None
            )
            common = {
                "protocol": run.protocol, "method": run.method, "seed": run.seed,
                "pipeline": "SQI filter -> Mahalanobis OOD rejection -> Softmax classification",
                "scenario": primary,
            }
            if missing:
                output.append({
                    **common, "available": False,
                    "reason": "same-run aligned SQI is absent; cross-model/cross-dataset splicing is prohibited",
                    "missing_fields": missing,
                    "required_to_enable": [
                        "per-sample validation/ID/OOD SQI or scalar quality from this exact Softmax run",
                        "stable sample IDs for validation, ID and OOD arrays",
                        "the already-present same-run validation/ID/OOD Mahalanobis scores",
                        "the already-present ID classifier probabilities and labels",
                    ],
                    "available_noise_curve_fields": noise_keys,
                    "why_noise_is_insufficient": (
                        "noise curves contain clean/corrupted test quality and predictions from a separately "
                        "trained model, but no aligned fold-9 or OOD quality/Mahalanobis arrays"
                    ),
                    "why_wearables_are_insufficient": (
                        f"wearable root {wearables_root} contains MHEALTH/WESAD, not aligned PTB-XL records"
                    ),
                })
                continue
            q_val = np.asarray(archive[quality_keys["validation"]], dtype=np.float64)
            q_id = np.asarray(archive[quality_keys["id"]], dtype=np.float64)
            q_out = np.asarray(archive[quality_keys[primary]], dtype=np.float64)
            score_val = np.asarray(archive[score_keys["validation"]], dtype=np.float64)
            score_id = np.asarray(archive[score_keys["id"]], dtype=np.float64)
            score_out = np.asarray(archive[score_keys[primary]], dtype=np.float64)
        raw = load_raw(run, raw_cache)
        if not (len(q_val) == len(score_val) and len(q_id) == len(score_id) == len(raw.test_y)
                and len(q_out) == len(score_out)):
            output.append({**common, "available": False, "reason": "same-run pipeline arrays are not length-aligned"})
            continue
        quality_threshold = float(np.quantile(q_val, 0.05))
        val_quality_pass = q_val >= quality_threshold
        if not val_quality_pass.any():
            output.append({**common, "available": False, "reason": "no validation records pass SQI threshold"})
            continue
        ood_threshold = float(np.quantile(score_val[val_quality_pass], 0.95))
        id_quality_reject = q_id < quality_threshold
        out_quality_reject = q_out < quality_threshold
        id_ood_reject = (~id_quality_reject) & (score_id > ood_threshold)
        out_ood_reject = (~out_quality_reject) & (score_out > ood_threshold)
        id_accept = ~(id_quality_reject | id_ood_reject)
        out_accept = ~(out_quality_reject | out_ood_reject)
        prediction = raw.test_prob.argmax(1)
        output.append({
            **common, "available": True,
            "threshold_fit": "quality 5th percentile then Mahalanobis 95th percentile on fold 9 only",
            "quality_threshold": quality_threshold, "ood_threshold": ood_threshold,
            "id_quality_rejection_rate": float(id_quality_reject.mean()),
            "id_ood_rejection_rate_after_quality": float(id_ood_reject.mean()),
            "id_total_rejection_rate": float((~id_accept).mean()),
            "ood_quality_rejection_rate": float(out_quality_reject.mean()),
            "ood_ood_rejection_rate_after_quality": float(out_ood_reject.mean()),
            "ood_total_detection_rate": float((~out_accept).mean()),
            "accepted_id_accuracy": float(np.mean(prediction[id_accept] == raw.test_y[id_accept]))
            if id_accept.any() else None,
            "accepted_id_n": int(id_accept.sum()), "accepted_ood_n": int(out_accept.sum()),
        })
    return output


def latex_escape(value: Any) -> str:
    replacements = {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
    }
    return "".join(replacements.get(character, character) for character in str(value))


def latex_table(title: str, fields: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> list[str]:
    lines = [f"% {title}", r"\begin{longtable}{" + "l" * len(fields) + "}",
             " & ".join(latex_escape(field) for field in fields) + r" \\ \hline"]
    for row in rows:
        values = []
        for field in fields:
            value = row.get(field)
            values.append("NA" if value is None else (f"{value:.6g}" if isinstance(value, float) else latex_escape(value)))
        lines.append(" & ".join(values) + r" \\")
    lines.extend((r"\end{longtable}", ""))
    return lines


def write_outputs(output_dir: Path, payload: dict[str, Any], inputs: Mapping[str, Any],
                  args: argparse.Namespace) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []

    def js(name: str, value: Any, pretty: bool = False) -> None:
        path = output_dir / name
        atomic_json(path, value, pretty=pretty)
        generated.append(path)

    def tab(name: str, key: str, fields: Sequence[str]) -> None:
        path = output_dir / name
        atomic_csv(path, payload[key], fields)
        generated.append(path)

    js("completion_matrix.json", payload["audit"], pretty=True)
    js("postprocess_results.json", payload)
    tab("completion_matrix.csv", "completion_matrix_rows", (
        "domain", "expected", "observed", "complete", "error_count", "skipped_array_count",
    ))
    tab("rare_classwise.csv", "rare_classwise", (
        "protocol", "method", "seed", "rare_threshold", "class_id", "class_name", "is_rare",
        "train_records", "validation_records", "test_records", "train_patients",
        "validation_patients", "test_patients", "precision", "recall", "f1", "auroc", "auprc",
    ))
    tab("rare_macro.csv", "rare_macro", (
        "protocol", "method", "seed", "rare_threshold", "n_classes_defined",
        "n_classes_auc_evaluable", "n_classes_auprc_evaluable", "train_records_sum",
        "test_records_sum", "macro_precision", "macro_recall", "macro_f1", "macro_auroc", "macro_auprc",
    ))
    tab("rare_seed_summary.csv", "rare_seed_summary", (
        "protocol", "method", "rare_threshold", "metric", "n", "mean", "sd", "ci_low", "ci_high", "seeds",
    ))
    tab("rare_patient_ci.csv", "rare_patient_ci", (
        "protocol", "method", "seed", "rare_threshold", "metric", "available", "observed",
        "ci_low", "ci_high", "n_patients", "bootstrap_requested", "bootstrap_finite", "reason",
    ))
    tab("rare_paired_patient.csv", "rare_paired_patient", (
        "protocol", "method_a", "method_b", "seed", "rare_threshold", "metric", "available",
        "observed_difference", "ci_low", "ci_high", "pvalue", "pvalue_holm", "holm_family_size",
        "n_patients", "bootstrap_requested", "bootstrap_finite", "reason",
    ))
    tab("rare_paired_seed.csv", "rare_paired_seed", (
        "protocol", "rare_threshold", "method_a", "method_b", "metric", "paired_seeds", "n",
        "mean", "sd", "ci_low", "ci_high", "t_statistic", "pvalue", "pvalue_holm",
        "holm_family_size", "cohen_dz",
    ))
    tab("selective_fixed_coverage.csv", "selective", (
        "protocol", "method", "seed", "target_coverage", "coverage", "accepted", "rejected",
        "risk", "accuracy", "balanced_accuracy", "macro_f1", "rare_rejection_rate",
        "frequent_rejection_rate", "rare_definition", "confidence",
    ))
    tab("selective_seed_summary.csv", "selective_seed_summary", (
        "protocol", "method", "target_coverage", "metric", "n", "mean", "sd", "ci_low", "ci_high", "seeds",
    ))
    tab("selective_paired_seed.csv", "selective_paired_seed", (
        "protocol", "target_coverage", "method_a", "method_b", "metric", "paired_seeds", "n",
        "mean", "sd", "ci_low", "ci_high", "t_statistic", "pvalue", "pvalue_holm",
        "holm_family_size", "cohen_dz",
    ))
    tab("ood_points.csv", "ood_points", (
        "protocol", "method", "seed", "detector", "scenario", "n_id", "n_ood", "auroc",
        "aupr_out", "aupr_in", "target_sensitivity", "threshold_at_target_sensitivity",
        "true_positive_rate", "false_positive_rate",
    ))
    tab("ood_skipped_arrays.csv", "ood_skipped_arrays", (
        "protocol", "method", "seed", "path", "array_key", "detector", "scenario",
        "shape", "dtype", "reason", "action",
    ))
    tab("ood_paired_seed.csv", "ood_paired_seed", (
        "protocol", "scenario", "method_a", "detector_a", "method_b", "detector_b", "metric",
        "paired_seeds", "n", "mean", "sd", "ci_low", "ci_high", "t_statistic", "pvalue",
        "pvalue_holm", "holm_family_size", "cohen_dz",
    ))
    tab("ood_paired_sample.csv", "ood_paired_sample", (
        "protocol", "scenario", "seed", "method_a", "detector_a", "method_b", "detector_b",
        "metric", "available", "auc_a", "auc_b", "difference", "ci_low", "ci_high", "pvalue",
        "pvalue_holm", "holm_family_size", "n_id", "n_ood", "test", "alignment_basis", "reason",
    ))
    tab("ood_alert_prevalence.csv", "ood_alerts", (
        "protocol", "method", "seed", "detector", "scenario", "prevalence", "target_sensitivity",
        "true_positive_rate", "false_positive_rate", "ppv", "true_alerts_per_1000",
        "false_alerts_per_1000", "total_alerts_per_1000", "threshold_at_target_sensitivity",
        "threshold_selection",
    ))
    tab("ood_alert_seed_summary.csv", "ood_alert_seed_summary", (
        "protocol", "method", "detector", "scenario", "prevalence", "target_sensitivity",
        "metric", "n", "mean", "sd", "ci_low", "ci_high", "seeds",
    ))
    tab("modular_pipeline.csv", "modular_pipeline", (
        "protocol", "method", "seed", "pipeline", "scenario", "available", "reason",
        "missing_fields", "quality_threshold", "ood_threshold", "id_quality_rejection_rate",
        "id_ood_rejection_rate_after_quality", "id_total_rejection_rate",
        "ood_quality_rejection_rate", "ood_ood_rejection_rate_after_quality",
        "ood_total_detection_rate", "accepted_id_accuracy", "accepted_id_n", "accepted_ood_n",
    ))
    tex_lines = []
    tex_lines.extend(latex_table(
        "Rare-class seed summaries", ("protocol", "method", "rare_threshold", "metric", "mean", "sd", "ci_low", "ci_high"),
        [row for row in payload["rare_seed_summary"] if row["method"] in MAIN],
    ))
    tex_lines.extend(latex_table(
        "Selective prediction", ("protocol", "method", "target_coverage", "metric", "mean", "sd", "ci_low", "ci_high"),
        [row for row in payload["selective_seed_summary"] if row["method"] in MAIN],
    ))
    tex_lines.extend(latex_table(
        "Paired-seed OOD contrasts", ("protocol", "scenario", "method_b", "detector_b", "metric", "mean", "pvalue_holm"),
        payload["ood_paired_seed"],
    ))
    tex_lines.extend(latex_table(
        "OOD alert burden by assumed prevalence",
        ("protocol", "method", "detector", "scenario", "prevalence", "metric", "mean", "sd", "ci_low", "ci_high"),
        [row for row in payload["ood_alert_seed_summary"] if row["method"] in MAIN],
    ))
    tex_path = output_dir / "postprocess_tables.tex"
    atomic_text(tex_path, "\n".join(tex_lines))
    generated.append(tex_path)

    manifest = {
        "schema": SCRIPT_VERSION, "created_at_utc": utc_now(), "command": sys.argv,
        "arguments": {
            "ptb_root": str(args.ptb_root), "noise_root": str(args.noise_root),
            "wearables_root": str(args.wearables_root), "output_dir": str(args.output_dir),
            "bootstrap": args.bootstrap, "target_sensitivity": args.target_sensitivity,
            "fail_on_incomplete": args.fail_on_incomplete,
        },
        "environment": {
            "python": platform.python_version(), "platform": platform.platform(),
            "numpy": np.__version__, "scipy": scipy.__version__, "sklearn": sklearn.__version__,
        },
        "script": {"path": str(Path(__file__).resolve()), "sha256": sha256_file(Path(__file__).resolve())},
        "inputs": sorted(inputs.values(), key=lambda item: item["path"]),
        "outputs": [
            {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
            for path in generated
        ],
        "note": "manifest.json is intentionally not self-hashed",
    }
    atomic_json(output_dir / "manifest.json", manifest, pretty=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--ptb-root", type=Path, required=True)
    parser.add_argument("--noise-root", type=Path, required=True)
    parser.add_argument("--wearables-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--target-sensitivity", type=float, default=0.95)
    parser.add_argument("--fail-on-incomplete", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    for name in ("ptb_root", "noise_root", "wearables_root", "output_dir"):
        setattr(args, name, getattr(args, name).resolve())
    if args.bootstrap < 100:
        raise SystemExit("--bootstrap must be >=100")
    if not 0.0 < args.target_sensitivity < 1.0:
        raise SystemExit("--target-sensitivity must lie in (0,1)")
    for root in (args.ptb_root, args.noise_root, args.wearables_root):
        if not root.is_dir():
            raise SystemExit(f"required input root absent: {root}")
        try:
            args.output_dir.relative_to(root)
        except ValueError:
            pass
        else:
            raise SystemExit("output directory must be outside all read-only input roots")

    records, ptb_audit, ptb_inputs = audit_ptb(args.ptb_root)
    auxiliary_audit, auxiliary_inputs = audit_auxiliary_roots(args.noise_root, args.wearables_root)
    inputs = {**ptb_inputs, **auxiliary_inputs}
    raw_cache: dict[Path, Raw] = {}
    rare_classwise, rare_macro, rare_patient_ci = rare_analyses(records, raw_cache, args.bootstrap)
    rare_paired_patient = paired_patient_rare(records, rare_macro, raw_cache, args.bootstrap)
    rare_seed_summary = seed_summaries(
        rare_macro, ("protocol", "method", "rare_threshold"),
        ("macro_precision", "macro_recall", "macro_f1", "macro_auroc", "macro_auprc"),
    )
    rare_paired_seed = paired_seed_rows(
        rare_macro, ("protocol", "rare_threshold"),
        ("macro_recall", "macro_f1", "macro_auroc", "macro_auprc"),
    )
    selective = selective_rows(records, raw_cache)
    selective_seed_summary = seed_summaries(
        selective, ("protocol", "method", "target_coverage"),
        ("risk", "accuracy", "balanced_accuracy", "macro_f1", "rare_rejection_rate", "frequent_rejection_rate"),
    )
    selective_paired_seed = paired_seed_rows(
        selective, ("protocol", "target_coverage"),
        ("risk", "accuracy", "balanced_accuracy", "macro_f1", "rare_rejection_rate", "frequent_rejection_rate"),
    )
    ood_points, ood_alerts, ood_skipped_arrays = ood_point_and_alert_rows(
        records, args.target_sensitivity,
    )
    ptb_audit["ood_metric_pairs_processed"] = len(ood_points)
    ptb_audit["ood_metric_arrays_skipped"] = ood_skipped_arrays
    ptb_audit["ood_metric_arrays_skipped_count"] = len(ood_skipped_arrays)
    ood_alert_seed_summary = seed_summaries(
        ood_alerts,
        ("protocol", "method", "detector", "scenario", "prevalence", "target_sensitivity"),
        ("ppv", "true_alerts_per_1000", "false_alerts_per_1000", "total_alerts_per_1000",
         "true_positive_rate", "false_positive_rate"),
    )
    ood_paired_seed = paired_ood_seed(ood_points)
    ood_paired_sample = paired_ood_samples(records, ood_points, raw_cache)
    pipeline = modular_pipeline(records, args.noise_root, args.wearables_root, raw_cache)
    complete = ptb_audit["complete"] and auxiliary_audit["complete"]
    noise_errors = [
        item for item in auxiliary_audit["errors"]
        if item.startswith("noise") or item.startswith("expected 3 valid noise")
    ]
    wearable_errors = [
        item for item in auxiliary_audit["errors"]
        if item.startswith("wearable") or item.startswith("expected 345 wearable")
    ]
    completion_matrix_rows = [
        {
            "domain": "ptbxl", "expected": ptb_audit["expected_records"],
            "observed": ptb_audit["observed_records"], "complete": ptb_audit["complete"],
            "error_count": len(ptb_audit["errors"]),
            "skipped_array_count": len(ood_skipped_arrays),
        },
        {
            "domain": "noise_sqi", "expected": auxiliary_audit["noise_expected"],
            "observed": auxiliary_audit["noise_observed"], "complete": not noise_errors,
            "error_count": len(noise_errors),
            "skipped_array_count": 0,
        },
        {
            "domain": "wearables", "expected": auxiliary_audit["wearable_expected"],
            "observed": auxiliary_audit["wearable_observed"], "complete": not wearable_errors,
            "error_count": len(wearable_errors),
            "skipped_array_count": 0,
        },
    ]
    payload = {
        "schema": SCRIPT_VERSION, "created_at_utc": utc_now(),
        "audit": {"complete": complete, "ptb": ptb_audit, "auxiliary": auxiliary_audit},
        "methodology": {
            "rare": "rare iff folds1-8 train record support is below 25, 50, or 100",
            "patient_ci": "equal-probability patient-cluster multinomial bootstrap; all records of a sampled patient receive the same multiplicity",
            "patient_ci_scope": "single-method patient CIs are reported for TrustOOD; TrustOOD-versus-baseline patient-cluster contrasts are paired within identical test patients",
            "selective": "retrospective ranking by negative vacuity when stored, otherwise maximum probability; ceil(target*N) accepted with stable sorting",
            "ood_seed": "paired by identical protocol/scenario/seed; Student-t CI and two-sided paired t test",
            "ood_sample": "paired DeLong for AUROC only after exact ordered unique ID/OOD record-ID alignment; missing or mismatched IDs make the comparison unavailable",
            "ood_array_contract": "ID and OOD inputs must both be finite, nonempty, one-dimensional floating vectors; multidimensional auxiliary arrays are recorded and skipped without flattening or column selection",
            "alerts": "empirical fixed-sensitivity ROC point and Bayes prevalence projection; retrospective, not a deployment threshold",
            "holm": "Holm familywise adjustment within each stated protocol/context/metric family",
            "missing": "no interpolation or fabricated values",
        },
        "completion_matrix_rows": completion_matrix_rows,
        "rare_classwise": rare_classwise, "rare_macro": rare_macro,
        "rare_seed_summary": rare_seed_summary, "rare_patient_ci": rare_patient_ci,
        "rare_paired_patient": rare_paired_patient, "rare_paired_seed": rare_paired_seed,
        "selective": selective, "selective_seed_summary": selective_seed_summary,
        "selective_paired_seed": selective_paired_seed,
        "ood_points": ood_points, "ood_skipped_arrays": ood_skipped_arrays,
        "ood_paired_seed": ood_paired_seed,
        "ood_paired_sample": ood_paired_sample, "ood_alerts": ood_alerts,
        "ood_alert_seed_summary": ood_alert_seed_summary,
        "modular_pipeline": pipeline,
    }
    write_outputs(args.output_dir, payload, inputs, args)
    print(
        f"[postprocess] ptb={len(records)}/212 noise={auxiliary_audit['noise_observed']}/3 "
        f"wearable={auxiliary_audit['wearable_observed']}/345 complete={complete}", flush=True,
    )
    return 2 if args.fail_on_incomplete and not complete else 0


if __name__ == "__main__":
    raise SystemExit(main())
