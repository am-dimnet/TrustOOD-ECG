"""Training-only HRV provenance guards; no training or data loading on import."""
from pathlib import Path
import hashlib,json,os
import numpy as np
SCHEMA='paper46-revision2-training-only-hrv-v1'
def sha256(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def record_ids(adapter,indices):
 if 'record_id' not in adapter.metadata:raise ValueError('Missing source record_id')
 ids=adapter.metadata['record_id'].astype(str).to_numpy(dtype=str)
 if len(set(ids[adapter.valid])) != int(adapter.valid.sum()):raise ValueError('Duplicate valid record IDs')
 return ids[np.asarray(indices,dtype=int)]
def fit_medians(raw,train):
 selected=np.asarray(raw)[np.asarray(train,dtype=int)]
 med=[]
 for col in selected.T:
  finite=col[np.isfinite(col)]
  if not len(finite):raise ValueError('No finite eligible training HRV values')
  med.append(np.median(finite))
 return np.asarray(med,dtype=np.float32)
def transform(raw,medians,valid):
 result=np.array(raw,dtype=np.float32,copy=True)
 for j,m in enumerate(medians):result[valid & ~np.isfinite(result[:,j]),j]=m
 if not np.isfinite(result[valid]).all():raise ValueError('Non-finite transformed valid rows')
 result[~valid]=np.nan
 return result
def validate_imputation(args,adapter,train):
 path=Path(args.cache_dir)/'training_only_hrv_manifest.json'
 m=json.loads(path.read_text())
 expected='closed' if args.protocol=='closed' else f'strict_tau{args.tau}'
 if m['schema']!=SCHEMA or m['protocol']!=expected:raise ValueError('Wrong HRV protocol/schema')
 if not np.array_equal(np.asarray(train),np.asarray(m['train_indices'])):raise ValueError('HRV fit split differs')
 if list(record_ids(adapter,train))!=m['train_record_ids']:raise ValueError('HRV train IDs differ')
 for entry in m['verified_inputs']:
  p=Path(entry['path'])
  if sha256(p)!=entry['sha256']:raise ValueError(f'Input hash mismatch: {p}')
 for name,entry in m['outputs'].items():
  if sha256(Path(args.cache_dir)/entry['filename'])!=entry['sha256']:raise ValueError(f'HRV output mismatch: {name}')
 return {'schema':SCHEMA,'protocol':expected,'sha256':sha256(path),'path':str(path),'medians':m['medians'],'implementation_sha256':sha256(__file__)}
def save_fitted_state(path,model,members,plan,protocol,diagnosis,states,definition):
 import torch
 from dataclasses import asdict
 networks=members if members else [model]
 payload={'schema':SCHEMA,'model_plan':asdict(plan),'state_dicts':[{k:v.detach().cpu() for k,v in net.state_dict().items()} for net in networks],
 'run_definition':definition,'class_names':protocol['class_names'],'calibration_and_metrics':diagnosis,
 'density_and_posthoc_states':states,'train_index':protocol['train_index'],'val_index':protocol['val_index'],
 'test_index':protocol['test_index'],'ood_indices':protocol['ood_indices'],'imputation':protocol['split_manifest']['hrv_imputation_manifest']}
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp')
 torch.save(payload,tmp);os.replace(tmp,path)
