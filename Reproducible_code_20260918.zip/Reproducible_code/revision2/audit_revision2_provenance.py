#!/usr/bin/env python3
"""Audit both result origins before allowing a combined statistical input view.

Never changes results, retrains, or substitutes an old HRV-dependent run. A full
pass covers exactly 415 corrected runs and 18 explicitly approved ECG-only runs.
The available-only mode is a progress check and cannot create an analysis view.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
SCHEMA = "paper46-revision2-training-only-hrv-v1"
REMOTE = Path("/root/autodl-tmp/Paper46_revision2")


def require(value, message):
    if not value:
        raise ValueError(message)


@lru_cache(maxsize=None)
def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def object_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def identity(job):
    return (job["family"], job["protocol"], job["tau"], job["model"], job["seed"])


def relative_json(job):
    p = Path(job["family"]) / job["protocol"]
    if job["protocol"] == "strict":
        p /= f"tau{job['tau']}"
    return p / job["model"] / f"seed_{job['seed']}.json"


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    tmp.replace(path)


def audit(root, available_only=False):
    root = root.resolve()
    jobs = json.loads((HERE / "configs/jobs.json").read_text())
    require(len(jobs) == 433 and len({identity(j) for j in jobs}) == 433, "matrix cardinality")
    require(Counter(j["action"] for j in jobs) == {"retrain": 415, "reuse_ecg_only": 18}, "origin counts")
    pinned_path = root / "environment/deployed_code_attempt2.json"
    pinned = json.loads(pinned_path.read_text())["files"]
    reuse_path = root / "reused_ecg_only/reuse_manifest.json"
    reuse = json.loads(reuse_path.read_text())
    require(reuse["schema"] == "paper46-explicit-historical-reuse-v1", "reuse schema")
    reuse_by_id = {identity(r["job"]): r for r in reuse["records"]}
    require(set(reuse_by_id) == {identity(j) for j in jobs if j["action"] == "reuse_ecg_only"}, "reuse allowlist")

    def resolve_original(path):
        return root / Path(path).relative_to(REMOTE)

    current = {}
    for name in ["run_ptbxl_revision.py", "run_ptbxl_missing_extensions.py", "revisionlib.py",
                 "data_adapter.py", "revision2_provenance.py"]:
        rel = "server_preparation/code/" + name
        current[name] = digest(root / rel)
        require(current[name] == pinned[rel], "training code changed since attempt2: " + name)

    # The queue may contain verified resume commands as well as original fits.
    commands = {}
    for path in sorted((root / "results/queue_logs").rglob("*.command.json")):
        data = json.loads(path.read_text())
        commands.setdefault(identity(data["job"]), []).append((path, data))

    records, failures, pending, references, cache_seen = [], [], [], {}, set()
    expected_json = {"results": set(), "reused_ecg_only": set()}
    for job in jobs:
        reused = job["action"] == "reuse_ecg_only"
        origin_dir = "reused_ecg_only" if reused else "results"
        relative = relative_json(job)
        path = root / origin_dir / relative
        expected_json[origin_dir].add(path)
        if available_only and not path.is_file():
            pending.append({"job": job, "reason": "result not yet published"})
            continue
        try:
            d = json.loads(path.read_text())
            require(d["status"] == "complete", "result status")
            require(d["seed"] == job["seed"] and d["protocol"] == job["protocol"], "identity")
            require(d["tau"] == (job["tau"] if job["protocol"] == "strict" else None), "tau")
            require(d["model"]["tag"] == job["model"], "model tag")
            definition = d["run_definition"]
            require(d["run_fingerprint"] == object_digest(definition), "fingerprint")
            for key in ["model", "seed", "protocol", "tau", "split", "n_classes", "class_names"]:
                require(definition[key] == d[key], "definition differs: " + key)
            args = d["environment"]["arguments"]
            require(definition["arguments"] == args, "argument linkage")
            require(definition["script_version"] == d["environment"]["script_version"], "version linkage")
            for key, value in {"epochs": 40, "batch_size": 256, "eval_batch_size": 512,
                               "learning_rate": .001, "ensemble_members": 5,
                               "rare_threshold": 50, "bootstrap": 0}.items():
                require(args[key] == value, "fixed configuration: " + key)
            for key in ["limit_train", "limit_val", "limit_test", "limit_ood", "limit_chapman"]:
                require(args[key] is None, "data limit: " + key)
            roles = {"raw_npz", "ood_npz"} | (set() if reused else {"fitted_state"})
            require(set(d["artifacts"]) == roles, "artifact roles")
            files = [{"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path), "role": "json"}]
            for role, entry in d["artifacts"].items():
                require(Path(entry["filename"]).name == entry["filename"], "artifact filename")
                f = path.parent / entry["filename"]
                require(f.stat().st_size == entry["bytes"] and digest(f) == entry["sha256"], "artifact checksum: " + role)
                files.append({"path": str(f), "bytes": f.stat().st_size, "sha256": digest(f), "role": role})
            successful_commands = []
            if reused:
                allowed = reuse_by_id[identity(job)]
                require(allowed["origin"] == "historical_ecg_only_unchanged", "reuse origin")
                require(job["protocol"] == "closed" and d["model"]["source_count"] == 1, "ECG-only eligibility")
                require(d["run_fingerprint"] == allowed["run_fingerprint"], "historical fingerprint")
                approved = {x["path"]: x for x in allowed["files"]}
                require(set(approved) == {str(Path(x["path"]).relative_to(root / origin_dir)) for x in files}, "historical file list")
                for x in files:
                    original = approved[str(Path(x["path"]).relative_to(root / origin_dir))]
                    require(x["sha256"] == original["sha256"] and x["bytes"] == original["bytes"], "historical output changed")
            else:
                code = {k: current[k] for k in ["run_ptbxl_revision.py", "revisionlib.py", "data_adapter.py"]}
                if job["family"] == "extensions":
                    code["base_run_ptbxl_revision.py"] = code["run_ptbxl_revision.py"]
                    code["run_ptbxl_revision.py"] = current["run_ptbxl_missing_extensions.py"]
                require(definition["code_sha256"] == code, "training code origin")
                for code_key, env_key in [("run_ptbxl_revision.py", "script_sha256"), ("revisionlib.py", "revisionlib_sha256"), ("data_adapter.py", "data_adapter_sha256")]:
                    require(code[code_key] == d["environment"][env_key], "environment code linkage")
                protocol = "closed" if job["protocol"] == "closed" else f"strict_tau{job['tau']}"
                require(args["cache_dir"] == str(REMOTE / "cache" / protocol), "protocol cache path")
                require(args["trustfed_cache"] == str(REMOTE / "wave_cache"), "wave cache path")
                require(args["results_dir"] == str(REMOTE / "results" / job["family"]), "result path")
                imputation = d["split"]["hrv_imputation_manifest"]
                require(imputation["schema"] == SCHEMA and imputation["protocol"] == protocol, "imputation protocol")
                require(imputation["implementation_sha256"] == current["revision2_provenance.py"], "imputation implementation")
                cache_path = root / "cache" / protocol / "training_only_hrv_manifest.json"
                require(imputation["sha256"] == digest(cache_path), "imputation manifest checksum")
                cache = json.loads(cache_path.read_text())
                require(cache["schema"] == SCHEMA and cache["protocol"] == protocol and imputation["medians"] == cache["medians"], "imputation values")
                if protocol not in cache_seen:
                    for entry in cache["verified_inputs"]:
                        require(digest(resolve_original(entry["path"])) == entry["sha256"], "preprocessing input checksum")
                    for entry in cache["outputs"].values():
                        require(digest(cache_path.parent / entry["filename"]) == entry["sha256"], "preprocessing output checksum")
                    cache_seen.add(protocol)
                for command_path, command_data in commands.get(identity(job), []):
                    log = command_path.with_name(command_path.name.replace(".command.json", ".log"))
                    exit_path = Path(str(log) + ".exit")
                    if not exit_path.exists() or exit_path.read_text().strip() != "0":
                        continue
                    require(log.is_file() and log.stat().st_size > 0, "queue log missing")
                    cmd = command_data["command"]
                    require(cmd[cmd.index("--models") + 1] == job["model"] and int(cmd[cmd.index("--seed") + 1]) == job["seed"], "queue identity")
                    for flag, value in {"--epochs": "40", "--batch-size": "256", "--eval-batch-size": "512", "--learning-rate": "0.001", "--ensemble-members": "5", "--bootstrap": "0"}.items():
                        require(cmd[cmd.index(flag) + 1] == value, "queue configuration: " + flag)
                    successful_commands.append({"command_path": str(command_path), "command_sha256": digest(command_path), "log_path": str(log), "log_sha256": digest(log), "exit_code": 0})
                if available_only and not successful_commands:
                    pending.append({"job": job, "reason": "awaiting queue exit record"})
                    continue
                require(successful_commands, "no successful authorized queue command")
            with np.load(path.parent / d["artifacts"]["raw_npz"]["filename"], allow_pickle=False) as raw, np.load(path.parent / d["artifacts"]["ood_npz"]["filename"], allow_pickle=False) as ood:
                refkey = (job["protocol"], job["tau"])
                arrays = {k: raw[k] for k in ["val_y", "test_y", "test_patient", "class_names", "rare_ids"]}
                if not reused:
                    arrays.update({k: raw[k] for k in ["train_record_id", "val_record_id", "test_record_id"]})
                    arrays.update({"ood:" + k: ood[k] for k in ood.files if k.endswith("_record_ids")})
                    require(list(raw["train_record_id"]) == cache["train_record_ids"], "imputer fit IDs")
                    require(np.array_equal(raw["test_record_id"], ood["id_record_ids"]), "OOD ID test alignment")
                    require(np.array_equal(raw["val_record_id"], ood["validation_record_ids"]), "OOD ID validation alignment")
                ref = references.setdefault(refkey, {})
                for key, values in arrays.items():
                    if key in ref:
                        require(np.array_equal(values, ref[key]), "cross-method row alignment: " + key)
                    else:
                        ref[key] = values.copy()
            records.append({"job": job, "origin": "historical_ecg_only_unchanged" if reused else "corrected_training_only_hrv_attempt2", "json_path": str(path), "run_fingerprint": d["run_fingerprint"], "code_sha256": definition["code_sha256"], "files": files, "successful_queue_commands": successful_commands})
        except Exception as exc:
            failures.append({"job": job, "path": str(path), "error": f"{type(exc).__name__}: {exc}"})
    for origin, expected in expected_json.items():
        observed = {p for family in ["formal", "extensions"] for p in (root / origin / family).rglob("seed_*.json")}
        for extra in sorted(observed - expected):
            failures.append({"path": str(extra), "error": "unexpected result cell"})
    return {"schema": "paper46-revision2-origin-audit-v1", "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "root": str(root), "complete": len(records) == 433 and not failures and not pending,
            "available_only": available_only, "verified": len(records), "origin_counts": dict(Counter(r["origin"] for r in records)), "expected": 433,
            "pending_count": len(pending), "pending": pending, "failures": failures, "records": records,
            "pinned_code_manifest_sha256": digest(pinned_path), "reuse_manifest_sha256": digest(reuse_path),
            "interpretation": "Exactly 415 corrected runs plus 18 unchanged ECG-only historical runs; neither quarantine nor partial families are eligible for final statistics."}


def build_view(report, view):
    require(report["complete"] and not report["available_only"], "Only a complete full audit can create the analysis view")
    require(not view.exists(), "Use a fresh analysis view; existing directories are never replaced")
    for row in report["records"]:
        parent = view / relative_json(row["job"]).parent
        parent.mkdir(parents=True, exist_ok=True)
        for f in row["files"]:
            # Real directories and file symlinks allow ordinary Path.rglob safely.
            (parent / Path(f["path"]).name).symlink_to(Path(f["path"]))
    atomic_json(view / "origin_audit.json", report)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--available-only", action="store_true")
    p.add_argument("--create-view", type=Path)
    a = p.parse_args()
    require(not (a.available_only and a.create_view), "available-only cannot create a statistical view")
    report = audit(a.root, a.available_only)
    atomic_json(a.output, report)
    print(json.dumps({k: report[k] for k in ["complete", "verified", "origin_counts", "pending_count", "failures"]}, indent=2))
    if report["failures"] or (not a.available_only and not report["complete"]):
        raise SystemExit(2)
    if a.create_view:
        build_view(report, a.create_view.resolve())


if __name__ == "__main__":
    main()
