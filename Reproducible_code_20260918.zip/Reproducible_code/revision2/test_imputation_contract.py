"""Synthetic unit checks only: no scientific data, model, or GPU experiment."""
from pathlib import Path
import sys,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'code'))
from revision2_provenance import fit_medians,transform,record_ids
raw=np.array([[1.,2.],[3.,np.nan],[100.,200.],[np.nan,10000.]])
med=fit_medians(raw,[0,1]);assert np.array_equal(med,[2.,2.])
changed=raw.copy();changed[2:]=999999;assert np.array_equal(med,fit_medians(changed,[0,1]))
strict=fit_medians(raw,[0]);assert np.array_equal(strict,[1.,2.])
out=transform(raw,med,np.ones(4,dtype=bool));assert out[1,1]==2 and out[3,0]==2
assert np.isnan(raw[1,1]) and out[3,1]==10000
try:fit_medians(np.full((2,2),np.nan),[0]);raise AssertionError('Must reject empty finite support')
except ValueError:pass
import pandas as pd,io
from types import SimpleNamespace
adapter=SimpleNamespace(metadata=pd.DataFrame({'record_id':['001','002','003']}),valid=np.ones(3,dtype=bool))
ids=record_ids(adapter,[2,0]);assert ids.dtype.kind=='U' and ids.tolist()==['003','001']
buffer=io.BytesIO();np.savez_compressed(buffer,record_ids=ids);buffer.seek(0)
with np.load(buffer,allow_pickle=False) as saved:assert saved['record_ids'].tolist()==['003','001']
print('PASS: held-out invariance, purged-fit distinction, frozen transform, raw missingness, empty-support guard, pickle-free record ID roundtrip')
