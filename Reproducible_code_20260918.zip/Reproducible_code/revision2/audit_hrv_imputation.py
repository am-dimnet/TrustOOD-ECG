#!/usr/bin/env python3
"""Independently recompute training-only HRV provenance from saved raw arrays.

No feature extraction, inference, or training is performed. All protocol splits,
medians, missing masks and frozen transforms are checked against saved outputs.
"""
from pathlib import Path
from collections import Counter
from functools import lru_cache
import argparse
import csv
import datetime
import hashlib
import json
import numpy as np
import pandas as pd

REMOTE = Path('/root/autodl-tmp/Paper46_revision2')
DESCRIPTORS = ['HR', 'meanRR', 'SDNN', 'RMSSD', 'pNN50', 'CVRR', 'RR_range', 'RR_median']


def require(value, message):
    if not value:
        raise ValueError(message)


@lru_cache(maxsize=None)
def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backup-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    a = parser.parse_args()
    root, out = a.backup_root.resolve(), a.output.resolve()
    require(not out.exists(), 'Use a fresh evidence directory')
    inputs = {}

    def checked(path, expected=None):
        path = Path(path)
        require(path.resolve().is_relative_to(root), 'Input escapes backup root')
        sha = digest(path.resolve())
        if expected is not None:
            require(sha == expected, 'Input hash mismatch: ' + str(path))
        inputs[str(path.relative_to(root))] = {'sha256': sha, 'bytes': path.stat().st_size}
        return path

    metadata = {}
    valid = {}
    for name in ['ptbxl', 'chapman']:
        metadata[name] = pd.read_csv(checked(root/'source_sidecars'/f'{name}_metadata.csv'),
                                     dtype={'record_id': str})
        v = metadata[name]['valid'].astype(str).str.lower()
        require(set(v).issubset({'true', 'false'}), 'Invalid boolean metadata')
        valid[name] = v.eq('true').to_numpy()
        require(np.array_equal(metadata[name].raw_index, np.arange(len(v))), 'Metadata row order')
        require(metadata[name].record_id[valid[name]].is_unique, 'Duplicate record IDs')
    meta = metadata['ptbxl']
    folds = meta.strat_fold.to_numpy(dtype=int)
    require(set(folds[valid['ptbxl']]).issubset(set(range(1, 11))), 'Fold range')
    closed = {k: np.flatnonzero(valid['ptbxl'] & mask) for k, mask in
              [('train', np.isin(folds, np.arange(1, 9))), ('val', folds == 9), ('test', folds == 10)]}
    patients = {k: set(meta.patient_id.iloc[ix]) for k, ix in closed.items()}
    require(not (patients['train'] & patients['val'] or patients['train'] & patients['test']
                 or patients['val'] & patients['test']), 'Patient leakage between official splits')
    labels = json.loads(checked(root/'source_sidecars/ptbxl_labels.json').read_text())
    codes = [json.loads(x) for x in checked(root/'source_sidecars/ptbxl_raw_scp_codes.jsonl').read_text().splitlines()]
    require(len(codes) == len(meta), 'Raw-code row count')
    for i, row in enumerate(codes):
        require(row['raw_index'] == i and str(row['ecg_id']) == meta.record_id.iloc[i], 'Raw-code record order')
        require(set(row['codes']) == set(row['scores']), 'Raw-code presence mismatch')
    presence = Counter(c for i in closed['train'] for c in set(codes[i]['codes']))
    require(dict(presence) == labels['trainfold_code_presence_counts'], 'Training code presence')
    baseline = set(labels['baseline_codes'])
    require(baseline == {'NORM', 'SR'}, 'Baseline code definition')
    all_codes = set().union(*(set(x['codes']) for x in codes)) - baseline
    split_sets, strict_details = {'closed': closed}, {}
    for tau in [40, 80, 160]:
        held = {c for c in all_codes if presence[c] < tau}
        has_held = np.array([bool(set(x['codes']) & held) for x in codes])
        has_known = np.array([bool(set(x['codes']) & (all_codes - held)) for x in codes])
        split = {}
        for name, ix in closed.items():
            split[name + '_id'] = ix[~has_held[ix]]
            split['test_ood' if name == 'test' else name + '_purged'] = ix[has_held[ix]]
        ix = split['test_ood']
        split['test_ood_pure'] = ix[~has_known[ix]]
        split['test_ood_mixed'] = ix[has_known[ix]]
        with np.load(checked(root/'source_sidecars'/f'ptbxl_strict_ood_tau{tau}.npz'), allow_pickle=False) as saved:
            require(set(saved.files) == set(split), 'Strict split keys')
            for name, ix in split.items():
                require(np.array_equal(ix, saved[name]), f'Strict split differs: {tau} {name}')
        key = f'strict_tau{tau}'
        split_sets[key] = {name: split[name + '_id'] for name in ['train', 'val', 'test']}
        split_sets[key].update({'ood': split['test_ood'], 'ood_pure': split['test_ood_pure'],
                                'ood_mixed': split['test_ood_mixed'], 'train_purged': split['train_purged'],
                                'val_purged': split['val_purged']})
        strict_details[key] = {'heldout_codes': sorted(held), 'counts': {k: len(v) for k, v in split.items()}}

    median_rows, missing_rows, protocols = [], [], []
    for key, partitions in split_sets.items():
        manifest_path = checked(root/'cache'/key/'training_only_hrv_manifest.json')
        m = json.loads(manifest_path.read_text())
        require(m['schema'] == 'paper46-revision2-training-only-hrv-v1' and m['protocol'] == key, 'Protocol/schema')
        checked(root/'server_preparation/prepare_training_only_cache.py', m['preparation_sha256'])
        require(m['descriptor_names'] == DESCRIPTORS, 'Descriptor order')
        for entry in m['verified_inputs']:
            checked(root/Path(entry['path']).relative_to(REMOTE), entry['sha256'])
        require(np.array_equal(m['train_indices'], partitions['train']), 'Imputer training indices')
        require(m['train_record_ids'] == meta.record_id.iloc[partitions['train']].tolist(), 'Imputer training record IDs')
        raw = {}
        for name, entry in m['raw_hrv'].items():
            raw_path = checked(root/Path(entry['path']).relative_to(REMOTE), entry['sha256'])
            raw[name] = np.load(raw_path, allow_pickle=False)
            require(raw[name].shape == (len(metadata[name]), 8) and raw[name].dtype == np.float32, 'Raw HRV dimensions/type')
            mask = np.load(checked(raw_path.with_name(f'{name}_missing_mask.npy')), allow_pickle=False)
            require(mask.dtype == bool and np.array_equal(mask, ~np.isfinite(raw[name])), 'Saved missing mask differs')
        train = raw['ptbxl'][partitions['train']]
        # Independent finite-value order statistics; does not call the fit helper.
        medians = []
        for j in range(8):
            finite = np.sort(train[np.isfinite(train[:, j]), j])
            require(len(finite) > 0, 'No finite training descriptor values')
            n = len(finite)
            medians.append(finite[n//2] if n % 2 else np.mean(finite[n//2-1:n//2+1], dtype=np.float32))
        medians = np.asarray(medians, dtype=np.float32)
        require(np.array_equal(medians.astype(float), m['medians']), 'Training-only medians differ')
        for j, name in enumerate(DESCRIPTORS):
            median_rows.append({'protocol': key, 'descriptor': name, 'training_median': float(medians[j]),
                                'finite_training_values': int(np.isfinite(train[:, j]).sum()),
                                'eligible_training_records': len(train)})

        for name, x in raw.items():
            expected = x.copy()
            selected = expected[valid[name]]
            selected = np.where(np.isfinite(selected), selected, medians)
            expected[valid[name]] = selected
            expected[~valid[name]] = np.nan
            entry = m['outputs'][name]
            actual = np.load(checked(manifest_path.parent/entry['filename'], entry['sha256']), allow_pickle=False)
            require(actual.dtype == np.float32 and np.array_equal(actual, expected, equal_nan=True), 'Frozen transform differs: ' + name)
            require(np.isfinite(actual[valid[name]]).all() and np.isnan(actual[~valid[name]]).all(), 'Transformed validity')

        groups = [('ptbxl', 'all_valid', np.flatnonzero(valid['ptbxl']), 'ptbxl')]
        groups += [('ptbxl', split, ix, 'ptb_' + split) for split, ix in partitions.items()]
        if 'chapman' in raw:
            groups.append(('chapman', 'external_valid', np.flatnonzero(valid['chapman']), 'chapman'))
        for dataset, split, ix, manifest_key in groups:
            missing = ~np.isfinite(raw[dataset][ix])
            count = {'missing_by_descriptor': missing.sum(0).tolist(), 'affected_records': int(missing.any(1).sum())}
            if manifest_key in m['counts']:
                require(m['counts'][manifest_key] == count, 'Saved missing count differs: ' + manifest_key)
            missing_rows.append({'protocol': key, 'dataset': dataset, 'split': split, 'n_records': len(ix),
                                 'affected_records': count['affected_records'],
                                 'affected_percent': 100 * count['affected_records'] / len(ix) if len(ix) else None,
                                 'missing_values': int(missing.sum()),
                                 **{f'missing_{name}': count['missing_by_descriptor'][j] for j, name in enumerate(DESCRIPTORS)}})
        protocols.append({'protocol': key, 'manifest_sha256': digest(manifest_path),
                          'train_record_count': len(partitions['train']), 'medians': medians.tolist(),
                          'raw_datasets': list(raw), 'all_checks_passed': True})

    out.mkdir(parents=True)
    for name, rows in [('hrv_training_medians.csv', median_rows), ('hrv_missing_counts.csv', missing_rows)]:
        with (out/name).open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    report = {'schema': 'paper46-independent-hrv-audit-v1', 'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'complete': True, 'backup_root': str(root), 'protocols': protocols, 'strict_reconstruction': strict_details,
              'inputs': inputs, 'script_sha256': digest(Path(__file__).resolve()),
              'generated_outputs': {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size} for p in out.glob('*.csv')},
              'scope': 'Existing raw arrays and outputs only. No training, feature extraction or model inference. This proves preprocessing consistency, not completion of the 415-run experiment matrix.'}
    (out/'audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'complete': True, 'protocols': len(protocols), 'median_rows': len(median_rows),
                      'missing_count_rows': len(missing_rows), 'input_files': len(inputs)}, indent=2))


if __name__ == '__main__':
    main()
