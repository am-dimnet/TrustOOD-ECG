#!/usr/bin/env python3
"""Check saved model/state archives without training or model inference.

Only files bound to a successful provenance report are deserialized. Every
network is constructed on CPU and loaded strictly; no forward pass is run.
"""
from pathlib import Path
from collections import Counter
from dataclasses import asdict, is_dataclass, fields
import argparse
import datetime
import gc
import json
import sys
import zipfile

from audit_revision2_provenance import digest, object_digest, require, atomic_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--origin-report', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--available-only', action='store_true')
    a = p.parse_args()
    require(not a.output.exists(), 'Preserve previous audits; use a new output path')
    report = json.loads(a.origin_report.read_text())
    require(not report['failures'], 'Upstream provenance audit has failures')
    if not a.available_only:
        require(report['complete'] and not report['available_only'] and len(report['records']) == 433,
                'Final state audit requires full 433-run provenance')
    root = Path(report['root']).resolve()
    code = root/'server_preparation/code'
    pinned = json.loads((root/'environment/deployed_code_attempt2.json').read_text())['files']
    for name in ['run_ptbxl_revision.py', 'run_ptbxl_missing_extensions.py', 'revisionlib.py',
                 'data_adapter.py', 'revision2_provenance.py']:
        require(digest(code/name) == pinned['server_preparation/code/'+name], 'Executed code changed')
    sys.path.insert(0, str(code))
    import numpy as np
    import pandas as pd
    import torch
    import run_ptbxl_revision as B
    import run_ptbxl_missing_extensions as E
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    record_ids = pd.read_csv(root/'source_sidecars/ptbxl_metadata.csv', dtype={'record_id': str}).record_id.to_numpy()

    def state_arrays(value):
        if isinstance(value, np.ndarray):
            require(value.dtype.kind != 'O', 'Object array in fitted state')
            if value.dtype.kind in 'fc':
                require(np.isfinite(value).all(), 'Nonfinite fitted array')
            return 1
        if torch.is_tensor(value):
            require(torch.isfinite(value).all().item(), 'Nonfinite fitted tensor')
            return 1
        if is_dataclass(value):
            return sum(state_arrays(getattr(value, x.name)) for x in fields(value))
        if isinstance(value, dict):
            return sum(state_arrays(x) for x in value.values())
        if isinstance(value, (list, tuple)):
            return sum(state_arrays(x) for x in value)
        if isinstance(value, (float, np.floating)):
            require(np.isfinite(value), 'Nonfinite fitted scalar')
        return 0

    checked, failures = [], []
    rows = [x for x in report['records'] if x['origin'] == 'corrected_training_only_hrv_attempt2']
    for row in rows:
        try:
            paths = {f['role']: f for f in row['files']}
            for role in ['json', 'fitted_state', 'raw_npz']:
                f = paths[role]; path = Path(f['path'])
                require(path.resolve().is_relative_to(root), 'Archive outside source root')
                require(path.stat().st_size == f['bytes'] and digest(path) == f['sha256'], 'Source file differs: '+role)
            m = json.loads(Path(paths['json']['path']).read_text())
            state_path = Path(paths['fitted_state']['path'])
            with zipfile.ZipFile(state_path) as z:
                require(z.testzip() is None, 'Archive CRC failed')
            # These are our own hash-verified outputs. Dataclass/NumPy density
            # objects require full trusted deserialization, not weights-only.
            s = torch.load(state_path, map_location='cpu', weights_only=False)
            require(s['schema'] == 'paper46-revision2-training-only-hrv-v1', 'State schema')
            require(object_digest(s['run_definition']) == m['run_fingerprint'] == row['run_fingerprint'], 'State fingerprint')
            require(s['model_plan'] == m['model'], 'Saved model plan')
            require(list(s['class_names']) == m['class_names'], 'Class order')
            require(s['imputation'] == m['split']['hrv_imputation_manifest'], 'Imputation linkage')
            require(B.jsonable(s['calibration_and_metrics']) == m['diagnosis'], 'Calibration/diagnosis linkage')
            mod = E if row['job']['family'] == 'extensions' else B
            plan = mod.parse_model_plan(row['job']['model'])
            require(asdict(plan) == m['model'], 'Reconstructed model plan')
            members = m['environment']['arguments']['ensemble_members'] if plan.family == 'ensemble' else 1
            require(len(s['state_dicts']) == members, 'Missing ensemble/member states')
            parameter_total = parameter_trainable = tensor_count = 0
            for state in s['state_dicts']:
                model = mod.build_model(plan, m['n_classes']).cpu()
                model.load_state_dict(state, strict=True)
                counts = B.parameter_count(model)
                parameter_total += counts['total']; parameter_trainable += counts['trainable']
                tensor_count += state_arrays(state)
                del model
            require(parameter_total == m['parameter_count']['total'], 'Total parameter count')
            require(parameter_trainable == m['parameter_count']['trainable'], 'Trainable parameter count')
            imputer = json.loads((root/'cache'/s['imputation']['protocol']/'training_only_hrv_manifest.json').read_text())
            require(np.array_equal(s['train_index'], imputer['train_indices']), 'State training indices')
            with np.load(paths['raw_npz']['path'], allow_pickle=False) as raw:
                for split in ['train', 'val', 'test']:
                    require(np.array_equal(record_ids[np.asarray(s[split+'_index'])], raw[split+'_record_id']), 'State/record alignment: '+split)
            fitted = s['density_and_posthoc_states']
            expected = {'posthoc'} if plan.family == 'softmax' else (set() if plan.family in ['matched_concat', 'ensemble'] else {'source_density'})
            require(set(fitted) == expected, 'Missing/unexpected density or posthoc state')
            n_arrays = state_arrays(fitted)
            checked.append({'job': row['job'], 'path': str(state_path), 'bytes': paths['fitted_state']['bytes'],
                            'sha256': paths['fitted_state']['sha256'], 'run_fingerprint': m['run_fingerprint'],
                            'members': members, 'network_tensors': tensor_count, 'parameter_total': parameter_total,
                            'fitted_arrays': n_arrays, 'fitted_sections': sorted(fitted), 'strict_cpu_load': True,
                            'zip_crc_passed': True})
            del s
            gc.collect()
        except Exception as exc:
            failures.append({'job': row['job'], 'error': f'{type(exc).__name__}: {exc}'})
    result = {'schema': 'paper46-fitted-state-archive-audit-v1',
              'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'complete': not a.available_only and len(checked) == 415 and not failures,
              'available_only': a.available_only, 'verified': len(checked), 'expected': 415,
              'family_counts': dict(Counter(x['job']['family'] for x in checked)),
              'origin_report': str(a.origin_report.resolve()), 'origin_report_sha256': digest(a.origin_report),
              'auditor_sha256': digest(Path(__file__).resolve()), 'records': checked, 'failures': failures,
              'model_training_or_inference': False,
              'scope': 'CRC, trusted deserialization, strict CPU state loading, full member count, finite model/fitted arrays and source/calibration/record linkage. No forward passes or replacement metrics.'}
    atomic_json(a.output, result)
    print(json.dumps({k: result[k] for k in ['complete', 'available_only', 'verified', 'family_counts', 'failures']}, indent=2))
    if failures or (not a.available_only and not result['complete']):
        raise SystemExit(2)


if __name__ == '__main__':
    main()
