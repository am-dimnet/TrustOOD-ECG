#!/usr/bin/env python3
"""Guarded post-training analysis; dry-run by default, no model training.

Execute only after all 415 new runs and 18 approved historical runs are ready.
Produces the formal and extension summaries, Reviewer 6 tables and the PTB
modular analysis. Independent noise/wearable integration, figures and manuscript
updates remain separate downstream work and are never labelled complete here.
"""
from pathlib import Path
import argparse
import datetime
import json
import os
import subprocess
import sys

from audit_revision2_provenance import audit, atomic_json, build_view, digest, require

HERE = Path(__file__).resolve().parent


def commands(root, output):
    py = sys.executable
    return [
        ("fitted_states", [py, str(HERE / "audit_fitted_state_archives.py"),
                           "--origin-report", str(output / "origin_full.json"),
                           "--output", str(output / "fitted_state_full.json")]),
        ("formal_212", [py, str(HERE / "code/aggregate_results.py"), str(output / "inputs/formal"),
                        "--output-dir", str(output / "formal"), "--expected-config", str(output / "expected_formal.json"),
                        "--bootstrap", "2000", "--fail-on-incomplete"]),
        ("extensions_221", [py, str(HERE / "audit_revision2_extensions.py"),
                            "--origin-report", str(output / "origin_full.json"), "--output", str(output / "promised_extensions")]),
        ("reviewer6", [py, str(HERE / "derive_reviewer6_tables.py"), "--results", str(root / "results"),
                       "--output", str(output / "reviewer6")]),
        ("modular_ptb", [py, str(HERE / "code/evaluate_modular_pipeline.py"), "--mode", "ptb",
                         "--ptb-seeds", "7,13,42,99,2026", "--ptb-results-dir", str(root / "results/formal"),
                         "--cache-dir", str(root / "cache"), "--trustfed-cache", str(root / "wave_cache"),
                         "--cache-provenance-root", str(root), "--experiment-dir", str(HERE / "code"),
                         "--device", "cpu", "--output-dir", str(output / "modular_pipeline")]),
    ]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--scope", choices=("core", "array-statistics", "server-modular"), default="core",
                   help="Split server-dependent modular evaluation from local array statistics; all scopes require the full matrix")
    p.add_argument("--execute", action="store_true")
    a = p.parse_args()
    root, output = a.root.resolve(), a.output.resolve()
    plan = commands(root, output)
    if a.scope == "array-statistics":
        plan = [(name, cmd) for name, cmd in plan if name not in ("modular_ptb", "fitted_states")]
    elif a.scope == "server-modular":
        plan = [(name, cmd) for name, cmd in plan if name in ("fitted_states", "modular_ptb")]
    if not a.execute:
        print(json.dumps({"execute": False, "required_new_runs": 415, "required_historical_ECG_only_runs": 18,
                          "scope": a.scope, "patient_bootstrap": 2000, "commands": plan,
                          "remaining_after_core": ["independent noise/wearable integration", "modular mathematical audit", "figures", "response and manuscript", "38-item consistency and layout QA"]}, indent=2))
        return
    require(not output.exists(), "Use a fresh output directory; previous analysis attempts are preserved")
    require(not output.is_relative_to(root / "results") and not output.is_relative_to(root / "reused_ecg_only"), "Analysis output must be separate from input results")
    env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}
    # Full raw-array integrity and full provenance must both pass before statistics.
    subprocess.run([sys.executable, str(HERE / "check_completed_outputs.py"), str(root / "results"), "--stage", "all"], env=env, check=True)
    report = audit(root, available_only=False)
    require(report["complete"] and not report["failures"], "Full 433-run provenance audit failed")
    output.mkdir(parents=True)
    atomic_json(output / "origin_full.json", report)
    build_view(report, output / "inputs")
    config_path = HERE / "configs/expected_ptbxl_results.json"
    config = json.loads(config_path.read_text())
    require(config["require_uniform_code_hashes"] is True, "Unexpected original code policy")
    # Each new origin and historical allowlisted origin was already checked
    # against exact immutable hashes. They legitimately have different hashes.
    config["require_uniform_code_hashes"] = False
    config["revision2_origin_policy"] = {
        "replacement_for_global_uniform_code_hash": "exact per-origin checks in full provenance audit",
        "formal_origin_counts": {"corrected_training_only_hrv_attempt2": 203, "historical_ecg_only_unchanged": 9},
        "origin_report": str(output / "origin_full.json"), "origin_report_sha256": digest(output / "origin_full.json"),
        "original_expected_config_sha256": digest(config_path),
        "all_other_matrix_configuration_and_statistical_contracts_unchanged": True,
    }
    require(sum(r["job"]["family"] == "formal" and r["job"]["action"] == "retrain" for r in report["records"]) == 203, "Formal origin count")
    atomic_json(output / "expected_formal.json", config)
    code = {str(path.relative_to(HERE)): digest(path) for path in HERE.rglob("*.py")}
    atomic_json(output / "analysis_code_manifest.json", code)
    (output / "logs").mkdir()
    state = {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "state": "running", "completed": [], "scope": a.scope}
    atomic_json(output / "status.json", state)
    for stage, command in plan:
        atomic_json(output / "logs" / (stage + ".command.json"), {"command": command})
        with (output / "logs" / (stage + ".log")).open("w") as log:
            proc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env)
        (output / "logs" / (stage + ".exit")).write_text(str(proc.returncode) + "\n")
        if proc.returncode:
            state.update(state="failed", failed_stage=stage, exit_code=proc.returncode)
            atomic_json(output / "status.json", state)
            raise SystemExit(proc.returncode)
        state["completed"].append(stage)
        atomic_json(output / "status.json", state)
    remaining = ["noise/wearable integration", "modular mathematical audit", "figures", "manuscript and response", "consistency and layout QA"]
    if a.scope == "array-statistics":
        remaining.insert(0, "separately verified server-modular output")
    elif a.scope == "server-modular":
        remaining.insert(0, "local formal/extension/Reviewer6 array statistics")
    state.update(state=a.scope.replace("-", "_") + "_complete", completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 remaining=remaining)
    atomic_json(output / "status.json", state)
    print(json.dumps(state, indent=2))


if __name__ == "__main__":
    main()
