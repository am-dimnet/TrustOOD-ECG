"""Redraw checked frozen aggregate tables; does not redo scientific auditing."""
from pathlib import Path
import argparse,hashlib,json,sys,subprocess
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
subprocess.run([sys.executable,str(root/'verify_package.py')],check=True)
assert not a.output.exists(),'Use a fresh output directory'
sys.path.insert(0,str(root/'revision2/code'))
import generate_manuscript_figures as g
a.output.mkdir(parents=True)
agg=root/'reference_outputs/aggregates'
def read(folder,name):return g.read_csv(agg/folder/name)
seed=read('ptbxl','seed_summary.csv');ood=read('ptbxl','ood_summary.csv')
g.fig_main_compare(seed,a.output)
g.fig_rare_scatter(read('ptbxl','classwise_summary.csv'),g.read_csv(root/'reference_outputs/manuscript_tables/Supplementary_Class_Distributions.csv'),a.output)
g.fig_ablation(seed,read('promised_extensions','summary.csv'),a.output)
g.fig_ood_openset(ood,a.output)
g.fig_ood_effects(read('promised_postprocess','ood_paired_seed.csv'),a.output)
g.fig_calibration(read('ptbxl','calibration_summary.csv'),a.output)
g.fig_risk_coverage(read('promised_postprocess','selective_seed_summary.csv'),a.output)
g.fig_noise(read('auxiliary','noise_summary.csv'),read('noise_shift_calibration_audit','calibration_metrics.csv'),a.output)
g.fig_source_weights(read('noise_gate_extensions','summary_aggregate.csv'),a.output)
g.fig_multimodal(read('auxiliary','wearable_summary.csv'),a.output)
g.fig_generalization(ood,read('promised_postprocess','ood_alert_seed_summary.csv'),a.output)
files=[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(a.output.glob('*.pdf'))]
assert len(files)==11
(a.output/'frozen_replot_manifest.json').write_text(json.dumps({'scope':'visual regeneration from checksum-verified frozen aggregates; not raw-array recomputation or a new provenance audit','source_origin_sha256':json.loads((root/'provenance.json').read_text())['origin_report_sha256'],'figures':files},indent=2)+'\n')
