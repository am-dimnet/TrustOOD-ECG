"""Print all fresh-run commands. No training or subprocess is executed."""
from pathlib import Path
import argparse,json,shlex,sys
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--cache-root',required=True,type=Path);p.add_argument('--wave-cache',required=True,type=Path)
p.add_argument('--output',required=True,type=Path);p.add_argument('--python',default=sys.executable)
a=p.parse_args();jobs=json.loads((root/'revision2/configs/jobs.json').read_text());assert len(jobs)==433
for j in jobs:
    script='run_ptbxl_revision.py' if j['family']=='formal' else 'run_ptbxl_missing_extensions.py'
    protocol='closed' if j['protocol']=='closed' else 'strict_tau'+str(j['tau'])
    command=[a.python,str(root/'revision2/code'/script),'--protocol',j['protocol'],'--models',j['model'],'--seed',str(j['seed']),'--tau',str(j['tau']),'--epochs','40','--batch-size','256','--eval-batch-size','512','--learning-rate','0.001','--ensemble-members','5','--rare-threshold','50','--bootstrap','0','--device','cuda','--cache-dir',str(a.cache_root/protocol),'--trustfed-cache',str(a.wave_cache),'--results-dir',str(a.output/j['family'])]
    if j['protocol']=='closed':command.append('--cross-dataset')
    print('# Published origin: '+j['action']+'; this command performs a NEW run')
    print(shlex.join(command))
